@objc class MONGoogleAnalytics {
  class func initializeTracker() {
    let bundleIdentifier = NSBundle.mainBundle().bundleIdentifier
    let configurationPlistPath = NSBundle.mainBundle().pathForResource("GoogleAnalyticsConfiguration", ofType: "plist")

    let gai = GAI.sharedInstance()
    gai.trackUncaughtExceptions = true
    gai.dispatchInterval = 20

    if let configurationForEnvironment = NSDictionary(contentsOfFile: configurationPlistPath!)?.objectForKey(bundleIdentifier!) as? NSDictionary {
      let gaiKey = configurationForEnvironment.objectForKey("gaiKey") as String
      let logLevel = configurationForEnvironment.objectForKey("logLevel") as String
      gai.trackerWithTrackingId(gaiKey)
      gai.logger.logLevel = getLogLevel(logLevel)
    }
  }

  class func trackView(screenNameValue: String) {
    let tracker = GAI.sharedInstance().defaultTracker
    tracker.set(kGAIScreenName, value:screenNameValue)
    tracker.send(GAIDictionaryBuilder.createScreenView().build())
  }
    class func trackEvent(aCategory: String, anAction: String, aLabel: String) {
        let tracker = GAI.sharedInstance().defaultTracker
        
        tracker.send(GAIDictionaryBuilder.createEventWithCategory(aCategory, action: anAction, label: aLabel, value: nil).build())
    }

  private class func getLogLevel(logLevel: String) -> GAILogLevel {
    switch logLevel {
    case "None":
      return GAILogLevel.None
    case "Error":
      return GAILogLevel.Error
    case "Warning":
      return GAILogLevel.Warning
    case "Info":
      return GAILogLevel.Info
    case "Verbose":
      return GAILogLevel.Verbose
    default:
      return GAILogLevel.Error
    }
  }
}