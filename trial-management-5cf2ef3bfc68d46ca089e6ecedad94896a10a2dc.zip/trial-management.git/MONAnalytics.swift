import UIKit

private enum MONAnalyticsEvent: String {
    case FullSync = "FULL_SYNC"
    case ButtonSync = "BUTTON_SYNC"
    case DeltaSync = "DELTA_SYNC"
    case TrialsSync = "NUMBER_OF_TRIALS_SYNCED"
    case ChangesDetected = "CHANGES_DETECTED_ON_TRIAL"
    case SaveTrial = "SAVE_TRIAL"
}

class MONAnalytics: NSObject {

    private override init() {
        super.init()
        let bundleIdentifier = NSBundle.mainBundle().bundleIdentifier
        let flurryConfigPlistPath = NSBundle.mainBundle().pathForResource("FlurryConfig", ofType: "plist")
        if let flurryConfigForEnvironment = NSDictionary(contentsOfFile: flurryConfigPlistPath!)?.objectForKey(bundleIdentifier!) as? NSDictionary {
            let flurryApiKey = flurryConfigForEnvironment.objectForKey("flurryApiKey") as String
            Flurry.startSession(flurryApiKey)
        }
    }
    
    class var EventFullSync: String { return MONAnalyticsEvent.FullSync.rawValue }
    
    class var EventButtonSync: String { return MONAnalyticsEvent.ButtonSync.rawValue }
    
    class var EventDeltaSync: String { return MONAnalyticsEvent.DeltaSync.rawValue }
    
    class var EventTrialsSync: String { return MONAnalyticsEvent.TrialsSync.rawValue }
    
    class var EventChangesDetected: String { return MONAnalyticsEvent.ChangesDetected.rawValue }
    
    class var EventSaveTrial: String { return MONAnalyticsEvent.SaveTrial.rawValue }
    
    class func startAnalyticsSession() {
        MONAnalytics()
    }
    
    class func logEvent(eventName: String, parameters: NSDictionary?, timed: Bool) {
        Flurry.logEvent(eventName, withParameters: parameters, timed: timed)
    }
    
    class func logEvent(eventName: String, timed: Bool) {
        Flurry.logEvent(eventName, timed: timed)
    }
    
    class func endTimedEvent(eventName: String, parameters: NSDictionary?) {
        Flurry.endTimedEvent(eventName, withParameters: parameters)
    }
    
    class func logError(errorName: String, message: String?, error: NSError?) {
        Flurry.logError(errorName, message: message, error: error)
    }
}
