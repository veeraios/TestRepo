import UIKit

protocol MONDisclosureViewDelegate {
    func criteriaSelected()
}

class MONDisclosureView: UIView, UITableViewDelegate, UITableViewDataSource {
    private let criteriaTableView: UITableView
    private let selectedCriteria: String
    private let rowHeight: CGFloat = 50
    
    var selectedCell: UITableViewCell?
    var disclosureViewDelegate: MONDisclosureViewDelegate?
    
    
    init(selectedCriteria:String) {
        self.selectedCriteria = selectedCriteria
        
        criteriaTableView = UITableView()
        criteriaTableView.allowsSelection = true
        criteriaTableView.registerClass(UITableViewCell.self, forCellReuseIdentifier: "CellIdentifier")
        
        super.init(frame: CGRectZero)
        
        criteriaTableView.delegate = self
        criteriaTableView.dataSource = self
        
        addSubview(criteriaTableView)
    }
    
    required init(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        criteriaTableView.sizeToFit()
        criteriaTableView.frame = CGRectMake(0.0, 0.0, CGRectGetWidth(frame), rowHeight)
    }
    
    func updateSelectedValue(selectedValue: String) {
        selectedCell?.textLabel?.text = selectedValue
    }
    
    //MARK: - UITableViewDataSource delegate methods
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        var cell = tableView.dequeueReusableCellWithIdentifier("CellIdentifier", forIndexPath:indexPath) as UITableViewCell
        cell.textLabel!.text = selectedCriteria
        cell.textLabel!.font = UIFont(name: OpenSansLight, size: 20)
        cell.accessoryType = UITableViewCellAccessoryType.DisclosureIndicator
        cell.selectionStyle = UITableViewCellSelectionStyle.None
        cell.backgroundColor = UIColor(forThemeComponentType: MONThemeComponentTypeBackground)
        
        return cell
    }
    
    //MARK: - UITableViewDelegate delegate methods
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return rowHeight
    }
    
    func tableView(tableView: UITableView, willDisplayCell cell: UITableViewCell, forRowAtIndexPath indexPath: NSIndexPath) {
        cell.separatorInset = UIEdgeInsetsZero
        cell.preservesSuperviewLayoutMargins = false
        cell.layoutMargins = UIEdgeInsetsZero
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        selectedCell = tableView.cellForRowAtIndexPath(indexPath)
        disclosureViewDelegate?.criteriaSelected()
    }
}
