#import "TMEditTrialEntriesViewController.h"
#import "TMEditTrialEntriesView.h"
#import "LXReorderableCollectionViewFlowLayout.h"
#import "TMEntryCollectionViewCell.h"
#import "TMAddEntriesViewController.h"
#import "MONDimensions.h"
#import "TMTreatmentModel.h"
#import "MONPopoverTableViewController.h"
#import "TMWorkingUnitOfWork.h"
#import "MONButton.h"
#import "NSArray+TMSortArray.h"
#import "UIImage+MONThemeImageProvider.h"
#import "TMTabNameConstants.h"
#import "TMReplaceEntryViewController.h"
#import "TMReplaceEntryModel.h"
#import "TMReplaceEntryNavigationController.h"
#import "NSManagedObject+MONCascadeDelete.h"
#import "TrialManagement-Swift.h"

@interface TMEditTrialEntriesViewController ()<UICollectionViewDataSource, UICollectionViewDelegate, UIPopoverControllerDelegate, UIAlertViewDelegate, ESCObservableInternal, LXReorderableCollectionViewDelegateFlowLayout, TMEntryCollectionViewCellDelegate, MONPopoverTableViewControllerObserver, TMReplaceEntryNavigationControllerDelegate>

@property (nonatomic) UICollectionView *entriesCollectionView;
@property (nonatomic) LXReorderableCollectionViewFlowLayout *collectionViewFlowLayout;
@property (nonatomic) TMEditTrialEntriesView *entriesView;
@property (nonatomic) TMSelectedEntriesModel *selectedEntriesModel;
@property (nonatomic) NSIndexPath *currentlyDraggedCellIndexPath;
@property (nonatomic) UIPopoverController *cellPopoverController;
@property (nonatomic) TMTreatmentModel *treatmentPopoverModel;
@property (nonatomic) TMEntryCollectionViewCell *activeCell;
@property (nonatomic) UIButton *addEntriesButton;
@property (nonatomic) UIButton *applyTreatmentButton;
@property (nonatomic) TMSelectedEntriesModel *addEntriesSelectedEntriesModel;
@property (nonatomic) MONButton *continueButton;
@property (nonatomic) TMTrialModel *trialModel;
@property (nonatomic) NSIndexPath *selectedEntryToDeletePath;
@property (nonatomic) TMAddEntriesViewController *addEntriesViewController;

@end

@implementation TMEditTrialEntriesViewController

@synthesize tabSettingsObject = _tabSettingsObject;

- (instancetype)initWithTrialModel:(TMTrialModel *)trialModel {
	self = [super initWithTrialModel:trialModel theClass:[self class]];
	if (self) {
		self.trialModel = trialModel;
		
		self.selectedEntriesModel = [[TMSelectedEntriesModel alloc] init];
		
		[self.selectedEntriesModel addObjects:[[self.trialModel.entries allObjects] sortByKeyPath:@"number"]];
	}
	return self;
}  

- (void)viewDidLoad {
    [super viewDidLoad];

	self.view.autoresizesSubviews = YES;
	
	//todo: create TMEditTrialEntriesModel
	
	self.collectionViewFlowLayout = [[LXReorderableCollectionViewFlowLayout alloc] init];
	self.collectionViewFlowLayout.minimumInteritemSpacing = 0;
	[self.collectionViewFlowLayout setScrollDirection:UICollectionViewScrollDirectionVertical];
	
	self.entriesCollectionView = [[UICollectionView alloc] initWithFrame:self.view.bounds collectionViewLayout:self.collectionViewFlowLayout];
	self.entriesCollectionView.delegate = self;
	self.entriesCollectionView.dataSource = self;
	self.entriesCollectionView.allowsMultipleSelection = YES;
	[self.entriesCollectionView registerClass:[TMEntryCollectionViewCell class] forCellWithReuseIdentifier:@"MONEntryCollectionViewCell"];
	
	self.addEntriesButton = [[UIButton alloc] init];
	[self.addEntriesButton setImage:[UIImage imageForUserColorPreference:@"ui-icon-add-product"] forState:UIControlStateNormal];
	[self.addEntriesButton addTarget:self action:@selector(addEntriesButtonTapped) forControlEvents:UIControlEventTouchUpInside];
	
	self.applyTreatmentButton = [[UIButton alloc] init];
	[self.applyTreatmentButton setImage:[UIImage imageForUserColorPreference:@"ui-icon-add-treatment-active"] forState:UIControlStateNormal];
	[self.applyTreatmentButton addTarget:self action:@selector(applyTreatmentButtonTapped) forControlEvents:UIControlEventTouchUpInside];

	self.continueButton = [[MONButton alloc] init];
	[self.continueButton setTitle:@"Continue" forState:UIControlStateNormal];
	[self.continueButton addTarget:self action:@selector(continueButtonTapped) forControlEvents:UIControlEventTouchUpInside];
	self.continueButton.enabled = ![self.trialModel isReadOnly];
	self.continueButton.alpha = ![self.trialModel isReadOnly] ? 1.0f : 0.7f;
	
	self.entriesView = [[TMEditTrialEntriesView alloc] initWithCollectionView:self.entriesCollectionView
																headerButtons:@[self.addEntriesButton, self.applyTreatmentButton, self.continueButton]];
	self.entriesView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
	[self.entriesView escAddObserver:self];
	[self.view addSubview:self.entriesView];
	
	self.collectionViewFlowLayout.longPressGestureRecognizer.minimumPressDuration = 0.25;
	
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(requestNewProductSubmitted) name:@"RequestNewProductSubmitted" object:nil];
}

-(void)dealloc {
	[[NSNotificationCenter defaultCenter] removeObserver:self];
}


- (void)viewWillAppear:(BOOL)animated {
	[super viewWillAppear:animated];
	[self.entriesCollectionView reloadData];
	
    NSArray *treatments = [[[TMWorkingUnitOfWork sharedInstance] treatmentsRepository] findTreatmentsByCrop:self.trialModel.cropName country:@"USA" year:self.trialModel.plantingYear];

	self.treatmentPopoverModel = [[TMTreatmentModel alloc] initWithDataSource:treatments];
	
	self.entriesView.frame = self.view.bounds;
	[self updateNumberOfEntriesCountAnimated:NO];
	[self updateApplyTreatmentButtonEnabledState];
}

- (void)viewDidAppear:(BOOL)animated {
	[super viewDidAppear:animated];

	[MONGoogleAnalytics trackView:@"Trial - Add Entries"];
}

- (void)viewWillLayoutSubviews {
	[super viewWillLayoutSubviews];
	
	CGFloat cardWidth = CGRectGetWidth(self.view.bounds) - 2.0 * MONDimensionsSmallPadding;
	[self.collectionViewFlowLayout setItemSize:CGSizeMake(cardWidth, 100)];
}

- (void)continueButtonTapped {
	[self.tabSettingsObject gotoNextTab];
}

- (void)setTitle:(NSString *)title {
	[super setTitle:title];
	[self.tabSettingsObject setGlobalTitle:title];
	if (title && ![title isEqualToString:TMTabNameNewTrial]) {
		[self.tabSettingsObject setTabTitle:TMTabNameEditTrial index:1];
	}
}

- (void)updateNumberOfEntriesCountAnimated:(BOOL)animated {
	[self.entriesView setNumberOfEntries:[self collectionView:self.entriesCollectionView numberOfItemsInSection:0] animated:animated];
}

- (void)applyTreatmentButtonTapped {
	self.activeCell = nil;
	
	MONPopoverTableViewController *tableViewController = [[MONPopoverTableViewController alloc] initWithModel:self.treatmentPopoverModel];
	[tableViewController escAddObserver:self];
	
	self.cellPopoverController = [[UIPopoverController alloc] initWithContentViewController:tableViewController];
	self.cellPopoverController.delegate = self;
	[self.cellPopoverController setPopoverContentSize:CGSizeMake(300, 200)];
	CGRect popoverPresetingRect = CGRectInset(self.applyTreatmentButton.bounds, 5.0, 5.0);
	[self.cellPopoverController presentPopoverFromRect:popoverPresetingRect inView:self.applyTreatmentButton permittedArrowDirections:UIPopoverArrowDirectionUp animated:YES];
}

- (void)requestNewProductSubmitted {
	[self dismissViewControllerAnimated:YES completion:^{
		[self dismissViewControllerAnimated:YES completion:nil];
		[self.selectedEntriesModel addObjects:self.addEntriesSelectedEntriesModel.selectedEntriesArray];
		[self.entriesView setNumberOfEntries:[self.selectedEntriesModel.selectedEntriesArray count] animated:YES];
		[self.entriesCollectionView reloadData];
		[self saveEntries];
	}];
}

- (void)addEntriesViewControllerDoneButtonTapped {
    [self.addEntriesViewController addSelectedProductsIfNotAdded];
	[self dismissViewControllerAnimated:YES completion:nil];
	[self.selectedEntriesModel addObjects:self.addEntriesSelectedEntriesModel.selectedEntriesArray];
	[self.entriesView setNumberOfEntries:[self.selectedEntriesModel.selectedEntriesArray count] animated:YES];
	NSSet *entriesSet = [NSSet setWithArray:self.selectedEntriesModel.selectedEntriesArray];
	[self.trialModel setEntries:entriesSet];
	[self.entriesCollectionView reloadData];
}

- (void)modalViewControllerCancelButtonTapped {
	[self dismissViewControllerAnimated:YES completion:nil];
}

- (void)updateApplyTreatmentButtonEnabledState {
	if ([[self.entriesCollectionView indexPathsForSelectedItems] count] > 0 && self.isReadOnly == NO) {
		self.applyTreatmentButton.enabled = YES;
	} else {
		self.applyTreatmentButton.enabled = NO;
	}	
}

- (void)updateCellNumbers {
	NSArray *visibleCellIndexPaths = [self.entriesCollectionView indexPathsForVisibleItems];
	for (NSIndexPath *indexPath in visibleCellIndexPaths) {
		TMEntryCollectionViewCell *cell = (TMEntryCollectionViewCell *)[self.entriesCollectionView cellForItemAtIndexPath:indexPath];
		[cell setNumber:indexPath.row + 1];
	}
}

- (void)saveEntries {
	self.trialModel.entries = [NSSet setWithArray:self.selectedEntriesModel.selectedEntriesArray];
	[[TMWorkingUnitOfWork sharedInstance] saveChanges];
}

#pragma mark - UICollectionViewDataSource Methods

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
	TMEntryCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier: @"MONEntryCollectionViewCell" forIndexPath:indexPath];
	
	//for random cells of the screen, sometimes the treatements are not found in the baseViewController's setAllViewsAsReadOnly
	[cell setIsReadOnly:self.isReadOnly];

	[cell setNumber:indexPath.row + 1];
	
	[cell setBrand:[self.selectedEntriesModel brandNameFromIndex:indexPath.row]];
	[cell setProduct:[self.selectedEntriesModel productNameFromIndex:indexPath.row]];
	[cell setRMValue:[self.selectedEntriesModel maturityRatingNameFromIndex:indexPath.row]];
	[cell setTrait:[self.selectedEntriesModel traitNameFromIndex:indexPath.row]];
	[cell setTreatment:[self.selectedEntriesModel treatmentNameFromIndex:indexPath.row]];
    [cell setReplaceButtonAvailable:![self.selectedEntriesModel hasNewProductAtIndex:indexPath.row]];
    cell.delegate = self;
	return cell;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
	return [self.selectedEntriesModel.selectedEntriesArray count];
}

#pragma mark - UICollectionViewDelegate Methods

-(BOOL)collectionView:(UICollectionView *)collectionView shouldHighlightItemAtIndexPath:(NSIndexPath *)indexPath {
    return NO == self.isReadOnly;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
	[self updateApplyTreatmentButtonEnabledState];
}

- (void)collectionView:(UICollectionView *)collectionView didDeselectItemAtIndexPath:(NSIndexPath *)indexPath {
	[self updateApplyTreatmentButtonEnabledState];
}

#pragma mark - LXReorderableCollectionViewDelegateFlowLayout Methods

- (BOOL)collectionView:(UICollectionView *)collectionView canMoveItemAtIndexPath:(NSIndexPath *)indexPath {
    return ![self.trialModel isReadOnly];
}

- (void)collectionView:(UICollectionView *)collectionView itemAtIndexPath:(NSIndexPath *)fromIndexPath didMoveToIndexPath:(NSIndexPath *)toIndexPath {
	[self.selectedEntriesModel moveObjectFromIndex:fromIndexPath.row toIndex:toIndexPath.row];
	[self saveEntries];
}

- (void)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout didEndDraggingItemAtIndexPath:(NSIndexPath *)indexPath {
	[collectionView reloadData];
	[self saveEntries];
}

#pragma mark - MONEditTrialEntriesViewObserver Methods

- (void)addEntriesButtonTapped {
	self.addEntriesSelectedEntriesModel = [[TMSelectedEntriesModel alloc] init];
	
	self.addEntriesViewController = [[TMAddEntriesViewController alloc] initWithSelectedEntriesModel:self.addEntriesSelectedEntriesModel trialModel:self.trialModel];

	UIBarButtonItem *cancelButton = [[UIBarButtonItem alloc] initWithTitle:@"Cancel" style:UIBarButtonItemStylePlain target:self action:@selector(modalViewControllerCancelButtonTapped)];
    [cancelButton setTintColor:[UIColor whiteColor]];
	self.addEntriesViewController.navigationItem.leftBarButtonItem = cancelButton;
	
	UIBarButtonItem *doneButton = [[UIBarButtonItem alloc] initWithTitle:@"Done" style:UIBarButtonItemStylePlain target:self action:@selector(addEntriesViewControllerDoneButtonTapped)];
    [doneButton setTintColor:[UIColor whiteColor]];
	self.addEntriesViewController.navigationItem.rightBarButtonItem = doneButton;

	UINavigationController *navigationController = [[UINavigationController alloc] initWithRootViewController:self.addEntriesViewController];
	navigationController.modalPresentationStyle = UIModalPresentationPageSheet;
	[self presentViewController:navigationController animated:YES completion:nil];
}

#pragma mark - TMEntryCollectionViewCellDelegate Methods

- (void)entryCollectionViewCell:(TMEntryCollectionViewCell *)entryCollectionViewCell addTreatmentsTappedInView:(UIView *)addTreatmentsView {
	self.activeCell = entryCollectionViewCell;
		
	MONPopoverTableViewController *tableViewController = [[MONPopoverTableViewController alloc] initWithModel:self.treatmentPopoverModel];
	[tableViewController escAddObserver:self];
	
	self.cellPopoverController = [[UIPopoverController alloc] initWithContentViewController:tableViewController];
	self.cellPopoverController.delegate = self;
	[self.cellPopoverController setPopoverContentSize:CGSizeMake(300, 200)];
	CGRect popoverPresetingRect = CGRectInset(addTreatmentsView.bounds, 5.0, 5.0);
	[self.cellPopoverController presentPopoverFromRect:popoverPresetingRect inView:addTreatmentsView permittedArrowDirections:UIPopoverArrowDirectionLeft | UIPopoverArrowDirectionRight animated:YES];
}

- (void)deleteButtonTapped:(TMEntryCollectionViewCell *)cell {
    self.selectedEntryToDeletePath = [self.entriesCollectionView indexPathForCell:cell];
    
    if ([self.trialModel hasEntryObservations]) {
        NSString *alertMessage = @"There are observations associated with this entry. Observations will be deleted and can not be recovered.\n Are you sure you want to continue?";
        UIAlertView *deleteAlert = [[UIAlertView alloc] initWithTitle:@"Remove Entry?" message:alertMessage delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"OK", nil];
        [deleteAlert show];
    } else {
        [self deleteSelectedEntry];
    }
}

- (NSString *)getSystemYear {
	NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
	[formatter setDateFormat:@"yyyy"];
	return [formatter stringFromDate:[NSDate date]];
}

- (void)deleteSelectedEntry {
    [self.entriesCollectionView performBatchUpdates:^{
        TMEntry *entry = [self.selectedEntriesModel.selectedEntriesArray objectAtIndex:self.selectedEntryToDeletePath.row];
        [self.trialModel deleteEntry:entry];
        
        [self.selectedEntriesModel removeObjectAtIndex:self.selectedEntryToDeletePath.row];
        NSSet *entriesSet = [NSSet setWithArray:self.selectedEntriesModel.selectedEntriesArray];
        [self.trialModel setEntries:entriesSet];
        
        [self.entriesCollectionView deleteItemsAtIndexPaths:@[self.selectedEntryToDeletePath]];
    }
                                         completion:^(BOOL finished) {
                                             if (finished) {
                                                 [self updateNumberOfEntriesCountAnimated:YES];
                                                 [self updateCellNumbers];
                                                 [self saveEntries];
                                             }
                                         }];
}

- (void)deleteTreatmentButtonTapped:(TMEntryCollectionViewCell *)cell {
	NSIndexPath *cellIndexPath = [self.entriesCollectionView indexPathForCell:cell];
	[self.selectedEntriesModel removeTreatmentAtIndex:cellIndexPath.row];
	[self saveEntries];
}

- (void)replaceButtonTapped:(TMEntryCollectionViewCell *)cell {
    NSInteger entryRow = [self.entriesCollectionView indexPathForCell:cell].row;
    TMEntry * entry = [[self.selectedEntriesModel selectedEntriesArray] objectAtIndex:entryRow];
    TMReplaceEntryModel *replaceModel = [[TMReplaceEntryModel alloc] initWithEntry:entry];
    
    
    TMReplaceEntryViewController *replaceEntryViewController = [[TMReplaceEntryViewController alloc] initWithCropName:self.trialModel.cropName brandName:self.trialModel.brandName];
    TMReplaceEntryNavigationController *replaceEntryNavigationController = [[TMReplaceEntryNavigationController alloc]initWithReplaceEntryViewController:replaceEntryViewController replaceEntryModel:replaceModel];
    replaceEntryNavigationController.modalPresentationStyle = UIModalPresentationPageSheet;
    replaceEntryNavigationController.dismissalDelegate = self;
    [self presentViewController:replaceEntryNavigationController animated:YES completion:nil];
}

#pragma mark - UIAlertViewDelegate Methods

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    if (buttonIndex == 1) {
        [self deleteSelectedEntry];
    }
}

#pragma mark - MONPopoverTableViewControllerObserver Methods

- (void)didSelectRowIndex:(NSInteger)rowIndex {
	NSString *treatmentName = [self.treatmentPopoverModel nameForItemAtIndex:rowIndex];

	if (self.activeCell) {
		[self.activeCell setTreatment:treatmentName];
		NSIndexPath *cellIndexPath = [self.entriesCollectionView indexPathForCell:self.activeCell];
		[self.selectedEntriesModel addTreatment:[self.treatmentPopoverModel objectInDataArrayAtIndex:rowIndex] atIndex:cellIndexPath.row];
	} else {
		NSArray *selectedIndexPaths = [self.entriesCollectionView indexPathsForSelectedItems];
		for (NSIndexPath *indexPath in selectedIndexPaths) {
			TMEntryCollectionViewCell *cell = (TMEntryCollectionViewCell *)[self.entriesCollectionView cellForItemAtIndexPath:indexPath];
			[cell setTreatment:treatmentName];
			[self.selectedEntriesModel addTreatment:[self.treatmentPopoverModel objectInDataArrayAtIndex:rowIndex] atIndex:indexPath.row];
			[self.entriesCollectionView deselectItemAtIndexPath:indexPath animated:YES];
		}
		[self updateApplyTreatmentButtonEnabledState];
	}
	[self.cellPopoverController dismissPopoverAnimated:YES];
	[self saveEntries];
}

#pragma mark - UIPopoverControllerDelegate Methods

- (void)popoverControllerDidDismissPopover:(UIPopoverController *)popoverController {
	self.activeCell = nil;
}

#pragma mark - TMReplaceEntryNavigationControllerDelegate Methods

- (void)dismissReplaceEntryNavigationController {
    [self dismissViewControllerAnimated:YES completion:^{
        [self.entriesCollectionView reloadData];
        [self saveEntries];}];
}
@end
