#import <UIKit/UIKit.h>

extern const CGFloat MONDimensionsSegmentedCornerRadius;
extern const CGFloat MONDimensionsMicroPadding;
extern const CGFloat MONDimensionsTinyPadding;
extern const CGFloat MONDimensionsSmallPadding;
extern const CGFloat MONDimensionsLargePadding;
extern const CGFloat MONDimensionsExtraLargePadding;
extern const CGFloat MONDimensionsThinBorderWidth;
extern const CGFloat MONDimensionsThickBorderWidth;
extern const CGFloat MONDimensionsCornerRadius;
extern const CGFloat MONDimensionsTableHeaderRowHeight;
extern const CGFloat MONDimensionsTableRowHeight;
extern const CGFloat MONDimensionsHeaderHeight;
extern const CGFloat MONDimensionsIconTouchTargetWidth;