#import "MONPersistenceBlocks.h"

@protocol TMDataSyncProtocol <NSObject>
@optional
-(void)syncFromService:(NSArray*)dataFromService completionBlock:(MONDataImportCompletionBlock)completionBlock;
-(void)syncFromServiceWithAssociatedObject:(id)associatedObject dataFromService:(NSArray*)dataFromService completionBlock:(MONDataImportCompletionBlock)completionBlock;
@end
