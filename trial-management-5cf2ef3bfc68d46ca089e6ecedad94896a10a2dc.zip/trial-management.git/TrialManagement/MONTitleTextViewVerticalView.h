#import <UIKit/UIKit.h>

@interface MONTitleTextViewVerticalView : UIView

- (void)setTitleText:(NSString *)titleText;
- (void)setTextViewText:(NSString *)textViewText;

@end
