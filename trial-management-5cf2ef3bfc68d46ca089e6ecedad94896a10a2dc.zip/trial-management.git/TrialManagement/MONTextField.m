#import "MONTextField.h"
#import "MONFonts.h"
#import "MONCardContainerView.h"
#import "MONDimensions.h"
#import "MONUIConvenienceFunctions.h"
#import "UIColor+MONThemeColorProvider.h"

static const CGFloat DefaultHeight = 35.0;

@interface MONTextField ()
@property (nonatomic) MONCardContainerView *cardContainerView;
@property (nonatomic) UITextField *textField;
@property (nonatomic) UITapGestureRecognizer *tapGestureRecognizer;

@end

@implementation MONTextField

- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        
        self.userInteractionEnabled = YES;
        
        self.tapGestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(mainViewTapped)];
        [self addGestureRecognizer:self.tapGestureRecognizer];
        
        self.cardContainerView = [[MONCardContainerView alloc] init];
        [self addSubview:self.cardContainerView];
        
        self.textField = [[UITextField alloc] init];
        self.textField.font = [UIFont fontWithName:OpenSans size:14.0];
        self.textField.textColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeText];
        self.textField.keyboardAppearance = UIKeyboardAppearanceDark;
        self.textField.delegate = self.delegate;
        [self.textField addTarget:self action:@selector(textFieldTextDidChange) forControlEvents:UIControlEventEditingChanged];
        [self.textField addTarget:self action:@selector(textFieldDidEndEditing) forControlEvents:UIControlEventEditingDidEnd];
        
        [self.cardContainerView.contentContainerView addSubview:self.textField];
    }
    return self;
}

-(void)setDelegate:(id<UITextFieldDelegate>)delegate{
    self.textField.delegate = delegate;
}
- (void)setTextColor:(UIColor *)textColor {
    self.textField.textColor = textColor;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    
    self.cardContainerView.frame = self.bounds;
    
    //	[self.textField sizeToFit];
    self.textField.frame = CGRectMake(MONDimensionsTinyPadding,
                                      MONUIScreenRoundToScreenScale((CGRectGetMaxY(self.bounds) - DefaultHeight) / 2.0),
                                      CGRectGetWidth(self.bounds) - 2.0 * MONDimensionsTinyPadding,
                                      DefaultHeight);
}

- (NSString *)text {
    return self.textField.text;
}

- (void)setText:(NSString *)text {
    
    self.textField.text = text;
}

- (void)setPlaceholderTextColor:(UIColor *)placeHolderTextColor {
    NSString *text = [self.textField.attributedPlaceholder string];
    if (text == nil) {
        text = @"";
    }
    self.textField.attributedPlaceholder = [[NSAttributedString alloc] initWithString:text attributes:@{NSForegroundColorAttributeName : placeHolderTextColor}];
}

- (void)setPlaceholderText:(NSString *)placeholderText {
    self.textField.attributedPlaceholder = [self attributedStringForText:placeholderText];
    [self setPlaceholderTextColor:[UIColor colorForThemeComponentType:MONThemeComponentTypePlaceholderText]];
}

- (void)setKeyboardType:(UIKeyboardType)keyboardType {
    self.textField.keyboardType = keyboardType;
}

- (NSAttributedString *)attributedStringForText:(NSString *)text {
    return [[NSAttributedString alloc] initWithString:text attributes:@{NSForegroundColorAttributeName : [UIColor colorForThemeComponentType:MONThemeComponentTypePlaceholderText]}];
}

- (CGSize)sizeThatFits:(CGSize)size {
    CGSize sizeThatFits = CGSizeMake(size.width, DefaultHeight);
    
    return sizeThatFits;
}

- (void)setAutocorrectionType:(UITextAutocorrectionType)autocorrectionType {
    //self.textField.autocorrectionType = autocorrectionType;
}

- (BOOL)becomeFirstResponder {
    return [self.textField becomeFirstResponder];
}

- (BOOL)resignFirstResponder {
    return [self.textField resignFirstResponder];
}

- (void)mainViewTapped {
    [self.textField becomeFirstResponder];
}

- (void)textFieldTextDidChange {
    [self.monTextFieldDelegate monTextFieldTextDidChange:self];
}

- (void)textFieldDidEndEditing {
    [self.monTextFieldDelegate monTextFieldDidEndEditing:self];
}


- (BOOL)enabled {
    return self.textField.enabled;
}

- (void)setEnabled:(BOOL)enabled {
    [self.textField setEnabled:enabled];
    if(enabled) {
        UIColor *color = [UIColor colorForThemeComponentType:MONThemeComponentTypeBackground];
        self.textField.backgroundColor = color;
        self.cardContainerView.backgroundColor = color;
    } else {
        [self setLockedColor];
    }
}

- (void)setLockedColor {
    UIColor *lockedColor= [UIColor colorForThemeComponentType:MONThemeComponentTypeLockedBackground] ;
    
    self.textField.backgroundColor = lockedColor;
    self.backgroundColor = lockedColor;
    self.cardContainerView.backgroundColor = lockedColor;
}

@end
