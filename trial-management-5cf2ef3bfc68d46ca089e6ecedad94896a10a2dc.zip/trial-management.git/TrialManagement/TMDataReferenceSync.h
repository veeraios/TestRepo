#import "TMDataSyncCoordinator.h"

@interface TMDataReferenceSync : NSObject

@property (nonatomic) id<TMDataSyncCoordinatorCompletionDelegate>delegate;

- (void)prepareForSync;
- (void)syncTechAgronomists;
- (void)syncBrands;
- (void)syncPlotTypes;
- (void)syncCrops;
- (void)syncTillageMethods;
- (void)syncPreviousCrops;
- (void)syncSoilTypes;
- (void)syncTiles;
- (void)syncTreatments;
- (void)syncStates;
- (void)syncSignatureImages;
- (void)syncProductsFromDate:(NSTimeInterval)fromDate;
- (void)syncGrowersAndDealersFromDate:(NSTimeInterval)fromDate;
- (void)syncTrialsFromDate:(NSTimeInterval)fromDate toDate:(NSTimeInterval)toDate batchSize:(NSUInteger)batchSize;
- (void)syncProtocols;
- (void)syncObservationReferenceData;
- (void)syncObservationCalculationDetails;
- (void)syncTraits;
- (void)syncReportReferenceData;
@end
