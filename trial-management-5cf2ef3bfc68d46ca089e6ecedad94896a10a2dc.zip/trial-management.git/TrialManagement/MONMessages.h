//
//  MONMessages.h
//  TrialManagement
//
//  Created by SINGH, SUPREET [AG/1000] on 7/1/14.
//  Copyright (c) 2014 Monsanto. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MONMessages : NSObject

+ (void)setDefaultViewController:(UIViewController *)viewController;

+ (void)showSuccessMessageTitle:(NSString *)title subtitle:(NSString *)subtitle;

+ (void)showErrorMessageTitle:(NSString *)title subtitle:(NSString *)subtitle;

+ (void)showWarningMessageTitle:(NSString *)title subtitle:(NSString *)subtitle;

+ (void)showSuccessMessageTitle:(NSString *)title subtitle:(NSString *)subtitle presentOverModal:(BOOL)presentOverModal;

+ (void)showErrorMessageTitle:(NSString *)title subtitle:(NSString *)subtitle presentOverModal:(BOOL)presentOverModal;

+ (void)showWarningMessageTitle:(NSString *)title subtitle:(NSString *)subtitle presentOverModal:(BOOL)presentOverModal;

@end
