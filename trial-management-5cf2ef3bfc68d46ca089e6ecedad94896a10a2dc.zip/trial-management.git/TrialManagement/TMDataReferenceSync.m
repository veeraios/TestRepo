#import "TMDataReferenceSync.h"
#import "TMReferenceDataService.h"
#import "TMTechAgronomist.h"
#import "TMWorkingUnitOfWork.h"
#import "TMTrialService.h"
#import "TMSignatureImageService.h"
#import "NSManagedObject+MONFilename.h"
#import "TrialManagement-Swift.h"

@interface TMDataReferenceSync ()

@property(nonatomic) TMReferenceDataService *referenceService;
@property(nonatomic) TMTrialService *trialService;
@property(nonatomic) NSMutableArray *syncedTrialIDs;
@property(nonatomic) NSUInteger numberOfTrialsWithSignatures;
@property(nonatomic) NSUInteger numberOfSignaturesSynced;
@property(nonatomic) TMTrialRepository *trialRepository;
@property(nonatomic) TMPendingSyncQueueRepository *pendingSyncQueueRepository;

@property(nonatomic) NSUInteger failedPageNumber;
@end

@implementation TMDataReferenceSync

- (instancetype)init {
  return [self initWithNetworkService:[[TMReferenceDataService alloc] init] trialService:[[TMTrialService alloc] init]];
}

- (instancetype)initWithNetworkService:(TMReferenceDataService *)referenceService trialService:(TMTrialService *)trialService {
  self = [super init];
  if (self) {
    self.referenceService = referenceService;
    self.trialService = trialService;
    self.trialRepository = (TMTrialRepository *) [[TMWorkingUnitOfWork sharedInstance] trialRepository];
    self.pendingSyncQueueRepository = (TMPendingSyncQueueRepository *) [[TMWorkingUnitOfWork sharedInstance] pendingSyncQueueRepository];
  }
  return self;
}

- (NSString *)getSystemYear {
  NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
  [formatter setDateFormat:@"yyyy"];
  return [formatter stringFromDate:[NSDate date]];
}

- (NSString *)getSystemPreviousYear {
  NSDate *today = [NSDate date];
  NSCalendar *cal = [NSCalendar currentCalendar];
  NSDateComponents *offsetComponents = [[NSDateComponents alloc] init];
  [offsetComponents setYear:-1];
  NSDate *nextYear = [cal dateByAddingComponents:offsetComponents toDate:today options:0];
  NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
  [formatter setDateFormat:@"yyyy"];
  return [formatter stringFromDate:nextYear];
}

- (void)prepareForSync {
  self.syncedTrialIDs = [NSMutableArray array];
  self.numberOfTrialsWithSignatures = 0;
  self.numberOfSignaturesSynced = 0;
}

- (void)syncCompleteFor:(NSString *)name {
  [self.delegate dataSyncCompletedFor:name];
}

- (void)syncFailedFor:(NSString *)name {
  [self.delegate dataSyncFailedFor:name];
}

- (void)syncTrialsFromDate:(NSTimeInterval)fromDate toDate:(NSTimeInterval)toDate batchSize:(NSUInteger)batchSize {
  if (![self.trialRepository wasCacheBuilt]) {
    [self.trialRepository buildRefDataCache];
  }

  if (self.failedPageNumber) {
    [self syncTrialsFromDate:fromDate toDate:toDate batchSize:batchSize pageNumber:self.failedPageNumber];
  } else {
    [self syncTrialsFromDate:fromDate toDate:toDate batchSize:batchSize pageNumber:1];
  }
}

- (void)syncTrialsFromDate:(NSTimeInterval)fromDate toDate:(NSTimeInterval)toDate batchSize:(NSUInteger)batchSize pageNumber:(NSUInteger)pageNumber {
  __weak TMDataReferenceSync *weakSelf = self;

  [self.trialService allTrialInformationFromDate:fromDate toDate:toDate batchSize:batchSize pageNumber:pageNumber completionBlock:^(NSArray *data, NSError *error) {
    if (error == nil) {
      __block NSArray *trialData = [data valueForKeyPath:@"trials"];
      __block NSUInteger pageCount = (NSUInteger) ((NSNumber *) [data valueForKeyPath:@"pageCount"]).integerValue;

      [self.trialRepository syncFromService:trialData trialIdsToSkip:[self.pendingSyncQueueRepository trialIdsOfTrialsInSyncQueue] completionBlock:^{
        DDLogInfo(@"Finished trials sync on page#: %lu of %lu for %lu trials", (unsigned long) pageNumber, (unsigned long) pageCount, (unsigned long) trialData.count);
        [weakSelf.syncedTrialIDs addObjectsFromArray:[trialData valueForKeyPath:@"trialTO.id"]];
      }];

      if (pageNumber == pageCount || pageCount == 0) {
        NSNumber *totalTrials = pageCount == 0 ? @0 : @(trialData.count + (pageCount - 1) * batchSize);
        [MONAnalytics logEvent:[MONAnalytics EventTrialsSync] parameters:@{@"numberOfTrials" : totalTrials, @"batchSize" : @(batchSize), @"pageCount" : @(pageCount)} timed:NO];
        [self performSelectorOnMainThread:@selector(syncCompleteFor:) withObject:SyncTrials waitUntilDone:NO];
      } else {
        [weakSelf syncTrialsFromDate:fromDate toDate:toDate batchSize:batchSize pageNumber:pageNumber + 1];
      }

    } else {
      self.failedPageNumber = pageNumber;
      [self performSelectorOnMainThread:@selector(syncFailedFor:) withObject:SyncTrials waitUntilDone:NO];
    }
  }];
}

- (void)syncObservationReferenceData {
  TMCropRepository *repo = (TMCropRepository *) [[TMWorkingUnitOfWork sharedInstance] cropRepository];
  NSArray *allCropNames = [[repo getAll] valueForKey:@"name"];
  TMObservationReferenceDataRepository *observationRefRepository = (TMObservationReferenceDataRepository *) [[TMWorkingUnitOfWork sharedInstance] observationReferenceDataRepository];
  __weak TMDataReferenceSync *weakSelf = self;

  __block NSInteger numberOfObservationCalls = 0;
  DDLogInfo(@"number of crops %lu", (unsigned long) [allCropNames count]);
  for (NSString *cropName in allCropNames) {
    [self.referenceService observationReferenceDataWithCompletionBlockForCropName:cropName completionBlock:^(NSArray *data, NSError *error) {
      if (error == nil) {
        [observationRefRepository syncFromServiceWithAssociatedObject:cropName dataFromService:data completionBlock:^{
          numberOfObservationCalls += 1;
          DDLogInfo(@"------observation ref data saved %@", cropName);
          __block NSArray *blockData = data;
          blockData = nil;
          if (numberOfObservationCalls == [allCropNames count]) {
            DDLogInfo(@"#############OBSERVATION REF DATA DONE##################");
            [weakSelf performSelectorOnMainThread:@selector(syncCompleteFor:) withObject:SyncObservationReferenceData waitUntilDone:NO];
          }
        }];
      } else {
        [weakSelf performSelectorOnMainThread:@selector(syncFailedFor:) withObject:SyncObservationReferenceData waitUntilDone:NO];
        //? return; //force out of loop if one fails?
      }
    }];
  }
}

- (void)syncGrowersAndDealersFromDate:(NSTimeInterval)fromDate {
  TMGrowerRepository *growerRepo = (TMGrowerRepository *) [[TMWorkingUnitOfWork sharedInstance] growerRepository];
  TMDealerRepository *dealerRepo = (TMDealerRepository *) [[TMWorkingUnitOfWork sharedInstance] dealerRepository];
  __weak TMDataReferenceSync *weakSelf = self;

  [self.referenceService cooperatorsFromDate:fromDate completionBlock:^(NSArray *data, NSError *error) {
    if (error == nil) {
      [growerRepo syncFromService:[data filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"category == 'Grower'"]] completionBlock:^{
        __block NSArray *blockData = data;
        blockData = nil;
      }];
      [dealerRepo syncFromService:[data filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"category == 'Dealer'"]] completionBlock:^{
        __block NSArray *blockData = data;
        blockData = nil;
        [weakSelf performSelectorOnMainThread:@selector(syncCompleteFor:) withObject:SyncGrowersAndDealers waitUntilDone:NO];
      }];
      [[TMWorkingUnitOfWork sharedInstance] saveChanges];
    } else {
      [weakSelf performSelectorOnMainThread:@selector(syncFailedFor:) withObject:[NSString stringWithFormat:@"%@", SyncGrowersAndDealers] waitUntilDone:NO];
    }
  }];
}

- (void)syncSignatureImages {
  self.numberOfSignaturesSynced = 0;
  id <TMTrialRepositoryProtocol> trialRepository = [[TMWorkingUnitOfWork sharedInstance] trialRepository];
  NSArray *trialsWithSignatures = [trialRepository trialsWithSignaturesForTrialIds:self.syncedTrialIDs];
  self.numberOfTrialsWithSignatures = [trialsWithSignatures count];
  if (self.numberOfTrialsWithSignatures == 0) {
    [self syncCompleteFor:SyncSignatureImages];
  } else {
    [self syncSignatureImageForTrials:trialsWithSignatures index:0];
  }
}

- (void)syncSignatureImageForTrials:(NSArray *)trialsArray index:(NSUInteger)index {
  TMSignatureImageService *signatureService = [TMSignatureImageService sharedInstance];
  if (index >= self.numberOfTrialsWithSignatures) {
    return;
  }
  TMTrial *trial = trialsArray[index];

  if (!trial) {
    return;
  }
  __weak TMDataReferenceSync *weakSelf = self;

  [signatureService signatureImageForTrialId:[trial.trialId longLongValue] responseBlock:^(UIImage *responseImage, NSError *error) {
    UIImage *signatureImage = nil;
    if (!error && responseImage) {
      signatureImage = responseImage;
      NSString *filename = [NSString stringWithFormat:@"%@_growerSignature.jpg", [trial filenameFromObjectId]];
      [signatureService saveSignatureImageLocally:signatureImage filename:filename];
      [weakSelf signatureImageSyncedForTrialId:[trial.trialId longLongValue] error:error];
    } else {
      [weakSelf signatureImageSyncedForTrialId:[trial.trialId longLongValue] error:error];
    }
    NSUInteger newIndex = index + 1;
    [weakSelf syncSignatureImageForTrials:trialsArray index:newIndex];
  }];
}

- (void)signatureImageSyncedForTrialId:(long long)trialId error:(NSError *)error {
  self.numberOfSignaturesSynced++;
  if (error) {
    DDLogError(@"Signature Image %lu / %lu Sync Error for trialId: %lld error: %@", (unsigned long) self.numberOfSignaturesSynced, (unsigned long) self.numberOfTrialsWithSignatures, trialId, error);
  } else {
    DDLogInfo(@"Signature Image %lu / %lu Synced for trialId: %lld", (unsigned long) self.numberOfSignaturesSynced, (unsigned long) self.numberOfTrialsWithSignatures, trialId);
  }
  if (self.numberOfSignaturesSynced == self.numberOfTrialsWithSignatures) {
    [self performSelectorOnMainThread:@selector(syncCompleteFor:) withObject:SyncSignatureImages waitUntilDone:NO];
  }
}

- (void)syncFromRepo:(id)repository object:(NSString *)object data:(NSArray *)data error:(NSError *)error {
  __weak TMDataReferenceSync *weakSelf = self;

  if (error == nil) {
    [repository syncFromService:data completionBlock:^{
      // Deallocate strong data
      __block NSArray *blockData = data;
      blockData = nil;

      [weakSelf performSelectorOnMainThread:@selector(syncCompleteFor:) withObject:object waitUntilDone:NO];
    }];
  } else {
    [weakSelf performSelectorOnMainThread:@selector(syncFailedFor:) withObject:object waitUntilDone:NO];
  }
}

- (void)syncCrops {
  [self.referenceService cropsWithCompletionBlock:^(NSArray *data, NSError *error) {
    [self syncFromRepo:[[TMWorkingUnitOfWork sharedInstance] cropRepository] object:SyncCrops data:data error:error];
  }];
}

- (void)syncPlotTypes {
  [self.referenceService plotTypesWithCompletionBlock:^(NSArray *data, NSError *error) {
    [self syncFromRepo:[[TMWorkingUnitOfWork sharedInstance] plotTypeRepository] object:SyncPlotTypes data:data error:error];
  }];
}

- (void)syncBrands {
  [self.referenceService brandsWithCompletionBlock:^(NSArray *data, NSError *error) {
    [self syncFromRepo:[[TMWorkingUnitOfWork sharedInstance] brandsRepository] object:SyncBrands data:data error:error];
  }];
}

- (void)syncTechAgronomists {
  [self.referenceService techAgronomistWithCompletionBlock:^(NSArray *data, NSError *error) {
    [self syncFromRepo:[[TMWorkingUnitOfWork sharedInstance] techAgronomistRepository] object:SyncTechAgronomists data:data error:error];
  }];
}

- (void)syncTillageMethods {
  [self.referenceService tillageMethodsWithCompletionBlock:^(NSArray *data, NSError *error) {
    [self syncFromRepo:[[TMWorkingUnitOfWork sharedInstance] tillageMethodsRepository] object:SyncTillageMethods data:data error:error];
  }];
}

- (void)syncProtocols {
  [self.referenceService protocolsWithCompletionBlock:^(NSArray *data, NSError *error) {
    [self syncFromRepo:[[TMWorkingUnitOfWork sharedInstance] protocolRepository] object:SyncProtocols data:data error:error];
  }];
}

- (void)syncProductsFromDate:(NSTimeInterval)fromDate {
  [self.referenceService productsFromDate:fromDate completionBlock:^(NSArray *data, NSError *error) {
    [self syncFromRepo:[[TMWorkingUnitOfWork sharedInstance] productRepository] object:SyncProducts data:data error:error];
  }];
}

- (void)syncPreviousCrops {
  [self.referenceService previousCropsWithCompletionBlock:^(NSArray *data, NSError *error) {
    [self syncFromRepo:[[TMWorkingUnitOfWork sharedInstance] previousCropsRepository] object:SyncPreviousCrops data:data error:error];
  }];
}

- (void)syncSoilTypes {
  [self.referenceService soilTypesWithCompletionBlock:^(NSArray *data, NSError *error) {
    [self syncFromRepo:[[TMWorkingUnitOfWork sharedInstance] soilTypesRepository] object:SyncSoilTypes data:data error:error];
  }];
}

- (void)syncTiles {
  [self.referenceService tilesWithCompletionBlock:^(NSArray *data, NSError *error) {
    [self syncFromRepo:[[TMWorkingUnitOfWork sharedInstance] tilesRepository] object:SyncTiles data:data error:error];
  }];
}

- (void)syncTreatments {
  [self.referenceService treatmentsWithCompletionBlock:[self getSystemYear] previousYear:[self getSystemPreviousYear] completionBlock:^(NSArray *data, NSError *error) {
    [self syncFromRepo:[[TMWorkingUnitOfWork sharedInstance] treatmentsRepository] object:SyncTreatments data:data error:error];
  }];
}

- (void)syncObservationCalculationDetails {
  [self.referenceService observationCalculationDetailsWithCompletionBlock:^(NSArray *data, NSError *error) {
    [self syncFromRepo:[[TMWorkingUnitOfWork sharedInstance] observationCalculationRepository] object:SyncObservationCalculationDetails data:data error:error];
  }];
}

- (void)syncStates {
  [self.referenceService statesMethodsWithCompletionBlock:^(NSArray *data, NSError *error) {
    [self syncFromRepo:[[TMWorkingUnitOfWork sharedInstance] stateRepository] object:SyncStates data:data error:error];
  }];
}

#pragma mark - DataModel: TrialManagement 2

- (void)syncTraits {
  [self.referenceService traitsWithCompletionBlock:^(NSArray *data, NSError *error) {
    [self syncFromRepo:[[TMWorkingUnitOfWork sharedInstance] traitRepository] object:SyncTraits data:data error:error];
  }];
}

#pragma mark - DataModel: TrialManagement 3

- (void)syncReportReferenceData {
    [self.referenceService reportReferenceDataWithCompletionBlock:^(NSArray *data, NSError *error) {
        [self syncFromRepo:[[TMWorkingUnitOfWork sharedInstance] reportReferenceDataRepository] object:SyncReportReferenceData data:data error:error];
    }];
}

@end