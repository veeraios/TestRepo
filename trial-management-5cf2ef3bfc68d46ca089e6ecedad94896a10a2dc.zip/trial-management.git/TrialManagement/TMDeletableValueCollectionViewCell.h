//
//  TMDeletableValueCollectionViewCell.h
//  TrialManagement
//
//  Created by WAIDMANN, ALAN [AG/1000] on 10/30/14.
//  Copyright (c) 2014 Monsanto. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MONSingleSelectionCardCollectionViewCell.h"
#import "TMReferenceListDataModel.h"

@interface TMDeletableValueCollectionViewCell: MONSingleSelectionCardCollectionViewCell

@property (nonatomic) id<TMReferenceListDataModel> cellModel;

@end
