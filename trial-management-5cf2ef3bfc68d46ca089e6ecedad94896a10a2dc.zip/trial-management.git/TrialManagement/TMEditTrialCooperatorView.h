#import "MONAgreementView.h"
#import "TMCooperatorInfoViewModel.h"
#import <UIKit/UIKit.h>

@protocol TMEditTrialCooperatorViewDelegate
- (void)shortDescriptionTapped:(NSString *)currentText;

- (void)selectGrowerTapped;

- (void)selectDealerTapped;

- (void)updateGrowerInfoTapped;

- (void)updateDealerInfoTapped;

- (void)harvestSpatiallyTapped:(BOOL)value;

- (void)stateWasSelected:(id)state;

- (void)countyWasSelected:(id)county;

- (void)resetCounty;
@end

@interface TMEditTrialCooperatorView : UIView
@property(nonatomic, weak) id <MONAgreementDelegate> agreementDelegate;
@property(nonatomic, weak) id <TMEditTrialCooperatorViewDelegate> delegate;

- (instancetype)initWithViewModel:(TMCooperatorInfoViewModel *)viewModel headerButtons:(NSArray *)headerButtons;

- (void)setState:(NSString *)stateName;

- (void)setCounty:(NSString *)countyName;

- (void)setDealerName:(NSString *)dealerName;

- (void)setGrowerName:(NSString *)growerName;

- (void)setCropName:(NSString *)cropName brandName:(NSString *)brandName;

- (void)setAgreementSignatureImage:(UIImage *)signatureImage;

- (void)setShortDescriptionText:(NSString *)enteredText;

- (void)setHarvestSpatially:(BOOL)value;

- (void)setCooperatorSignatureDate:(NSDate *)date;

- (void)setCooperatorSignature:(BOOL)value;

- (void)setCooperatorRelease:(BOOL)value;
@end