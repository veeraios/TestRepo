#import "MONButton.h"
#import "TMReferenceListDataModel.h"
#import "MONLabeledTextField.h"

@protocol MONPopoverButtonDelegate <NSObject>
@optional
-(void)valueWasSelected:(id)sender selectedValue:(NSString*)selectedValue selectedIndex:(NSInteger)selectedIndex;
@end

@interface MONPopoverButton : MONButton
- (instancetype)initWithPopoverTitle:(NSString*)title model:(id<TMReferenceListDataModel>)model buttonText:(NSString*)buttonText;
- (instancetype)initWithPopoverTitle:(NSString*)title model:(id<TMReferenceListDataModel>)model buttonImage:(UIImage*)buttonImage;
- (instancetype)initWithModel:(id<TMReferenceListDataModel>)model buttonImage:(UIImage*)buttonImage;
@property (nonatomic, weak) id<MONPopoverButtonDelegate> popoverDelegate;
@property (nonatomic) id<TMReferenceListDataModel> model;
@end

