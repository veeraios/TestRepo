#import "NSNumber+TMNSNumberHelper.h"

@implementation NSNumber (TMNSNumberHelper)

- (NSString *)roundedStringToTwoDecimalPlaces {
	NSNumberFormatter * decimalFormatter = [[NSNumberFormatter alloc] init];
	[decimalFormatter setMinimumFractionDigits:2];
	[decimalFormatter setMaximumFractionDigits:2];
	return [decimalFormatter stringFromNumber:self];
}

- (NSString *)roundedString:(NSInteger)decimalPlaces {
	NSNumberFormatter * decimalFormatter = [[NSNumberFormatter alloc] init];
	[decimalFormatter setMinimumFractionDigits:0];
	[decimalFormatter setMaximumFractionDigits:decimalPlaces];
	return [decimalFormatter stringFromNumber:self];
}

- (NSString *)roundedStringWithPrefixPadding:(NSInteger)decimalPlaces {
	NSString *result = [self roundedString:decimalPlaces];
	if([result hasPrefix:@"."]) {
		result = [NSString stringWithFormat:@"0%@",result];
	}
	return result;
}

- (id)safeNumber {
	if(self == nil) {
		return [NSNull null];
	}
	return self;
}

-(NSString*)jsonBool {
	if(self == nil || [self boolValue] == NO) {
		return @"false";
	}
	return @"true";
}
@end
