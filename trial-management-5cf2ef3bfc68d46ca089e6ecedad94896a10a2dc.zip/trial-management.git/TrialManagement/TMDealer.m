//
//  TMDealer.m
//  TrialManagement
//
//  Created by Jason Ludwig on 6/17/14.
//  Copyright (c) 2014 Monsanto. All rights reserved.
//

#import "TMDealer.h"


@implementation TMDealer

@dynamic accountId;
@dynamic address1;
@dynamic address2;
@dynamic category;
@dynamic city;
@dynamic country;
@dynamic dealerId;
@dynamic email;
@dynamic faxNumber;
@dynamic name;
@dynamic phoneNumber;
@dynamic postalCode;
@dynamic state;
@dynamic trials;
@dynamic users;

@end
