#import "TMFieldObservationModel.h"

@interface TMFieldObservationModel()
@property (nonatomic) TMTrialModel *trialModel;
@end

@implementation TMFieldObservationModel

- (instancetype)initWithTrialModel:(TMTrialModel*)trialModel {
	self = [super init];
	if(self) {
		self.trialModel = trialModel;
	}
	return self;
}

-(BOOL)hasObservations {
	return [self.trialModel hasFieldInfoObservations];
}

- (NSArray*)fieldInfoObservations {
	return [self.trialModel fieldInfoObservations];
}
@end
