#import "MONLabeledDateTextFieldButton.h"
#import "MONDimensions.h"

static const CGFloat DefaultButtonWidth = 115.0;

@interface MONLabeledDateTextFieldButton() <UITextViewDelegate>
@property (nonatomic) MONDateTextFieldButton *dateTextFieldButton;
@end

@implementation MONLabeledDateTextFieldButton

- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
		self.labelLocation = MONLabeledControlLabelLocationLeft;
		
		self.dateTextFieldButton = [[MONDateTextFieldButton alloc] initWithFrame:frame];
		self.controlView = self.dateTextFieldButton;
	}
    return self;
}

- (void)layoutSubviews {
	[super layoutSubviews];
	
	[self.dateTextFieldButton sizeToFit];
	self.dateTextFieldButton.frame = CGRectMake(CGRectGetMaxX(self.label.frame) + MONDimensionsSmallPadding,
										  CGRectGetMinY(self.label.frame),
										  DefaultButtonWidth,
										  CGRectGetHeight(self.bounds));
}

- (CGSize)sizeThatFits:(CGSize)size {
	CGSize sizeThatFits = CGSizeZero;
	[self.label sizeToFit];
	[self.dateTextFieldButton sizeToFit];
	sizeThatFits.width = CGRectGetWidth(self.label.frame);
	sizeThatFits.width += MONDimensionsSmallPadding;
	sizeThatFits.width += DefaultButtonWidth;
	
	sizeThatFits.height += CGRectGetHeight(self.dateTextFieldButton.frame);
	return sizeThatFits;
}

- (void)showErrorMessage:(NSString*)errorMessage {
	[self.dateTextFieldButton showErrorMessage:errorMessage];
}

- (BOOL)isEnabled {
	return self.dateTextFieldButton.enabled;
}

- (void)setEnabled:(BOOL)enabled {
	self.dateTextFieldButton.enabled = enabled;
}

- (NSDate*)maximumDate {
	return self.dateTextFieldButton.maximumDate;
}

- (void)setMaximumDate:(NSDate *)maximumDate {
	[self.dateTextFieldButton setMaximumDate:maximumDate];
}

- (NSDate*)minimumDate {
	return self.dateTextFieldButton.minimumDate;
}

- (void)setMinimumDate:(NSDate *)minimumDate {
	[self.dateTextFieldButton setMinimumDate:minimumDate];
}

- (void)setDate:(NSDate*)date {
	[self.dateTextFieldButton setDateTextField:date];
}

- (id<MONDateTextFieldButtonDelegate>)dateDelegate {
	return self.dateTextFieldButton.dateDelegate;
}

- (void)setDateDelegate:(id<MONDateTextFieldButtonDelegate>)dateDelegate {
	self.dateTextFieldButton.dateDelegate = dateDelegate;
}

- (void)setLabelFont:(UIFont*)font {
	self.label.font = font;
}

- (void)setLabelText:(NSString*)text {
	self.label.text = text;
}

- (void)setPlaceholderText:(NSString *)placeholderText {
	[self.dateTextFieldButton setPlaceholderText:placeholderText];
}

@end
