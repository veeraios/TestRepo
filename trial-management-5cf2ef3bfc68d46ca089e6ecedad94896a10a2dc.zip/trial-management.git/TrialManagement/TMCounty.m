//
//  TMCounty.m
//  TrialManagement
//
//  Created by Jason Ludwig on 8/13/14.
//  Copyright (c) 2014 Monsanto. All rights reserved.
//

#import "TMCounty.h"


@implementation TMCounty

@dynamic countyId;
@dynamic name;
@dynamic fipscode;
@dynamic state;
@dynamic trialEmailCounties;
@dynamic trialPostCards;
@dynamic trials;

@end
