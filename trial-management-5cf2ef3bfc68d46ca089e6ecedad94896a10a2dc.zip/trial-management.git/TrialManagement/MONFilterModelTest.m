#import "MONFilterModel.h"

@interface MONFilterModelTest : XCTestCase

@property (nonatomic) MONFilterModel *testObject;
@property (nonatomic) id mockFilterModelObserver;
@property (nonatomic) id mockFilter;

@end

@implementation MONFilterModelTest

- (void)setUp {
	[super setUp];
	
	self.mockFilter = [OCMockObject niceMockForProtocol:@protocol(MONFilter)];
	
	self.testObject = [[MONFilterModel alloc] initWithFilter:self.mockFilter];
	
	self.mockFilterModelObserver = [OCMockObject niceMockForProtocol:@protocol(MONFilterModelObserver)];
	[self.testObject escAddObserver:self.mockFilterModelObserver];

}

- (void)testCancelFilter_NotifiesObservers {
	[[self.mockFilterModelObserver expect] filterCancelled];
	
	[self.testObject cancelFilter];
	
	[self.mockFilterModelObserver verify];	
}

- (void)testCancelFilter_ResetsFilteredItems {
	NSArray *expectedAllItemsArray = @[[[NSObject alloc] init], [[NSObject alloc] init], [[NSObject alloc] init]];
	NSArray *expectedFilteredItemsArray = @[[[NSObject alloc] init], [[NSObject alloc] init]];
	NSString *expectedFilterText = @"filterText";
	[self.testObject setAllItemsArray:expectedAllItemsArray];
	[[[self.mockFilter stub] andReturn:expectedFilteredItemsArray] filteredArrayFromArray:expectedAllItemsArray filterText:expectedFilterText];
	[self.testObject filterItemsWithText:expectedFilterText];
	XCTAssertEqualObjects([self.testObject filteredItems], expectedFilteredItemsArray);
	[self.testObject cancelFilter];
	
	NSArray *actualFilteredItems = [self.testObject filteredItems];
	
	XCTAssertEqualObjects(actualFilteredItems, expectedAllItemsArray);
}

- (void)testFilterItemsWithText_DelegatesToFilter {
	NSString *expectedFilterText = @"filter text";
	NSArray *expectedAllItemsArray = @[[[NSObject alloc] init], [[NSObject alloc] init], [[NSObject alloc] init]];
	[self.testObject setAllItemsArray:expectedAllItemsArray];
	[[self.mockFilter expect] filteredArrayFromArray:expectedAllItemsArray filterText:expectedFilterText];
	
	[self.testObject filterItemsWithText:expectedFilterText];
	
	[self.mockFilter verify];
}

- (void)testFilterItemsWithText_IfTextIsBlank_ResetFilter {
	NSString *expectedFilterString = @"";
	NSArray *expectedAllItemsArray = @[[[NSObject alloc] init], [[NSObject alloc] init], [[NSObject alloc] init]];
	NSArray *expectedFilteredItemsArray = @[[[NSObject alloc] init], [[NSObject alloc] init]];
	[self.testObject setAllItemsArray:expectedAllItemsArray];
	[[[self.mockFilter stub] andReturn:expectedFilteredItemsArray] filteredArrayFromArray:expectedAllItemsArray filterText:expectedFilterString];
	[self.testObject filterItemsWithText:expectedFilterString];
	
	NSArray *actualFilteredItems = [self.testObject filteredItems];
	
	XCTAssertEqualObjects(actualFilteredItems, expectedAllItemsArray);
}


- (void)testFilterItemsWithText_NotifiesObservers {
	NSString *expectedFilterText = @"123";
	[[self.mockFilter expect] filteredArrayFromArray:[OCMArg any] filterText:expectedFilterText];
	[[self.mockFilterModelObserver expect] filterUpdated];
	
	[self.testObject filterItemsWithText:expectedFilterText];
	
	[self.mockFilterModelObserver verify];
}

- (void)testFilteredItemAtIndex_ProvidesCorrectItem {
	NSObject *item1 = [[NSObject alloc] init];
	NSObject *item2 = [[NSObject alloc] init];
	NSObject *item3 = [[NSObject alloc] init];
	NSArray *allItemsArray = @[item1, item2, item3];
	[self.testObject setAllItemsArray:allItemsArray];
	
	NSObject *actualItem = [self.testObject filteredItemAtIndex:2];
	
	XCTAssertEqualObjects(actualItem, item3);
}

- (void)testFilterItemsWithText_UpdatesFilteredItemsArray {
	NSString *expectedFilterText = @"filter text";
	NSArray *expectedAllItemsArray = @[[[NSObject alloc] init], [[NSObject alloc] init], [[NSObject alloc] init]];
	NSArray *expectedFilteredItemsArray = @[[[NSObject alloc] init], [[NSObject alloc] init]];
	[self.testObject setAllItemsArray:expectedAllItemsArray];
	[[[self.mockFilter stub] andReturn:expectedFilteredItemsArray] filteredArrayFromArray:expectedAllItemsArray filterText:expectedFilterText];
	[self.testObject filterItemsWithText:expectedFilterText];
	
	NSArray *actualFilteredItemsArray = [self.testObject filteredItems];
	
	XCTAssertEqualObjects(actualFilteredItemsArray, expectedFilteredItemsArray);
}

- (void)testItemsWereFiltered_TrueWhenFilterTextIsValid {
    NSArray *testAllItems = @[[[NSObject alloc] init], [[NSObject alloc] init], [[NSObject alloc] init]];
    NSArray *testFilteredItems = @[[[NSObject alloc] init]];
    
    [self.testObject setAllItemsArray:testAllItems];
    [[[self.mockFilter stub] andReturn:testFilteredItems] filteredArrayFromArray:testAllItems filterText:[OCMArg any]];
    [self.testObject filterItemsWithText:@"filter"];
    
    XCTAssert([self.testObject itemsWereFiltered]);
}

- (void)testItemsWereFiltered_FalseWhenFilterTextIsEmpty {
    NSArray *testAllItems = @[[[NSObject alloc] init], [[NSObject alloc] init], [[NSObject alloc] init]];
    
    [self.testObject setAllItemsArray:testAllItems];
    [[self.mockFilter reject] filteredArrayFromArray:[OCMArg any] filterText:[OCMArg any]];
    [self.testObject filterItemsWithText:@""];
    
    XCTAssertFalse([self.testObject itemsWereFiltered]);
    [self.mockFilter verify];
}

@end
