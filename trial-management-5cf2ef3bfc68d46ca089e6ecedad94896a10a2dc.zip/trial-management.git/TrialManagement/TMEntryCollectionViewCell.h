#import <UIKit/UIKit.h>

@class TMEntryCollectionViewCell;
@protocol TMEntryCollectionViewCellDelegate <NSObject>

- (void)entryCollectionViewCell:(TMEntryCollectionViewCell *)entryCollectionViewCell addTreatmentsTappedInView:(UIView *)addTreatmentsView;
- (void)deleteTreatmentButtonTapped:(TMEntryCollectionViewCell *)cell;
- (void)deleteButtonTapped:(TMEntryCollectionViewCell *)cell;
- (void)replaceButtonTapped:(TMEntryCollectionViewCell *)cell;

@end

@interface TMEntryCollectionViewCell : UICollectionViewCell

@property (nonatomic,weak) id<TMEntryCollectionViewCellDelegate> delegate;

- (void)setIsReadOnly:(BOOL)isReadOnly;
- (void)setReplaceButtonAvailable:(BOOL)replaceAvailable;
- (void)setNumber:(NSInteger)number;
- (void)setBrand:(NSString *)brand;
- (void)setProduct:(NSString *)product;
- (void)setRMValue:(NSDecimalNumber *)rmValue;
- (void)setTrait:(NSString *)trait;
- (void)setTreatment:(NSString *)treatment;

@end
