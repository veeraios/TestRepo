#import "TMBrandModel.h"
#import "TMBrand.h"

@interface TMBrandModel ()

@property (nonatomic) NSArray *dataArray;

@end

@implementation TMBrandModel
-(instancetype)initWithDataSource:(NSArray*)dataSource {
	self = [super init];
	if (self) {
		self.dataArray = dataSource;
	}
	return self;
}

- (NSString *)nameForItemAtIndex:(NSInteger)index {
	TMBrand *dataObject = (TMBrand*)[self.dataArray objectAtIndex:index];
	return dataObject.name;
}

- (NSString *)nameForItem:(id)item {
    return [[self dataArray] containsObject:item] ? ((TMBrand *)item).name : @"";
}

- (NSInteger)indexForItem:(id)item {
    return [[self dataArray] indexOfObject:item];
}
@end
