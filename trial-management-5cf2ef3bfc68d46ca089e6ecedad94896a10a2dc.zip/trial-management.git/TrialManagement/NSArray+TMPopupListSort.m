#import "NSArray+TMPopupListSort.h"

@implementation NSArray (TMPopupListSort)

-(NSArray*)sortPopupListByKey:(NSString*)key {
	NSCharacterSet *charactersToRemove = [[NSCharacterSet alphanumericCharacterSet] invertedSet];
	
	NSSortDescriptor *sortDescriptor = [NSSortDescriptor sortDescriptorWithKey:key
																	 ascending:YES
																	comparator:^NSComparisonResult(NSString *name1, NSString *name2) {
																		
																		if (![name1 isKindOfClass:[NSString class]] || ![name2 isKindOfClass:[NSString class]]) {
																			return ([name1 compare:name2]);
																		}
																		
																		NSString *trimmedName1 = [[name1 componentsSeparatedByCharactersInSet:charactersToRemove] componentsJoinedByString:@""];
																		
																		NSString *trimmedName2 = [[name2 componentsSeparatedByCharactersInSet:charactersToRemove] componentsJoinedByString:@""];
																		
																		
																		return [trimmedName1 caseInsensitiveCompare:trimmedName2];
																	}];
	
	return [self sortedArrayUsingDescriptors:[NSArray arrayWithObject:sortDescriptor]];

}
@end
