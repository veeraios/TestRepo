static const CGFloat CooperatorLabelWidthPercent = 40.0;
static const CGFloat StateLabelWidthPercent = 15.0;
static const CGFloat CityLabelWidthPercent = 30.0;
static const CGFloat PostalCodeLabelWidthPercent = 15.0;