#import "TMEntryCollectionViewCell.h"
#import "MONCardContainerView.h"
#import "MONDimensions.h"
#import "MONColors.h"
#import "TMEntryCollectionCellContentView.h"
#import "UIColor+MONThemeColorProvider.h"

@interface TMEntryCollectionViewCell ()<TMEntryCollectionCellContentViewDelegate>

@property (nonatomic) TMEntryCollectionCellContentView *entryCollectionCellContentView;
@property (nonatomic) UISwipeGestureRecognizer *leftSwipeGestureRecognizer;
@property (nonatomic) UISwipeGestureRecognizer *rightSwipeGestureRecognizer;
@property (nonatomic) UIButton *deleteButton;
@property (nonatomic) UIButton *replaceButton;
@property (nonatomic) BOOL replaceButtonAvailableForEntry;

@end

@implementation TMEntryCollectionViewCell

- (id)initWithFrame:(CGRect)frame {
	self = [super initWithFrame:frame];
	if (self) {
		self.backgroundColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeBackground];

		self.deleteButton = [[UIButton alloc] init];
        self.deleteButton.backgroundColor = [MONColors pomegranateColor];
        self.deleteButton.layer.cornerRadius = MONDimensionsCornerRadius;
		[self.deleteButton setImage:[UIImage imageNamed:@"ui-icon-remove-entry"] forState:UIControlStateNormal];
		[self.deleteButton addTarget:self action:@selector(deleteButtonTapped) forControlEvents:UIControlEventTouchUpInside];
        [self.contentView addSubview:self.deleteButton];

        self.replaceButton = [[UIButton alloc] init];
        self.replaceButton.backgroundColor = [UIColor orangeColor];
        self.replaceButton.layer.cornerRadius = MONDimensionsCornerRadius;
        [self.replaceButton setImage:[UIImage imageNamed:@"ui-icon-replace-product"] forState:UIControlStateNormal];
        [self.replaceButton addTarget:self action:@selector(replaceButtonTapped) forControlEvents:UIControlEventTouchUpInside];
        [self.contentView addSubview:self.replaceButton];
        
		self.entryCollectionCellContentView = [[TMEntryCollectionCellContentView alloc] init];
        self.entryCollectionCellContentView.delegate = self;

		[self.contentView addSubview:self.entryCollectionCellContentView];
		
		self.leftSwipeGestureRecognizer = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(leftSwipeGestureDetected)];
		self.leftSwipeGestureRecognizer.direction = UISwipeGestureRecognizerDirectionLeft;
		[self addGestureRecognizer:self.leftSwipeGestureRecognizer];
		
		self.rightSwipeGestureRecognizer = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(rightSwipeGestureDetected)];
		self.rightSwipeGestureRecognizer.direction = UISwipeGestureRecognizerDirectionRight;
		[self addGestureRecognizer:self.rightSwipeGestureRecognizer];
        
        self.replaceButtonAvailableForEntry = YES;
	}
	return self;
}

-(void)setIsReadOnly:(BOOL)isReadOnly {
	[self removeGestureRecognizer:self.leftSwipeGestureRecognizer];
	[self removeGestureRecognizer:self.rightSwipeGestureRecognizer];

	if(!isReadOnly) {
		[self addGestureRecognizer:self.leftSwipeGestureRecognizer];
		[self addGestureRecognizer:self.rightSwipeGestureRecognizer];
	}
	[self.entryCollectionCellContentView setIsReadOnly:isReadOnly];
}

- (void)setReplaceButtonAvailable:(BOOL)replaceAvailable {
    self.replaceButtonAvailableForEntry = replaceAvailable;
}

- (void)prepareForReuse {
	[super prepareForReuse];
	
	[self showOptionsMenu:NO animated:NO];
}

- (void)layoutSubviews {
	[super layoutSubviews];

    [self.deleteButton sizeToFit];
    [self.replaceButton sizeToFit];

    CGFloat buttonSquareDimen = CGRectGetHeight(self.bounds);
    
    self.deleteButton.frame = CGRectMake(CGRectGetMaxX(self.bounds) - buttonSquareDimen,
                                         0.0,
                                         buttonSquareDimen,
                                         buttonSquareDimen);

    self.replaceButton.frame = self.deleteButton.frame;

	self.entryCollectionCellContentView.frame = self.bounds;
}

- (void)deleteButtonTapped {
	[self.delegate deleteButtonTapped:self];
}

- (void)replaceButtonTapped {
    [self.delegate replaceButtonTapped:self];
}

- (void)leftSwipeGestureDetected {
	[self showOptionsMenu:YES animated:YES];
}

- (void)rightSwipeGestureDetected {
	[self showOptionsMenu:NO animated:YES];
}

- (void)showOptionsMenu:(BOOL)showOptionsMenu animated:(BOOL)animated {

    CGRect replaceButtonAnimatedFrame = self.replaceButton.frame;
    replaceButtonAnimatedFrame.origin.x = (CGRectGetMinX(self.deleteButton.frame) - (showOptionsMenu && self.replaceButtonAvailableForEntry ? CGRectGetWidth(self.deleteButton.bounds) : 0.0));
    
    [self.replaceButton setUserInteractionEnabled:self.replaceButtonAvailableForEntry];
    [self.replaceButton setHidden:!self.replaceButtonAvailableForEntry];
    
    CGRect contentContainerViewFrame = self.entryCollectionCellContentView.frame;
    contentContainerViewFrame.origin.x = showOptionsMenu ? (CGRectGetMinX(replaceButtonAnimatedFrame) - CGRectGetWidth(self.entryCollectionCellContentView.bounds)) : 0.0;
	
	void (^animationBlock)(void) = ^{
		self.entryCollectionCellContentView.frame = contentContainerViewFrame;
        self.replaceButton.frame = replaceButtonAnimatedFrame;
	};
	
	if (animated) {
		[UIView animateWithDuration:0.25
							  delay:0.0
							options:UIViewAnimationOptionBeginFromCurrentState
						 animations:animationBlock
						 completion:nil];
	} else {
		animationBlock();
	}
}

- (void)setNumber:(NSInteger)number {
	[self.entryCollectionCellContentView setNumber:number];
}

- (void)setBrand:(NSString *)brand {
	[self.entryCollectionCellContentView setBrand:brand];
}

- (void)setProduct:(NSString *)product {
	[self.entryCollectionCellContentView setProduct:product];
}

- (void)setRMValue:(NSDecimalNumber *)rmValue {
	[self.entryCollectionCellContentView setRMValue:rmValue];
}

- (void)setTrait:(NSString *)trait {
	[self.entryCollectionCellContentView setTrait:trait];
}

- (void)setTreatment:(NSString *)treatment {
	[self.entryCollectionCellContentView setTreatment:treatment];
}

- (void)setSelected:(BOOL)selected {
	[super setSelected:selected];
	
	UIColor *backgroundColor = nil;
	
	backgroundColor = selected ? [UIColor colorForThemeComponentType:MONThemeComponentTypeText]: [UIColor colorForThemeComponentType:MONThemeComponentTypeSelectedText];
	
	self.entryCollectionCellContentView.contentContainerView.backgroundColor = backgroundColor;
	[self.entryCollectionCellContentView setSelected:selected];
}

#pragma mark - TMEntryCollectionCellContentViewDelegate Methods

- (void)entryCollectionCellContentAddTreatmentTapped:(UIView *)view {
	[self.delegate entryCollectionViewCell:self addTreatmentsTappedInView:view];
}

- (void)deleteTreatmentButtonTapped {
	[self.delegate deleteTreatmentButtonTapped:self];
	[self.entryCollectionCellContentView setTreatment:nil];
}

@end
