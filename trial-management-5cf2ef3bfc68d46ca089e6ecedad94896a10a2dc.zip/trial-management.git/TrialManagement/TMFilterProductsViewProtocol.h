//
//  TMFilterProductsViewProtocol.h
//  TrialManagement
//
//  Created by SINGH, SUPREET [AG/1000] on 11/10/14.
//  Copyright (c) 2014 Monsanto. All rights reserved.
//
#import <Foundation/Foundation.h>

@protocol TMFilterProductsViewDelegate<NSObject>

- (void)brandSearchTextChanged:(NSString *)brandSearchText;
- (void)productSearchTextChanged:(NSString *)productSearchText;
- (void)traitsSearchTextChanged:(NSString *)traitsSearchText;
- (void)rmSearchTextChanged:(NSString *)rmSearchText;
- (void)rmVarianceSearchTextChanged:(NSString *)rmVarianceSearchText;

@end

@protocol TMFilterProductsView<NSObject>

- (void)setFilterProductsViewDelegate:(NSObject<TMFilterProductsViewDelegate> *)filterProductsViewDelegate;
- (void)refreshTableWithNumberOfResults:(NSUInteger)numberOfResults;

@end
