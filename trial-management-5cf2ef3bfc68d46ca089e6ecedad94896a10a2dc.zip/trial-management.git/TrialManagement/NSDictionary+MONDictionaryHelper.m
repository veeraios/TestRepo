#import "NSDictionary+MONDictionaryHelper.h"
#import "NSDictionary+TMBlocks.h"

@implementation NSDictionary (MONDictionaryHelper)

- (id)safeObjectForKey:(NSString *)key {
	id object = [self objectForKey:key];
	if ([object isEqual:[NSNull null]]) {
		object = nil;
	}
	return object;
}

- (NSDictionary *)replaceNullObjectsWithObject:(id)replacementObject {
	NSMutableDictionary *unnullableDictionary = [self mutableCopy];
	NSArray *nullObjects = [unnullableDictionary allKeysForObject:[NSNull null]];
	for (id key in nullObjects) {
		[unnullableDictionary setObject:replacementObject forKey:key];
	}
	return unnullableDictionary;
}

- (NSDictionary*)dictionaryWithOnlyValuesOfClass:(Class)theClass {
	NSDictionary *dictOfType = [self where:^BOOL(id key, id obj) {
		return [[self objectForKey:key] isKindOfClass:theClass];
	}];
	return dictOfType;
}
@end
