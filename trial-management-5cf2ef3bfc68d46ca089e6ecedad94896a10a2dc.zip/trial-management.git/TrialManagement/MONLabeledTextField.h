#import "MONLabeledControl.h"
#import <UIKit/UIKit.h>

typedef NS_ENUM(NSInteger, MONLabeledTextFieldLocation) {
	MONLabeledTextFieldLocationTop,
	MONLabeledTextFieldLocationLeft,
	MONLabeledTextFieldLocationHide
};


@class MONLabeledTextField;

@protocol MONLabeledTextFieldDelegate <NSObject>

@optional
- (void)monLabeledTextFieldDidBeginEditing:(MONLabeledTextField *)labeledTextField;
- (void)monLabeledTextFieldTextDidChange:(MONLabeledTextField *)labeledTextField;
- (void)monLabeledTextFieldTextDidEndEditing:(MONLabeledTextField *)labeledTextField;
- (BOOL)monLabeledTextField:(MONLabeledTextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string;

@end

@interface MONLabeledTextField : MONLabeledControl

@property (nonatomic, weak) id<MONLabeledTextFieldDelegate> delegate;
@property (nonatomic) NSString *textFieldText;
@property (nonatomic) BOOL enabled;

- (void)setValueText:(NSString *)valueText;
- (void)setTextFieldPlaceholderText:(NSString *)placeholderText;
- (void)setAutocorrectionType:(UITextAutocorrectionType)autocorrectionType;
- (void)shouldDismissKeyboardWithReturnKey:(BOOL)value;
- (void)allowOnlyNumbers:(BOOL)value;
- (void)setKeyboardType:(UIKeyboardType)keyboardType;
- (void)setLockedColor;
- (void)setLabelLocation:(MONLabeledTextFieldLocation)location;

@end
