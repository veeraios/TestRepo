#import <UIKit/UIKit.h>
#import "MONDatePicker.h"
#import "MONTextFieldButton.h"

extern NSString * const MONDatePopoverButtonDidShowPopover;

@protocol MONDateTextFieldButtonDelegate <NSObject>
- (void)dateChanged:(NSDate*)date;
@optional
- (BOOL)isSelectedDateValid:(NSDate*)date;
@end

@interface MONDateTextFieldButton : MONTextFieldButton
@property (nonatomic, weak) id<MONDateTextFieldButtonDelegate> dateDelegate;
@property (nonatomic) NSDate * maximumDate;
@property (nonatomic) NSDate * minimumDate;
@property (nonatomic, readonly) NSDate *date;
- (void)setDateTextField:(NSDate*)date;
- (void)showErrorMessage:(NSString*)errorMessage;
@end
