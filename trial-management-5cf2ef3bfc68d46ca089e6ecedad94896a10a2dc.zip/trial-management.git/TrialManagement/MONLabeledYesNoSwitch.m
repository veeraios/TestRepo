#import "MONLabeledYesNoSwitch.h"
#import "MONLabel.h"
#import "MONFonts.h"
#import "MONDimensions.h"
#import "MONUIConvenienceFunctions.h"
#import "UIColor+MONThemeColorProvider.h"

static const CGFloat LabelTextSize = 16.0;

@interface MONLabeledYesNoSwitch()

@property (nonatomic) MONLabel *label;

@end

@implementation MONLabeledYesNoSwitch

- (id)initWithTitle:(NSString*)title borderColor:(UIColor*)borderColor defaultValue:(BOOL)defaultValue {
	self = [self initWithTitle:title borderColor:borderColor];
	[self.yesNoSwitch setSwitchValue:defaultValue];
	return self;
}

- (id)initWithTitle:(NSString*)title borderColor:(UIColor*)borderColor {
	self = [self initWithTitle:title];
	[self setBorderColor:borderColor];
	return self;
}

- (id)initWithTitle:(NSString *)title {
    self = [super init];
    if (self) {
		self.label = [[MONLabel alloc] init];
		self.label.font = [UIFont fontWithName:OpenSansBold size:LabelTextSize];
		[self.label setText:title];
		[self.label setTextColor:[UIColor colorForThemeComponentType:MONThemeComponentTypeText]];
		[self.contentContainerView addSubview:self.label];
		
		self.yesNoSwitch = [[MONYesNoSwitch alloc] init];
		[self.contentContainerView addSubview:self.yesNoSwitch];
	}
    return self;
}

- (id)initWithTitle:(NSString*)title defaultValue:(BOOL)defaultValue {
	self = [self initWithTitle:title];
	[self.yesNoSwitch setSwitchValue:defaultValue];
	return self;
}

- (void)layoutSubviews {
	[super layoutSubviews];
	
	[self.yesNoSwitch sizeToFit];
	self.yesNoSwitch.frame = CGRectMake(CGRectGetMaxX(self.contentContainerView.bounds) - CGRectGetWidth(self.yesNoSwitch.frame) - MONDimensionsSmallPadding,
										MONUIScreenRoundToScreenScale((CGRectGetMaxY(self.contentContainerView.bounds) - CGRectGetHeight(self.yesNoSwitch.frame)) / 2.0),
										CGRectGetWidth(self.yesNoSwitch.frame),
										CGRectGetHeight(self.yesNoSwitch.frame));
	
	[self.label sizeToFit];
	self.label.frame = CGRectMake(MONDimensionsSmallPadding,
								  MONUIScreenRoundToScreenScale((CGRectGetMaxY(self.contentContainerView.bounds) - CGRectGetHeight(self.label.frame)) / 2.0),
								  CGRectGetWidth(self.label.frame),
								  CGRectGetHeight(self.label.frame));
	
	
	
}

- (CGSize)sizeThatFits:(CGSize)size {
	CGSize sizeThatFits = CGSizeZero;
	[self.label sizeToFit];
	[self.yesNoSwitch sizeToFit];
	
	sizeThatFits.width += CGRectGetWidth(self.label.frame);
	sizeThatFits.width += MONDimensionsSmallPadding * 2.0;
	sizeThatFits.width += CGRectGetWidth(self.yesNoSwitch.frame);
	
	sizeThatFits.height += MAX(CGRectGetHeight(self.label.frame), CGRectGetHeight(self.yesNoSwitch.frame));
	sizeThatFits.height += 2.0 * MONDimensionsSmallPadding;
	
	
	return sizeThatFits;
}



@end
