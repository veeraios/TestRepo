//
//  TMMergeSectionViewModel.swift
//  TrialManagement
//
//  Created by SINGH, SUPREET [AG/1000] on 2/11/15.
//  Copyright (c) 2015 Monsanto. All rights reserved.
//

import UIKit

class TMMergeSectionViewModel: NSObject {
    let section: TMMergeSection
    let mergeGroups: [TMMergeGroupViewModel]
    
    init(section: TMMergeSection, mergeGroups: [TMMergeGroupViewModel]) {
        self.section = section
        self.mergeGroups = mergeGroups
        super.init()
    }
}
