#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@protocol MONDataModelMigration <NSObject>

- (NSPersistentStoreCoordinator *)lightweightMigrationToCurrentVersionForStore:(NSURL *)storeURL;
- (NSManagedObjectModel *)modelForCurrentVersion;

@end
