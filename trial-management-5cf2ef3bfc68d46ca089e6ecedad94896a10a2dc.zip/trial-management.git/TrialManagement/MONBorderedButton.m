#import "MONBorderedButton.h"
#import "MONDimensions.h"
#import "UIColor+MONThemeColorProvider.h"

@implementation MONBorderedButton

- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
		self.backgroundColor = [UIColor clearColor];
		[self setTitleColor:[UIColor colorForThemeComponentType:MONThemeComponentTypeText] forState:UIControlStateNormal];
		[self.layer setBorderColor:[UIColor colorForThemeComponentType:MONThemeComponentTypeThickBorder].CGColor];
		[self setBorderWidth:MONDimensionsThickBorderWidth];
    }
    return self;
}

- (void)setBorderWidth:(CGFloat)borderWidth {
	[self.layer setBorderWidth:borderWidth];
	[self setNeedsLayout];
}

@end
