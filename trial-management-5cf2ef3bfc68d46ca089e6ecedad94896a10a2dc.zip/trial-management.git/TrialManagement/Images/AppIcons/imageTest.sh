#!/bin/sh

args=("$@")
IMGPATH=$args

DIMEN=`/opt/local/bin/identify -verbose $IMGPATH |grep "Geometry: "|grep -o "[[:digit:]]*x[[:digit:]]*"|grep -o "[[:digit:]]*"`
BOUND=`echo "sqrt(($DIMEN*$DIMEN)/2)/2"|bc`
ORIGIN=`echo "-1*$BOUND"|bc`
CURVE=`echo "$BOUND/10"|bc`

/opt/local/bin/mogrify -fill red -draw "rotate 45 roundrectangle $ORIGIN,$ORIGIN $BOUND,$BOUND $CURVE,$CURVE" -fill white -pointsize 17 -weight bold -region 22x25+5+5 +repage -draw "gravity center text 0,0 'T'" +region -fill yellow -draw "roundrectangle 84,84 143,107 6,6" -fill red -pointsize 10 -region 60x24+85+85 +repage -draw "gravity center text 0,0 '`/usr/libexec/PlistBuddy -c "Print :CFBundleShortVersionString" "${SRCROOT}/TrialManagement/TrialManagement-Info.plist"`'" $IMGPATH
