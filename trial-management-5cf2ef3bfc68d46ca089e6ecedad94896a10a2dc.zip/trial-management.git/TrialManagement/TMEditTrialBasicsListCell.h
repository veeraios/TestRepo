#import "MONSingleSelectionCardCollectionViewCell.h"
#import "TMReferenceListDataModel.h"

@interface TMEditTrialBasicsListCell : MONSingleSelectionCardCollectionViewCell
//todo: these should be reference lists
	@property (nonatomic) id<TMDataModel> cellModel;
@end
