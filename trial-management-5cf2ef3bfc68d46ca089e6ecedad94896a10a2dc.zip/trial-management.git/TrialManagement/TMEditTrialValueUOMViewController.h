#import <UIKit/UIKit.h>
#import "TMValueUOMModel.h"

@interface TMEditTrialValueUOMViewController : UIViewController

@property (nonatomic, readonly) NSNumber *value;
@property (nonatomic, readonly) NSString *selectedUnitOfMeasure;

- (instancetype)init UNAVAILABLE_ATTRIBUTE;
- (instancetype)initWithTitle:(NSString *)title
			   unitOfMeasures:(NSArray *)unitOfMeasures
						value:(NSNumber *)value
		selectedUnitOfMeasure:(NSString *)selectedUnitOfMeasure;

@end
