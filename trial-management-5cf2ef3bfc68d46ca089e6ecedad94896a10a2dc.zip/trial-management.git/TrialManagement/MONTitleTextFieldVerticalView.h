#import <UIKit/UIKit.h>

@interface MONTitleTextFieldVerticalView : UIView

- (void)setTitleText:(NSString *)titleText;
- (void)setTextFieldText:(NSString *)textFieldText;

@end
