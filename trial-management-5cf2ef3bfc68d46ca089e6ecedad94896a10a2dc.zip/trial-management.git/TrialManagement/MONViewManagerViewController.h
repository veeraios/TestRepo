#import <UIKit/UIKit.h>

@interface MONViewManagerViewController : UIViewController

- (instancetype)initWithLoginViewController:(UIViewController *)loginViewController rootViewController:(UIViewController *)rootViewController;
- (void)popToLoginViewAnimated:(BOOL)animated;
- (void)pushRootViewAnimated:(BOOL)animated;

@end
