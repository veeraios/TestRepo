#import "MONSegmentedControl.h"

@interface MONYesNoSwitch : MONSegmentedControl
- (void)setSwitchValue:(BOOL)value;
- (BOOL)switchValue;
@end
