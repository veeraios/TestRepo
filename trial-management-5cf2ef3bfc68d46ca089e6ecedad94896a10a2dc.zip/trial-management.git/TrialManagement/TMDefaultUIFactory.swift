//
//  MONDefaultUIFactory.swift
//  TrialManagement
//
//  Created by SINGH, SUPREET [AG/1000] on 1/28/15.
//  Copyright (c) 2015 Monsanto. All rights reserved.
//

import UIKit

class TMDefaultUIFactory: NSObject {

    class func createHeaderView(title: NSString, numberOfItems: Int) -> MONHeaderView {
        let headerView = MONHeaderView(frame: CGRectZero)
        headerView.showNumberOfItems(true)
        headerView.setNumberOfItems(UInt(numberOfItems))
        headerView.setAlertColorForItemCount()
        headerView.setTitle(title)
        headerView.showBottomBorder(false)
        return headerView
    }
    
    class func createDefaultBoldLabel(text: NSString, size: CGFloat, numberOfLines: Int) -> UILabel {
        return self.createDefaultLabel(text, size: size, numberOfLines: numberOfLines, bold: true)
    }
    
    class func createDefaultLabel(text: NSString, size: CGFloat, numberOfLines: Int) -> UILabel {
        return self.createDefaultLabel(text, size: size, numberOfLines: numberOfLines, bold: false)
    }

    private class func createDefaultLabel(text: NSString, size: CGFloat, numberOfLines: Int, bold: Bool) -> UILabel {
        let label = UILabel()
        label.font = UIFont(name: bold ? OpenSansBold : OpenSansSemibold, size: size)
        label.textColor = UIColor(forThemeComponentType: MONThemeComponentTypeText)
        label.textAlignment = NSTextAlignment.Center
        label.lineBreakMode = NSLineBreakMode.ByWordWrapping
        label.numberOfLines = numberOfLines
        label.text = text
        return label
    }
    
    class func createTitleLabel(text: NSString) -> UILabel {
        let label = UILabel()
        label.font = UIFont(name: OpenSansBold, size: 14)
        label.textColor = UIColor(forThemeComponentType: MONThemeComponentTypeText)
        label.textAlignment = NSTextAlignment.Right
        label.text = String(format: "%@:", arguments: [text])
        return label
    }

    class func createConflictValueLabel(text: NSString) -> UILabel {
        let label = UILabel()
        label.font = UIFont(name: OpenSansBoldItalic, size: 14)
        label.textColor = UIColor(forThemeComponentType: MONThemeComponentTypeHighlight)
        label.textAlignment = NSTextAlignment.Left
        label.text = String(format: "● %@", arguments: [text])
        return label
    }

    class func createRegularValueLabel(text: NSString) -> UILabel {
        let label = UILabel()
        label.font = UIFont(name: OpenSans, size: 14)
        label.textColor = UIColor(forThemeComponentType: MONThemeComponentTypeText)
        label.textAlignment = NSTextAlignment.Left        
        label.text = String(format: "     %@", arguments: [text])
        return label
    }

    
}
