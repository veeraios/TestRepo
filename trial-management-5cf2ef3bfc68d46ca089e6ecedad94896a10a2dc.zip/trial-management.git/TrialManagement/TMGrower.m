//
//  TMGrower.m
//  TrialManagement
//
//  Created by Jason Ludwig on 6/17/14.
//  Copyright (c) 2014 Monsanto. All rights reserved.
//

#import "TMGrower.h"


@implementation TMGrower

@dynamic accountId;
@dynamic address1;
@dynamic address2;
@dynamic category;
@dynamic city;
@dynamic country;
@dynamic email;
@dynamic faxNumber;
@dynamic growerId;
@dynamic name;
@dynamic phoneNumber;
@dynamic postalCode;
@dynamic state;
@dynamic trials;
@dynamic users;

@end
