#import "MONFilter.h"
#import <ESCObservable/ESCObservable.h>
#import <Foundation/Foundation.h>

@protocol MONFilterModelObserver <NSObject>

@optional
- (void)filterUpdated;
- (void)filterCancelled;

@end

@interface MONFilterModel : NSObject<ESCObservable>

- (instancetype)init UNAVAILABLE_ATTRIBUTE;
- (instancetype)initWithFilter:(id<MONFilter>)filter;
- (void)filterItemsWithText:(NSString *)filterText;
- (id)filteredItemAtIndex:(NSInteger)index;
- (void)cancelFilter;
- (void)setAllItemsArray:(NSArray *)allItemsArray;
- (NSArray *)filteredItems;
- (BOOL)itemsWereFiltered;

@end
