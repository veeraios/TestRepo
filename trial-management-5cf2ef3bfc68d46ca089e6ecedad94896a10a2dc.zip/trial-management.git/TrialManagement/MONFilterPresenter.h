#import "MONFilterView.h"
#import "MONFilterModel.h"
#import <Foundation/Foundation.h>

@interface MONFilterPresenter : NSObject

- (instancetype)initWithFilterView:(MONFilterView *)filterView filterModel:(MONFilterModel *)filterModel;

@end
