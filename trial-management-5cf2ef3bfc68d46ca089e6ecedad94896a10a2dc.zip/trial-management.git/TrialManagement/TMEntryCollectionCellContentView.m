#import "TMEntryCollectionCellContentView.h"
#import "MONTitleValueVerticalLabels.h"
#import "MONTitleValueVerticalButtonLabelView.h"
#import "MONLabel.h"
#import "UIColor+MONThemeColorProvider.h"
#import "UIImage+MONThemeImageProvider.h"
#import "MONColors.h"

static const CGFloat ContentHorizontalPadding = 26.0;
static const CGFloat NumberLabelFontSize = 32.0;
static const CGFloat NumberContainerWidth = 55.0;
static NSString * const BrandTitle = @"Brand";
static NSString * const ProductTitle = @"Product";
static NSString * const RMTitle = @"RM";
static NSString * const TraitTitle = @"Trait";
static NSString * const TreatmentTitle = @"Treatment";
static NSString * const TreatmentButtonText = @"Add Treatment?";

@interface TMEntryCollectionCellContentView ()<MONTitleValueVerticalButtonLabelViewDelegate>

@property (nonatomic) UIView *numberContainerView;
@property (nonatomic) MONLabel *numberLabel;
@property (nonatomic) MONTitleValueVerticalLabels *brandTitleLabel;
@property (nonatomic) MONTitleValueVerticalLabels *productTitleLabel;
@property (nonatomic) MONTitleValueVerticalLabels *rmValueTitleLabel;
@property (nonatomic) MONTitleValueVerticalLabels *traitTitleLabel;
@property (nonatomic) MONTitleValueVerticalButtonLabelView *treatmentTitleLabel;
@property (nonatomic) MONTitleValueVerticalLabels *staticTreatmentTitleLabel;
@property (nonatomic) BOOL treatmentSelected;
@property (nonatomic) BOOL selected;
@property (nonatomic) BOOL isStaticCellView;

@end

@implementation TMEntryCollectionCellContentView

- (id)initWithFrame:(CGRect)frame {
    return [self initWithFrame:frame asStaticCellView:NO];
}

- (id)initWithFrame:(CGRect)frame asStaticCellView:(BOOL)isStaticCellView {
    self = [super initWithFrame:frame];
    if (self) {
        self.isStaticCellView = isStaticCellView;
        
        self.numberContainerView = [[UIView alloc] init];
        self.numberContainerView.backgroundColor = [MONColors midnightBlueColor];
        [self.contentContainerView addSubview:self.numberContainerView];
        
        self.numberLabel = [[MONLabel alloc] init];
        self.numberLabel.textColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeSelectedText];
        self.numberLabel.textSize = NumberLabelFontSize;
        self.numberLabel.textAlignment = NSTextAlignmentCenter;
        [self.numberContainerView addSubview:self.numberLabel];
        
        self.brandTitleLabel = [[MONTitleValueVerticalLabels alloc] init];
        [self.brandTitleLabel setTitleText:BrandTitle];
        [self.contentContainerView addSubview:self.brandTitleLabel];
        
        self.productTitleLabel = [[MONTitleValueVerticalLabels alloc] init];
        [self.productTitleLabel setTitleText:ProductTitle];
        [self.contentContainerView addSubview:self.productTitleLabel];
        
        self.rmValueTitleLabel = [[MONTitleValueVerticalLabels alloc] init];
        [self.rmValueTitleLabel setTitleText:RMTitle];
        [self.contentContainerView addSubview:self.rmValueTitleLabel];
        
        self.traitTitleLabel = [[MONTitleValueVerticalLabels alloc] init];
        [self.traitTitleLabel setTitleText:TraitTitle];
        [self.contentContainerView addSubview:self.traitTitleLabel];
        
        if (self.isStaticCellView) {
            self.staticTreatmentTitleLabel = [[MONTitleValueVerticalLabels alloc] init];
            [self.staticTreatmentTitleLabel setTitleText:TreatmentTitle];
            [self.contentContainerView addSubview:self.staticTreatmentTitleLabel];
        } else {
            self.treatmentTitleLabel = [[MONTitleValueVerticalButtonLabelView alloc] init];
            [self.treatmentTitleLabel setTitleText:TreatmentTitle];
            [self.treatmentTitleLabel setButtonText:TreatmentButtonText];
            [self.treatmentTitleLabel setIconButtonImage:[self treatmentIconImage]];
            self.treatmentTitleLabel.delegate = self;
            [self.contentContainerView addSubview:self.treatmentTitleLabel];
        }
    }
    return self;
}

-(void)setIsReadOnly:(BOOL)isReadOnly {
	[self.treatmentTitleLabel setIsReadOnly:isReadOnly];
}

- (void)layoutSubviews {
	[super layoutSubviews];
	
	self.numberContainerView.frame = CGRectMake(0.0, 0.0, NumberContainerWidth, CGRectGetHeight(self.contentContainerView.bounds));
	
	[self.numberLabel sizeToFit];
	self.numberLabel.frame = CGRectMake(0.0,
										0.0,
										CGRectGetWidth(self.numberContainerView.bounds),
										CGRectGetHeight(self.numberContainerView.bounds));
	
	CGFloat availableSpace = CGRectGetMaxX(self.contentContainerView.bounds) - CGRectGetMaxX(self.numberContainerView.frame) - 2.0 * ContentHorizontalPadding;
	
	self.brandTitleLabel.frame = CGRectMake(CGRectGetMaxX(self.numberContainerView.frame) + ContentHorizontalPadding, 0.0, availableSpace * 0.25, CGRectGetHeight(self.bounds));
	self.productTitleLabel.frame = CGRectMake(CGRectGetMaxX(self.brandTitleLabel.frame), 0.0, availableSpace * 0.25, CGRectGetHeight(self.contentContainerView.bounds));
	self.rmValueTitleLabel.frame = CGRectMake(CGRectGetMaxX(self.productTitleLabel.frame), 0.0, availableSpace * 0.1, CGRectGetHeight(self.contentContainerView.bounds));
	self.traitTitleLabel.frame = CGRectMake(CGRectGetMaxX(self.rmValueTitleLabel.frame), 0.0, availableSpace * 0.15, CGRectGetHeight(self.contentContainerView.bounds));
    if (self.isStaticCellView) {
        self.staticTreatmentTitleLabel.frame = CGRectMake(CGRectGetMaxX(self.traitTitleLabel.frame), 0.0, availableSpace * 0.25, CGRectGetHeight(self.contentContainerView.bounds));
    } else {
        self.treatmentTitleLabel.frame = CGRectMake(CGRectGetMaxX(self.traitTitleLabel.frame), 0.0, availableSpace * 0.25, CGRectGetHeight(self.contentContainerView.bounds));
    }
}

- (void)setNumber:(NSInteger)number {
	self.numberLabel.text = [NSString stringWithFormat:@"%ld", (long)number];
	[self setNeedsLayout];
}


- (void)setBrand:(NSString *)brand {
	[self.brandTitleLabel setValueText:brand];
}

- (void)setProduct:(NSString *)product {
	[self.productTitleLabel setValueText:product];
}

- (void)setRMValue:(NSDecimalNumber *)rmValue {
	[self.rmValueTitleLabel setValueText:[NSString stringWithFormat:@"%.1f", [rmValue floatValue]]];
}

- (void)setTrait:(NSString *)trait {
	[self.traitTitleLabel setValueText:trait];
}

- (void)setTreatment:(NSString *)treatment {
    if (self.isStaticCellView) {
        [self.staticTreatmentTitleLabel setValueText:treatment];
    } else {    
        if ([treatment length] > 0) {
            [self.treatmentTitleLabel setButtonText:treatment];
            self.treatmentSelected = YES;
        } else {
            [self.treatmentTitleLabel setButtonText:TreatmentButtonText];
            self.treatmentSelected = NO;
        }
        [self.treatmentTitleLabel setIconButtonImage:[self treatmentIconImage]];
    }
}

- (void)setSelected:(BOOL)selected {
	if (selected != _selected) {
		_selected = selected;
		UIColor *textColor = selected ? [UIColor colorForThemeComponentType:MONThemeComponentTypeSelectedText] : [UIColor colorForThemeComponentType:MONThemeComponentTypeText];
		
		[self.brandTitleLabel setTextColor:textColor];
		[self.productTitleLabel setTextColor:textColor];
		[self.rmValueTitleLabel setTextColor:textColor];
		[self.traitTitleLabel setTextColor:textColor];
		[self.treatmentTitleLabel setTextColor:textColor];
		
		[self.treatmentTitleLabel setIconButtonImage:[self treatmentIconImage]];
	}
}

- (UIImage *)treatmentIconImage {
	NSString *iconImageName = nil;
	if (self.treatmentSelected) {
		iconImageName = @"ui-icon-remove-small";
	} else {
		iconImageName = @"ui-icon-add-treatment-small";
	}
	if (self.selected) {
		iconImageName = [iconImageName stringByAppendingString:@"-inverse"];
	}
	return [UIImage imageForUserColorPreference:iconImageName];
}

#pragma mark - MONTitleValueVerticalButtonLabelViewDelegate Methods

- (void)titleValueVerticalButtonLabelViewButtonTapped:(MONTitleValueVerticalButtonLabelView *)titleValueVerticalButtonLabelView {
    [self.delegate entryCollectionCellContentAddTreatmentTapped:self.treatmentTitleLabel];
}

- (void)iconButtonTapped {
	if (self.treatmentSelected) {
		[self.delegate deleteTreatmentButtonTapped];
	} else {
		[self.delegate entryCollectionCellContentAddTreatmentTapped:self.treatmentTitleLabel];
	}
}

@end
