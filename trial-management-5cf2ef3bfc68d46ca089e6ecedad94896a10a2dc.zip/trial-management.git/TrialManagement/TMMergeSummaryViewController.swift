//
//  TMMergeSummaryViewController.swift
//  TrialManagement
//
//  Created by SINGH, SUPREET [AG/1000] on 1/12/15.
//  Copyright (c) 2015 Monsanto. All rights reserved.
//

import UIKit

@objc protocol TMMergeUIOptionsDelegate: class {
    func close()
    func saveResolvedValues()
}

class TMMergeSummaryViewController: UIViewController, TMMergeSummaryViewDelegate, TMMergeUIOptionsDelegate {
    var delegate: TMMergeUIOptionsDelegate?
    private let mergeSummaryView: TMMergeSummaryView
    private let mergeTrialViewModel: TMMergeTrialViewModel
    private let mergeManageViewController: TMMergeManageViewController
    
    init(mergeTrialModel: TMMergeTrialModel, mergeTrialViewModel: TMMergeTrialViewModel) {
        self.mergeTrialViewModel = mergeTrialViewModel
        mergeSummaryView = TMMergeSummaryView(numberOfTotalConflicts: mergeTrialViewModel.totalConflicts(), numberOfTrials: 1)
        mergeManageViewController = TMMergeManageViewController(mergeTrialModel: mergeTrialModel, mergeTrialViewModel: mergeTrialViewModel)
        super.init(nibName: nil, bundle: nil)
        mergeSummaryView.autoresizingMask = UIViewAutoresizing.FlexibleWidth | UIViewAutoresizing.FlexibleHeight
        mergeSummaryView.delegate = self
        view.addSubview(mergeSummaryView)
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        mergeSummaryView.frame = view.bounds
    }
    
    func closeFromSummary() {
        delegate?.close()
    }
    
    func close() {
        dismissViewControllerAnimated(true) {[unowned self] in self.closeFromSummary()}
    }
    
    func saveResolvedValues() {
        close()
        delegate?.saveResolvedValues()
    }
    
    func manage() {
        mergeManageViewController.delegate = self
        mergeManageViewController.modalPresentationStyle = UIModalPresentationStyle.OverFullScreen
        mergeManageViewController.modalTransitionStyle = UIModalTransitionStyle.CrossDissolve
        presentViewController(mergeManageViewController, animated: true, completion: nil)
    }
    
    required init(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

}
