#import "MONLabeledControl.h"
#import "MONDimensions.h"

static const CGFloat VerticalSpacing = 3.0;

@interface MONLabeledControl ()

@property (nonatomic) CGFloat labelWidth;

@end

@implementation MONLabeledControl

- (id)initWithFrame:(CGRect)frame {
	self = [super initWithFrame:frame];
	if (self) {
		self.labelLocation = MONLabeledControlLabelLocationTop;
		
		_label = [[MONLabel alloc] init];
		[self addSubview:self.label];
	}
	return self;
}

- (void)setLabelText:(NSString *)labelText {
	self.label.text = labelText;
}

- (void)layoutSubviews {
	[super layoutSubviews];
	
	[self.label sizeToFit];
	CGSize labelSize = CGSizeZero;
	labelSize.width = (self.labelWidth > 0.01) ? self.labelWidth : CGRectGetWidth(self.label.frame);
	labelSize.height = CGRectGetHeight(self.bounds);
	
	if (self.labelLocation == MONLabeledControlLabelLocationLeft) {
		self.label.frame = CGRectMake(0.0, 0.0, labelSize.width, labelSize.height);
		
		self.controlView.frame = CGRectMake(CGRectGetMaxX(self.label.frame) + MONDimensionsSmallPadding,
										  0.0,
										  CGRectGetWidth(self.bounds) - CGRectGetMaxX(self.label.frame) - MONDimensionsSmallPadding,
										  CGRectGetHeight(self.bounds));
	} else if (self.labelLocation == MONLabeledControlLabelLocationTop) {
		self.label.lineBreakMode = NSLineBreakByTruncatingTail;
		self.label.frame = CGRectMake(0.0, 0.0, CGRectGetWidth(self.bounds), CGRectGetHeight(self.label.frame));
		
		self.controlView.frame = CGRectMake(0.0,
										  CGRectGetMaxY(self.label.frame) + VerticalSpacing,
										  CGRectGetWidth(self.bounds),
										  CGRectGetHeight(self.bounds) - CGRectGetMaxY(self.label.frame));
	} else if (self.labelLocation == MONLabeledControlLabelLocationNone) {
		self.label.hidden = YES;
		self.controlView.frame = self.bounds;
	}
}

- (CGSize)sizeThatFits:(CGSize)size {
	CGSize sizeThatFits;
	
	[self.label sizeToFit];
	[self.controlView sizeToFit];
	
	CGFloat labelWidth = (self.labelWidth > 0.01) ? self.labelWidth : CGRectGetWidth(self.label.frame);

	if (self.labelLocation == MONLabeledControlLabelLocationLeft) {
		sizeThatFits.width = labelWidth;
		sizeThatFits.width += MONDimensionsSmallPadding;
		sizeThatFits.width += CGRectGetWidth(self.controlView.frame);
		sizeThatFits.height = MAX(CGRectGetHeight(self.label.frame), CGRectGetHeight(self.controlView.frame));
	} else if (self.labelLocation == MONLabeledControlLabelLocationTop) {
		sizeThatFits.width = size.width;
		sizeThatFits.height = CGRectGetHeight(self.label.frame);
		sizeThatFits.height += VerticalSpacing;
		sizeThatFits.height += CGRectGetHeight(self.controlView.frame);		
	} else if (self.labelLocation == MONLabeledControlLabelLocationNone) {
		CGSize controlViewSize = [self.controlView sizeThatFits:size];
		sizeThatFits = controlViewSize;
	}
	
	return sizeThatFits;
}

- (void)setControlView:(UIView *)controlView {
	[_controlView removeFromSuperview];
	
	_controlView = controlView;
	
	[self addSubview:_controlView];
}

@end
