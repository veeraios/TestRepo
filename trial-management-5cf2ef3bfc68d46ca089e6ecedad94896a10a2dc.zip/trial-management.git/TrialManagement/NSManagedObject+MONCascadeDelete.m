//
//  NSManagedObject+MONCascadeDelete.m
//  TrialManagement
//
//  Created by GADIRAJU, PRANEETH [AG/1000] on 1/7/15.
//  Copyright (c) 2015 Monsanto. All rights reserved.
//

#import "NSManagedObject+MONCascadeDelete.h"

@implementation NSManagedObject (CascadeDelete)

- (void)deleteWithRefData {
    [self deleteWithTraversal:nil];
}

- (void)deleteWithTraversal:(NSDictionary *)traversal {
    NSEntityDescription *entityDescription = [self entity];
    
    NSDictionary *relationships = [entityDescription relationshipsByName];
    
    NSEnumerator *relationshipEnumerator = [[relationships allKeys] objectEnumerator];
    NSString *relationshipName;
    
    NSArray *allowedRelationships = [traversal objectForKey:[[self entity] name]];
    
    while (relationshipName = [relationshipEnumerator nextObject]) {
        
        //TODO: Remove current traversed relationship from the traversal dictionary to prevent cyclic references.
        if (!traversal || [allowedRelationships containsObject:relationshipName]) {
            if (![[relationships objectForKey:relationshipName] isToMany]) {
                NSManagedObject *destination = [self valueForKey:relationshipName];
                [self setValue:nil forKey:relationshipName];
                [destination deleteWithTraversal:traversal];
            } else {
                NSMutableSet *mutableRelationship = [self mutableSetValueForKey:relationshipName];
                for(NSManagedObject *setObject in [mutableRelationship copy]) {
                    [mutableRelationship removeObject:setObject];
                    [setObject deleteWithTraversal:traversal];
                }
            }
        }
    }
    
    [self deleteObject];
}

- (void)deleteObject {
    [[self managedObjectContext] deleteObject:self];
}
@end

