//
//  TMMergeManageView.swift
//  TrialManagement
//
//  Created by SINGH, SUPREET [AG/1000] on 1/15/15.
//  Copyright (c) 2015 Monsanto. All rights reserved.
//

import UIKit

protocol TMMergeManageViewDelegate: class {
    func closeFromManage()
    func conflictResolved(side: TMMergeSide, subsection: TMMergeSubsection, section: TMMergeSection)
    func saveResolvedValues()
}

@IBDesignable class TMMergeManageView: UIView, TMMergeSectionViewDelegate {
    weak var delegate : TMMergeManageViewDelegate?
    private let trialViewModel: TMMergeTrialViewModel
    private let headerBackground: UIView
    private let headerLabel: UILabel
    private let closeButton: UIButton
    private var dataConflictsHeader: MONHeaderView?
    private var trialsConflictsHeader: MONHeaderView?
    private let topBorderView: UIView
    private let trialNameLabel: UILabel?
    private let growerNameAndPlotDescLabel: UILabel?
    private let trialCounterAndConflictsLabel: UILabel
    private let bottomBorderView: UIView
    private let scrollView: UIScrollView
    private let mergeSectionViews = [TMMergeSectionView]()
    private var saveConfirmationMessage: UILabel?
    private var saveButton: UIButton?

    init(_ mergeTrialViewModel: TMMergeTrialViewModel) {
        trialViewModel = mergeTrialViewModel
        headerBackground = UIView()
        headerBackground.backgroundColor = UIColor(forThemeComponentType: MONThemeComponentTypeNavigationBar)
        headerLabel = UILabel()
        headerLabel.font = UIFont(name: OpenSansSemibold, size: 17)
        headerLabel.textColor = UIColor(forThemeComponentType: MONThemeComponentTypeNavigationBarText)
        headerLabel.textAlignment = NSTextAlignment.Center
        headerLabel.text = "Manually Merge Data Conflicts"
        closeButton = UIButton()
        closeButton.setTitle("Close", forState: UIControlState.Normal)
        topBorderView = UIView();
        topBorderView.backgroundColor = UIColor(forThemeComponentType: MONThemeComponentTypeBorder)
        trialCounterAndConflictsLabel = UILabel()
        trialCounterAndConflictsLabel.textAlignment = NSTextAlignment.Center
        bottomBorderView = UIView()
        bottomBorderView.backgroundColor = UIColor(forThemeComponentType: MONThemeComponentTypeBorder)
        scrollView = UIScrollView()
        super.init(frame: CGRectZero)
        backgroundColor = UIColor(forThemeComponentType: MONThemeComponentTypeBackground)
        dataConflictsHeader = TMDefaultUIFactory.createHeaderView("Current Data Conflicts", numberOfItems: mergeTrialViewModel.totalConflicts())
        trialsConflictsHeader = TMDefaultUIFactory.createHeaderView("Trials", numberOfItems: 1)
        closeButton.addTarget(self, action: "close", forControlEvents: UIControlEvents.TouchUpInside)
        trialNameLabel = TMDefaultUIFactory.createDefaultBoldLabel(mergeTrialViewModel.trialName, size: 20, numberOfLines: 1)
        growerNameAndPlotDescLabel = TMDefaultUIFactory.createDefaultBoldLabel(String(format: "Grower: %@ | Plot Desc: %@", arguments: [mergeTrialViewModel.growerName, mergeTrialViewModel.plotDescription]), size: 20, numberOfLines: 1)
        trialCounterAndConflictsLabel.attributedText = createTrialConflictsSummaryString(1, numberOfTrials: 1, numberOfTotalConflicts: mergeTrialViewModel.totalConflicts())
        addSubview(headerBackground)
        addSubview(headerLabel)
        addSubview(closeButton)
        addSubview(dataConflictsHeader!)
        addSubview(trialsConflictsHeader!)
        addSubview(topBorderView)
        addSubview(trialNameLabel!)
        addSubview(growerNameAndPlotDescLabel!)
        addSubview(trialCounterAndConflictsLabel)
        addSubview(bottomBorderView)
        addSubview(scrollView)
        
        mergeSectionViews = buildSectionViews(mergeTrialViewModel.mergeSections)
        mergeSectionViews.forEach({[unowned self] in self.scrollView.addSubview($0)})
    }
    
    func buildSectionViews(mergeSectionModels: [TMMergeSectionViewModel]) -> [TMMergeSectionView] {
        return mergeSectionModels.map({[unowned self] in
            let sectionView = TMMergeSectionView($0)
            sectionView.delegate = self
            return sectionView
        })
    }
    
    func buildConfirmation() {
        saveConfirmationMessage = TMDefaultUIFactory.createDefaultBoldLabel("Hitting the \"SAVE TRIAL\" button will sync with the server and update this trial with your selected changes. You can scroll up and review your changes if needed.", size: 18, numberOfLines: 2)
        saveConfirmationMessage?.textColor = UIColor(forThemeComponentType: MONThemeComponentTypeHighlight)
        saveButton = MONButton(title: "SAVE TRIAL")
        saveButton?.addTarget(self, action: "saveResolvedValues", forControlEvents: UIControlEvents.TouchUpInside)
        scrollView.addSubview(saveConfirmationMessage!)
        scrollView.addSubview(saveButton!)
        setNeedsLayout()
    }
    
    private func updateConflictsCount() {
        let totalConflicts = trialViewModel.mergeSections.reduce(0, combine: {(total, mergeSection) -> Int in total + mergeSection.mergeGroups.filter({$0.resolvedSide == nil}).count})
        dataConflictsHeader!.setNumberOfItems(UInt(totalConflicts))
        trialCounterAndConflictsLabel.attributedText = createTrialConflictsSummaryString(1, numberOfTrials: 1, numberOfTotalConflicts: totalConflicts)
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        headerBackground.frame = CGRectMake(bounds.minX, bounds.minY, bounds.width, MONDimensionsHeaderHeight)
        headerLabel.frame = CGRectMake(bounds.minX, MONDimensionsTinyPadding, bounds.width, MONDimensionsHeaderHeight)
        closeButton.sizeToFit()
        closeButton.frame = CGRectMake(MONDimensionsSmallPadding, MONDimensionsLargePadding, closeButton.frame.width, closeButton.frame.height)
        let dataConflictsHeaderSize = dataConflictsHeader!.sizeThatFits(CGSizeMake(360, bounds.height))
        dataConflictsHeader!.frame = CGRectMake(0, headerBackground.frame.maxY, dataConflictsHeaderSize.width, dataConflictsHeaderSize.height)
        trialsConflictsHeader!.frame = CGRectMake(dataConflictsHeader!.frame.maxX, dataConflictsHeader!.frame.minY, 110, dataConflictsHeaderSize.height)
        topBorderView.frame = CGRectMake(MONDimensionsTinyPadding, trialsConflictsHeader!.frame.maxY, bounds.width - (MONDimensionsTinyPadding * 2.0), MONDimensionsThinBorderWidth)
        trialNameLabel!.sizeToFit()
        trialNameLabel!.frame = CGRectMake(MONDimensionsSmallPadding, topBorderView.frame.maxY + MONDimensionsTinyPadding, bounds.width, trialNameLabel!.frame.height)
        growerNameAndPlotDescLabel!.sizeToFit()
        growerNameAndPlotDescLabel!.frame = CGRectMake(MONDimensionsSmallPadding, trialNameLabel!.frame.maxY, bounds.width, growerNameAndPlotDescLabel!.frame.height)
        trialCounterAndConflictsLabel.sizeToFit()
        trialCounterAndConflictsLabel.frame = CGRectMake(MONDimensionsSmallPadding, growerNameAndPlotDescLabel!.frame.maxY, bounds.width, trialNameLabel!.frame.height)
        bottomBorderView.frame = CGRectMake(MONDimensionsTinyPadding, trialCounterAndConflictsLabel.frame.maxY + MONDimensionsSmallPadding, bounds.width - (MONDimensionsTinyPadding * 2.0), MONDimensionsThinBorderWidth)
        
        scrollView.frame = CGRectMake(MONDimensionsTinyPadding, bottomBorderView.frame.maxY + MONDimensionsTinyPadding, bounds.width - MONDimensionsTinyPadding * 2.0,
            bounds.height - bottomBorderView.frame.maxY - MONDimensionsTinyPadding * 2.0)
        
        var totalScrollViewContentHeight: CGFloat = 0.0
        for (index, mergeSectionView) in enumerate(mergeSectionViews) {
            var size = mergeSectionView.sizeThatFits(CGSize(width: scrollView.bounds.width, height: scrollView.bounds.height))
            totalScrollViewContentHeight = size.height + totalScrollViewContentHeight
            if (index == 0) {
                mergeSectionView.frame = CGRectMake(0, 0, size.width, size.height)
            } else {
                mergeSectionView.frame = CGRectMake(0, mergeSectionViews[index-1].frame.maxY, size.width, size.height)
            }
        }
        if (saveConfirmationMessage != nil) {
            saveConfirmationMessage?.frame = CGRectMake(MONDimensionsMicroPadding, mergeSectionViews.last!.frame.maxY + MONDimensionsMicroPadding, scrollView.bounds.width - MONDimensionsMicroPadding * 2.0, 50)
            saveButton?.sizeToFit()
            saveButton?.frame = CGRectMake((scrollView.bounds.width - saveButton!.frame.width) / 2.0, saveConfirmationMessage!.frame.maxY + MONDimensionsMicroPadding, saveButton!.frame.width, saveButton!.frame.height)
            totalScrollViewContentHeight = saveConfirmationMessage!.frame.height + saveButton!.frame.height + MONDimensionsMicroPadding * 3.0 + totalScrollViewContentHeight
        }
        scrollView.contentSize = CGSize(width: scrollView.frame.width, height: totalScrollViewContentHeight)
    }
    
    private func createTrialConflictsSummaryString(currentTrial: Int, numberOfTrials: Int, numberOfTotalConflicts: Int) -> NSMutableAttributedString {
        let conflictsSummaryRawString = "Trial \(currentTrial) of \(numberOfTrials) | Total Trial Conflicts: \(numberOfTotalConflicts)"
        let conflictsSummaryString = NSMutableAttributedString(string: conflictsSummaryRawString)
        conflictsSummaryString.addAttribute("NSFont", value: UIFont(name: OpenSansBold, size: 20)!, range: NSMakeRange(0, countElements(conflictsSummaryRawString)))
        conflictsSummaryString.addAttribute("NSColor", value: UIColor(forThemeComponentType: MONThemeComponentTypeText), range: NSMakeRange(0, countElements(conflictsSummaryRawString) - 1))
        conflictsSummaryString.addAttribute("NSColor", value: UIColor(forThemeComponentType: MONThemeComponentTypeHighlight), range: NSMakeRange(countElements(currentTrial.description) + countElements(numberOfTrials.description) + 36, countElements(numberOfTotalConflicts.description)))
        return conflictsSummaryString
    }
    
    func close() {
        delegate?.closeFromManage()
    }

    func saveResolvedValues() {
        delegate?.saveResolvedValues()
    }
    
    func sideTapped(side: TMMergeSide, subsection: TMMergeSubsection, section: TMMergeSection) {
        updateConflictsCount()
        delegate?.conflictResolved(side, subsection: subsection, section: section)
    }
    
    func resolveAllConflicts(side: TMMergeSide) {
        trialViewModel.mergeSections.forEach({$0.mergeGroups.forEach({
            (mergeGroup) in mergeGroup.resolvedSide = side})
        })
        updateConflictsCount()
        mergeSectionViews.forEach({$0.updateResolvedConflicts()})
        if (saveConfirmationMessage == nil) {
            buildConfirmation()
        }
    }
    
    required init(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

}
