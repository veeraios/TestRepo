#import "NSString+Helper.h"

@implementation NSString (Helper)
-(NSString*)safeString {
	if(self == nil  || [self length] == 0 || [self isEqualToString:@"<null>"]) {
		return @"";
	}
	return self;
}

-(BOOL)contains:(NSString*)searchString {
	return [self rangeOfString:searchString].location != NSNotFound;
}

@end
