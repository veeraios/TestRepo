#import <UIKit/UIKit.h>

@interface MONLabeledLabel : UIView

- (void)setLabelText:(NSString *)labelText;
- (void)setValueText:(NSString *)valueText;
- (void)setTextColor:(UIColor *)textColor;

@end
