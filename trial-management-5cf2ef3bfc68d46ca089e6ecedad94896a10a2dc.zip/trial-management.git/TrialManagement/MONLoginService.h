#import <MNetworking/MNetAccessManager.h>
#import <Foundation/Foundation.h>

@interface MONLoginService : NSObject

- (instancetype)initWithNetAccessManager:(id<MNetAccessManager>)netAccessManager;
- (void)loginWithUsername:(NSString *)username
                 password:(NSString *)password
             successBlock:(void(^)(void))successBlock
             failureBlock:(void(^)(NSError *))failureBlock;
- (void)logout;
- (BOOL)userIsAuthenticated;

@end
