typedef void (^TMSearchResultsBlock)(NSArray *searchResuts, NSError *error);

@protocol MONReferenceSearchableModel <NSObject>
- (void)search:(NSString*)searchText criteria:(NSDictionary*)criteria searchResultsBlock:(TMSearchResultsBlock)searchResultsBlock;
- (id)modelAtIndex:(NSInteger)index;
@end
