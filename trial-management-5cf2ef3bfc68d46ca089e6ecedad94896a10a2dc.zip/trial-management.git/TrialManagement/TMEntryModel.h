#import "TMEntry.h"
#import "TMObservationCalculationModel.h"
#import "TMYieldCalculationModel.h"

@interface TMEntryModel : NSObject
- (instancetype)initWithEntry:(TMEntry*)entry;
- (instancetype)initWithEntry:(TMEntry *)entry
  observationCalculationModel:(TMObservationCalculationModel *)observationCalculationModel disablePlotWeightAndYield:(BOOL)disablePlotWeightAndYield
 hasDefaultRowsHarvestedValue: (BOOL) hasDefaultRowsHarvestedValue
    hasDefaultRowSpacingValue: (BOOL) hasDefaultRowSpacingValue;
- (TMYieldCalculationModel *)yieldCalculationModel;
- (NSArray*)inSeasonObservations;
- (NSArray*)observationTypes;
- (NSInteger)entryNumber;
- (NSString*)productName;
- (NSString*)brandName;
- (BOOL)hasInSeasonObservations;
- (NSString*)traitName;
- (NSString*)maturityRating;
- (NSString*)treatmentName;
- (NSArray*)harvestObservations;
- (NSArray*)harvestYieldObservations;
- (NSArray*)harvestMoistureObservations;
- (BOOL)disablePlotWeightAndYield;
- (BOOL)hasUnapprovedProduct;

@end
