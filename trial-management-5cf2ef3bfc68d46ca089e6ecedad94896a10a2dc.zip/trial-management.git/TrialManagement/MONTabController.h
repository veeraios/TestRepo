#import "MONTabSettingsObject.h"
#import <Foundation/Foundation.h>

@protocol MONTabController <NSObject>

@property (nonatomic) MONTabSettingsObject *tabSettingsObject;

@end
