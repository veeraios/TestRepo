#import "MONYesNoSwitch.h"
#import "MONCardContainerView.h"

@interface MONLabeledYesNoSwitch : MONCardContainerView
@property (nonatomic) MONYesNoSwitch *yesNoSwitch;
- (id)initWithTitle:(NSString*)title;
- (id)initWithTitle:(NSString*)title defaultValue:(BOOL)defaultValue;
- (id)initWithTitle:(NSString*)title borderColor:(UIColor*)borderColor;
- (id)initWithTitle:(NSString*)title borderColor:(UIColor*)borderColor defaultValue:(BOOL)defaultValue;
@end
