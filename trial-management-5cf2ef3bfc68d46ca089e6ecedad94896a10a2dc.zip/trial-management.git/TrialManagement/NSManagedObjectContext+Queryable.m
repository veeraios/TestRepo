#import "NSManagedObjectContext+Queryable.h"

@implementation NSManagedObjectContext (Queryable)
-(MONQuery*) ofType:(NSString*)typeName
{
    return [[MONQuery alloc] initWithType:typeName context:self];
}
@end

@interface MONQuery()

@property (strong) NSManagedObjectContext* context;
@property (strong) NSArray* sorts;
@property (strong) NSArray* whereClauses;
@property (strong) NSArray* propertiesToFetchArray;
@property int skipCount;
@property int takeCount;
@property (strong) NSString* type;

@end

@implementation MONQuery

-(id)initWithType:(NSString *)entityType context:(NSManagedObjectContext*)theContext
{
    self = [super init];
    if(self != nil)
    {
        self.type = entityType;
        self.context = theContext;
        self.takeCount = INT32_MAX;
        self.skipCount = 0;
    }
    
    return self;
}

-(id)initWithType:(NSString*)entityType context:(NSManagedObjectContext*)theContext take:(int)newTake skip:(int)newSkip sorts:(NSArray*)newSorts whereClauses:(NSArray*)newWhereClauses propertiesToFetch:(NSArray*)propertiesToFetch
{
    self = [super init];
    if(self != nil)
    {
        self.type = entityType;
        self.context = theContext;
        self.takeCount = newTake;
        self.skipCount = newSkip;
        self.sorts  = newSorts;
        self.whereClauses = newWhereClauses;
		self.propertiesToFetchArray = propertiesToFetch;
    }
    
    return self;
}

-(NSArray*)fetchOnIds:(BOOL)fetchIds
{
    if(self.takeCount <= 0)
        return [[NSArray alloc] init];
    
    NSInteger skip = MAX(self.skipCount, 0);
	
    NSError* error = nil;
    
    NSEntityDescription *entityDescription = [NSEntityDescription
                                              entityForName:self.type
                                              inManagedObjectContext:self.context];
    
    NSFetchRequest* fetchRequest = [[NSFetchRequest alloc] init];
    [fetchRequest setEntity:entityDescription];
	
    fetchRequest.sortDescriptors = self.sorts;
    
    [fetchRequest setFetchOffset:skip];
    [fetchRequest setFetchLimit:self.takeCount];

    [fetchRequest setResultType: fetchIds ? NSManagedObjectIDResultType : NSManagedObjectResultType];
	if(self.propertiesToFetchArray != nil) {
//		[fetchRequest setResultType:NSDictionaryResultType];
		[fetchRequest setPropertiesToFetch:self.propertiesToFetchArray];
	}
	
    if (self.whereClauses != nil) {
        fetchRequest.predicate = [NSCompoundPredicate andPredicateWithSubpredicates:self.whereClauses];
	}
    
    NSArray* results = [self.context executeFetchRequest:fetchRequest error:&error];
    return results;
}

-(NSArray*)toArray {
    return [self fetchOnIds:NO];
}

-(NSArray*)fetchOnIds {
    return [self fetchOnIds:YES];
}

-(NSArray*)add:(id)object toArray:(NSArray*)array
{
    NSMutableArray* a = [NSMutableArray arrayWithArray:array];
    return [a arrayByAddingObject:object];
}

-(MONQuery*) orderBy:(NSString*)fieldName
{
    NSSortDescriptor* descriptor = [self sortDescriptorForOrderByField:fieldName ascending:YES];
    NSArray* newSorts = [self add:descriptor toArray:self.sorts];
    
    MONQuery* q = [[MONQuery alloc] initWithType:self.type context:self.context take:self.takeCount skip:self.skipCount sorts:newSorts whereClauses:self.whereClauses propertiesToFetch:self.propertiesToFetchArray];
    return q;
}

-(MONQuery*) orderByDescending:(NSString*)fieldName
{
    NSSortDescriptor* descriptor = [self sortDescriptorForOrderByField:fieldName ascending:NO];
    NSArray* newSorts = [self add:descriptor toArray:self.sorts];
    
    MONQuery* q = [[MONQuery alloc] initWithType:self.type context:self.context take:self.takeCount skip:self.skipCount sorts:newSorts whereClauses:self.whereClauses propertiesToFetch:self.propertiesToFetchArray];
    return q;
}

-(MONQuery*) skip:(int)numberToSkip
{
    MONQuery* q = [[MONQuery alloc] initWithType:self.type context:self.context take:self.takeCount skip:numberToSkip sorts:self.sorts whereClauses:self.whereClauses propertiesToFetch:self.propertiesToFetchArray];
	
    return q;
}

-(MONQuery*) take:(int)numberToTake
{
    MONQuery* q = [[MONQuery alloc] initWithType:self.type context:self.context take:numberToTake skip:self.skipCount sorts:self.sorts whereClauses:self.whereClauses propertiesToFetch:self.propertiesToFetchArray];
    
    return q;
}
-(MONQuery*)propertyToFetch:(NSArray*)propertiesToFetch
{
    MONQuery* q = [[MONQuery alloc] initWithType:self.type context:self.context take:self.takeCount skip:self.skipCount sorts:self.sorts whereClauses:self.whereClauses propertiesToFetch:propertiesToFetch];
    
    return q;
}
-(MONQuery*)wherePredicate:(NSPredicate*)predicate
{
    NSArray* newWheres = [self add:predicate toArray:self.whereClauses];
    
    MONQuery* q = [[MONQuery alloc] initWithType:self.type context:self.context take:self.takeCount skip:self.skipCount sorts:self.sorts whereClauses:newWheres propertiesToFetch:self.propertiesToFetchArray];
    
    return q;
}

-(MONQuery*)where:(NSString*)condition
{
    NSPredicate* predicate = [NSPredicate predicateWithFormat:condition];
    NSArray* newWheres = [self add:predicate toArray:self.whereClauses];
    
    MONQuery* q = [[MONQuery alloc] initWithType:self.type context:self.context take:self.takeCount skip:self.skipCount sorts:self.sorts whereClauses:newWheres propertiesToFetch:self.propertiesToFetchArray];
    
    return q;
}

-(id)first
{
    MONQuery* q = [[MONQuery alloc] initWithType:self.type context:self.context take:1 skip:self.skipCount sorts:self.sorts whereClauses:self.whereClauses propertiesToFetch:self.propertiesToFetchArray];
    
    NSArray* results = [q toArray];
    if(results.count > 0)
        return [results objectAtIndex:0];
    else
        return nil;
}

- (NSSortDescriptor *)sortDescriptorForOrderByField:(NSString *)fieldName ascending:(BOOL)ascending {
    NSEntityDescription *entityDescription = [NSEntityDescription entityForName:self.type inManagedObjectContext:self.context];
    NSAttributeDescription *sortAttribute = [[entityDescription attributesByName] objectForKey:fieldName];
    
    if ([NSClassFromString(sortAttribute.attributeValueClassName) instancesRespondToSelector:@selector(localizedStandardCompare:)]) {
        return [[NSSortDescriptor alloc] initWithKey:fieldName ascending:ascending selector:@selector(localizedStandardCompare:)];
    }
    
    return [[NSSortDescriptor alloc] initWithKey:fieldName ascending:ascending];
}

@end