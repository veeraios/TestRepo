#import "TMMarketingActionOptionsListModel.h"
#import "TMTrialDataSync.h"
#import "TMTrialActionListModel.h"
#import "MONMessages.h"


@interface TMMarketingActionOptionsListModel()
@property (nonatomic) NSArray *dataArray;
@property (nonatomic) NSDictionary *harvestActionsDispatchTable;
@property (nonatomic) TMTrialModel *trialModel;
@property (nonatomic) TMTrialActionListModel *harvestActionModel;
@property (nonatomic,assign) TMUserRole role;
@end

@implementation TMMarketingActionOptionsListModel

-(instancetype)initWithUserRole:(TMUserRole)userRole trialModel:(TMTrialModel*)trialModel {
    self = [super init];
    if(self) {
		self.role = userRole;
        self.dataArray = [NSArray array];
        self.trialModel = trialModel;
        self.harvestActionModel = [[TMTrialActionListModel alloc] init];
		
		if([self.trialModel isTrialIncomplete] || [self trialIsPendingAndCurrentUserCanApprove]) {
			self.dataArray = @[TMRelinqushAndSubmitToMarketingMessage, TMRelinquishTrialMessage, TMCancelTrialMessage];
		} else if([self.trialModel canSubmitToMarketing]) {
			self.dataArray = @[TMSubmitToMarketingMessage];
		}
		self.harvestActionsDispatchTable = @{TMRelinqushAndSubmitToMarketingMessage: NSStringFromSelector(@selector(relinquishAndSubmitToMarketing)),
                                             TMSubmitToMarketingMessage: NSStringFromSelector(@selector(submitToMarketing)),
                                             TMRelinquishTrialMessage: NSStringFromSelector(@selector(relinquish)),
                                             TMCancelTrialMessage: NSStringFromSelector(@selector(cancelTrial))};
    }
    return self;
}

- (BOOL)trialIsPendingAndCurrentUserCanApprove {
    return ([self.trialModel isTrialPending] && (self.role == TMUserRoleTA || self.role == TMUserRoleSuperUser));
}

- (BOOL)marketingActionsAvailable {
	return [self.dataArray count] != 0;
}

-(void)relinquishAndSubmitToMarketing {
    [self saveTrialAndThenExcuteBlock:^{
        [self.harvestActionModel relinquish:self.trialModel submitToMarketing:YES completionBlock:^(NSError *error) {
            if(error == nil) {
                [self.delegate relinquishComplete];
                [self.delegate submitToMarketingComplete];
            }
    }];} errorDetail:@"relinquish and submit to marketing" syncQueueType:TMPendingSyncQueueItemTypeRelinquishAndSubmitToMarketing];
}

-(void)submitToMarketing {
    [self.harvestActionModel submitToMarketing:self.trialModel completionBlock:^(NSError *error) {
        if(error == nil) {
            [self.delegate submitToMarketingComplete];
        }
    }];
}

-(void)relinquish {
    [self saveTrialAndThenExcuteBlock:^{
        [self.harvestActionModel relinquish:self.trialModel submitToMarketing:NO completionBlock:^(NSError *error) {
                if(error == nil) {
                    [self.delegate relinquishComplete];
                }
    }];} errorDetail:@"relinquish" syncQueueType:TMPendingSyncQueueItemTypeRelinquish];
}

-(void)cancelTrial {
    [self saveAndCancelTrialAndThenExcuteBlock:^{
        [self.harvestActionModel cancelTrial:self.trialModel completionBlock:^(NSError *error) {
            if(error == nil) {
                [self.delegate cancelTrialComplete];
            }
        }];} errorDetail:@"cancel trial" syncQueueType:TMPendingSyncQueueItemTypeCancelTrial];
}

-(void)saveTrialAndThenExcuteBlock:(void (^)(void))block errorDetail:(NSString *)errorDetail syncQueueType:(TMPendingSyncQueueItemType)type {
	if([self.trialModel harvestDate] == nil) {
		[MONMessages showErrorMessageTitle:@"Harvest Date not set." subtitle:@"Harvest Date must be set prior to relinquish."];
		return;
	}
	
	if([self.trialModel isFTNTrial] && [self.trialModel hasEntryObservationsForObsName:PlotWeightObsName]) {
		[MONMessages showErrorMessageTitle:@"To relinquish remove plot Weight for FTN trial" subtitle:@"Remove plot weight to relinquish."];
		return;
	}
	
	[[[TMTrialDataSync alloc] init] saveTrialThruPendingQueue:self.trialModel.trial completionBlock:^(NSDictionary * data, NSError *error) {
        if(![self.trialModel hasNewPendingProducts]){
            if(error == nil) {
                block();
            } else {
                [self.harvestActionModel addToPendingSyncQueue:self.trialModel.trial type:type error:error];
                [MONMessages showErrorMessageTitle:[NSString stringWithFormat:@"Trial could not be saved to the server, so the %@ request will be queued for later.", errorDetail]
                                          subtitle:error.localizedDescription];
            }
        }else{
            [self throwPendingProductError];
        }
    }];
}

-(void)saveAndCancelTrialAndThenExcuteBlock:(void (^)(void))block errorDetail:(NSString *)errorDetail syncQueueType:(TMPendingSyncQueueItemType)type {
    [[[TMTrialDataSync alloc] init] saveTrialThruPendingQueue:self.trialModel.trial completionBlock:^(NSDictionary * data, NSError *error) {
        if(error == nil) {
            block();
        } else {
            [self.harvestActionModel addToPendingSyncQueue:self.trialModel.trial type:type error:error];
            [MONMessages showErrorMessageTitle:[NSString stringWithFormat:@"Trial could not be saved to the server, so the %@ request will be queued for later.", errorDetail]
                                      subtitle:error.localizedDescription
             ];
        }
    }];
} 

-(void)throwPendingProductError {
     NSString *appendedEntryNumbers = [[self.trialModel getEntryNumbersOfEntriesWithUnapprovedProducts] componentsJoinedByString:@", "];
     [MONMessages showErrorMessageTitle:@"Cannot relinquish the trial" subtitle: [NSString stringWithFormat:@"Product request for entry number(s): %@ is not complete. Please contact TPS Support: 1-888-711-7717 for further information", appendedEntryNumbers]];
}

-(NSString *)nameForItemAtIndex:(NSInteger)index {
    return [self.dataArray objectAtIndex:index];
}

- (void)performActionForItemAtIndex:(NSInteger)index {
    SEL actionToPerform = NSSelectorFromString([self.harvestActionsDispatchTable valueForKey:[self.dataArray objectAtIndex:index]]);
    
    //methodForSelector returns IMP, and IMP is an 'id',
    //therefore ARC will attempt to manage it, so we must cast the IMP as void (*)(id, SEL))
    ((void (*)(id, SEL))[self methodForSelector:actionToPerform])(self, actionToPerform);
}

@end
