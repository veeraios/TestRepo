@interface TMEntryTableViewHeaderView : UIView

@end
