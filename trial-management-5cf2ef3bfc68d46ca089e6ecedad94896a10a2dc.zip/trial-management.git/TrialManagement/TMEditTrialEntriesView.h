#import <ESCObservable/ESCObservable.h>
#import <UIKit/UIKit.h>

@protocol TMEditTrialEntriesViewObserver <NSObject>

- (void)addEntriesButtonTapped;

@end

@interface TMEditTrialEntriesView : UIView<ESCObservable>

- (instancetype)init UNAVAILABLE_ATTRIBUTE;
- (instancetype)initWithCollectionView:(UICollectionView *)collectionView headerButtons:(NSArray *)headerButtons;
- (void)setNumberOfEntries:(NSUInteger)numberOfEntries animated:(BOOL)animated;

@end
