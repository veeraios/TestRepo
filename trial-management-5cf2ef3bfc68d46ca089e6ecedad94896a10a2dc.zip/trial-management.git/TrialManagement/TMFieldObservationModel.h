#import "TMTrialModel.h"

@interface TMFieldObservationModel : NSObject
- (instancetype)initWithTrialModel:(TMTrialModel*)trialModel;
- (BOOL)hasObservations;
- (NSArray*)fieldInfoObservations;
@end
