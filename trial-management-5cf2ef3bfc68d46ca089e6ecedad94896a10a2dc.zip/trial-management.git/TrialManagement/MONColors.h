#import <Foundation/Foundation.h>

@interface MONColors : NSObject

+ (UIColor *)boneColor;
+ (UIColor *)moonDustColor;
+ (UIColor *)belizeHoleColor;
+ (UIColor *)freshAsphaltColor;
+ (UIColor *)freshAsphaltAlternateColor;
+ (UIColor *)midnightBlueColor;
+ (UIColor *)wetAsphaltColor;
+ (UIColor *)earlGrayColor;
+ (UIColor *)pomegranateColor;
+ (UIColor *)filterBackgroundColor;
+ (UIColor *)ashColor;
+ (UIColor *)selectedCellColor;
+ (UIColor *)previouslySelectedCellColor;
+ (UIColor*)lockedColor;
@end
