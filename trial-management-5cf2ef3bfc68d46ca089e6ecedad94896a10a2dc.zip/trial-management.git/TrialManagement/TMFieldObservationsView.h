#import "TMFieldObservationModel.h"

@protocol TMFieldObservationsViewDelegate
- (void)addObservationsTapped;
@end

@interface TMFieldObservationsView : UIView

@property (nonatomic, weak) id<TMFieldObservationsViewDelegate> delegate;

- (instancetype)initWithFieldObservationModel:(TMFieldObservationModel*)model headerButtons:(NSArray *)headerButtons;
- (void)refreshObservations:(TMFieldObservationModel*)model;
@end
