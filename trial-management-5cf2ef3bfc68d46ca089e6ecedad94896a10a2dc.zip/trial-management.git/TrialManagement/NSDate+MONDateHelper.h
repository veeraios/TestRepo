@interface NSDate (MONDateHelper)
+(NSDate*)currentDateWithYearsFrom:(NSInteger)year;
+(NSDate*)currentDateWithAddedDays:(NSInteger)days;
-(NSDate*)dateWithAddedDays:(NSInteger)days;
-(NSDate*)startOfDate;
+(NSDate*)dateFromMonth:(NSInteger)month day:(NSInteger)day year:(NSInteger)year;
+(NSDate*)midPointBetweenStartDate:(NSDate*)startDate endDate:(NSDate*)endDate;
+(NSArray*)splitDatesByInterval:(NSDate*)startDate endDate:(NSDate*)endDate interval:(NSInteger)interval;
@end
