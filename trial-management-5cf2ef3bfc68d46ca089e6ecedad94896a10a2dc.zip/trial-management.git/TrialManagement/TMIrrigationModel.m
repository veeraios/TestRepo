#import "TMIrrigationModel.h"

@implementation TMIrrigationModel

-(instancetype)init {
    return [super initWithDataArray:@[@"Yes", @"No"] nameBlock:^NSString *(NSInteger index) {
        return [self.dataArray objectAtIndex:index];
    } placeholderText:IrrigationPlaceholderValue];
}

@end
