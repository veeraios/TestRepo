#import "MONTextViewEditorView.h"
#import "MONLabel.h"
#import "MONDimensions.h"
#import "MONFonts.h"
#import "UIColor+MONThemeColorProvider.h"

static const CGFloat HeaderLabelOffset = 7.0;

@interface MONTextViewEditorView ()<UITextViewDelegate, ESCObservableInternal>

@property (nonatomic) MONLabel *headerLabel;
@property (nonatomic) UITextView *textView;
@property (nonatomic) CGRect keyboardFrame;

@end

@implementation MONTextViewEditorView

- (id)initWithFrame:(CGRect)frame {
	self = [super initWithFrame:frame];
	if (self) {
		[self escRegisterObserverProtocol:@protocol(MONTextViewEditorViewObserver)];
		
		self.backgroundColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeBackground];
		
		self.headerLabel = [[MONLabel alloc] init];
		self.headerLabel.font = [UIFont fontWithName:OpenSansLight size:MONFontsHeaderTextSize];
		
		[self addSubview:self.headerLabel];
		
		self.textView = [[UITextView alloc] init];
		self.textView.font = [UIFont fontWithName:OpenSans size:14.0];
		self.textView.delegate = self;
		self.textView.textColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeText];
		self.textView.backgroundColor = self.backgroundColor;
		self.textView.keyboardAppearance = UIKeyboardAppearanceDark;
		self.textView.layer.borderColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeBorder].CGColor;
		self.textView.layer.borderWidth = MONDimensionsThinBorderWidth;
		self.textView.layer.cornerRadius = MONDimensionsCornerRadius;
		self.textView.textContainerInset = UIEdgeInsetsMake(MONDimensionsSmallPadding, MONDimensionsSmallPadding, MONDimensionsSmallPadding, MONDimensionsSmallPadding);
		[self addSubview:self.textView];
		
		[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
	}
	return self;
}

-(void)dealloc {
	[[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)layoutSubviews {
	[super layoutSubviews];
	
	[self.headerLabel sizeToFit];
	self.headerLabel.frame = CGRectMake(MONDimensionsSmallPadding,
										MONDimensionsLargePadding - HeaderLabelOffset,
										CGRectGetWidth(self.headerLabel.frame),
										CGRectGetHeight(self.headerLabel.frame));
	
	self.textView.frame = CGRectMake(MONDimensionsSmallPadding,
									 CGRectGetMaxY(self.headerLabel.frame) + MONDimensionsSmallPadding,
									 CGRectGetWidth(self.bounds) - 2.0 * MONDimensionsSmallPadding,
									 CGRectGetHeight(self.bounds) - CGRectGetMaxY(self.headerLabel.frame) - CGRectGetHeight(self.keyboardFrame) - MONDimensionsSmallPadding - MONDimensionsSmallPadding);
}

- (BOOL)becomeFirstResponder {
	return [self.textView becomeFirstResponder];
}

- (void)setHeaderText:(NSString *)headerText {
	self.headerLabel.text = [headerText uppercaseString];
}

- (void)setText:(NSString *)text {
	self.textView.text = text;
}

#pragma mark - UITextViewDelegate Methods

- (void)textViewDidChange:(UITextView *)textView {
	[self.escNotifier textViewEditorTextDidChange:textView.text];
}

#pragma mark - UIKeyboardDidShowNotification Methods

- (void)keyboardWillShow:(NSNotification *)notification {
	NSValue *keyboardFrameValue = [notification.userInfo objectForKey:UIKeyboardFrameEndUserInfoKey];
	CGRect keyboardFrame = [keyboardFrameValue CGRectValue];
	keyboardFrame = [self convertRect:keyboardFrame fromView:nil];

	self.keyboardFrame = keyboardFrame;
}

#pragma mark - UIKeyboardDidHideNotification Methods

- (void)keyboardWillHide:(NSNotification *)notification {
	
}


@end
