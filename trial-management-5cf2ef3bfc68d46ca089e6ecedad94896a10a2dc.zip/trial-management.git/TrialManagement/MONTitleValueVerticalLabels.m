#import "MONTitleValueVerticalLabels.h"
#import "MONUIConvenienceFunctions.h"
#import "MONLabel.h"
#import "MONFonts.h"

static const CGFloat ValueLabelTopMargin = 5.0;

@interface MONTitleValueVerticalLabels ()

@property (nonatomic) MONLabel *titleLabel;
@property (nonatomic) MONLabel *valueLabel;

@end

@implementation MONTitleValueVerticalLabels

- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
		self.titleLabel = [[MONLabel alloc] init];
		self.titleLabel.fontName = OpenSansBold;
		[self addSubview:self.titleLabel];
		
		self.valueLabel = [[MONLabel alloc] init];
		self.valueLabel.text = @" ";
		self.valueLabel.fontName = OpenSans;
		[self addSubview:self.valueLabel];
    }
    return self;
}

- (void)layoutSubviews {
	[super layoutSubviews];
	[self.titleLabel sizeToFit];
	[self.valueLabel sizeToFit];
	
	CGFloat totalHeight = CGRectGetHeight(self.titleLabel.frame) + ValueLabelTopMargin + CGRectGetHeight(self.valueLabel.frame);
	CGFloat titleLabelTop = MONUIScreenRoundToScreenScale((CGRectGetHeight(self.bounds) - totalHeight) / 2.0);

	self.titleLabel.frame = CGRectMake(0.0, titleLabelTop, CGRectGetWidth(self.bounds), CGRectGetHeight(self.titleLabel.frame));
	
	self.valueLabel.frame = CGRectMake(0.0, CGRectGetMaxY(self.titleLabel.frame) + ValueLabelTopMargin, CGRectGetWidth(self.bounds), CGRectGetHeight(self.valueLabel.frame));
}

- (CGSize)sizeThatFits:(CGSize)size {
	CGSize sizeThatFits = CGSizeMake(size.width, 0.0);
	[self.titleLabel sizeToFit];
	[self.valueLabel sizeToFit];
	
	sizeThatFits.height += CGRectGetHeight(self.titleLabel.frame);
	sizeThatFits.height += ValueLabelTopMargin;
	sizeThatFits.height += CGRectGetHeight(self.valueLabel.frame);
	
	return sizeThatFits;
}

- (void)setTitleText:(NSString *)titleText {
	self.titleLabel.text = titleText;
}

- (void)setValueText:(NSString *)valueText {
	self.valueLabel.text = [valueText uppercaseString];
}

- (void)setTextColor:(UIColor *)textColor {
	self.titleLabel.textColor = textColor;
	self.valueLabel.textColor = textColor;
}

@end
