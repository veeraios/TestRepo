#import "MONLabeledLabel.h"
#import "MONLabel.h"
#import "MONFonts.h"

static const CGFloat InterlabelPadding = 4.0;

@interface MONLabeledLabel ()

@property (nonatomic) MONLabel *textLabel;
@property (nonatomic) MONLabel *valueLabel;

@end

@implementation MONLabeledLabel

- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.textLabel = [[MONLabel alloc] init];
		[self.textLabel setFontName:OpenSansBold];
		[self.textLabel setTextSize:12.0];
		[self addSubview:self.textLabel];
		
        self.valueLabel = [[MONLabel alloc] init];
		[self.valueLabel setFontName:OpenSans];
		[self.valueLabel setTextSize:12.0];
		[self addSubview:self.valueLabel];
		
		[self setValueText:@"N/A"];
    }
    return self;
}

- (void)layoutSubviews {
	[super layoutSubviews];
	
	[self.textLabel sizeToFit];
	self.textLabel.frame = CGRectMake(0.0,
									  0.0,
									  CGRectGetWidth(self.textLabel.frame),
									  CGRectGetHeight(self.textLabel.frame));
	
	[self.valueLabel sizeToFit];
	self.valueLabel.frame = CGRectMake(CGRectGetMaxX(self.textLabel.frame) + InterlabelPadding,
									   0.0,
									   CGRectGetWidth(self.bounds) - CGRectGetWidth(self.textLabel.frame) - InterlabelPadding,
									   CGRectGetHeight(self.valueLabel.frame));
}

- (CGSize)sizeThatFits:(CGSize)size {
	CGSize sizeThatFits = CGSizeZero;
	[self.textLabel sizeToFit];
	[self.valueLabel sizeToFit];
	
	sizeThatFits.width += CGRectGetWidth(self.textLabel.frame);
	sizeThatFits.width += InterlabelPadding;
	sizeThatFits.width += CGRectGetWidth(self.valueLabel.frame);
	
	sizeThatFits.height += MAX(CGRectGetHeight(self.textLabel.frame), CGRectGetHeight(self.valueLabel.frame));
	
	return sizeThatFits;
}

- (void)setLabelText:(NSString *)labelText {
	self.textLabel.text = [NSString stringWithFormat:@"%@:", [labelText uppercaseString]];
	[self setNeedsLayout];
}

- (void)setValueText:(NSString *)valueText {
	if (valueText && ([valueText length] != 0)) {
		self.valueLabel.text = [valueText uppercaseString];
	} else {
		self.valueLabel.text = @"N/A";
	}
	[self setNeedsLayout];
}

- (void)setTextColor:(UIColor *)textColor {
	self.textLabel.textColor = textColor;
	self.valueLabel.textColor = textColor;
}

@end
