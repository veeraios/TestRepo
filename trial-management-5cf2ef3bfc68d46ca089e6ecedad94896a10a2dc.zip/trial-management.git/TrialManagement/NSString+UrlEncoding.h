#import <Foundation/Foundation.h>

@interface NSString (UrlEncoding)
-(NSString*)urlEncode;
@end
