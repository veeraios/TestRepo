@interface TMHarvestInfoViewController : UIViewController

- (instancetype)initWithCropName:(NSString *)cropName;

@end
