#import <Foundation/Foundation.h>
#import "TMHarvestEditContainerView.h"
#import "TMYieldCalculationModel.h"
#import "TMEntryModel.h"

@protocol TMHarvestEditContainerPresenterDelegate <NSObject>
- (void)yieldWasUpdated;
- (void)moistureWasUpdated;
@end

@interface TMHarvestEditContainerPresenter : NSObject
@property (nonatomic, weak) id<TMHarvestEditContainerPresenterDelegate> delegate;

- (instancetype)initWithEntryModel:(TMEntryModel *)entryModel
                   harvestEditContainerView:(TMHarvestEditContainerView *)harvestEditContainerView;

- (void)calculateYieldAndSetAsReadOnlyIfNeeded;

@end
