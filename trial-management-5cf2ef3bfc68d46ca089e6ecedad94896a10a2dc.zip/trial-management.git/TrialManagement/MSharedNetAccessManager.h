#import <Foundation/Foundation.h>
#import "MNetAccessManager.h"

@interface MSharedNetAccessManager : NSObject

+ (id<MNetAccessManager>) sharedNetAccessManager;

@end
