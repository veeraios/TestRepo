#import "MONReadOnlyProtocol.h"

@interface TMHarvestEditContainerView : UIView<MONReadOnlyProtocol>
- (instancetype)initWithHarvestObservations:(NSArray *)harvestObservations;
- (void)shouldSetAsReadOnly:(BOOL)isReadOnly forObsRefCode:(NSString *)observationRefCode;
- (void)setAutoCalulatedValue:(NSString *)value withLabel:(NSString *)labelText forObsRefCode:(NSString *)observationRefCode;
@end
