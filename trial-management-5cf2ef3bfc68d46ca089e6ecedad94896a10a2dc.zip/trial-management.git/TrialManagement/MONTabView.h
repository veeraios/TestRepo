#import <UIKit/UIKit.h>

@protocol MONTabViewDelegate <NSObject>

- (void)tabTappedAtIndex:(NSUInteger)index;

@end

@interface MONTabView : UIView

@property (nonatomic, weak) id<MONTabViewDelegate> delegate;

- (void)setTabModels:(NSArray *)tabModels;
- (void)setSelectedViewController:(UIViewController *)selectedViewController;
- (void)setSelectedTabAtIndex:(NSUInteger)index;

@end
