#import "TMFilterProductsModel.h"
#import "TMWorkingUnitOfWork.h"

@interface TMFilterProductsModel()

@property (nonatomic) NSArray *dataArray;
@property (nonatomic, readonly) NSArray *fullDataArray;
@property (nonatomic) NSArray *searchResults;
@property (nonatomic) NSNumber *cropId;
@property (nonatomic) NSString *brandSearchText;
@property (nonatomic) NSString *productSearchText;
@property (nonatomic) NSString *traitsSearchText;
@property (nonatomic) NSString *rmSearchText;
@property (nonatomic) NSString *rmVarianceSearchText;
@property (nonatomic) id<TMProductRepositoryProtocol> productRepository;

@end

@implementation TMFilterProductsModel

- (instancetype)init {
	return [self initWithProductRepository:[[TMWorkingUnitOfWork sharedInstance] productRepository]];
}

- (instancetype)initWithProductRepository:(id)productRepository {
	self = [super init];
	if (self) {
		self.productRepository = productRepository;
	}
	return self;
}

- (void)setBrandSearchText:(NSString *)brandSearchText {
	_brandSearchText = brandSearchText;
	[self search];
}

- (void)setProductSearchText:(NSString *)productSearchText {
	_productSearchText = productSearchText;
	[self search];
}

- (void)setTraitsSearchText:(NSString *)traitsSearchText {
	_traitsSearchText = traitsSearchText;
	[self search];
}

- (void)setRmSearchText:(NSString *)rmSearchText {
	_rmSearchText = rmSearchText;
	[self search];
}

- (void)setRmVarianceSearchText:(NSString *)rmVarianceSearchText {
	_rmVarianceSearchText = rmVarianceSearchText;
	[self search];
}

- (void)search {
	NSArray *filteredArray = [self.productRepository filterProduct:self.productSearchText
															 brand:self.brandSearchText
															 trait:self.traitsSearchText
																rm:self.rmSearchText
														rmVariance:self.rmVarianceSearchText
															 cropId:self.cropId];
	self.searchResults = filteredArray;
	[self.delegate searchPerformed];
}
@end
