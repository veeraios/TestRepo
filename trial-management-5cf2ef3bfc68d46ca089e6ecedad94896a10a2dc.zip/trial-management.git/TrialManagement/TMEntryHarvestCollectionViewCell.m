#import "TMEntryHarvestCollectionViewCell.h"
#import "MONLabel.h"
#import "MONTitleValueVerticalLabels.h"
#import "MONColors.h"
#import "TMEntryCollectionCellContentView.h"
#import "MONDimensions.h"
#import "TMHarvestEditContainerView.h"
#import "UIColor+MONThemeColorProvider.h"
#import "TMHarvestEditContainerPresenter.h"

static const CGFloat ContentHorizontalPadding = 26.0;
static const CGFloat NumberLabelFontSize = 32.0;
static const CGFloat NumberContainerWidth = 55.0;
static const CGFloat HeaderDefaultHeight = 64.0;
static NSString * const BrandTitle = @"Brand";
static NSString * const ProductTitle = @"Product";
static NSString * const RMTitle = @"RM";
static NSString * const TraitTitle = @"Trait";
static NSString * const TreatmentTitle = @"Treatment";

@interface TMEntryHarvestCollectionViewCell ()<TMHarvestEditContainerPresenterDelegate>

@property (nonatomic) MONCardContainerView *backgroundCardContainerView;
@property (nonatomic) MONCardContainerView *entryHeaderCardContainerView;
@property (nonatomic) UIView *numberContainerView;
@property (nonatomic) MONLabel *numberLabel;
@property (nonatomic) MONTitleValueVerticalLabels *brandTitleLabel;
@property (nonatomic) MONTitleValueVerticalLabels *productTitleLabel;
@property (nonatomic) MONTitleValueVerticalLabels *rmTitleLabel;
@property (nonatomic) MONTitleValueVerticalLabels *traitTitleLabel;
@property (nonatomic) MONTitleValueVerticalLabels *treatmentTitleLabel;
@property (nonatomic) TMHarvestEditContainerView *harvestEditContainerView;
@property (nonatomic) TMHarvestEditContainerPresenter *harvestEditContainerPresenter;

@end

@implementation TMEntryHarvestCollectionViewCell

- (id)initWithFrame:(CGRect)frame {
	self = [super initWithFrame:frame];
	if (self) {
		self.backgroundCardContainerView = [[MONCardContainerView alloc] init];
		[self.contentView addSubview:self.backgroundCardContainerView];
		
		self.entryHeaderCardContainerView = [[MONCardContainerView alloc] init];
		self.entryHeaderCardContainerView.layer.cornerRadius = 0.0;
		[self.backgroundCardContainerView addSubview:self.entryHeaderCardContainerView];
		
		self.numberContainerView = [[UIView alloc] init];
		self.numberContainerView.backgroundColor = [MONColors midnightBlueColor];
		[self.entryHeaderCardContainerView.contentContainerView addSubview:self.numberContainerView];
		
		self.numberLabel = [[MONLabel alloc] init];
		self.numberLabel.textSize = NumberLabelFontSize;
		self.numberLabel.textColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeSelectedText];
		self.numberLabel.textAlignment = NSTextAlignmentCenter;
		[self.numberContainerView addSubview:self.numberLabel];
		
		self.brandTitleLabel = [[MONTitleValueVerticalLabels alloc] init];
		[self.brandTitleLabel setTitleText:BrandTitle];
		[self.entryHeaderCardContainerView.contentContainerView addSubview:self.brandTitleLabel];
		
		self.productTitleLabel = [[MONTitleValueVerticalLabels alloc] init];
		[self.productTitleLabel setTitleText:ProductTitle];
		[self.entryHeaderCardContainerView.contentContainerView addSubview:self.productTitleLabel];
		
		self.rmTitleLabel = [[MONTitleValueVerticalLabels alloc] init];
		[self.rmTitleLabel setTitleText:RMTitle];
		[self.entryHeaderCardContainerView.contentContainerView addSubview:self.rmTitleLabel];

		self.traitTitleLabel = [[MONTitleValueVerticalLabels alloc] init];
		[self.traitTitleLabel setTitleText:TraitTitle];
		[self.entryHeaderCardContainerView.contentContainerView addSubview:self.traitTitleLabel];

		self.treatmentTitleLabel = [[MONTitleValueVerticalLabels alloc] init];
		[self.treatmentTitleLabel setTitleText:TreatmentTitle];
		[self.entryHeaderCardContainerView.contentContainerView addSubview:self.treatmentTitleLabel];

	}
	return self;
}

- (void)layoutSubviews {
	[super layoutSubviews];
	self.backgroundCardContainerView.frame = self.contentView.bounds;
	
	self.entryHeaderCardContainerView.frame = CGRectMake(0.0,
														 0.0,
														 CGRectGetWidth(self.backgroundCardContainerView.bounds),
														 HeaderDefaultHeight);
	
	self.harvestEditContainerView.frame = CGRectMake(MONDimensionsSmallPadding,
														  CGRectGetMaxY(self.entryHeaderCardContainerView.frame) + MONDimensionsLargePadding,
														  CGRectGetWidth(self.backgroundCardContainerView.bounds) - 2.0 * MONDimensionsSmallPadding,
														  CGRectGetHeight(self.backgroundCardContainerView.bounds) - CGRectGetMaxY(self.entryHeaderCardContainerView.frame) - MONDimensionsSmallPadding - MONDimensionsLargePadding);
	
	self.numberContainerView.frame = CGRectMake(0.0,
												0.0,
												NumberContainerWidth,
												CGRectGetHeight(self.entryHeaderCardContainerView.contentContainerView.bounds));
	
	[self.numberLabel sizeToFit];
	
	//TODO: Need to shrink/grow based on orientation

	//quick hack to get some decent layout of table headers, need to make it grow/shrink dynamically based on 'best fit'
	CGFloat brandWidth = 100.0f;
	CGFloat productWidth = 130.0f;
	CGFloat rmWidth = 40.0f;
	CGFloat traitWidth = 80.0f;
	CGFloat treatementWidth = 180.0f;
	if(UIInterfaceOrientationIsLandscape([[UIApplication sharedApplication] statusBarOrientation])) {
		brandWidth = 100.0f + 25;
		productWidth = 130.0f + 25;
		rmWidth = 50.0f + 25;
		traitWidth = 100.0f + 25;
		treatementWidth = 180.0f + 100;
	}
	self.numberLabel.frame = CGRectMake(0.0,
										0.0,
										CGRectGetWidth(self.numberContainerView.bounds),
										CGRectGetHeight(self.numberContainerView.bounds));
	
	self.brandTitleLabel.frame = CGRectMake(CGRectGetMaxX(self.numberContainerView.frame) + ContentHorizontalPadding,
											0.0,
											brandWidth,
											CGRectGetHeight(self.entryHeaderCardContainerView.contentContainerView.bounds));
	
	self.productTitleLabel.frame = CGRectMake(CGRectGetMaxX(self.brandTitleLabel.frame) + ContentHorizontalPadding,
											  0.0,
											  productWidth,
											  CGRectGetHeight(self.entryHeaderCardContainerView.contentContainerView.bounds));
	
	
	self.rmTitleLabel.frame = CGRectMake(CGRectGetMaxX(self.productTitleLabel.frame) + ContentHorizontalPadding,
											  0.0,
											  rmWidth,
											  CGRectGetHeight(self.entryHeaderCardContainerView.contentContainerView.bounds));

	self.traitTitleLabel.frame = CGRectMake(CGRectGetMaxX(self.rmTitleLabel.frame) + ContentHorizontalPadding,
											  0.0,
											  traitWidth,
											  CGRectGetHeight(self.entryHeaderCardContainerView.contentContainerView.bounds));

	self.treatmentTitleLabel.frame = CGRectMake(CGRectGetMaxX(self.traitTitleLabel.frame) + ContentHorizontalPadding,
											  0.0,
											  treatementWidth,
											  CGRectGetHeight(self.entryHeaderCardContainerView.contentContainerView.bounds));
	
}

- (CGSize)sizeThatFits:(CGSize)size {
	CGSize sizeThatFits = CGSizeMake(size.width, 0.0);
	
	sizeThatFits.height += HeaderDefaultHeight;
	
	CGSize harvestEditContainerViewSize = [self.harvestEditContainerView sizeThatFits:CGSizeMake(size.width, size.height - HeaderDefaultHeight)];
	sizeThatFits.height += harvestEditContainerViewSize.height;
	sizeThatFits.height += MONDimensionsLargePadding + MONDimensionsSmallPadding;
	
	return sizeThatFits;
}

- (void)moistureWasUpdated {
	[self.delegate moistureWasUpdated];
}

-(void)yieldWasUpdated {
	[self.delegate yieldWasUpdated];
}

- (void)setEntryModel:(TMEntryModel*)entryModel {
    NSArray *harvestObservations = [entryModel harvestObservations];
    TMHarvestEditContainerView *harvestEditContainerView = [[TMHarvestEditContainerView alloc] initWithHarvestObservations:harvestObservations];
    self.harvestEditContainerPresenter = [[TMHarvestEditContainerPresenter alloc] initWithEntryModel:entryModel
                                                                            harvestEditContainerView:harvestEditContainerView];
	self.harvestEditContainerPresenter.delegate = self;
	[self setHarvestEditContainerView:harvestEditContainerView];
	[self setNumber:[entryModel entryNumber]];
	[self setBrand:[entryModel brandName]];
	[self setProduct:[entryModel productName]];
	[self setRM:[entryModel maturityRating]];
	[self setTrait:[entryModel traitName]];
	[self setTreatment:[entryModel treatmentName]];
}

- (void)setHarvestEditContainerView:(TMHarvestEditContainerView *)harvestEditContainerView {
	[_harvestEditContainerView removeFromSuperview];
	
	_harvestEditContainerView = harvestEditContainerView;
	
	[self.backgroundCardContainerView addSubview:harvestEditContainerView];
}

- (void)setNumber:(NSInteger)number {
	self.numberLabel.text = [NSString stringWithFormat:@"%ld", (long)number];
	[self setNeedsLayout];
}

- (void)setBrand:(NSString *)brand {
	[self.brandTitleLabel setValueText:brand];
}

- (void)setProduct:(NSString *)product {
	[self.productTitleLabel setValueText:product];
}

- (void)setRM:(NSString *)rm {
	[self.rmTitleLabel setValueText:rm];
}

- (void)setTrait:(NSString *)trait {
	[self.traitTitleLabel setValueText:trait];
}

- (void)setTreatment:(NSString *)treatment {
	[self.treatmentTitleLabel setValueText:treatment];
}

- (void)setharvestEditContainerView:(TMHarvestEditContainerView *)harvestEditContainerView {
	[_harvestEditContainerView removeFromSuperview];
	
	_harvestEditContainerView = harvestEditContainerView;
	
	[self.backgroundCardContainerView addSubview:harvestEditContainerView];
}

- (void)calculateYieldAndSetAsReadOnlyIfNeeded {
    [self.harvestEditContainerPresenter calculateYieldAndSetAsReadOnlyIfNeeded];
}

#pragma mark MONReadOnlyProtocol
- (void)setAsReadOnly {
    [self.harvestEditContainerView setAsReadOnly];
}

@end
