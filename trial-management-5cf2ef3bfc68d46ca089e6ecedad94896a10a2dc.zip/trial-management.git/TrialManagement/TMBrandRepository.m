#import "TMBrandRepository.h"
#import "TMBrand.h"

@implementation TMBrandRepository

- (TMBrand *)createBrandWithBrandId:(NSNumber *)brandId
						brandName:(NSString *)brandName {
	TMBrand *brand;
	if (brandId == nil) {
		brand = [self brandForBrandName:brandName];
	} else {
        brand = [self brandForBrandId:brandId];
    }
	if (brand == nil) {
		brand = [self create];
		brand.brandId = brandId;
		brand.name = brandName;
        [self saveContext];
	}
	return brand;
}

- (void)syncFromService:(NSArray*)dataFromService completionBlock:(MONDataImportCompletionBlock)completionBlock {	
	__block TMUser *currentUser = [self currentUser];

	MONDataImportBlock block = ^(NSDictionary* dict, NSManagedObject *coredataModel) {
		TMBrand* cdmodel = (TMBrand*)coredataModel;
		cdmodel.brandId = dict[@"id"];
		cdmodel.name = dict[@"name"];
		[cdmodel addUsersObject:currentUser];
	};

	[self import:dataFromService dataServicePrimaryKey:@"id" databasePrimaryKey:@"brandId" dataImportBlock:block currentUser:currentUser completionBlock:completionBlock];
}

- (TMBrand *)brandForBrandId:(NSNumber *)brandId {
	NSArray *brands = [self find:[NSString stringWithFormat:@"brandId == %@", brandId]];
	return [brands firstObject];
}

- (TMBrand *)brandForBrandName:(NSString *)brandName {
	return [self findWithoutUser:[TMBrand class] key:@"name" value:brandName];
}

- (NSArray *)validBrandsSortedByName {
    return [self find:@"name != NULL AND name != ''" orderBy:@"name" ascending:YES];
}

@end
