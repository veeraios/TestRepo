#import "TMEditTrialCooperatorView.h"
#import "MONHeaderView.h"
#import "MONDimensions.h"
#import "MONFonts.h"
#import "TMShortDescriptionView.h"
#import "TMPlotLocationView.h"
#import "TMSearchView.h"
#import "MONLabeledYesNoSwitch.h"
#import "UIColor+MONThemeColorProvider.h"

static NSString *const SelectGrowerDealerPlaceholderText = @"None Selected";

@interface TMEditTrialCooperatorView () <UIScrollViewDelegate, TMPlotLocationViewDelegate, TMSearchViewDelegate, TMShortDescriptionViewDelegate>

@property(nonatomic) TMCooperatorInfoViewModel *viewModel;
@property(nonatomic) UIScrollView *scrollView;
@property(nonatomic) MONHeaderView *headerView;
@property(nonatomic) MONLabeledYesNoSwitch *harvestedSpatially;
@property(nonatomic) TMPlotLocationView *plotLocationView;
@property(nonatomic) UIView *selectContainerView;
@property(nonatomic) TMSearchView *selectGrowerView;
@property(nonatomic) TMSearchView *selectDealerView;
@property(nonatomic) TMShortDescriptionView *shortDescriptionView;
@property(nonatomic) MONAgreementView *agreementView;
@property(nonatomic) MONLabel *responseRequiredLabel;

@end

@implementation TMEditTrialCooperatorView

- (instancetype)initWithViewModel:(TMCooperatorInfoViewModel *)viewModel headerButtons:(NSArray *)headerButtons {
  self = [super init];
  if (self) {
    self.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;

    self.viewModel = viewModel;

    self.scrollView = [[UIScrollView alloc] init];
    self.scrollView.scrollEnabled = YES;
    self.scrollView.bounces = YES;
    self.scrollView.delegate = self;
    [self addSubview:self.scrollView];

    self.headerView = [[MONHeaderView alloc] init];
    self.headerView.backgroundColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeBackground];
    [self.headerView setRightButtons:headerButtons];
    [self.headerView setTitle:@"GROWER INFORMATION"];
    [self addSubview:self.headerView];

    self.harvestedSpatially = [[MONLabeledYesNoSwitch alloc] initWithTitle:@"Will this be harvested Spatially? *"];
    [self.harvestedSpatially.yesNoSwitch addTarget:self action:@selector(harvestedSpatiallyWasTapped) forControlEvents:UIControlEventValueChanged];
    [self.scrollView addSubview:self.harvestedSpatially];

    self.plotLocationView = [[TMPlotLocationView alloc] initWithModel:self.viewModel.statesModel];
    self.plotLocationView.delegate = self;
    [self.scrollView addSubview:self.plotLocationView];

    self.selectContainerView = [[UIView alloc] init];
    [self.scrollView addSubview:self.selectContainerView];

    self.selectDealerView = [[TMSearchView alloc] initWithTitle:@"SELECT A DEALER"];
    self.selectDealerView.delegate = self;
    [self.selectContainerView addSubview:self.selectDealerView];

    self.selectGrowerView = [[TMSearchView alloc] initWithTitle:@"SELECT A GROWER"];
    self.selectGrowerView.delegate = self;
    [self.selectContainerView addSubview:self.selectGrowerView];

    self.shortDescriptionView = [[TMShortDescriptionView alloc] init];
    self.shortDescriptionView.delegate = self;
    [self.scrollView addSubview:self.shortDescriptionView];

    self.agreementView = [[MONAgreementView alloc] init];
    self.agreementView.delegate = self.agreementDelegate;
    [self.scrollView addSubview:self.agreementView];

    self.responseRequiredLabel = [[MONLabel alloc] init];
    self.responseRequiredLabel.text = @"* = Response Required";
    [self.responseRequiredLabel setFontName:OpenSans];
    [self.scrollView addSubview:self.responseRequiredLabel];
  }
  return self;
}

- (void)setCooperatorRelease:(BOOL)value {
  [self.agreementView setCooperatorRelease:value];
}

- (void)setCooperatorSignature:(BOOL)value {
  [self.agreementView setSignatureIsAgreed:value];
}

- (void)setCooperatorSignatureDate:(NSDate *)date {
  [self.agreementView setSignatureDate:date];
}

- (void)stateWasSelected:(id)state {
  [self.delegate stateWasSelected:state];
}

- (void)resetCounty {
  [self.delegate resetCounty];
}

- (void)countyWasSelected:(id)county {
  [self.delegate countyWasSelected:county];
}

- (void)harvestedSpatiallyWasTapped {
  [self.delegate harvestSpatiallyTapped:self.harvestedSpatially.yesNoSwitch.switchValue];
}

- (void)layoutSubviews {
  [super layoutSubviews];

  self.scrollView.frame = self.bounds;

  CGFloat columnWidth = (CGFloat) ((CGRectGetWidth(self.bounds) - (MONDimensionsSmallPadding * 3.0)) / 2.0);

  [self.headerView sizeToFit];
  self.headerView.frame = CGRectMake(0.0, 0.0, CGRectGetWidth(self.bounds), CGRectGetHeight(self.headerView.frame));

  [self.harvestedSpatially sizeToFit];
  self.harvestedSpatially.frame = CGRectMake(MONDimensionsSmallPadding, CGRectGetMaxY(self.headerView.frame) + MONDimensionsSmallPadding, CGRectGetWidth(self.headerView.frame) - (MONDimensionsSmallPadding * 2), CGRectGetHeight(self.harvestedSpatially.frame));


  CGSize growerContainerSize = [self.selectGrowerView sizeThatFits:CGSizeZero];
  CGSize dealerContainerSize = [self.selectDealerView sizeThatFits:CGSizeZero];
  CGFloat totalGrowerDealerHeight = growerContainerSize.height + MONDimensionsSmallPadding + dealerContainerSize.height;
  CGSize plotLocationViewSize = [self.plotLocationView sizeThatFits:CGSizeMake(columnWidth, CGFLOAT_MAX)];
  CGFloat sectionHeight = MAX(totalGrowerDealerHeight, plotLocationViewSize.height);

  self.plotLocationView.frame = CGRectMake(MONDimensionsSmallPadding,
      CGRectGetMaxY(self.harvestedSpatially.frame) + MONDimensionsSmallPadding,
      columnWidth,
      sectionHeight);

  self.selectContainerView.frame = CGRectMake(CGRectGetMaxX(self.plotLocationView.frame) + MONDimensionsSmallPadding,
      CGRectGetMinY(self.plotLocationView.frame),
      columnWidth,
      sectionHeight);
  self.selectGrowerView.frame = CGRectMake(0.0, 0.0, CGRectGetWidth(self.selectContainerView.bounds), growerContainerSize.height);
  self.selectDealerView.frame = CGRectMake(0.0, CGRectGetMaxY(self.selectGrowerView.frame) + MONDimensionsSmallPadding, CGRectGetWidth(self.selectContainerView.bounds), dealerContainerSize.height);

  CGSize shortDescSize = [self.shortDescriptionView sizeThatFits:self.bounds.size];

  self.shortDescriptionView.frame = CGRectMake(MONDimensionsSmallPadding,
      CGRectGetMaxY(self.plotLocationView.frame) + MONDimensionsSmallPadding,
      (CGFloat) (CGRectGetWidth(self.scrollView.bounds) - MONDimensionsSmallPadding * 2.0),
      shortDescSize.height);

  CGSize agreementViewSize = [self.agreementView sizeThatFits:CGSizeMake((CGFloat) (CGRectGetWidth(self.bounds) - 2.0 * MONDimensionsSmallPadding), CGFLOAT_MAX)];
  self.agreementView.frame = CGRectMake(MONDimensionsSmallPadding,
      CGRectGetMaxY(self.shortDescriptionView.frame) + MONDimensionsSmallPadding,
      (CGFloat) (CGRectGetWidth(self.bounds) - 2.0 * MONDimensionsSmallPadding),
      agreementViewSize.height);

  [self.responseRequiredLabel sizeToFit];
  self.responseRequiredLabel.frame = CGRectMake(MONDimensionsSmallPadding,
      CGRectGetMaxY(self.agreementView.frame) + MONDimensionsSmallPadding,
      CGRectGetWidth(self.responseRequiredLabel.frame),
      CGRectGetHeight(self.responseRequiredLabel.frame));

  CGFloat scrollContentHeight = CGRectGetMaxY(self.responseRequiredLabel.frame) + MONDimensionsSmallPadding;
  self.scrollView.contentSize = CGSizeMake(CGRectGetWidth(self.scrollView.bounds), scrollContentHeight);
}

- (void)setHarvestSpatially:(BOOL)value {
  [self.harvestedSpatially.yesNoSwitch setSwitchValue:value];
}

- (void)setAgreementSignatureImage:(UIImage *)signatureImage {
  [self.agreementView setSignatureImage:signatureImage];
}

- (void)setAgreementDelegate:(id <MONAgreementDelegate>)agreementDelegate {
  _agreementView.delegate = agreementDelegate;
  _agreementDelegate = agreementDelegate;
}

- (void)setDealerName:(NSString *)dealerName {
  [self.selectDealerView setShortDescriptionText:[dealerName length] > 0 ? dealerName : SelectGrowerDealerPlaceholderText];
  [self setNeedsLayout];
}

- (void)setGrowerName:(NSString *)growerName {
  [self.selectGrowerView setShortDescriptionText:[growerName length] > 0 ? growerName : SelectGrowerDealerPlaceholderText];
  [self.agreementView setGrowerNameToSignature:growerName];
  [self setNeedsLayout];
}

- (void)setState:(NSString *)stateName {
  [self.plotLocationView setState:stateName];
}

- (void)setCounty:(NSString *)countyName {
  [self.plotLocationView setCounty:countyName];
}

- (void)setShortDescriptionText:(NSString *)enteredText {
  [self.shortDescriptionView setShortDescriptionText:enteredText];
  [self setNeedsLayout];
}

- (void)setCropName:(NSString *)cropName brandName:(NSString *)brandName {
  [self.agreementView setCropName:cropName brandName:brandName];
}

#pragma mark - TMSearchViewDelegate Methods

- (void)searchCooperatorButtonTapped:(TMSearchView *)searchView {
  if (searchView == self.selectDealerView) {
    [self.delegate selectDealerTapped];
  } else if (searchView == self.selectGrowerView) {
    [self.delegate selectGrowerTapped];
  }
}

- (void)updateCooperatorButtonTapped:(TMSearchView *)searchView {
  if (searchView == self.selectDealerView) {
    [self.delegate updateDealerInfoTapped];
  } else if (searchView == self.selectGrowerView) {
    [self.delegate updateGrowerInfoTapped];
  }
}

#pragma mark - TMShortDescriptionViewDelegate Methods

- (void)shortDescriptionViewTapped:(TMShortDescriptionView *)shortDescriptionView {
  [self.delegate shortDescriptionTapped:[self.shortDescriptionView shortDescriptionText]];
}

@end