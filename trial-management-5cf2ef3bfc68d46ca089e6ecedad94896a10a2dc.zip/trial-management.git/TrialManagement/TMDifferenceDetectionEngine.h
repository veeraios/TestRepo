//
//  TMDifferenceDetectionEngine.h
//  TrialManagement
//
//  Created by GADIRAJU, PRANEETH [AG/1000] on 1/5/15.
//  Copyright (c) 2015 Monsanto. All rights reserved.
//

#import "TMTrial.h"
#import "MONContextProtocol.h"

@interface TMDifferenceDetectionEngine : NSObject
- (instancetype)initWithBackupContext:(id<MONContextProtocol>)backupContext;
- (NSDictionary *)changesInCurrentContextForTrial:(TMTrial *)trial;
@end
