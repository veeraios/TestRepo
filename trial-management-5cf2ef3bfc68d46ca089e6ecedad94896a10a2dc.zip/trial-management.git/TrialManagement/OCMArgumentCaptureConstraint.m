@implementation OCMArg(OCMArgumentCaptureConstraint)

+ (id)capture:(void *)captor {
	return [[OCMArgumentCaptureConstraint alloc] initWithCaptor:(id __strong *)captor];
}

@end

@interface OCMArgumentCaptureConstraint()

@end

@implementation OCMArgumentCaptureConstraint

- (id)initWithCaptor:(id __strong *)captor {
    if (self = [super init]) {
		_captor = captor;
    }
    return self;
}

- (BOOL)evaluate:(id)value {
	if ([self isBlock:value]) {
		*_captor = [value copy];
	} else {
		*_captor = value;
	}
	return YES;
}

- (BOOL)isBlock:(id)item {
	id block = ^{};
	Class blockClass = [block class];
	while ([blockClass superclass] != [NSObject class]) {
		blockClass = [blockClass superclass];
	}
	return [item isKindOfClass:blockClass];
}
@end
