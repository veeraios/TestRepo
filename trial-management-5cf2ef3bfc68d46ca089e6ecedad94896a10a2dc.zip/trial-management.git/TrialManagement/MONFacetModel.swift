import UIKit

protocol MONFacetModelDelegate: class {
    func finalizedFacet(prevFacet: MONFacetModel, nextFacet: MONFacetModel)
}

class MONFacetModel: NSObject {
    weak var delegate: MONFacetModelDelegate?
    
    private(set) var finalizedObjectIds = [String]()
    private(set) var fetchedObjects = [MONFacetSearchObjectProtocol]()
    
    private let basePredicate: MONFacetPredicateProtocol
    private(set) var prevText: String?
    
    init(basePredicate: MONFacetPredicateProtocol, fetchedObjects: [MONFacetSearchObjectProtocol]) {
        self.basePredicate = basePredicate
        self.fetchedObjects = fetchedObjects
        super.init()
    }
    
    convenience init(basePredicate: MONFacetPredicateProtocol, finalizedObjectIds: [String]) {
        self.init(basePredicate: basePredicate, fetchedObjects: [])
        self.finalizedObjectIds = finalizedObjectIds
    }

    func searchOnText(text: String?, dataSource: [MONFacetSearchObjectProtocol], filteredIds: [String]) {
        let idPredicate = NSPredicate(format: "self.searchID IN %@", filteredIds)!
        let fullPredicate = NSCompoundPredicate(type: NSCompoundPredicateType.AndPredicateType, subpredicates: [idPredicate, basePredicate.facetPredicateWithText(text)])

        if text != nil && !text!.isEmpty {
            if !fetchedObjects.isEmpty && text!.hasPrefix(prevText ?? "") {
                fetchedObjects = fetchedObjects.filter( {fullPredicate.evaluateWithObject($0)} )
            } else {
                fetchedObjects = dataSource.filter( {fullPredicate.evaluateWithObject($0)} )
            }
        } else {
            fetchedObjects = dataSource.filter( {idPredicate.evaluateWithObject($0)} )
        }
        prevText = text
    }
    
    func recalculateFacet(dataSource: [MONFacetSearchObjectProtocol], filteredIds: [String]) {
        fetchedObjects = [MONFacetSearchObjectProtocol]()
        searchOnText(prevText, dataSource: dataSource, filteredIds: filteredIds)
    }
    
    func finializeFacet(dataSource: [MONFacetSearchObjectProtocol]) {
        if let facetDelegate = delegate {
            let predicate = basePredicate.facetPredicateWithText(prevText)
            finalizedObjectIds = dataSource.filter( {predicate.evaluateWithObject($0)} ).map( {$0.searchID} )
            facetDelegate.finalizedFacet(self, nextFacet: MONFacetModel(basePredicate: basePredicate, fetchedObjects: fetchedObjects))
            fetchedObjects.removeAll(keepCapacity: false)
        }
    }
    
    func compareFinalizedFacetIds(searchIDs: [String]) -> [String]{
        return finalizedObjectIds.filter( {contains(searchIDs, $0)} )
    }
}
