//
//  TMMergeGroupFactory.swift
//  TrialManagement
//
//  Created by WAIDMANN, ALAN [AG/1000] on 1/26/15.
//  Copyright (c) 2015 Monsanto. All rights reserved.
//


class TMMergeGroupFactory : NSObject {
    typealias PathFilter = (String,String) -> Bool
    
    let allChanges : [MONChange]
    let allChangePaths : [String]
    let crop: TMCrop
    
    init(crop: TMCrop, allChanges: [MONChange] ) {
        self.allChanges = allChanges
        self.allChangePaths = allChanges.map( {$0.path} )
        self.crop = crop
        super.init()
    }
    
    func filterChangesForAllSections() -> [()->[TMMergeGroup]]  {
        /** Filter changes for all sections

        return [{[unowned self] in self.filterChangesForEditTrialSection()},
                {[unowned self] in self.filterChangesForGrowerInfoSection()},
                {[unowned self] in self.filterChangesForGPSInfoSection()},
                {[unowned self] in self.filterChangesForPlantingInfoSection()},
                {[unowned self] in self.filterChangesForMarketingSection()},
                {[unowned self] in self.filterChangesForFieldObservationsSection()},
                {[unowned self] in self.filterChangesForAddEntriesSection()},
                {[unowned self] in self.filterChangesForInSeasonObservationsSection()},
                {[unowned self] in self.filterChangesForHarvestDataSection()}]
       
        **/
        
        return [{[unowned self] in self.filterChangesForEditTrialSection()}]
    }
    
    //Simple prefix
    func filterChangesForEditTrialSection() -> [TMMergeGroup] {
        return filterChangesForSection(TMMergeEditTrialSection().groups, section: TMMergeEditTrialSection().section)
    }
    
    func filterChangesForGrowerInfoSection() -> [TMMergeGroup] {
        return filterChangesForSection(TMMergeGrowerInfoSection().groups, section: TMMergeGrowerInfoSection().section)
    }
    
    func filterChangesForGPSInfoSection() -> [TMMergeGroup] {
        return filterChangesForSection(TMMergeGPSInfoSection().groups, section: TMMergeGPSInfoSection().section)
    }

    func filterChangesForPlantingInfoSection() -> [TMMergeGroup] {
        return filterChangesForSection(TMMergePlantingInfoSection().groups, section: TMMergePlantingInfoSection().section)
    }
    
    func filterChangesForMarketingSection() -> [TMMergeGroup] {
        return filterChangesForSection(TMMergeMarketingSection().groups, section: TMMergeMarketingSection().section)
    }
    
    //Single variable prefix
    func filterChangesForFieldObservationsSection() -> [TMMergeGroup] {
        return filterChangesForSection(explicitPrefixesForSection(TMMergeFieldObservationsSection()), section: TMMergeFieldObservationsSection().section)
    }
    
    //Single variable join prefix
    func filterChangesForAddEntriesSection() -> [TMMergeGroup] {
        return filterChangesForSection(explicitPrefixesForSection(TMMergeAddEntriesSection()), section: TMMergeAddEntriesSection().section)
    }
    
    //Multi variable join prefix
    func filterChangesForInSeasonObservationsSection() -> [TMMergeGroup] {
        return filterChangesForSection(explicitPrefixesForSection(TMMergeInSeasonObservationsSection()), section: TMMergeInSeasonObservationsSection().section)
    }
    
    func filterChangesForHarvestDataSection() -> [TMMergeGroup] {
        return filterChangesForSection(explicitPrefixesForSection(TMMergeHarvestSection(cropName: crop.name!)), section: TMMergeHarvestSection().section)
    }
    
    private func filterChangesForSection(groupSpecs: [TMMergeGroupSpec], section: TMMergeSection) -> [TMMergeGroup] {
        
        var groups = [TMMergeGroup]()
        for specification in groupSpecs {
            
            var filteredChanges = [TMMergeValue]()
            for pathPrefix in specification.pathPrefixes {
                let changesByPath = allChanges.filter( {$0.path.hasPrefix(pathPrefix)} )
                filteredChanges.extend(changesByPath.map({TMMergeValue(title:"", path: $0.path, webValue: $0.leftValue, mobileValue: $0.rightValue, resolvedValue: $0.resolvedValue)}))
            }
            if !filteredChanges.isEmpty {
                groups.append(TMMergeGroup(section: section, subsection: specification.subSection, mergeValues: filteredChanges, pathLabelSpecs: specification.labelPathSpecs))
            }
        }
        return groups
    }
    
    private func buildExplicitPathPrefixes(templateSpec: TMMergeGroupSpec, variables: [String:[String]]) -> [TMMergeGroupSpec] {
        
        func replaceTemplateKeyWithValues(template:String, keyValuePair:(String,String)) -> String {
            return template.stringByReplacingOccurrencesOfString("<\(keyValuePair.0)>", withString: keyValuePair.1, options: NSStringCompareOptions.allZeros, range: template.startIndex..<template.endIndex)
        }
        
        func populateValuesInAllTemplates(templates:[String], keyValuePair:(String,String)) -> [String] {
            return templates.map({replaceTemplateKeyWithValues($0, keyValuePair)})
        }
        
        func buildExplicitPathPrefixesForVar(expandedTemplates: ([String],[TMMergePathDisplaySpec]), key: String, values: [String]) -> [([String],[TMMergePathDisplaySpec])] {
            var prefixToDisplaySpec = [([String],[TMMergePathDisplaySpec])]()
            var prefixGroup = [String]()
            
            for value in values {
                prefixGroup = populateValuesInAllTemplates(expandedTemplates.0, (key, value))
                
                var displaySpecs = [TMMergePathDisplaySpec]()
                expandedTemplates.1.forEach({displaySpecs.append(TMMergePathDisplaySpec(label: $0.label, valueFormat: $0.valueFormat, valueFormatArgs: populateValuesInAllTemplates($0.valueFormatArgs, (key, value))))})
                
                prefixToDisplaySpec.extend([(prefixGroup,displaySpecs)])
            }
            
            return prefixToDisplaySpec
        }
        
        var prefixLabelSpecsPair = [([String] ,[TMMergePathDisplaySpec])]()
        var explicitPrefixes = [[String]]()
        var labelPathSpecs = [[TMMergePathDisplaySpec]]()
        for key in variables.keys.array {
            prefixLabelSpecsPair = prefixLabelSpecsPair.isEmpty ? prefixLabelSpecsPair + buildExplicitPathPrefixesForVar((templateSpec.pathPrefixes,templateSpec.labelPathSpecs), key, variables[key]!) : prefixLabelSpecsPair.reduce([], combine: { $0 + buildExplicitPathPrefixesForVar($1, key, variables[key]!)} )
            
        }
        return prefixLabelSpecsPair.map( {TMMergeGroupSpec(subSection: templateSpec.subSection, pathPrefixes: $0.0, labelPathSpecs: $0.1)} )
    }
    
    
    
    private func explicitPrefixesForSection(section: TMMergeSectionProtocol) -> [TMMergeGroupSpec] {
        var explicitGroupPrefixes = [TMMergeGroupSpec]()
        
        for groupSpec in section.groups {
            
            var allPopulatedVars = [String:[String]]()
            for template in groupSpec.pathPrefixes {
                let populatedVars = TMPathTemplateVariablePopulator.populateVarsInPath(template, pathsToChanges: allChangePaths)
                for (varName,varValues) in populatedVars {
                    allPopulatedVars[varName] = (allPopulatedVars[varName] != nil) ? allPopulatedVars[varName]! + varValues.filter( {!contains(allPopulatedVars[varName]!, $0)} ) : varValues
                }
            }
            
            explicitGroupPrefixes.extend( buildExplicitPathPrefixes(groupSpec, variables: allPopulatedVars) )
        }
        
        return explicitGroupPrefixes
    }
}