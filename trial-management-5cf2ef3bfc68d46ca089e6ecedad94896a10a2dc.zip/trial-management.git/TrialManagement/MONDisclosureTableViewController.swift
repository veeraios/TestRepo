import UIKit

protocol MONDisclosureTableViewControllerDelegate {
    func criteriaUpdated(element:String?)
}

class MONDisclosureTableViewController: UIViewController, MONDisclosureTableViewDelegate {
    private let criteriaSelectionView: MONDisclosureTableView
    
    var delegate: MONDisclosureTableViewControllerDelegate?
    
    init(title:String, criteriaDataArray: [String], selectedValue:String) {
        criteriaSelectionView = MONDisclosureTableView(criteriaDataArray: criteriaDataArray, selectedValue: selectedValue)
        
        super.init(nibName: nil, bundle: nil)
        
        criteriaSelectionView.selectionViewDelegate = self
        
        self.title = title
        
        view.addSubview(criteriaSelectionView)
    }
    
    required init(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        
        criteriaSelectionView.frame = view.bounds
    }
    
    //MARK: - MONSelectionViewDelegate methods
    func criteriaSelected(element:String?) {
        delegate?.criteriaUpdated(element)
    }
}
