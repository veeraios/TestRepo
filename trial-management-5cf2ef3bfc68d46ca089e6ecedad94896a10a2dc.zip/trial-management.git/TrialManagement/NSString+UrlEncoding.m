#import "NSString+UrlEncoding.h"

@implementation NSString (UrlEncoding)

-(NSString*)urlEncode {

	NSString *charactersToEscape = @"!*'();:@&=+$,/?%#[]\" ";
	NSCharacterSet *allowedCharacters = [[NSCharacterSet characterSetWithCharactersInString:charactersToEscape] invertedSet];
	
	return [self stringByAddingPercentEncodingWithAllowedCharacters:allowedCharacters];

}
@end
