#import "TMEntryModel.h"
#import "TMObservationModel.h"
#import "TMProduct.h"
#import "TMObservationTypeModel.h"
#import "NSArray+TMBlocks.h"
#import "TMTreatment.h"
#import "TMObservationReferenceCategory.h"
#import "TMTrial.h"
#import "TMCrop.h"
#import "TrialManagement-Swift.h"

@interface TMEntryModel()

@property (nonatomic) TMEntry *entry;
@property (nonatomic) NSArray *harvestObservations;
@property (nonatomic) NSArray *inSeasonObservations;
@property (nonatomic) TMObservationCalculationModel *observationCalculationModel;
@property (nonatomic) TMYieldCalculationModel *yieldCalculationModel;
@property (nonatomic) BOOL disablePlotWeightAndYield;
@property (nonatomic) BOOL hasDefaultRowsHarvested;
@property (nonatomic) BOOL hasDefaultRowSpacing;

@end

@implementation TMEntryModel

-(instancetype)initWithEntry:(TMEntry*)entry {
	self = [super init];
	if(self) {
        self.entry = entry;
	}
	return self;
}

- (instancetype)initWithEntry:(TMEntry *)entry
  observationCalculationModel:(TMObservationCalculationModel *)observationCalculationModel
    disablePlotWeightAndYield:(BOOL)disablePlotWeightAndYield
 hasDefaultRowsHarvestedValue:(BOOL)hasDefaultRowsHarvestedValue
    hasDefaultRowSpacingValue:(BOOL)hasDefaultRowSpacingValue{
    self = [super init];
    if(self) {
        self.entry = entry;
        self.observationCalculationModel = observationCalculationModel;
        self.disablePlotWeightAndYield = disablePlotWeightAndYield;
        self.hasDefaultRowsHarvested = hasDefaultRowsHarvestedValue;
        self.hasDefaultRowSpacing = hasDefaultRowSpacingValue;
    }
    return self;
}

-(TMYieldCalculationModel *)yieldCalculationModel {
    if (!_yieldCalculationModel) {
        self.yieldCalculationModel = [[TMYieldCalculationModel alloc] initWithObservationCalculationModel:self.observationCalculationModel
                                                                                                 cropName:self.entry.trial.crop.name
                                                                                        observationModels:self.harvestObservations];
    }
    return _yieldCalculationModel;
}

- (BOOL)hasInSeasonObservations {
	return [self.inSeasonObservations count] > 0;
}

- (NSArray*)harvestYieldObservations {
	return [[self harvestObservations] where:^BOOL(TMObservationModel *item) {
		return [[[item observationClass] uppercaseString] isEqualToString:@"YIELD"];
	}];
}

- (NSArray*)harvestMoistureObservations {
	return [[self harvestObservations] where:^BOOL(TMObservationModel *item) {
		return [[[item observationClass] uppercaseString] isEqualToString:@"HARVEST MOISTURE"];
	}];
}

- (NSArray*)harvestObservations {
    if (!_harvestObservations) {
        _harvestObservations = [[self.entry.observations allObjects] arrayForEach:^TMObservationModel*(TMObservation* observation) {
            
            TMObservationModel *tmObservationModel =  [[TMObservationModel alloc] initWithObservation:observation];
            
            if(!tmObservationModel.observationValue) {
                [tmObservationModel setObservationValue:[self defaultValueFromTrialPlantingModel:observation]];
            }
            
            return tmObservationModel;
            
        } where:^BOOL(TMObservation* whereObj) {
            return [whereObj.observationReferenceData.category.name isEqualToString:[TMConstants Harvest]];
        }];
    }
    
    return _harvestObservations;
}

- (NSString *)defaultValueFromTrialPlantingModel:(TMObservation *)observation {
    NSString *defaultValue = nil;
    
    if([observation.observationReferenceData.name isEqualToString:RowSpacingObsName] && !self.hasDefaultRowSpacing) {
        defaultValue = [self.entry.trial.rowSpacing stringValue];
    } else if ([observation.observationReferenceData.name isEqualToString:RowsHarvestedObsName] && !self.hasDefaultRowsHarvested) {
        defaultValue = [self.entry.trial.rowsPerPlot stringValue];
    }
    
    return defaultValue;
    
}

- (NSArray*)inSeasonObservations {
    if (!_inSeasonObservations) {
        _inSeasonObservations = [[self.entry.observations allObjects] arrayForEach:^TMObservationModel*(TMObservation* observation) {
            return [[TMObservationModel alloc] initWithObservation:observation];;
        } where:^BOOL(TMObservation *whereObj) {
            return [whereObj.observationReferenceData.category.name isEqualToString:[TMConstants InSeason]];
        }];
    }
	return _inSeasonObservations;
}

- (NSArray*)observationTypes {
	NSArray *observationTypes = [[self.entry.observations allObjects] valueForKeyPath:@"observationReferenceData"];
	return [observationTypes arrayForEach:^TMObservationTypeModel*(TMObservationReferenceData* observationType) {
		return [[TMObservationTypeModel alloc] initWithObservationType:observationType];
	}];
}

- (NSString*)treatmentName {
	return self.entry.treatment.chemicalName;
}

- (NSString*)traitName {
	return self.entry.product.traitName;
}

- (NSInteger)entryNumber {
	return [self.entry.number integerValue];
}

- (NSString*)maturityRating {
	return [self.entry.product.maturityRating stringValue];
}

- (NSString*)productName {
	return self.entry.product.productName;
}

- (BOOL)hasUnapprovedProduct {
    return self.entry.product.inventoryId == nil;
}

- (BOOL)disablePlotWeightAndYield {
    return _disablePlotWeightAndYield;
}

//domain refactoring note, this shouldn't be duplicated, a relationship should exist and
//it should come from the brand relationship to product.
- (NSString*)brandName {
	return self.entry.product.brandName;
}

@end
