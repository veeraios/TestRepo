//
//  TMHTMLEntityDecoder.swift
//  TrialManagement
//
//  Created by GADIRAJU, PRANEETH [AG/1000] on 6/24/15.
//  Copyright (c) 2015 Monsanto. All rights reserved.
//

class TMHTMLEntityDecoder {
    
    private enum HTMLEntity: String {
        case GreaterThan = "&gt;"
        case LesserThan = "&lt;"
        case Apostrophe = "&apos;"
        case Quotation = "&quot;"
    }
    
    private var entityDecoderDictionary =  Dictionary<HTMLEntity,String>()
    
    init() {
        entityDecoderDictionary[.GreaterThan] = ">"
        entityDecoderDictionary[.LesserThan] = "<"
        entityDecoderDictionary[.Apostrophe] = "'"
        entityDecoderDictionary[.Quotation] = "\""
    }
    
    func decode(textToDecode: String) -> String {
        var decodedText = textToDecode
        entityDecoderDictionary.keys.array.forEach({[unowned self] in
            if(decodedText.contains($0.rawValue)) {
                decodedText = self.decode(decodedText, entity:$0)
            }
        })
        
        return decodedText
    }
    
    private func decode(textToDecode: String, entity: HTMLEntity) -> String {
        return textToDecode.stringByReplacingOccurrencesOfString(entity.rawValue, withString: entityDecoderDictionary[entity]!, options: NSStringCompareOptions.LiteralSearch, range: nil)
    }
}
