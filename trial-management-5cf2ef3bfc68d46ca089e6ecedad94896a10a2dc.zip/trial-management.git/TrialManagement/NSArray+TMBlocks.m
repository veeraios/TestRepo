#import "NSArray+TMBlocks.h"

@implementation NSArray (TMBlocks)

- (NSArray *)where:(BOOL (^)(id item))block {
    NSMutableArray* result = [[NSMutableArray alloc] init];
    for(id item in self) {
		if (block(item)) {
			[result addObject:item];
		}
    }
    return result;
}

- (id)whereOrPerformBlock:(BOOL (^)(id item))block itemNotFoundBlock:(void (^)(id item))itemNotFoundBlock {
    NSMutableArray* results = [[NSMutableArray alloc] init];
    for(id item in self) {
		if (block(item)) {
			[results addObject:item];
		} else {
			itemNotFoundBlock(item);
		}
    }
	if([results count] != 0) {
		return [results firstObject];
	}
	return nil;
}

- (id)whereUniqueOrBlock:(BOOL (^)(id item))block itemNotFoundBlock:(id (^)())itemNotFoundBlock {
    NSMutableArray* results = [[NSMutableArray alloc] init];
    for(id item in self) {
		if (block(item)) {
			[results addObject:item];
		}
    }
	if([results count] == 1) {
		return [results firstObject];
	} else {
		return itemNotFoundBlock();
	}
}
- (id)whereUniqueOrNil:(BOOL (^)(id item))block {
    NSMutableArray* results = [[NSMutableArray alloc] init];
    for(id item in self) {
		if (block(item)) {
			[results addObject:item];
		}
    }
	if([results count] == 1) {
		return [results firstObject];
	}
    return nil;
}

- (id)whereUnique:(BOOL (^)(id item))block notUniqueBlock:(id (^)())notUniqueBlock {
    NSMutableArray* results = [[NSMutableArray alloc] init];
    for(id item in self) {
		if (block(item)) {
			[results addObject:item];
		}
    }
	if([results count] == 1) {
		return [results firstObject];
	} else if(self != nil) {
		if(notUniqueBlock) {
			notUniqueBlock();
		}
	}
    return nil;
}

- (id)whereUnique:(BOOL (^)(id item))block {
    NSMutableArray* results = [[NSMutableArray alloc] init];
    for(id item in self) {
		if (block(item)) {
			[results addObject:item];
		}
    }
	if([results count] == 1) {
		return [results firstObject];
	} else {
		if(self != nil && [self count] > 0) {
			DDLogError(@"expected result set after filter for %@ to contain one item, it contains: %lu", NSStringFromClass([[self firstObject] class]), (unsigned long)[results count]);
		}
	}
    return nil;
}

- (BOOL)any:(BOOL (^)(id item))block {
    for (id item in self) {
        if (block(item)) {
            return YES;
        }
    }
    return NO;
}

- (NSArray *)sort:(id (^)(id obj))block {
    return [self sortedArrayUsingComparator:^NSComparisonResult(id obj1, id obj2) {
        id valueOne = block(obj1);
        id valueTwo = block(obj2);
        NSComparisonResult result = [valueOne compare:valueTwo];
        return result;
    }];
}

- (NSArray *)filter:(BOOL (^)(id whereObj))where {
	NSMutableArray *filteredArray = [NSMutableArray array];
	[self enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
		if(where) {
			if(where(obj)) {
				[filteredArray addObject: obj];
			}
		} else {
			[filteredArray addObject: obj];
		}
	}];
	return filteredArray;
}

- (NSArray *)sort:(id (^)(id obj))block where:(BOOL (^)(id whereObj))where {
    return [ [self filter:where] sortedArrayUsingComparator:^NSComparisonResult(id obj1, id obj2) {
        return [block(obj1) compare:block(obj2)];
    }];
}

- (NSArray*)arrayForEach:(id (^)(id obj))block where:(BOOL (^)(id whereObj))where {
	NSMutableArray *rtnArray = [NSMutableArray array];
	if(block == nil) {
		return rtnArray;
	}
	[self enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
		if(where) {
			if(where(obj)) {
				[rtnArray addObject: block(obj)];
			}
		} else {
			[rtnArray addObject: block(obj)];
		}
	}];
	return rtnArray;
}

- (NSArray*)arrayForEach:(id (^)(id obj))block {
	NSMutableArray *rtnArray = [NSMutableArray array];
	if(block == nil) {
		return rtnArray;
	}
	[self enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
		[rtnArray addObject: block(obj)];
	}];
	return rtnArray;
}

- (id)all:(id (^)(id obj))block {
	__block id rtnObj = nil;
	if(block == nil) {
		return rtnObj;
	}
	[self enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
		rtnObj = block(obj);
	}];
	return rtnObj;
}

- (void)forAll:(void(^)(id obj))block {
	if(block == nil) {
		return;
	}
	[self enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
		block(obj);
	}];
	return;
}

@end
