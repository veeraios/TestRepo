//
//  TMCooperatorUpdateViewController.swift
//  TrialManagement
//
//  Created by GADIRAJU, PRANEETH [AG/1000] on 5/2/15.
//  Copyright (c) 2015 Monsanto. All rights reserved.
//

@objc protocol TMCooperatorOptionsDelegate {
        func updateCooperators()
}

@objc protocol TMAddNewCooperatorDelegate {
    func addNewCooperator(cooperator:TMCooperatorModel)
}

class TMCooperatorUpdateViewController: UIViewController, TMCooperatorUpdateViewDelegate {
    var cooperatorUpdateViewdelegate: TMCooperatorOptionsDelegate?
    var cooperatorAddNewCooperatorDelegate: TMAddNewCooperatorDelegate?
    
    private let cooperatorModel:TMCooperatorModel
    private let cooperatorView:TMCooperatorUpdateView
    private let statesModel: TMStatesModel
    private let cancelButton: UIBarButtonItem?
    private let submitButton: UIBarButtonItem?
    private var name: String
    private var accountId: String
    private var address1: String
    private var address2: String
    private var city: String
    private var state: String
    private var zip: String
    private var phone: String
    private var email :String
    private let isExceptionPlotType:Bool
    private let cooperatorValidationRequired: Bool
    
    init(cooperator:TMCooperatorModel, isExceptionPlotType:Bool, cooperatorValidationRequired:Bool, operation:CooperatorOperation) {
        self.cooperatorModel = cooperator
        self.isExceptionPlotType = isExceptionPlotType
        self.cooperatorValidationRequired = cooperatorValidationRequired
        
        statesModel = TMStatesModel(dataSource: TMWorkingUnitOfWork.sharedInstance().stateRepository.sortedEntitiesByName())
        let statePopover = MONSearchableLabeledPopoverButton(model: statesModel, filter: TMNameFilter(), placeholderText: "Select state")
        cooperatorView = TMCooperatorUpdateView(title:cooperator.title(), statesPopover:statePopover, addressRequired:isExceptionPlotType, validationRequired:cooperatorValidationRequired,
            operation:operation)
        
        name = cooperator.name
        accountId = cooperator.accountId
        address1 = cooperator.address1
        address2 = cooperator.address2
        city = cooperator.city
        state = cooperator.state
        zip = cooperator.postalCode
        email = cooperator.email
        phone = cooperator.phone
        
        super.init(nibName: nil, bundle: nil)
        cooperatorView.delegate = self
        
        cancelButton = UIBarButtonItem(title: "Cancel", style: UIBarButtonItemStyle.Plain, target: self, action: Selector("cancelButtonTapped"))
        cancelButton?.tintColor = UIColor.whiteColor()
        navigationItem.leftBarButtonItem = cancelButton;
        
        submitButton = UIBarButtonItem(title: "Submit", style: UIBarButtonItemStyle.Plain, target: self, action: Selector("submitButtonTapped"))
        navigationItem.rightBarButtonItem = submitButton;
        disableSubmitButton()
        
        self.title = operation == .Update ? "Update \(self.cooperatorModel.title())" : "Add new \(self.cooperatorModel.title())"
        view.addSubview(self.cooperatorView)
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        cooperatorView.frame = view.bounds
        let fetchedState = statesModel.stateForNameOrAbbr(cooperatorModel.state)
        
        cooperatorView.setName(cooperatorModel.name, accountId: cooperatorModel.accountId, email: cooperatorModel.email, phone: cooperatorModel.phone, address1: cooperatorModel.address1, address2: cooperatorModel.address2, city: cooperatorModel.city, state: fetchedState != nil ? fetchedState.name : "", zip: cooperatorModel.postalCode)
    }

    override func viewDidAppear(animated: Bool) {
        super.viewDidAppear(animated)

        let cooperatorType = (cooperatorModel as? TMGrowerModel) != nil ? "Grower" : "Dealer"
        let viewType = cooperatorAddNewCooperatorDelegate != nil ? "New" : "Update"
        MONGoogleAnalytics.trackView("Trial - Grower Information - " + cooperatorType + " " + viewType)
    }
    
    required init(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        cooperatorView.autoresizingMask = UIViewAutoresizing.FlexibleWidth | UIViewAutoresizing.FlexibleHeight
    }
    
    func verifyRequiredInfo() {
        if ((cooperatorModel as? TMDealerModel) != nil) {
            updatedInfoNotEmpty(self.name) ? enableSubmitButton() : disableSubmitButton()
        } else if ((cooperatorModel as? TMGrowerModel) != nil) {
            if(updatedInfoNotEmpty(self.name) && updatedInfoNotEmpty(self.city) && updatedInfoNotEmpty(self.zip) && updatedInfoNotEmpty(self.state) && countElements(self.zip) == 5 && verifyAddress()) {
                enableSubmitButton()
            } else {
                disableSubmitButton()
            }
        }
    }
    
    func verifyAddress() -> Bool {
        return isExceptionPlotType ? updatedInfoNotEmpty(self.address1) : true
    }
    
    func updatedInfoNotEmpty(value:String?) -> Bool {
        if let updatedValue = value {
            return !updatedValue.isEmpty
        }
        return false
    }

    func enableSubmitButton() {
        submitButton?.enabled = true
        submitButton!.tintColor = UIColor.whiteColor()
    }
    
    func disableSubmitButton() {
        submitButton?.enabled = false
        submitButton?.tintColor = MONColors.lockedColor()
    }
    
    func cancelButtonTapped() {
        if(cooperatorModel.isNew()) {
            TMWorkingUnitOfWork.sharedInstance().workingContext.removeManagedObject(cooperatorModel.cooperator())
            TMWorkingUnitOfWork.sharedInstance().saveChanges()
        }
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    func submitButtonTapped() {
        cooperatorModel.name = name
        cooperatorModel.accountId = accountId
        cooperatorModel.email = email
        cooperatorModel.phone = phone
        cooperatorModel.city = city
        cooperatorModel.state = state
        cooperatorModel.postalCode = zip
        cooperatorModel.address1 = address1
        cooperatorModel.address2 = address2
        
        cooperatorAddNewCooperatorDelegate?.addNewCooperator(cooperatorModel)
        cooperatorUpdateViewdelegate?.updateCooperators()
        
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    
    //MARK: - TMCooperatorUpdateViewDelegate methods
    func updatedInformation(name: String, accountId: String, email: String, phone: String, address1: String, address2: String, city: String, zip: String) {
        self.name = name
        self.accountId = accountId
        self.email = email
        self.phone = phone
        self.address1 = address1
        self.address2 = address2
        self.city = city
        self.zip = zip
        
        verifyRequiredInfo()
    }
    
    func selectedState(state: AnyObject) {
        self.state = (state as? TMState)!.abbreviation
        verifyRequiredInfo()
    }
    
}
