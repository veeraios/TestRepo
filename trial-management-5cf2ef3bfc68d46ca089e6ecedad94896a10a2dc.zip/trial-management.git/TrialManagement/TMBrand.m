//
//  TMBrand.m
//  TrialManagement
//
//  Created by Jason Ludwig on 6/17/14.
//  Copyright (c) 2014 Monsanto. All rights reserved.
//

#import "TMBrand.h"


@implementation TMBrand

@dynamic brandId;
@dynamic name;
@dynamic protocols;
@dynamic techAgronomists;
@dynamic trials;
@dynamic users;

@end
