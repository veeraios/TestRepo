#import "MONTextFieldButton.h"
#import "MONCardContainerView.h"
#import "MONDimensions.h"
#import "MONFonts.h"
#import "UIColor+MONThemeColorProvider.h"

static const CGFloat DefaultHeight = 35.0;
static const CGFloat TextHorizontalPaddingAdjustment = 1.0;

@interface MONTextFieldButton ()

@property (nonatomic) MONCardContainerView *cardContainerView;
@property (nonatomic) NSString *placeholderText;

@end

@implementation MONTextFieldButton

- (instancetype)initWithFrame:(CGRect)frame {
	self = [super initWithFrame:frame];
	if (self) {
		self.titleLabel.font = [UIFont fontWithName:OpenSans size:14.0];
		self.contentEdgeInsets = UIEdgeInsetsMake(0.0, MONDimensionsTinyPadding + TextHorizontalPaddingAdjustment, 0.0, MONDimensionsTinyPadding + TextHorizontalPaddingAdjustment);
		[self setContentHorizontalAlignment:UIControlContentHorizontalAlignmentLeft];

		self.cardContainerView = [[MONCardContainerView alloc] initWithFrame:self.bounds];
		self.cardContainerView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
		self.cardContainerView.userInteractionEnabled = NO;
		[self addSubview:self.cardContainerView];
		
		[self bringSubviewToFront:self.titleLabel];
	}
	return self;
}

- (CGSize)sizeThatFits:(CGSize)size {
	CGSize sizeThatFits = CGSizeMake(size.width, DefaultHeight);
	return sizeThatFits;
}

- (void)setTitle:(NSString *)title forState:(UIControlState)state {
	if ([title length] > 0) {
		[super setTitle:title forState:state];
		[self setTitleColor:[UIColor colorForThemeComponentType:MONThemeComponentTypeText] forState:UIControlStateNormal];
	} else {
		[self setPlaceholderText:_placeholderText];
	}
}

- (void)setPlaceholderText:(NSString *)placeholderText {
	_placeholderText = placeholderText;
	[super setTitle:placeholderText forState:UIControlStateNormal];
	[self setTitleColor:[UIColor colorForThemeComponentType:MONThemeComponentTypePlaceholderText] forState:UIControlStateNormal];
}

@end
