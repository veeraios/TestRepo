#import "MONSingleSelectionCardCollectionViewCell.h"
#import "MONSingleSelectionCardView.h"

@interface MONSingleSelectionCardCollectionViewCell ()

@property (nonatomic) MONSingleSelectionCardView *singleSelectionCardView;
@end

@implementation MONSingleSelectionCardCollectionViewCell
@synthesize cellModel;

- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
		
		self.singleSelectionCardView = [[MONSingleSelectionCardView alloc] init];
		self.singleSelectionCardView.frame = self.bounds;
		self.singleSelectionCardView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        self.singleSelectionCardView.delegate = self;
		[self addSubview:self.singleSelectionCardView];
    }
    return self;
}
-(NSString*)selectedText {
	return [self.singleSelectionCardView selectedText];
}
-(void)setIsReadOnly:(BOOL)isReadOnly {
	self.singleSelectionCardView.isReadOnly = isReadOnly;
}

-(BOOL)isReadOnly {
	return self.singleSelectionCardView.isReadOnly;
}

- (void)setTitle:(NSString *)title {
	[self.singleSelectionCardView setTitle:title];
}

- (void)setSelectedText:(NSString *)selectedText {
	[self.singleSelectionCardView setSelectedText:selectedText];
}

#pragma mark - MONSingleSelectionCardViewDelegate
- (void)selectOptionsButtonTapped {
    [self.delegate selectOptionsButtonTappedOnCell:self];
}
@end
