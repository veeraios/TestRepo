@interface TMHarvestModel : NSObject

@property (nonatomic) NSArray *entryModels;
@property (nonatomic, readonly) NSDate *harvestDate;
@property (nonatomic, readonly) NSDate *plantingDate;

- (instancetype)initWithEntryModels:(NSArray*)entryModels
                        harvestDate:(NSDate*)harvestDate
                       plantingDate:(NSDate*)plantingDate;
- (BOOL)isValidHarvestDate:(NSDate*)harvestDate;
- (NSArray*)harvestYieldObservations;
- (NSArray*)moistureObservations;
@end
