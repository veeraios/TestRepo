#import <Foundation/Foundation.h>

extern NSString * const RobotoThin;
extern NSString * const RobotoBold;

extern NSString * const OpenSans;
extern NSString * const OpenSansItalic;
extern NSString * const OpenSansLight;
extern NSString * const OpenSansLightItalic;
extern NSString * const OpenSansSemibold;
extern NSString * const OpenSansSemiboldItalic;
extern NSString * const OpenSansBold;
extern NSString * const OpenSansBoldItalic;
extern NSString * const OpenSansExtrabold;
extern NSString * const OpenSansExtraboldItalic;

static const CGFloat MONFontsHeaderTextSize = 24.0;

@interface MONFonts : NSObject
@end
