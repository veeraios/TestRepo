#import "TMEditTrialPlantingViewController.h"
#import "TMEditTrialPlantingView.h"
#import "TMEditTrialSingleSelectionCell.h"
#import "MONDimensions.h"
#import "TMPlantingCellProvider.h"
#import "MONPopoverTableViewController.h"
#import "MONTextViewCardCollectionViewCell.h"
#import "MONTextViewEditorViewController.h"
#import "TMEditTrialBasicsTextCell.h"
#import "TMEditTrialValueUOMCell.h"
#import "TMEditTrialValueUOMViewController.h"
#import "NSDate+MONDateHelper.h"
#import "TMIrrigationModel.h"
#import "TMTabNameConstants.h"
#import "TMObservationSelectionConstants.h"
#import "UIViewController+TMOrientation.h"
#import "TrialManagement-Swift.h"

static const CGFloat SingleSelectionCardHeight = 150.0;
static const CGFloat TextViewCellCardHeight = 100.0;

static NSString * const NewTrialHeaderText = @"New Trial";

@interface TMEditTrialPlantingViewController ()<UICollectionViewDataSource, UICollectionViewDelegate, UIPopoverControllerDelegate, UITextFieldDelegate, ESCObservableInternal,TMPlantingCellProviderSelectionDelegate>

@property (nonatomic) UICollectionView *collectionView;
@property (nonatomic) UICollectionViewFlowLayout *collectionViewFlowLayout;
@property (nonatomic) TMEditTrialPlantingView *editTrialPlantingView;
@property (nonatomic) TMPlantingCellProvider *plantingCellProvider;
@property (nonatomic) UIPopoverController *cellPopoverController;
@property (nonatomic) UICollectionViewCell *selectedCell;
@property (nonatomic) MONTextViewEditorViewController *textViewEditorViewController;
@property (nonatomic) id<TMReferenceListDataModel> popoverModel;
@property (nonatomic) TMEditTrialValueUOMViewController *valueUOMViewController;
@property (nonatomic) TMTrialModel *trialModel;

@end

@implementation TMEditTrialPlantingViewController

@synthesize tabSettingsObject = _tabSettingsObject;

- (instancetype)initWithTrialModel:(TMTrialModel *)trialModel {
	self = [super initWithTrialModel:trialModel theClass:[self class]];
	if (self) {
		self.trialModel = trialModel;
	}
	return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];

	self.plantingCellProvider = [[TMPlantingCellProvider alloc] initWithTrialModel:self.trialModel];
    self.plantingCellProvider.delegate = self;
	self.collectionViewFlowLayout = [[UICollectionViewFlowLayout alloc] init];
	self.collectionViewFlowLayout.minimumLineSpacing = MONDimensionsSmallPadding;
	self.collectionViewFlowLayout.minimumInteritemSpacing = MONDimensionsSmallPadding;
	[self.collectionViewFlowLayout setScrollDirection:UICollectionViewScrollDirectionVertical];

	self.collectionView = [[UICollectionView alloc] initWithFrame:self.view.bounds collectionViewLayout:self.collectionViewFlowLayout];
	self.collectionView.dataSource = self;
	self.collectionView.delegate = self;
	[self.collectionView registerClass:[TMDeletableValueCollectionViewCell class] forCellWithReuseIdentifier:@"TMDeletableValueCollectionViewCell"];
	[self.collectionView registerClass:[MONTextViewCardCollectionViewCell class] forCellWithReuseIdentifier:@"MONTextViewCardCollectionViewCell"];	
	[self.collectionView registerClass:[TMEditTrialBasicsTextCell class] forCellWithReuseIdentifier:@"TMEditTrialBasicsTextCell"];
	[self.collectionView registerClass:[TMEditTrialValueUOMCell class] forCellWithReuseIdentifier:@"TMEditTrialValueUOMCell"];

	self.editTrialPlantingView = [[TMEditTrialPlantingView alloc] initWithCollectionView:self.collectionView];
	self.editTrialPlantingView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
	[self.view addSubview:self.editTrialPlantingView];
}

- (void)viewWillAppear:(BOOL)animated {
	[super viewWillAppear:animated];

	self.editTrialPlantingView.frame = self.view.bounds;
}

- (void)viewDidAppear:(BOOL)animated {
	[super viewDidAppear:animated];

	[MONGoogleAnalytics trackView:@"Trial - Planting Information"];
}

- (void)viewWillLayoutSubviews {
	[super viewWillLayoutSubviews];
	
	[self.collectionViewFlowLayout invalidateLayout];
}

- (void)viewWillTransitionToSize:(CGSize)size withTransitionCoordinator:(id<UIViewControllerTransitionCoordinator>)coordinator {
    [self.collectionViewFlowLayout invalidateLayout];
    [super viewWillTransitionToSize:size withTransitionCoordinator:coordinator];
}

- (void)textViewCellCardTapped:(UICollectionViewCell *)cell indexPath:(NSIndexPath *)indexPath {
	self.textViewEditorViewController = [[MONTextViewEditorViewController alloc] init];	
	NSString *previouslyEnteredText = [(MONTextViewCardCollectionViewCell *)cell selectedText];
	[self.textViewEditorViewController setEnteredText:previouslyEnteredText];
	
	if (indexPath.row == CellTypeComments) {
		[self.textViewEditorViewController setHeaderText:@"Comments"];
		[self.textViewEditorViewController setTitle:@"Add Comments"];
	} else {
		[self.textViewEditorViewController setHeaderText:@"Directions"];
		[self.textViewEditorViewController setTitle:@"Add Directions"];
	}
	
	UIBarButtonItem *cancelButton = [[UIBarButtonItem alloc] initWithTitle:@"Cancel" style:UIBarButtonItemStylePlain target:self action:@selector(modalCancelButtonTapped)];
    [cancelButton setTintColor:[UIColor whiteColor]];
	self.textViewEditorViewController.navigationItem.leftBarButtonItem = cancelButton;
	UIBarButtonItem *doneButton = [[UIBarButtonItem alloc] initWithTitle:@"Done" style:UIBarButtonItemStylePlain target:self action:@selector(textViewEditorDoneButtonTapped)];
    [doneButton setTintColor:[UIColor whiteColor]];
	self.textViewEditorViewController.navigationItem.rightBarButtonItem = doneButton;
	
	UINavigationController *navigationController = [[UINavigationController alloc] initWithRootViewController:self.textViewEditorViewController];
	navigationController.modalPresentationStyle = UIModalPresentationPageSheet;
	
	[self presentViewController:navigationController animated:YES completion:nil];
}

- (void)modalCancelButtonTapped {
	[self dismissViewControllerAnimated:YES completion:nil];
}

- (void)textViewEditorDoneButtonTapped {
	MONTextViewCardCollectionViewCell *cell = (MONTextViewCardCollectionViewCell *)self.selectedCell;
	NSString *valueEntered = [self.textViewEditorViewController enteredText];
	[cell setSelectedText:valueEntered];
	
	NSIndexPath *index = [self.collectionView indexPathForCell:self.selectedCell];
	
	if (index.row == CellTypeComments) {
		[self.trialModel setComments:valueEntered];
	} else if(index.row == CellTypeDirections) {
		[self.trialModel setDirections:valueEntered];
	}
	
	[self dismissViewControllerAnimated:YES completion:^{
		[self.collectionViewFlowLayout invalidateLayout];
		self.selectedCell = nil;
	}];
}

- (void)valueUOMModalDoneButtonTapped {
	TMEditTrialValueUOMCell *cell = (TMEditTrialValueUOMCell *)self.selectedCell;

    TMValueUOMModel *uomModel = cell.cellModel;
    [cell updateValue:self.valueUOMViewController.value selectedUnitOfMeasure:self.valueUOMViewController.selectedUnitOfMeasure];
    NSIndexPath *index = [self.collectionView indexPathForCell:self.selectedCell];
    if (index.row == CellTypePlantingRate) {
        [self.trialModel setPlantingRate:uomModel.value unit:uomModel.selectedUnitOfMeasure];
    } else if(index.row == CellTypeRowSpacing) {
        [self.trialModel setRowSpacing:uomModel.value unit:uomModel.selectedUnitOfMeasure];
    }
	
	[self dismissViewControllerAnimated:YES completion:^{
		self.selectedCell = nil;
	}];
}

- (void)setTitle:(NSString *)title {
	[super setTitle:title];
	[self.tabSettingsObject setGlobalTitle:title];
	if (title && ![title isEqualToString:NewTrialHeaderText]) {
		[self.tabSettingsObject setTabTitle:TMTabNameEditTrial index:1];
	}
}

#pragma mark - TMPlantingCellProviderSelectionDelegate

- (void)selectOptionsButtonTappedOnCell:(UICollectionViewCell *)cell {
    self.selectedCell = cell;
    if ([cell isKindOfClass:[TMDeletableValueCollectionViewCell class]]) {
        self.popoverModel = [(TMDeletableValueCollectionViewCell *)cell cellModel];
        MONPopoverTableViewController *tableViewController = [[MONPopoverTableViewController alloc] initWithModel:self.popoverModel];
        [tableViewController escAddObserver:self];
        
        self.cellPopoverController = [[UIPopoverController alloc] initWithContentViewController:tableViewController];
        self.cellPopoverController.delegate = self;
        [self.cellPopoverController setPopoverContentSize:CGSizeMake(300, 200)];
        CGRect popoverPresetingRect = CGRectInset(cell.bounds, 5.0, 5.0);
        [self.cellPopoverController presentPopoverFromRect:popoverPresetingRect inView:cell permittedArrowDirections:UIPopoverArrowDirectionLeft | UIPopoverArrowDirectionRight animated:YES];
    } else if ([cell isKindOfClass:[TMEditTrialValueUOMCell class]]) {
        TMValueUOMModel *valueUOMModel = ((TMEditTrialValueUOMCell *)self.selectedCell).cellModel;
        self.valueUOMViewController = [[TMEditTrialValueUOMViewController alloc] initWithTitle:valueUOMModel.title
                                                                                unitOfMeasures:valueUOMModel.unitOfMeasureNames
                                                                                         value:valueUOMModel.value
                                                                         selectedUnitOfMeasure:valueUOMModel.selectedUnitOfMeasure];
        UIBarButtonItem *cancelButton = [[UIBarButtonItem alloc] initWithTitle:@"Cancel" style:UIBarButtonItemStylePlain target:self action:@selector(modalCancelButtonTapped)];
        self.valueUOMViewController.navigationItem.leftBarButtonItem = cancelButton;
        UIBarButtonItem *doneButton = [[UIBarButtonItem alloc] initWithTitle:@"Done" style:UIBarButtonItemStylePlain target:self action:@selector(valueUOMModalDoneButtonTapped)];
        self.valueUOMViewController.navigationItem.rightBarButtonItem = doneButton;
        UINavigationController *navigationController = [[UINavigationController alloc] initWithRootViewController:self.valueUOMViewController];
        navigationController.modalPresentationStyle = UIModalPresentationPageSheet;
        [self presentViewController:navigationController animated:YES completion:nil];
    }
}

#pragma mark - UITextFieldDelegate

-(void)textFieldDidEndEditing:(UITextField *)textField {
    if(![textField.text isEqualToString:@""]) {
        [self.trialModel setNumberOfRows:[NSNumber numberWithInteger:[textField.text integerValue]]];
    }else {
        [self.trialModel setNumberOfRows:nil];
        textField.text = UnselectedText;
    }
    textField.userInteractionEnabled = NO;
}

#pragma mark - UICollectionViewDataSource Methods

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
	UICollectionViewCell *cell = [self.plantingCellProvider collectionView:collectionView cellForItemAtIndexPath:indexPath];
    [cell setUserInteractionEnabled:!self.isReadOnly];
	return cell;
}

#pragma mark - UICollectionViewDelegate Methods

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
	self.selectedCell = [collectionView cellForItemAtIndexPath:indexPath];
    if (indexPath.row == CellTypePlantingDate) {
        UICollectionViewCell *cell = [collectionView cellForItemAtIndexPath:indexPath];
        MONDatePicker *picker = [[MONDatePicker alloc] init];
        picker.delegate = self;
        picker.datePickerMode = UIDatePickerModeDate;
        picker.minimumDate = [NSDate currentDateWithYearsFrom:-1];
        picker.maximumDate = [NSDate date];
        picker.date = picker.maximumDate;
        UIViewController *datePickerViewController = [[UIViewController alloc] init];
        datePickerViewController.view = picker;
        
        self.cellPopoverController = [[UIPopoverController alloc] initWithContentViewController:datePickerViewController];
        self.cellPopoverController.delegate = self;
        [self.cellPopoverController setPopoverContentSize:CGSizeMake(300, 200)];
        CGRect popoverPresetingRect = CGRectInset(cell.bounds, 5.0, 5.0);
        [self.cellPopoverController presentPopoverFromRect:popoverPresetingRect inView:cell permittedArrowDirections:UIPopoverArrowDirectionLeft | UIPopoverArrowDirectionRight animated:YES];
    } else if (indexPath.row == CellTypeNumberOfRows) {
        TMEditTrialBasicsTextCell *textCell = (TMEditTrialBasicsTextCell*)[collectionView cellForItemAtIndexPath:indexPath];
        textCell.textField.userInteractionEnabled = YES;
        if([textCell.textField canBecomeFirstResponder]) {
            textCell.textField.delegate = self;
            if([textCell.textField.text isEqualToString:UnselectedText]) {
                textCell.textField.text = @"";
            }
            [textCell.textField becomeFirstResponder];
        }
    } else if (indexPath.row >= CellTypeComments) {
        [self textViewCellCardTapped:[collectionView cellForItemAtIndexPath:indexPath] indexPath:indexPath];
	}
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
	return [self.plantingCellProvider collectionView:collectionView numberOfItemsInSection:section];
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
	CGSize cardSize = CGSizeZero;
	CGFloat availableWidth = CGRectGetWidth(self.view.bounds) - 2.0 * MONDimensionsSmallPadding;
	if (indexPath.row > CellTypePlantingDate) {
		cardSize.width = availableWidth;
		UICollectionViewCell *cell = [collectionView cellForItemAtIndexPath:indexPath];
		if (!cell) {
			cardSize.height = TextViewCellCardHeight;
		} else {
			CGSize cellSizeThatFits = [cell sizeThatFits:CGSizeMake(availableWidth, CGFLOAT_MAX)];
			cardSize.height = cellSizeThatFits.height;
		}
	} else {
		CGFloat cardWidth = 0;
		if ([self isOrientationLandscape]) {
			cardWidth = (availableWidth - 3.0 * MONDimensionsSmallPadding) / 4.0;
		} else {
			cardWidth = (availableWidth - 2.0 * MONDimensionsSmallPadding) / 3.0;
		}
		cardSize.width = cardWidth;
		cardSize.height = SingleSelectionCardHeight;
	}
	return cardSize;
}

#pragma mark - UIPopoverControllerDelegate Methods

- (void)popoverControllerDidDismissPopover:(UIPopoverController *)popoverController {
	self.selectedCell = nil;
}

#pragma mark - MONPopoverTableViewControllerObserver Methods

- (void)didSelectRowIndex:(NSInteger)rowIndex {
	[self.cellPopoverController dismissPopoverAnimated:YES];

	if([self.selectedCell isKindOfClass:[TMDeletableValueCollectionViewCell class]]) {
		TMDeletableValueCollectionViewCell *cell = (TMDeletableValueCollectionViewCell*)self.selectedCell;
		TMReferenceDataListGenericModel *referenceDataListGenericModel = (TMReferenceDataListGenericModel *)cell.cellModel;

        if (rowIndex == 0) {
            [self.trialModel deleteTrialDataForDataModel:cell.cellModel];
        } else if([cell.cellModel isKindOfClass:[TMIrrigationModel class]]) {
			NSString * irrigationString = [referenceDataListGenericModel objectAtIndex:rowIndex];
			[self.trialModel setIrrigation:[irrigationString boolValue]];
        } else {
			[self.trialModel setRelationship: [referenceDataListGenericModel objectAtIndex:rowIndex]];
		}
        NSString *selectedText = [self.popoverModel nameForItemAtIndex:rowIndex];
        [cell setSelectedText:selectedText];
    }
}

#pragma mark - MONDatePickerDelegate Methods

- (void)datePickerChanged:(MONDatePicker *)datePicker newDate:(NSDate *)newDate {
	NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
	[dateFormatter setDateFormat:@"MM-dd-yyyy"];
	NSString *dateString =[dateFormatter stringFromDate:newDate];

	[(MONSingleSelectionCardCollectionViewCell *)self.selectedCell setSelectedText:dateString];
	[self.trialModel setPlantingDate:newDate];
}

@end
