//
//  TMMergeConflictView.swift
//  TrialManagement
//
//  Created by SINGH, SUPREET [AG/1000] on 2/5/15.
//  Copyright (c) 2015 Monsanto. All rights reserved.
//

import UIKit

protocol TMMergeConflictViewDelegate: class  {
    func sideTapped(side: TMMergeSide, subsection: TMMergeSubsection)
}

class TMMergeConflictView: UIView {
    private let standardRowHeight: CGFloat = 22
    private let darkColor = UIColor(forThemeComponentType: MONThemeComponentTypeText)
    private let lightColor = UIColor(forThemeComponentType: MONThemeComponentTypeBackground)
    private let conflictColor = UIColor(forThemeComponentType: MONThemeComponentTypeHighlight)
    
    weak var delegate: TMMergeConflictViewDelegate?
    private let groupModel: TMMergeGroupViewModel
    private let leftBackground: UIView
    private let leftLabels = [UILabel]()
    private let leftValues = [UILabel]()
    private var leftImage: UIImageView

    private let rightBackground: UIView
    private let rightLabels = [UILabel]()
    private let rightValues = [UILabel]()
    private var rightImage: UIImageView

    init(_ mergeGroupModel: TMMergeGroupViewModel) {
        groupModel = mergeGroupModel
        leftBackground = UIView()
        leftBackground.layer.borderWidth = MONDimensionsThinBorderWidth
        leftBackground.layer.borderColor = UIColor(forThemeComponentType: MONThemeComponentTypeBorder).CGColor
        leftBackground.layer.cornerRadius = MONDimensionsCornerRadius
        leftBackground.backgroundColor = lightColor
        leftImage = UIImageView(image: UIImage(named: "ui-icon-checkmark-empty")!)
        rightBackground = UIView()
        rightBackground.layer.borderWidth = MONDimensionsThinBorderWidth
        rightBackground.layer.borderColor = UIColor(forThemeComponentType: MONThemeComponentTypeBorder).CGColor
        rightBackground.layer.cornerRadius = MONDimensionsCornerRadius
        rightBackground.backgroundColor = lightColor
        rightImage = UIImageView(image: UIImage(named: "ui-icon-checkmark-empty")!)
        super.init(frame: CGRectZero)
        
        for mergeValue in mergeGroupModel.mergeValues {
            let leftAndRightLabelAndValues = buildLabelsForMergeValue(mergeValue)
            leftLabels.append(leftAndRightLabelAndValues.left.label)
            leftValues.append(leftAndRightLabelAndValues.left.value)
            rightLabels.append(leftAndRightLabelAndValues.right.label)
            rightValues.append(leftAndRightLabelAndValues.right.value)
        }
        addSubview(leftBackground)
        addSubview(rightBackground)
        leftLabels.forEach({[unowned self] in self.addSubview($0)})
        leftValues.forEach({[unowned self] in self.addSubview($0)})
        rightLabels.forEach({[unowned self] in self.addSubview($0)})
        rightValues.forEach({[unowned self] in self.addSubview($0)})
        addSubview(leftImage)
        addSubview(rightImage)
        
        leftBackground.addGestureRecognizer(UITapGestureRecognizer(target: self, action: "tapLeft"))
        rightBackground.addGestureRecognizer(UITapGestureRecognizer(target: self, action: "tapRight"))
    }
    
    func tapLeft() {
        groupModel.resolvedSide = .Left
        conflictResolved()
        delegate?.sideTapped(groupModel.resolvedSide!, subsection: groupModel.subsection)
    }
    
    func tapRight() {
        groupModel.resolvedSide = .Right
        conflictResolved()
        delegate?.sideTapped(groupModel.resolvedSide!, subsection: groupModel.subsection)
    }
    
    func conflictResolved() {
        if (groupModel.resolvedSide == .Left) {
            updateResolvedSide(leftImage, backgroundView: leftBackground, labels: leftLabels, values: leftValues)
            updateUnresolvedSide(rightImage, backgroundView: rightBackground, labels: rightLabels, values: rightValues)
        } else {
            updateResolvedSide(rightImage, backgroundView: rightBackground, labels: rightLabels, values: rightValues)
            updateUnresolvedSide(leftImage, backgroundView: leftBackground, labels: leftLabels, values: leftValues)
        }
    }
    
    func updateResolvedSide(imageView: UIImageView, backgroundView: UIView, labels: [UILabel], values: [UILabel]) {
        imageView.image = UIImage(named: "ui-icon-checkmark-filled")!
        backgroundView.backgroundColor = UIColor(forThemeComponentType: MONThemeComponentTypeTabButtonBackground)
        labels.forEach({[unowned self] in $0.textColor = self.lightColor})
        values.forEach({[unowned self] in $0.textColor = self.lightColor})
    }
    
    func updateUnresolvedSide(imageView: UIImageView, backgroundView: UIView, labels: [UILabel], values: [UILabel]) {
        imageView.image = UIImage(named: "ui-icon-checkmark-empty")!
        backgroundView.backgroundColor = lightColor
        labels.forEach({[unowned self] in $0.textColor = self.darkColor})
        values.forEach({[unowned self] in $0.textColor = $0.text!.hasPrefix("●") == true ? self.conflictColor : self.darkColor})
    }
    
    private func buildLabelsForMergeValue(mergeValue: TMMergeValueViewModel) -> (left: (label: UILabel, value: UILabel), right: (label: UILabel, value: UILabel)) {
        var leftLabel, leftValue, rightLabel, rightValue: UILabel
        leftLabel = TMDefaultUIFactory.createTitleLabel(mergeValue.title)
        rightLabel = TMDefaultUIFactory.createTitleLabel(mergeValue.title)
        if (mergeValue.isChanged()) {
            leftValue = TMDefaultUIFactory.createConflictValueLabel(mergeValue.leftValue)
            rightValue = TMDefaultUIFactory.createConflictValueLabel(mergeValue.rightValue)
        } else {
            leftValue = TMDefaultUIFactory.createRegularValueLabel(mergeValue.leftValue)
            rightValue = TMDefaultUIFactory.createRegularValueLabel(mergeValue.rightValue)
        }
        return ((leftLabel, leftValue), (rightLabel, rightValue))
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        var totalHeight = calculateHeight()
        leftBackground.frame = CGRectMake(0, 0, (bounds.width - MONDimensionsSmallPadding) / 2.0, totalHeight)
        rightBackground.frame = CGRectMake(leftBackground.frame.maxX + MONDimensionsSmallPadding, 0, (bounds.width - MONDimensionsSmallPadding) / 2.0, totalHeight)
        leftImage.sizeToFit()
        leftImage.frame = CGRectMake(leftBackground.frame.minX + MONDimensionsLargePadding, totalHeight / 2.0 - leftImage.frame.height / 2.0, leftImage.frame.width, leftImage.frame.height)
        rightImage.sizeToFit()
        rightImage.frame = CGRectMake(rightBackground.frame.minX + MONDimensionsLargePadding, totalHeight / 2.0 - rightImage.frame.height / 2.0, rightImage.frame.width, rightImage.frame.height)
        
        for (index, leftLabel) in enumerate(leftLabels) {
            if (index == 0) {
                leftLabels[0].frame = CGRectMake(0, MONDimensionsMicroPadding, leftBackground.frame.width / 2.0 - MONDimensionsTinyPadding, standardRowHeight)
                leftValues[0].frame = CGRectMake(leftBackground.frame.width / 2.0, MONDimensionsMicroPadding, leftBackground.frame.width / 2.0 - MONDimensionsMicroPadding, standardRowHeight)
                rightLabels[0].frame = CGRectMake(rightBackground.frame.minX, MONDimensionsMicroPadding, rightBackground.frame.width / 2.0 - MONDimensionsTinyPadding, standardRowHeight)
                rightValues[0].frame = CGRectMake(rightBackground.frame.midX, MONDimensionsMicroPadding, rightBackground.frame.width / 2.0 - MONDimensionsTinyPadding, standardRowHeight)
            } else {
                leftLabels[index].frame = CGRectMake(0, leftLabels[index - 1].frame.maxY, leftBackground.frame.width / 2.0 - MONDimensionsTinyPadding, standardRowHeight)
                leftValues[index].frame = CGRectMake(leftBackground.frame.width / 2.0, leftValues[index - 1].frame.maxY ,
                                                     leftBackground.frame.width / 2.0 - MONDimensionsMicroPadding, standardRowHeight)
                rightLabels[index].frame = CGRectMake(rightBackground.frame.minX, rightLabels[index - 1].frame.maxY ,
                                                      rightBackground.frame.width / 2.0 - MONDimensionsTinyPadding, standardRowHeight)
                rightValues[index].frame = CGRectMake(rightBackground.frame.midX, rightValues[index - 1].frame.maxY ,
                                                      rightBackground.frame.width / 2.0 - MONDimensionsTinyPadding, standardRowHeight)
            }
        }
    }
    
    private func calculateHeight() -> CGFloat {
        let calculatedHeight = MONDimensionsMicroPadding * 2 + standardRowHeight * CGFloat(leftLabels.count)
        let minimumHeight = MONDimensionsMicroPadding * 2 + leftImage.bounds.height
        return calculatedHeight > minimumHeight ? calculatedHeight : minimumHeight
    }
    
    override func sizeThatFits(size: CGSize) -> CGSize {
        return CGSize(width: size.width, height: calculateHeight());
    }
    
    required init(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

}
