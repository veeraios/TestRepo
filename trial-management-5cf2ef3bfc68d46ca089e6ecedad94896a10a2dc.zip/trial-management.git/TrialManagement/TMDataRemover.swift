import UIKit

enum DataRemovalStatus {
    case Success
    case Failure
    case Incomplete
}

class TMDataRemover {
    private var workingUnitOfWork = TMWorkingUnitOfWork.sharedInstance()
    private var backupUnitOfWork = TMBackupUnitOfWork.sharedInstance()
    private var pendingSyncRepository = TMWorkingUnitOfWork.sharedInstance().pendingSyncQueueRepository
    private var trialRepository = TMWorkingUnitOfWork.sharedInstance().trialRepository
    
    convenience init(pendingSyncRepo: TMPendingSyncQueueProtocol) {
        self.init()
        pendingSyncRepository = pendingSyncRepo
    }
    
    convenience init(trialRepository: TMTrialRepositoryProtocol, backupUnitOfWork: TMBackupUnitOfWorkProtocol) {
        self.init()
        self.trialRepository = trialRepository
        self.backupUnitOfWork = backupUnitOfWork
    }
    
    func removeDataFor(stage: RemovalStage, completion: DataRemovalStatus -> ()) {
        switch stage {
        case .Trial: removeTrialData(completion)
        case .Treatment: removeTreatmentData(completion)
        case .PendingQueue: removePendingQueueData(completion)
        default: completion(.Incomplete)
        }
    }
    
    private func removeTrialData(completion: (DataRemovalStatus) -> ()) {
        let removalPredicate = buildYearRemovalCriteria("plantingYear")
        
        let traversal = [
            "TMTrial": ["observations", "entries"],
            "TMEntry": ["observations"]]
        
        if let trialsToRemove = trialRepository.findWithPredicate(removalPredicate) as? [TMTrial] {
            MONLogger.logInfo("Found \(trialsToRemove.count) Trials to remove from device.")
            
            let removalCompletion: (DataRemovalStatus) -> () = {[unowned self] status in
                if (status == .Success) {
                    trialsToRemove.forEach( {$0.deleteWithTraversal(traversal)} )
                    self.trialRepository.saveContext()
                }
                completion(status)
            }
            
            removeBackupTrialDataForTrials(trialsToRemove, completion: removalCompletion)
        } else {
            completion(.Failure)
        }
    }
    
    private func removeBackupTrialDataForTrials(trials: [TMTrial], completion: (DataRemovalStatus) -> ()) {
        trials.forEach({[unowned self] in self.backupUnitOfWork.deleteBackupCopyOfTrial($0) })
        completion(.Success)
    }
    
    private func removeTreatmentData(completion: DataRemovalStatus -> ()) {
        completion(.Success)
    }
    
    private func removePendingQueueData(completion: DataRemovalStatus -> ()) {
        pendingSyncRepository.removeTrialItemsWithNoAssociatedTrials()
        completion(.Success)
    }
    
    func buildYearRemovalCriteria(yearProperty: String) -> NSPredicate {
        let baseComparison = "self.\(yearProperty) != %@"
        var comparisons = [String]()
        for index in 0..<TMYearModel().dataArray().count {
            comparisons.append(baseComparison)
        }
        
        return NSPredicate(format: " AND ".join(comparisons), argumentArray: TMYearModel().dataArray())
    }
}
