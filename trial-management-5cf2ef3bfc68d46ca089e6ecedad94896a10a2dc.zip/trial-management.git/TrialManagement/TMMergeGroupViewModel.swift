//
//  TMMergeGroupViewModel.swift
//  TrialManagement
//
//  Created by SINGH, SUPREET [AG/1000] on 2/10/15.
//  Copyright (c) 2015 Monsanto. All rights reserved.
//

import UIKit

class TMMergeGroupViewModel: NSObject {
    let subsection: TMMergeSubsection
    let mergeValues: [TMMergeValueViewModel]
    var resolvedSide: TMMergeSide?
    
    init(subsection: TMMergeSubsection, mergeValues: [TMMergeValueViewModel]) {
        self.subsection = subsection
        self.mergeValues = mergeValues
        super.init()
    }
}
