#import "NSDecimalNumber+MONNumberHelper.h"

@implementation NSDecimalNumber (MONNumberHelper)

+ (NSDecimalNumber *)safeDecimalNumberWithString:(NSString *)decimalString {
	NSDecimalNumber *decimalNumber = nil;
	if (decimalString != nil  && [decimalString length] != 0  && ![decimalString isEqualToString:@"<null>"]) {
		decimalNumber = [[self class] decimalNumberWithString:decimalString];
	}
	return decimalNumber;
}

@end
