#import "MONFonts.h"

NSString * const RobotoThin = @"Roboto-Thin";
NSString * const RobotoBold = @"Roboto-Bold";
NSString * const OpenSans = @"OpenSans";
NSString * const OpenSansItalic = @"OpenSans-Italic";
NSString * const OpenSansLight = @"OpenSans-Light";
NSString * const OpenSansLightItalic = @"OpenSansLight-Italic";
NSString * const OpenSansSemibold = @"OpenSans-Semibold";
NSString * const OpenSansSemiboldItalic = @"OpenSans-SemiboldItalic";
NSString * const OpenSansBold = @"OpenSans-Bold";
NSString * const OpenSansBoldItalic = @"OpenSans-BoldItalic";
NSString * const OpenSansExtrabold = @"OpenSans-Extrabold";
NSString * const OpenSansExtraboldItalic = @"OpenSans-ExtraboldItalic";
