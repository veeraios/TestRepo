#import "MONLabeledTextView.h"
#import "MONDimensions.h"
#import "MONFonts.h"
#import "UIColor+MONThemeColorProvider.h"

@interface MONLabeledTextView() <UITextViewDelegate>
@property (nonatomic) MONTextView *textView;
@property (nonatomic) MONLabel *label;
@property (nonatomic) UILabel *placeHolderLabel;
@property (nonatomic) CGFloat labelWidth;
@end

@implementation MONLabeledTextView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
		self.label = [[MONLabel alloc] initWithFrame:frame];
		self.label.textAlignment = NSTextAlignmentRight;
		[self addSubview:self.label];

		self.placeHolderLabel = [[MONLabel alloc] initWithFrame:frame];
		self.placeHolderLabel.textAlignment = NSTextAlignmentRight;
		self.placeHolderLabel.backgroundColor = [UIColor clearColor];
		self.placeHolderLabel.font = [UIFont fontWithName:OpenSans size:14];
		[self addSubview:self.placeHolderLabel];

		self.textView = [[MONTextView alloc] initWithFrame:frame];

		[self addSubview:self.textView];
		
    }
    return self;
}

-(void)setTextViewDelegate:(id<UITextViewDelegate>)textViewDelegate {
	[self.textView setTextViewDelegate:textViewDelegate];
}

-(void)setLabelText:(NSString*)text {
	self.label.text = text;
}

-(void)setPlaceHolderText:(NSString*)placeHolderText {
	self.placeHolderLabel.attributedText =  [[NSAttributedString alloc] initWithString:placeHolderText attributes:@{NSForegroundColorAttributeName : [UIColor colorForThemeComponentType:MONThemeComponentTypePlaceholderText]}];
	[self setPlaceholderTextColor:[UIColor colorForThemeComponentType:MONThemeComponentTypePlaceholderText]];
	if([self.textView.text length] == 0) {
		self.placeHolderLabel.hidden = NO;
		[self bringSubviewToFront:self.placeHolderLabel];
		[self setNeedsLayout];
	}
}

- (void)setPlaceholderTextColor:(UIColor *)placeHolderTextColor {
	NSString *text = [self.placeHolderLabel.attributedText string];
	if (text == nil) {
		text = @"";
	}
	self.placeHolderLabel.attributedText = [[NSAttributedString alloc] initWithString:text attributes:@{NSForegroundColorAttributeName : placeHolderTextColor}];
}

- (void)setEditable:(BOOL)editable {
	[self.textView setEditable:editable];
}

-(void)setText:(NSString*)text {
	if(text && text.length > 0 ) {
		self.placeHolderLabel.hidden = YES;
		[self bringSubviewToFront:self.textView];
	} else {
		self.placeHolderLabel.hidden = NO;
		[self bringSubviewToFront:self.placeHolderLabel];
	}
	self.textView.text = text;
	[self setNeedsLayout];
}

- (void)layoutSubviews {
	[super layoutSubviews];

	self.label.lineBreakMode = NSLineBreakByTruncatingTail;
	self.label.textAlignment = NSTextAlignmentLeft;
	self.label.frame = CGRectMake(0.0, 0.0, CGRectGetWidth(self.bounds), 20);
	
	self.textView.frame = CGRectMake(0.0,
									  CGRectGetMaxY(self.label.frame) + 3.0,
									  CGRectGetWidth(self.bounds),
									  CGRectGetHeight(self.bounds) - CGRectGetMaxY(self.label.frame));
		
	if([self.placeHolderLabel.text length] > 0) {
		CGSize labelSize = [self.placeHolderLabel.text sizeWithAttributes:
						@{NSFontAttributeName:
							  self.placeHolderLabel.font}];
		
		self.placeHolderLabel.frame = CGRectMake(CGRectGetMinX(self.textView.frame) + MONDimensionsTinyPadding,
												 CGRectGetMinY(self.textView.frame) + MONDimensionsTinyPadding,
												 labelSize.width,
												 labelSize.height);
	}

}

- (CGSize)sizeThatFits:(CGSize)size {
	CGSize sizeThatFits = size;
	[self.label sizeToFit];
	[self.textView sizeToFit];
	sizeThatFits.height = CGRectGetHeight(self.textView.frame);
	return sizeThatFits;
}


@end
