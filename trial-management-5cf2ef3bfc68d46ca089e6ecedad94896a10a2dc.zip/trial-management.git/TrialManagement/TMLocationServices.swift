//
//  TMLocationServices.swift
//  TrialManagement
//
//  Created by GADIRAJU, PRANEETH [AG/1000] on 3/16/15.
//  Copyright (c) 2015 Monsanto. All rights reserved.
//

import CoreLocation

private let sharedLocationServices = TMLocationServices()

class TMLocationServices: NSObject, CLLocationManagerDelegate {
    private var locationManager:CLLocationManager
    private var currentLocation:CLLocation
    
    override init() {
        locationManager = CLLocationManager()
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.activityType = CLActivityType.Fitness
        
        currentLocation = CLLocation()
        
        super.init()
        
        locationManager.delegate = self
    }
    
    convenience init(locationManager: CLLocationManager, currentLocation: CLLocation) {
        self.init()
        self.locationManager = locationManager
        self.currentLocation = currentLocation
    }
    
    class var sharedInstance: TMLocationServices {
        return sharedLocationServices
    }
    
    func requestAuthorization() {
        locationManager.requestWhenInUseAuthorization()
    }
    
    func resumeLocationServices() {
        if(isLocationServicesAuthorizedByUser()) {
            locationManager.startUpdatingLocation()
        }
    }
    
    func pauseLocationServices() {
        locationManager.stopUpdatingLocation()
    }
    
    func getCurrentLocation() -> CLLocation {
        return currentLocation
    }
    
    func locationManager(manager: CLLocationManager!, didChangeAuthorizationStatus status: CLAuthorizationStatus) {
        switch status {
        case CLAuthorizationStatus.AuthorizedWhenInUse:
            resumeLocationServices()
        default:
            pauseLocationServices()
            notifyCurrentLocation(CLLocation(latitude: TMConstants.emptyLocation, longitude: TMConstants.emptyLocation))
        }
    }
    
    func isLocationServicesAuthorizedByUser() -> Bool {
        return CLLocationManager.authorizationStatus() == CLAuthorizationStatus.AuthorizedWhenInUse
    }
    
    func locationManager(manager: CLLocationManager!, didUpdateLocations locations: [AnyObject]!) {
        if let lastUpdatedLocation = locations.last as? CLLocation {
            notifyCurrentLocation(lastUpdatedLocation)
        }
    }
    
    func notifyCurrentLocation(location:CLLocation) {
        currentLocation = location
        let coordinate = currentLocation.coordinate
        NSNotificationCenter.defaultCenter().postNotificationName(TMConstants.locationUpdatedNotification, object: nil, userInfo: [TMConstants.latitude: coordinate.latitude, TMConstants.longitude: coordinate.longitude, TMConstants.locationAccuracy: currentLocation.horizontalAccuracy])
    }
}


