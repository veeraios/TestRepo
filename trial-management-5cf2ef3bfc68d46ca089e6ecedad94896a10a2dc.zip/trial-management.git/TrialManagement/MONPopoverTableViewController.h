#import "TMReferenceListDataModel.h"
#import <UIKit/UIKit.h>
#import <ESCObservable/ESCObservable.h>

@protocol MONPopoverTableViewControllerObserver <NSObject>

- (void)didSelectRowIndex:(NSInteger)rowIndex;

@end

@interface MONPopoverTableViewController : UIViewController<ESCObservable>

- (instancetype)initWithModel:(id<TMReferenceListDataModel>)model;
- (instancetype)initWithTitle:(NSString*)title model:(id<TMReferenceListDataModel>)model;
@end
