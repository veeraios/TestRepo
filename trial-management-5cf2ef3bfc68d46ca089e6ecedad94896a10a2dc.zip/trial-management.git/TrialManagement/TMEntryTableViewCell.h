#import <UIKit/UIKit.h>

@interface TMEntryTableViewCell : UITableViewCell

- (void)setBrandText:(NSString *)brandText;
- (void)setProductText:(NSString *)productText;
- (void)setRMText:(NSString *)rmText;
- (void)setTraitText:(NSString *)traitText;
- (void)useAlternateBackgroundColor:(BOOL)useAlternatBackgroundColor;

@end
