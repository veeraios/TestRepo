#import "TMHarvestModel.h"

@protocol TMHarvestViewDelegate <NSObject>
- (void)setTrialHarvestDate:(NSDate*)date;
- (void)updatedPlotStatsState:(BOOL)plotStatsArePassed;
@end
@interface TMHarvestView : UIView

@property (nonatomic, weak) id<TMHarvestViewDelegate> delegate;
- (instancetype)initWitHarvestModel:(TMHarvestModel*)harvestModel rightHeaderButtons:(NSArray *)rightHeaderButtons leftHeaderButtons:(NSArray *)leftHeaderButtons;
- (void)refreshObservations:(NSArray*)entryModels;
- (void)setSubmittedDate:(NSDate*)date animate:(BOOL)animate;
- (void)setRightHeaderButtons:(NSArray *)rightHeaderButtons;
- (void)setLeftHeaderButtons:(NSArray *)leftHeaderButtons;
@end
