#import "TMTrialModel.h"
#import "MONTabController.h"
#import "TMGlobalMenuView.h"
#import <UIKit/UIKit.h>

@protocol TMGlobalMenuViewControllerDelegate <NSObject>

- (void)setupTrialButtonTapped;
- (void)observationsButtonTapped;
- (void)closeButtonTapped;
- (void)harvestButtonTapped;
- (void)marketingButtonTapped;
@end

@interface TMGlobalMenuViewController : UIViewController<MONTabController>

@property (nonatomic) id<TMGlobalMenuViewControllerDelegate> delegate;

- (instancetype)initWithTrialModel:(TMTrialModel *)trialModel;
- (void)setSelectedGlobalMenuButtonType:(TMGlobalMenuButtonType)globalMenuButtonType;

@end
