#import <XCTest/XCTest.h>
#import "TMIrrigationModel.h"

@interface TMIrrigationModelTest : XCTestCase
@property (nonatomic) TMIrrigationModel *testObject;
@end

@implementation TMIrrigationModelTest

- (void)setUp {
    [super setUp];
    self.testObject = [[TMIrrigationModel alloc] init];
}

- (void)tearDown {
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testFirstItemIsPlaceholderText {
    NSString *actual =  [self.testObject nameForItemAtIndex:0];
    XCTAssertNotNil(actual);
    XCTAssertEqualObjects(actual,self.testObject.placeholderText);
}

- (void)testSecondItemIsYes {
    NSString *actual =  [self.testObject nameForItemAtIndex:1];
    XCTAssertNotNil(actual);
    XCTAssertEqualObjects(actual,@"Yes");
}

- (void)testLastItemIsNo {
    NSString *actual =  [self.testObject nameForItemAtIndex:2];
    XCTAssertNotNil(actual);
    XCTAssertEqualObjects(actual,@"No");
}
@end
