//
//  TMAuthority.h
//  TrialManagement
//
//  Created by Jason Ludwig on 6/17/14.
//  Copyright (c) 2014 Monsanto. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class TMUser;

@interface TMAuthority : NSManagedObject

@property (nonatomic, retain) NSString * authority;
@property (nonatomic, retain) NSSet *users;
@end

@interface TMAuthority (CoreDataGeneratedAccessors)

- (void)addUsersObject:(TMUser *)value;
- (void)removeUsersObject:(TMUser *)value;
- (void)addUsers:(NSSet *)values;
- (void)removeUsers:(NSSet *)values;

@end
