#import "TMEmailTableViewModel.h"
#import "TMState.h"
#import "NSArray+TMPopupListSort.h"

@interface TMEmailTableViewModel()
	@property (nonatomic) NSArray *counties;
@end

@implementation TMEmailTableViewModel

-(instancetype) initWithCounties:(NSArray*)counties {
	self = [super init];
	if (self) {
		self.counties = [counties sortPopupListByKey:@"name"];
	}
	return self;
}

- (NSInteger)numberOfItems {
	return [self.counties count];
}

- (NSString *)nameForItemAtIndex:(NSInteger)index {
	TMCounty *county = ((TMCounty *)[self.counties objectAtIndex:index]);
	return [NSString stringWithFormat:@"%@ (%@)", county.name, county.state.name];
}

- (id)objectForItemAtIndex:(NSInteger)index {
	return ((TMCounty *)[self.counties objectAtIndex:index]);
}
@end
