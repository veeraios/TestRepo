import UIKit

class TMDataModelMigration: NSObject, MONDataModelMigration {
    private let TrialManagement = "TrialManagement"
    private let VersionInfo = "VersionInfo"
    private let CurrentVersionKey = "NSManagedObjectModel_CurrentVersionName"
    
    private let ModelVersionToForcedReferenceSyncCalls = [
        1 : [],
        2 : [SyncTreatments,SyncTraits,SyncGrowersAndDealers],
        3 : [SyncReportReferenceData, SyncObservationReferenceData]
    ]
    
    func lightweightMigrationToCurrentVersionForStore(storeURL: NSURL?) -> NSPersistentStoreCoordinator? {
        
        if let currentModel = modelForCurrentVersion() {
            
            if let storePath = storeURL {
                if let storeVersion = persistentStoreVersionID(storePath) {
                    if let modelVersion = currentModelVersionID() {
                        buildForceSyncReferenceCalls(storeVersion, modelVersion: modelVersion)
                    }
                }
            }
            
            let coordinator = NSPersistentStoreCoordinator(managedObjectModel: currentModel)
            let error = NSErrorPointer()
            coordinator.addPersistentStoreWithType(
                NSSQLiteStoreType,
                configuration: nil,
                URL: storeURL,
                options: [NSMigratePersistentStoresAutomaticallyOption: true, NSInferMappingModelAutomaticallyOption: true],
                error: error)
            
            if error != nil {
                MONLogger.logError("Error while migrating to model version \(currentModel)" + error.debugDescription)
            } else {
                return coordinator
            }
        }
        return nil
    }
    
    func modelForCurrentVersion() -> NSManagedObjectModel? {
        let modelDir = NSBundle.mainBundle().pathsForResourcesOfType("momd", inDirectory: nil).filter( {[unowned self] in $0.lastPathComponent.rangeOfString(self.TrialManagement) != nil} )
        if let versionedModelDir = modelDir.first?.lastPathComponent {
            if let versioningPlist = NSBundle.mainBundle().pathForResource(VersionInfo, ofType: "plist", inDirectory: versionedModelDir) {
                let plistDict = NSDictionary(contentsOfFile: versioningPlist)
                
                if let modelURL = NSBundle.mainBundle().URLForResource(plistDict?.objectForKey(CurrentVersionKey) as String, withExtension: "mom", subdirectory: versionedModelDir) {
                    return NSManagedObjectModel(contentsOfURL: modelURL)
                }
            }
        }
        return nil
    }
    
    private func persistentStoreVersionID(storeURL: NSURL) -> Int? {
        if let metadata = NSPersistentStoreCoordinator.metadataForPersistentStoreOfType(NSSQLiteStoreType, URL: storeURL, error: nil) {
            if let version = (metadata[NSStoreModelVersionIdentifiersKey] as? NSArray)?.firstObject as? String {
                return (version as NSString).integerValue
            }
        }
        return nil
    }
    
    private func currentModelVersionID() -> Int? {
        return (modelForCurrentVersion()?.versionIdentifiers.anyObject() as? NSString)?.integerValue
    }
    
    private func buildForceSyncReferenceCalls(persistentStoreVersion: Int, modelVersion: Int) {
        if (persistentStoreVersion < modelVersion) {
            var referenceCalls = NSSet()
            for versionIndex in (persistentStoreVersion+1)...modelVersion {
                referenceCalls = referenceCalls.setByAddingObjectsFromArray(ModelVersionToForcedReferenceSyncCalls[versionIndex]!)
            }
            TMDeltaSyncManager().saveForceSyncReferenceCalls(referenceCalls)
        }
    }
}
