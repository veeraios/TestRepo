#import "TMHarvestEditContainerView.h"
#import "TMObservationView.h"
#import "NSArray+TMBlocks.h"
#import "MONDimensions.h"

static const NSInteger NumberOfItemsInPortrait = 3;
static const NSInteger NumberOfItemsInLandscape = 4;
static const CGFloat ObservationViewHeight = 60.0f;

@interface TMHarvestEditContainerView()
@property (nonatomic) NSArray *observationViews;
@property (nonatomic) TMObservationView *commentsObservationView;

@end

@implementation TMHarvestEditContainerView

- (instancetype)initWithHarvestObservations:(NSArray *)harvestObservations {
	self = [super init];
	if (self) {
		NSArray *sortedObservationsWithoutComments = [harvestObservations sort:^NSString*(TMObservationModel* observationModel) {
			return [observationModel observationHeading];
		} where:^BOOL(id whereObj) {
			return [whereObj isComments] == NO;
		}];
		
		self.observationViews = [sortedObservationsWithoutComments arrayForEach:^TMObservationView* (TMObservationModel* observationModel) {
			TMObservationView *observationView = [[TMObservationView alloc] initWithObservationModel:observationModel];
			[observationView setLastUpdatedDateEnabled:NO];
			return observationView;
		}];
		
		NSArray *commentsView = [harvestObservations arrayForEach:^TMObservationView* (TMObservationModel* observationModel) {
			return [[TMObservationView alloc] initWithObservationModel:observationModel];
		} where:^BOOL(TMObservationModel* whereObj) {
			return [whereObj isComments] == YES;
		}];
		
		if([commentsView count]) {
			self.commentsObservationView = [commentsView firstObject];
			[self addSubview:self.commentsObservationView];
		}
		
		for (TMObservationView *view in self.observationViews) {
			[self addSubview:view];
		}
	}
	return self;
}

- (void)layoutSubviews {
	[super layoutSubviews];
	
	NSInteger numberOfItemsAcross = [self numberOfItemsAcross];
	
	CGFloat observationViewWidthToUse = (CGRectGetWidth(self.bounds) - ((numberOfItemsAcross - 1) * MONDimensionsLargePadding)) / numberOfItemsAcross;
	
	__block CGRect observationViewFrame = CGRectMake(0.0, 0.0, observationViewWidthToUse, ObservationViewHeight);
	__block NSInteger rowCount = 0;
	
	[self.observationViews enumerateObjectsUsingBlock:^(TMObservationView *observationView, NSUInteger index, BOOL *stop) {
		observationView.frame = observationViewFrame;
		observationViewFrame.origin.x += CGRectGetWidth(observationView.frame) + MONDimensionsLargePadding;
		if(++rowCount == numberOfItemsAcross) {
			rowCount = 0;
			observationViewFrame.origin.x = 0.0f;
			observationViewFrame.origin.y += ObservationViewHeight + MONDimensionsLargePadding;
		}
	}];
	
	if (self.commentsObservationView) {
		TMObservationView *lastObservationView = [self.observationViews lastObject];
		CGSize commentsObservationViewSize = [self.commentsObservationView sizeThatFits:CGSizeMake(CGRectGetWidth(self.bounds), CGFLOAT_MAX)];
		self.commentsObservationView.frame = CGRectMake(0.0, CGRectGetMaxY(lastObservationView.frame) + MONDimensionsLargePadding, CGRectGetWidth(self.bounds), commentsObservationViewSize.height);		
	}
}

- (CGSize)sizeThatFits:(CGSize)size {
	CGSize sizeThatFits = CGSizeMake(size.width, 0.0);
	
	CGFloat numberOfObservationViews = [self.observationViews count];
	double numberOfRows = ceil(numberOfObservationViews / (CGFloat)[self numberOfItemsAcross]);
	
	sizeThatFits.height = (numberOfRows * ObservationViewHeight) + ((numberOfRows - 1) * MONDimensionsExtraLargePadding);
	if(self.commentsObservationView) {
		sizeThatFits.height += ObservationViewHeight + MONDimensionsExtraLargePadding;
	}
	return sizeThatFits;
}

- (NSInteger)numberOfItemsAcross {
	BOOL isPortrait = UIInterfaceOrientationIsPortrait([[UIApplication sharedApplication] statusBarOrientation]);
	NSInteger numberOfItemsAcross = isPortrait ? NumberOfItemsInPortrait : NumberOfItemsInLandscape;
	return numberOfItemsAcross;
}

- (void)shouldSetAsReadOnly:(BOOL)isReadOnly forObsRefCode:(NSString *)observationRefCode {
    [[self findObservationViewByRefCode:observationRefCode] shouldSetAsReadOnly:isReadOnly];
}

- (void)setAutoCalulatedValue:(NSString *)value withLabel:(NSString *)labelText forObsRefCode:(NSString *)observationRefCode{
    [[self findObservationViewByRefCode:observationRefCode] setValueText:value withLabel:labelText];
}

- (TMObservationView *)findObservationViewByRefCode:(NSString *)observationRefCode {
    for (TMObservationView *observationView in self.observationViews) {
        if ([observationRefCode isEqualToString:observationView.observationRefCode]) {
            return observationView;
        }
    }
    return nil;
}

#pragma mark MONReadOnlyProtocol
- (void)setAsReadOnly {
    for (TMObservationView *observationView in self.observationViews) {
        [observationView setAsReadOnly];
    }
    [self.commentsObservationView setAsReadOnly];
}

@end
