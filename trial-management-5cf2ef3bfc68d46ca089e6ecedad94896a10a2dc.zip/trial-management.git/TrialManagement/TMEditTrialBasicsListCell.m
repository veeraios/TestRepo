#import "TMEditTrialBasicsListCell.h"

@implementation TMEditTrialBasicsListCell

@end
