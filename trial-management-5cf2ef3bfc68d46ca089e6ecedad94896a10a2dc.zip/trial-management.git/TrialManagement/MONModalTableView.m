#import "MONDimensions.h"
#import "MONModalTableView.h"
#import "MONLabel.h"
#import "UIColor+MONThemeColorProvider.h"

static const CGFloat MONModalTableViewFooterHeight = 30.0;

@interface MONModalTableView()<UITableViewDataSource, UITableViewDelegate>
@property (nonatomic) UIView *headerView;
@property (nonatomic) UIView *footerView;
@property (nonatomic) UIButton *modalButton;
@property (nonatomic) MONLabel *subTitleLabel;
@property (nonatomic) UITableView *tableView;
@property (nonatomic) id<MONModalTableViewModel> model;
@end

@implementation MONModalTableView

- (instancetype)initWithHeaderView:(UIView*)headerView tableTitle:(NSString*)tableTitle modalButton:(UIButton*)modalButton footerView:(UIView*)footerView
							 model:(id<MONModalTableViewModel>)model {
    self = [super init];
    if (self) {
		self.model = model;
		self.headerView = headerView;
		[self addSubview:self.headerView];
		
		self.subTitleLabel = [[MONLabel alloc] init];
		[self.subTitleLabel setText:tableTitle];
		[self addSubview:self.subTitleLabel];
		
		self.tableView = [[UITableView alloc] init];
		self.tableView.allowsMultipleSelection = YES;
		
		//todo: replace with custom cell
		[self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:NSStringFromClass([UITableViewCell class])];
		self.tableView.backgroundColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeBackground];
		self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
		self.tableView.layer.cornerRadius = MONDimensionsCornerRadius;
        self.tableView.allowsSelection = NO;
		self.tableView.delegate = self;
		self.tableView.dataSource = self;
		[self addSubview:self.tableView];
		
		self.modalButton = modalButton;
		[self.modalButton addTarget:self action:@selector(modalButtonWasTapped) forControlEvents:UIControlEventTouchUpInside];
		[self addSubview:self.modalButton];
		
		self.footerView = footerView;
		[self addSubview:self.footerView];

    }
    return self;
}
- (void)setAsReadOnly {
	self.modalButton.alpha = 0.7f;
}

- (void)layoutSubviews {
	[super layoutSubviews];
	
	[self.headerView sizeToFit];
	self.headerView.frame = CGRectMake(0.0, 0.0, CGRectGetWidth(self.bounds), CGRectGetHeight(self.headerView.frame));

	[self.subTitleLabel sizeToFit];
	self.subTitleLabel.frame = CGRectMake(MONDimensionsSmallPadding, CGRectGetMaxY(self.headerView.frame), CGRectGetWidth(self.bounds), CGRectGetHeight(self.subTitleLabel.frame));

	[self.modalButton sizeToFit];
	[self.footerView sizeToFit];

	CGFloat countiesTableHeight = CGRectGetHeight(self.bounds) - ((CGRectGetHeight(self.modalButton.frame) + MONModalTableViewFooterHeight) + (CGRectGetHeight(self.headerView.frame) + CGRectGetHeight(self.subTitleLabel.frame)) + (MONDimensionsSmallPadding*2));
	
	self.tableView.frame = CGRectMake(MONDimensionsSmallPadding,
												  CGRectGetMaxY(self.subTitleLabel.frame) + MONDimensionsTinyPadding,
												  CGRectGetWidth(self.bounds) - (MONDimensionsSmallPadding*2),
												  countiesTableHeight);
	
	self.modalButton.frame = CGRectMake((CGRectGetWidth(self.bounds) - CGRectGetWidth(self.modalButton.frame)) / 2.0, CGRectGetMaxY(self.tableView.frame) + MONDimensionsTinyPadding, CGRectGetWidth(self.modalButton.frame), CGRectGetHeight(self.modalButton.frame));


	self.footerView.frame = CGRectMake((CGRectGetWidth(self.bounds) - CGRectGetWidth(self.footerView.frame)) / 2.0,
												  CGRectGetMaxY(self.modalButton.frame), CGRectGetWidth(self.bounds), MONModalTableViewFooterHeight);
}

- (CGSize)sizeThatFits:(CGSize)size {
	CGSize sizeThatFits = size;
	[self.headerView sizeToFit];
	[self.subTitleLabel sizeToFit];
	[self.modalButton sizeToFit];
	[self.footerView sizeToFit];
	[self.tableView sizeToFit];
	sizeThatFits.height = CGRectGetHeight(self.headerView.frame) + CGRectGetHeight(self.subTitleLabel.frame) + CGRectGetHeight(self.tableView.frame) + CGRectGetHeight(self.modalButton.frame) + MONModalTableViewFooterHeight + MONDimensionsSmallPadding  +  MONDimensionsSmallPadding;
	return sizeThatFits;
}

- (void)modalButtonWasTapped {
	[self.delegate modalButtonWasTapped:self];
}

- (void)refreshTable:(id<MONModalTableViewModel>)model {
	self.model = model;
	[self.tableView reloadData];
}

#pragma mark - UITableViewDataSource Methods

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
	return [self.model numberOfItems];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"UITableViewCell"];
	cell.textLabel.text = [self.model nameForItemAtIndex:indexPath.row];
	cell.textLabel.textColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeNavigationBarText];
	cell.textLabel.font = [UIFont fontWithName:@"OpenSans" size:14];
	[cell.layer setBorderWidth:7.5];
	[cell.layer setBorderColor:[UIColor colorForThemeComponentType:MONThemeComponentTypeBackground].CGColor];

	cell.layer.cornerRadius = 11;
	cell.layer.masksToBounds = YES;
	cell.clipsToBounds = YES;
	cell.layer.opaque = NO;
	
	UIButton *removeButton = [[UIButton alloc] init];
	removeButton.tag = indexPath.row;
	[removeButton setImage:[UIImage imageNamed:@"ui-icon-image-delete"] forState:UIControlStateNormal];
	[removeButton addTarget:self action:@selector(removeButtonTapped:) forControlEvents:UIControlEventTouchUpInside];
	removeButton.frame = CGRectMake(0, 0, 20, 20);
	removeButton.backgroundColor = [UIColor clearColor];
	cell.accessoryView = removeButton;
	cell.backgroundColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeTabButtonBackground];

	return cell;
}

-(void)removeButtonTapped:(id) sender {
    UIButton *tappedButton = (UIButton *) sender;
	[self.delegate removeButtonTapped:self index:tappedButton.tag objectToRemove:[self.model objectForItemAtIndex:tappedButton.tag]];
}

- (void)setModalButtonEnabled:(BOOL)enabled {
    [self.modalButton setUserInteractionEnabled:enabled];
    [self.modalButton setEnabled:enabled];
    self.modalButton.alpha = enabled ? 1 : 0.7f;
}

@end
