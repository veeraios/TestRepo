#import <UIKit/UIKit.h>

@interface MONPlaceholderControl : UIControl

- (void)setImage:(UIImage *)image;
- (void)setText:(NSString *)text;

@end
