#import <Foundation/Foundation.h>

@protocol MONFilter <NSObject>

- (NSArray *)filteredArrayFromArray:(NSArray *)itemsArray filterText:(NSString *)filterText;

@end
