#import "MONLabel.h"
#import "MONHeaderViewAlertProtocol.h"

@interface MONHeaderView : UIView<MONHeaderViewAlertProtocol>
-(NSString*)title;
-(UIFont*)font;
@end
