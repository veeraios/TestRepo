#import "MONPopoverTableViewController.h"
#import "MONLabel.h"
#import "MONFonts.h"

@interface MONPopoverTableViewController ()<ESCObservableInternal, UITableViewDataSource, UITableViewDelegate>

@property (nonatomic) UITableView *tableView;
@property (nonatomic) id<TMReferenceListDataModel> model;
@property (nonatomic) NSString *popoverTitle;
@end

@implementation MONPopoverTableViewController

- (instancetype)initWithTitle:(NSString*)title model:(id<TMReferenceListDataModel>)model {
	self = [super init];
	if (self) {
		[self escRegisterObserverProtocol:@protocol(MONPopoverTableViewControllerObserver)];
		self.popoverTitle = title;
		self.model = model;
	}
	return self;
}

- (instancetype)initWithModel:(id<TMReferenceListDataModel>)model {
	self = [super init];
	if (self) {
		[self escRegisterObserverProtocol:@protocol(MONPopoverTableViewControllerObserver)];
		self.model = model;
	}
	return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
	
	self.tableView = [[UITableView alloc] init];
	[self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"UITableViewCell"];
	self.tableView.dataSource = self;
	self.tableView.delegate = self;
	[self.view addSubview:self.tableView];
}

- (void)viewWillAppear:(BOOL)animated {
	[super viewWillAppear:animated];
	if([self.popoverTitle length] > 0 ) {
	MONLabel *label = [MONLabel defaultLabelWithText:self.popoverTitle];
	[label setTextAlignment:NSTextAlignmentCenter];
	label.fontName = OpenSansSemibold;
	label.textSize = 20;
	[label sizeToFit];
	CGRect rect = CGRectMake(0, 0, CGRectGetWidth(self.view.frame), 50);
	label.frame =rect;
	[self.view addSubview:label];
	
	CALayer* layer = [label layer];
	CALayer *bottomBorder = [CALayer layer];
	bottomBorder.borderColor = [UIColor colorWithRed:175.0f/255.0f green:175.0f/255.0f blue:175.0f/255.0f alpha:1.0].CGColor;
	bottomBorder.borderWidth = 1;
	bottomBorder.frame = CGRectMake(-1, layer.frame.size.height-1, layer.frame.size.width, 1);
	
	[layer addSublayer:bottomBorder];
	MONLabel *label2 = [MONLabel defaultLabelWithText:@"    SELECT ONE"];
	label2.fontName = OpenSansBold;
	label2.textSize = 14;
	[label2 sizeToFit];
	CGRect rect2 = CGRectMake(0, CGRectGetHeight(label.frame), CGRectGetWidth(self.view.frame), 25);
	label2.frame =rect2;
	label2.backgroundColor = [UIColor colorWithRed:224.0f/255.0f green:224.0f/255.0f blue:225.0f/255.0f alpha:1.0];
	[self.view addSubview:label2];
	
	self.tableView.frame = CGRectMake(0, CGRectGetHeight(label.frame) + CGRectGetHeight(label2.frame), CGRectGetWidth(self.view.frame), CGRectGetHeight(self.view.frame) - (CGRectGetHeight(label.frame) + CGRectGetHeight(label2.frame)));
	[self.view addSubview:self.tableView];
	} else {
		self.tableView.frame = self.view.frame;
	}
}

#pragma mark - UITableViewDataSource Methods

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
	if([self.popoverTitle length] != 0) {
		return 55;
	}
	return 50;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
	return [self.model numberOfItems];
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"UITableViewCell"];
	cell.textLabel.text = [self.model nameForItemAtIndex:indexPath.row];
	return cell;
}

#pragma mark - UITableViewDelegate Methods

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	[self.escNotifier didSelectRowIndex:indexPath.row];
	[tableView deselectRowAtIndexPath:indexPath animated:YES];
}
@end
