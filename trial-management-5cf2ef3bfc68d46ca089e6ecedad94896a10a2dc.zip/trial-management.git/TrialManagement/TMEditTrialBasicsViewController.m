#import "TMEditTrialBasicsViewController.h"
#import "TMEditTrialBasicsView.h"
#import "MONDimensions.h"
#import "TMEditTrialBasicsCellProvider.h"
#import "MONPopoverTableViewController.h"
#import "TMEditTrialBasicsListCell.h"
#import "TMReferenceDataModel.h"
#import "MONTextViewCardCollectionViewCell.h"
#import "TMEditTrialBasicsTextCell.h"
#import "TMTrialBasicsModel.h"
#import "MONButton.h"
#import "TMWorkingUnitOfWork.h"
#import "UIColor+MONThemeColorProvider.h"
#import "TMTabNameConstants.h"
#import "UIViewController+TMOrientation.h"
#import "TMYearModel.h"
#import "TrialManagement-Swift.h"

static const CGFloat CardHeight = 150.0;
static NSString * const NewTrialHeaderText = @"New Trial";
static NSString * const EditTrialHeaderText = @"Edit Trial";

@interface TMEditTrialBasicsViewController ()<ESCObservableInternal, UICollectionViewDataSource, UICollectionViewDelegate, UIPopoverControllerDelegate, TMEditTrialBasicsCellProviderDelegate, MONSingleSelectionCardCollectionViewCellDelegate>

@property (nonatomic) TMEditTrialBasicsView *editTrialBasicsView;
@property (nonatomic) TMEditTrialBasicsCellProvider *basicsCellProvider;
@property (nonatomic) UICollectionView *collectionView;
@property (nonatomic) UICollectionViewFlowLayout *collectionViewFlowLayout;
@property (nonatomic) UIPopoverController *cellPopoverController;
@property (nonatomic) TMEditTrialBasicsListCell *selectedCell;
@property (nonatomic) TMTrialModel *trialModel;
@property (nonatomic) NSMutableDictionary * cellControlsDictionary;
@property (nonatomic) MONButton *continueButton;

@end

@implementation TMEditTrialBasicsViewController

@synthesize tabSettingsObject = _tabSettingsObject;

- (instancetype)initWithTrialModel:(TMTrialModel *)trialModel {
	self = [super initWithTrialModel:trialModel theClass:[self class]];
	if (self) {
		self.trialModel = trialModel;
	}
	return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];

	self.view.backgroundColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeBackground];
	
	self.basicsCellProvider = [[TMEditTrialBasicsCellProvider alloc] initWithTrialModel:self.trialModel];
	self.basicsCellProvider.delegate = self;
	self.collectionViewFlowLayout = [[UICollectionViewFlowLayout alloc] init];
	self.collectionViewFlowLayout.minimumLineSpacing = MONDimensionsSmallPadding;
	self.collectionViewFlowLayout.minimumInteritemSpacing = MONDimensionsSmallPadding;
	[self.collectionViewFlowLayout setScrollDirection:UICollectionViewScrollDirectionVertical];
	
	self.collectionView = [[UICollectionView alloc] initWithFrame:self.view.bounds collectionViewLayout:self.collectionViewFlowLayout];
	self.collectionView.dataSource = self;
	self.collectionView.delegate = self;
	[self.collectionView registerClass:[TMEditTrialBasicsListCell class] forCellWithReuseIdentifier:@"TMEditTrialBasicsListCell"];
	[self.collectionView registerClass:[TMEditTrialBasicsTextCell class] forCellWithReuseIdentifier:@"TMEditTrialBasicsTextCell"];
	
	self.continueButton = [[MONButton alloc] init];
	[self.continueButton setTitle:@"Continue" forState:UIControlStateNormal];
	[self.continueButton addTarget:self action:@selector(continueButtonTapped) forControlEvents:UIControlEventTouchUpInside];
	self.continueButton.enabled = ![self.trialModel isReadOnly];
	self.continueButton.alpha = ![self.trialModel isReadOnly] ? 1.0f : 0.7f;
	
	NSString *title = [self.trialModel isNewTrial] ? NewTrialHeaderText : EditTrialHeaderText;
	self.editTrialBasicsView = [[TMEditTrialBasicsView alloc] initWithCollectionView:self.collectionView headerButtons:@[self.continueButton]];
	self.editTrialBasicsView.frame = self.view.bounds;
	self.editTrialBasicsView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
	[self.editTrialBasicsView setHeaderText:title];
	[self.view addSubview:self.editTrialBasicsView];
	
	self.cellControlsDictionary = [[NSMutableDictionary alloc] init];
}

- (void)viewWillAppear:(BOOL)animated {
	[super viewWillAppear:animated];
	
	self.editTrialBasicsView.frame = self.view.bounds;
}

- (void)viewDidAppear:(BOOL)animated {
	[super viewDidAppear:animated];

	[MONGoogleAnalytics trackView:[self.trialModel isNewTrial] ? @"New Trial - Basics" : @"Trial - Basics"];
}

- (void)viewWillLayoutSubviews {
	[super viewWillLayoutSubviews];
	
	CGFloat cardWidth = 0;
	CGFloat availableWidth = CGRectGetWidth(self.view.bounds) - 2.0 * MONDimensionsSmallPadding;
	if ([self isOrientationLandscape]) {
		cardWidth = (availableWidth - 3.0 * MONDimensionsSmallPadding) / 4.0;
	} else {
		cardWidth = (availableWidth - 2.0 * MONDimensionsSmallPadding) / 3.0;
	}
	[self.collectionViewFlowLayout setItemSize:CGSizeMake(cardWidth, CardHeight)];
}

- (void)viewDidDisappear:(BOOL)animated {
	[super viewDidDisappear:animated];
	[[TMWorkingUnitOfWork sharedInstance] saveChanges];
}

- (void)continueButtonTapped {
	[self.tabSettingsObject gotoNextTab];
}

- (void)setTitle:(NSString *)title {
	BOOL wasTitleChanged = NO == [title isEqualToString:self.title];
	[super setTitle:title];
	[self.tabSettingsObject setGlobalTitle:title];
	if (title && NO == [title isEqualToString:TMTabNameNewTrial] && wasTitleChanged) {
		[self.editTrialBasicsView setHeaderText:EditTrialHeaderText];
		[self.tabSettingsObject setTabTitle:TMTabNameEditTrial viewController:self];
	}
}

#pragma mark - UICollectionViewDataSource Methods

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
	
	TMEditTrialBasicsListCell *cell = (TMEditTrialBasicsListCell *)[self.basicsCellProvider collectionView:collectionView cellForItemAtIndexPath:indexPath];
    
    ((MONSingleSelectionCardCollectionViewCell*)cell).delegate = self;
	
	if ([cell.cellModel conformsToProtocol:@protocol(TMReferenceListDataModel)]) {

		MONPopoverTableViewController *tableViewController = [[MONPopoverTableViewController alloc] initWithModel:(TMReferenceDataListGenericModel*)cell.cellModel];
		[tableViewController escAddObserver:self];
		
		//probably not needed
		self.cellPopoverController = [[UIPopoverController alloc] initWithContentViewController:tableViewController];
		self.cellPopoverController.delegate = self;

		[self.cellControlsDictionary setObject:tableViewController forKey:indexPath];
		
		return cell;
	} else if ([cell.cellModel conformsToProtocol:@protocol(TMReferenceDataModel)]) {
		TMEditTrialBasicsTextCell *cell = (TMEditTrialBasicsTextCell *)[self.basicsCellProvider collectionView:collectionView cellForItemAtIndexPath:indexPath];
		
		MONTextViewCardCollectionViewCell *textViewCell = [[MONTextViewCardCollectionViewCell alloc] init];
		
		[textViewCell setTitle:((id<TMReferenceDataModel>)cell.cellModel).modelValue];
		[cell addSubview:textViewCell];
		[self.cellControlsDictionary setObject:textViewCell forKey:indexPath];
		return cell;
	}
	return cell;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
	return [self.basicsCellProvider collectionView:collectionView numberOfItemsInSection:section];
}

- (void)selectOptionsButtonTappedOnCell:(UICollectionViewCell *)cell {
    TMEditTrialBasicsListCell *selectedCell = (TMEditTrialBasicsListCell *)cell;
    
    if(selectedCell.isReadOnly) {
        return;
    }
    
    self.selectedCell = selectedCell;
    
    id object =  [self.cellControlsDictionary objectForKey:[self.collectionView indexPathForCell:cell]];
    
    if(object && [object isKindOfClass:[MONPopoverTableViewController class]] ){
        MONPopoverTableViewController *tableViewController = (MONPopoverTableViewController*)object;
        self.cellPopoverController = [[UIPopoverController alloc] initWithContentViewController:tableViewController];
        self.cellPopoverController.delegate = self;

        [self.cellPopoverController setPopoverContentSize:CGSizeMake(300, 200)];
        CGRect popoverPresetingRect = CGRectInset(cell.bounds, 5.0, 5.0);
        [self.cellPopoverController presentPopoverFromRect:popoverPresetingRect inView:cell permittedArrowDirections:UIPopoverArrowDirectionLeft | UIPopoverArrowDirectionRight animated:YES];
    }
}

#pragma mark - UIPopoverControllerDelegate Methods

- (void)popoverControllerDidDismissPopover:(UIPopoverController *)popoverController {
	self.selectedCell = nil;
}

#pragma mark - MONPopoverTableViewControllerObserver Methods

- (void)didSelectRowIndex:(NSInteger)rowIndex {
    [self.cellPopoverController dismissPopoverAnimated:YES];
    if ([self.selectedCell.cellModel conformsToProtocol:@protocol(TMReferenceListDataModel)]) {
        Class cellModelClass = [self.selectedCell.cellModel class];
        if([cellModelClass isSubclassOfClass:[TMDSMModel class]]) {
            [self.basicsCellProvider filterTechAgronomistDataByDSM:[(TMReferenceDataListGenericModel *)self.selectedCell.cellModel objectAtIndex:rowIndex]];
            [self.collectionView reloadData];
            return;
            
        } else if([cellModelClass isSubclassOfClass:[TMTAModel class]]) {
            [self.basicsCellProvider filterTechAgronomistDataByTA:[(TMReferenceDataListGenericModel *)self.selectedCell.cellModel objectAtIndex:rowIndex]];
            [self.collectionView reloadData];
            return;
        } else if([cellModelClass isSubclassOfClass:[TMTerritoryModel class]] ||
                  [cellModelClass isSubclassOfClass:[TMRalModel class]]) {
            [self.selectedCell setSelectedText:[(TMReferenceDataListGenericModel *)self.selectedCell.cellModel nameForItemAtIndex:rowIndex]];
            [self updateTechAgronomist];
        } else if([cellModelClass isSubclassOfClass:[TMBrandModel class]]) {
            [self.trialModel setRelationship: [(TMReferenceDataListGenericModel *)self.selectedCell.cellModel objectAtIndex:rowIndex]];
            [self updateTechAgronomist];
            [self.basicsCellProvider filterAccordingToProtocolByBrand];
            [self.collectionView reloadData];
            return;
        } else if([cellModelClass isSubclassOfClass:[TMCropModel class]]) {
            [self.trialModel setRelationship: [(TMReferenceDataListGenericModel *)self.selectedCell.cellModel objectAtIndex:rowIndex]];
            [self updateTechAgronomist];
            [self.basicsCellProvider filterAccordingToProtocolByCrop];
            [self.collectionView reloadData];
            return;
        } else if ([cellModelClass isSubclassOfClass:[TMYearModel class]]) {
            [self.trialModel setPlantingYear:[(TMReferenceDataListGenericModel *)self.selectedCell.cellModel objectAtIndex:rowIndex]];
        } else {
            [self.trialModel setRelationship: [(TMReferenceDataListGenericModel *)self.selectedCell.cellModel objectAtIndex:rowIndex]];
        }
        [self.selectedCell setSelectedText:[(TMReferenceDataListGenericModel *)self.selectedCell.cellModel nameForItemAtIndex:rowIndex]];
    }
}

-(void)reloadFinished {
	[self updateTechAgronomist];
}

-(void)updateTechAgronomist {
	[self.trialModel setTechAgronomist:[self selectedDSMValue]  ta:[self selectedTAValue] ral:[self selectedRALValue] territory:[self selectedTerritoryValue] brand:[self selectedBrandValue]];
}

-(NSString*)selectedDSMValue {
	return [((TMEditTrialBasicsListCell*)[self.collectionView cellForItemAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0]]) selectedText];
}

-(NSString*)selectedBrandValue {
	return [((TMEditTrialBasicsListCell*)[self.collectionView cellForItemAtIndexPath:[NSIndexPath indexPathForRow:3 inSection:0]]) selectedText];
}

-(NSString*)selectedRALValue {
	return [((TMEditTrialBasicsListCell*)[self.collectionView cellForItemAtIndexPath:[NSIndexPath indexPathForRow:5 inSection:0]]) selectedText];
}

-(NSString*)selectedTerritoryValue {
	return [((TMEditTrialBasicsListCell*)[self.collectionView cellForItemAtIndexPath:[NSIndexPath indexPathForRow:4 inSection:0]]) selectedText];
}

-(NSString*)selectedTAValue {
	return [((TMEditTrialBasicsListCell*)[self.collectionView cellForItemAtIndexPath:[NSIndexPath indexPathForRow:1 inSection:0]]) selectedText];
}
@end
