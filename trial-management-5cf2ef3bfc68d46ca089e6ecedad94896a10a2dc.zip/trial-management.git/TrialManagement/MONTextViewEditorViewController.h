#import <UIKit/UIKit.h>

@interface MONTextViewEditorViewController : UIViewController

@property (nonatomic) NSString *enteredText;

- (void)setHeaderText:(NSString *)headerText;

@end
