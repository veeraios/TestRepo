#import "TMEntryModel.h"
#import "MONReadOnlyProtocol.h"

@protocol TMEntryHarvestCollectionViewCellDelegate <NSObject>
- (void)yieldWasUpdated;
- (void)moistureWasUpdated;
@end

@interface TMEntryHarvestCollectionViewCell : UICollectionViewCell<MONReadOnlyProtocol>
@property (nonatomic, weak) id<TMEntryHarvestCollectionViewCellDelegate> delegate;

- (void)setEntryModel:(TMEntryModel*)entryModel;
- (void)calculateYieldAndSetAsReadOnlyIfNeeded;
@end
