#import "MONTabView.h"
#import "MONTabsContainerView.h"
#import "MONUIConvenienceFunctions.h"
#import "MONDimensions.h"
#import "UIColor+MONThemeColorProvider.h"

@interface MONTabView ()<MONTabsContainerViewDelegate>

@property (nonatomic) UIViewController *selectedViewController;
@property (nonatomic) MONTabsContainerView *tabsContainerView;
@property (nonatomic) UIView *bottomBorderView;
@property (nonatomic) NSArray *tabModels;

@end

@implementation MONTabView

- (instancetype)init {
	self = [super init];
	if (self) {
		self.backgroundColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeBackground];
		self.bottomBorderView = [[UIView alloc] init];
		self.bottomBorderView.backgroundColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeBorder];
		[self addSubview:self.bottomBorderView];
	}
	return self;
}

- (void)layoutSubviews {
	[super layoutSubviews];
	
	CGRect contentRect = self.bounds;

	[self.tabsContainerView sizeToFit];
	self.tabsContainerView.frame = CGRectMake(MONUIScreenRoundToScreenScale((CGRectGetMaxX(self.bounds) - CGRectGetWidth(self.tabsContainerView.frame)) / 2.0),
											  CGRectGetMaxY(self.bounds) - CGRectGetHeight(self.tabsContainerView.frame) - MONDimensionsSmallPadding,
											  CGRectGetWidth(self.tabsContainerView.frame),
											  CGRectGetHeight(self.tabsContainerView.frame));
	
	self.bottomBorderView.frame = CGRectMake(MONUIScreenRoundToScreenScale(MONDimensionsSmallPadding / 2.0),
											 CGRectGetMinY(self.tabsContainerView.frame) - MONDimensionsSmallPadding,
											 CGRectGetWidth(contentRect) - MONDimensionsSmallPadding,
											 MONDimensionsThinBorderWidth);

	self.selectedViewController.view.frame = CGRectMake(CGRectGetMinX(contentRect),
										CGRectGetMinY(contentRect),
										CGRectGetWidth(contentRect),
										CGRectGetHeight(contentRect) - (CGRectGetMaxY(contentRect) - CGRectGetMinY(self.bottomBorderView.frame)));
}

- (void)setTabModels:(NSArray *)tabModels {
	_tabModels = tabModels;

	if (self.tabsContainerView) {
		[self.tabsContainerView removeFromSuperview];
	}
	self.tabsContainerView = [[MONTabsContainerView alloc] initWithTabModels:tabModels];
	self.tabsContainerView.delegate = self;
	[self addSubview:self.tabsContainerView];
	[self setNeedsLayout];
}

- (void)setSelectedViewController:(UIViewController *)selectedViewController {
	[_selectedViewController.view removeFromSuperview];
	
	_selectedViewController = selectedViewController;

	[self addSubview:selectedViewController.view];
}

- (void)setSelectedTabAtIndex:(NSUInteger)index {
	[self.tabsContainerView setSelectedTabAtIndex:index];
}

#pragma mark - MONTabsContainerViewDelegate Methods

- (void)tabTappedAtIndex:(NSUInteger)index {
	[self.delegate tabTappedAtIndex:index];
}

@end
