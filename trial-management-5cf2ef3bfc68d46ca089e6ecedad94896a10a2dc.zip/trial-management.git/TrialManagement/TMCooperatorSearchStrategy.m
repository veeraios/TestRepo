#import "TMCooperatorSearchStrategy.h"
#import "TMCooperatorSearchResultsTableViewHeaderView.h"
#import "TMSearchCooperatorsView.h"
#import "TMSearchCooperatorsModel.h"

@interface TMCooperatorSearchStrategy()
@property(readwrite, nonatomic) CooperatorCategory cooperatorCategory;
@end

@implementation TMCooperatorSearchStrategy
- (instancetype)initWithCooperatorCategory:(CooperatorCategory)cooperatorCategory {
  if (self) {
    self.cooperatorCategory = cooperatorCategory;
  }
  return self;
}

- (NSObject <MONReferenceSearchableModel> *)searchModel {
  NSObject <MONReferenceSearchableModel> *searchModel = [[TMSearchCooperatorsModel alloc] initWithCooperatorCategory:self.cooperatorCategory];
  return searchModel;
}

- (UIView *)tableViewHeader {
  TMCooperatorSearchResultsTableViewHeaderView *headerCell = [[TMCooperatorSearchResultsTableViewHeaderView alloc] init];
  return headerCell;
}

- (UIView <MONSearchViewProtocol> *)searchView {
  TMSearchCooperatorsView *searchGrowersView = [[TMSearchCooperatorsView alloc] initWithCooperatorCategory:(Grower == self.cooperatorCategory ? Grower : Dealer)];
  return searchGrowersView;
}
@end