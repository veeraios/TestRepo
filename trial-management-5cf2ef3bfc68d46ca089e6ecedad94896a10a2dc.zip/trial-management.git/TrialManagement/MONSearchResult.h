@protocol MONSearchResult <NSObject>
- (id)searchModelItem;
@end
