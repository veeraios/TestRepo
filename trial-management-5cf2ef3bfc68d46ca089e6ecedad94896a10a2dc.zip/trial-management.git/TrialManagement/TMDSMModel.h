#import "TMReferenceDataListGenericModel.h"

@interface TMDSMModel : TMReferenceDataListGenericModel
-(instancetype)initWithDataSource:(NSArray*)dataSource;
@end
