#import "TMCooperatorInfoViewModel.h"
#import "TMWorkingUnitOfWork.h"

@interface TMCooperatorInfoViewModel ()
@property (nonatomic,readwrite) TMStatesModel *statesModel;
@end

@implementation TMCooperatorInfoViewModel

- (instancetype)init {
	self = [super init];
	if (self) {
		id<TMStateRepositoryProtocol> stateRepository = [[TMWorkingUnitOfWork sharedInstance] stateRepository];
		self.statesModel =[[TMStatesModel alloc] initWithDataSource:[stateRepository sortedEntitiesByName]];
	}
	return self;
}

@end
