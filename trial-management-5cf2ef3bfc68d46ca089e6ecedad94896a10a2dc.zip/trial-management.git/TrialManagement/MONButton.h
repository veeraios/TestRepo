@interface MONButton : UIButton
- (id)initWithTitle:(NSString*)title;
- (void)setReadOnly:(BOOL)value;
@end
