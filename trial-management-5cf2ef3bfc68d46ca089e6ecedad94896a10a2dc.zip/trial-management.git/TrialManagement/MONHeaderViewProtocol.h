#import "MONLabel.h"

@protocol MONHeaderViewProtocol <NSObject>

@property (nonatomic) MONLabel *headerLabel;
- (void)setFont:(UIFont*)font;
- (void)setTitle:(NSString *)title;
- (void)setNumberOfItems:(NSUInteger)numberOfItems;
- (void)showNumberOfItems:(BOOL)showNumberOfItems;
- (void)setRightButtons:(NSArray *)rightButtons;
- (void)setLeftButtons:(NSArray *)leftButtons;
- (void)showBottomBorder:(BOOL)showBottomBorder;
@end

