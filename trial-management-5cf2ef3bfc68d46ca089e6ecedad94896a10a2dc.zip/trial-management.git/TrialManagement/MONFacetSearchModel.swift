import UIKit

@objc protocol MONFacetSearchModelDelegate: class {
    func filterUpdated()
    func facetFinalized(facet: MONFacetModel)
}

class MONFacetSearchModel: NSObject {
    weak var delegate: MONFacetSearchModelDelegate?
    
    private(set) var dataSource = [MONFacetSearchObjectProtocol]()
    private(set) var filteredIds = [String]()
    private(set) var facetModels = [MONFacetModel]()
    private(set) var currentSearch: MONFacetModel
    private var searchTimer: NSTimer?
    
    init(basePredicate: MONFacetPredicateProtocol) {
        currentSearch = MONFacetModel(basePredicate: basePredicate, fetchedObjects: [])
        super.init()
        currentSearch.delegate = self
    }
    
    convenience init(basePredicate: MONFacetPredicateProtocol, dataSource: [MONFacetSearchObjectProtocol], facetModels: [MONFacetModel], currentFacetModel: MONFacetModel) {
        
        self.init(basePredicate: basePredicate)
        self.dataSource = dataSource
        self.facetModels = facetModels
        self.currentSearch = currentFacetModel
    }
    
    func facetRemoved(facet: MONFacetModel) {
        facetModels = facetModels.filter( {$0 != facet} )
        minimalObjectIdSet()
        currentSearch.recalculateFacet(dataSource, filteredIds: filteredIds)
        delegate?.filterUpdated()
    }
    
    func finalizeCurrentSearch() {
        if (searchTimer != nil && searchTimer!.valid) {
            searchTimer!.fire()
            searchTimer!.invalidate()
        }
        currentSearch.finializeFacet(dataSource)
    }
    
    func minimalObjectIdSet() {
        let orderedModels = facetModels
            .sorted( {$0.finalizedObjectIds.count < $1.finalizedObjectIds.count} )
        
        if orderedModels.count > 1 {
            filteredIds = orderedModels
                .tail()
                .reduce(orderedModels.first!.finalizedObjectIds, combine: {$1.compareFinalizedFacetIds($0)} )
        } else {
            filteredIds = (orderedModels.count == 1) ? orderedModels[0].finalizedObjectIds : dataSource.map( {$0.searchID} )
        }
    }
}

extension MONFacetSearchModel: MONSearchModelProtocol {
    func filterItemsWithText(filterText: String) {
        if (searchTimer != nil && searchTimer!.valid) {
            searchTimer!.invalidate()
        }
        
        let interval = filterText.isEmpty ? 0.0 : 0.4
        
        searchTimer = NSTimer.scheduledTimerWithTimeInterval(interval,
            target: self,
            selector: "searchOnText:",
            userInfo: filterText,
            repeats: false)
    }
    
    func searchOnText(timer: NSTimer) {
        if let searchText = timer.userInfo as? String {
            currentSearch.searchOnText(searchText, dataSource: dataSource, filteredIds: filteredIds)
        }
        delegate?.filterUpdated()
    }
    
    func filteredItemAtIndex(index: Int) -> AnyObject? {
        return !itemsWereFiltered() ? dataSource[index] : currentSearch.fetchedObjects[index]
    }
    
    func setAllSearchItems(items: [AnyObject]?) {
        if let allItems = items as? [MONFacetSearchObjectProtocol]{
            dataSource = allItems
            filteredIds = allItems.map( {$0.searchID} )
            delegate?.filterUpdated()
        }
    }
    
    func filteredItems() -> [AnyObject]? {
        return !itemsWereFiltered() ? dataSource : currentSearch.fetchedObjects
    }
    
    func itemsWereFiltered() -> Bool {
        return !facetModels.isEmpty || (currentSearch.prevText != nil && !currentSearch.prevText!.isEmpty)
    }
    
    func cancelSearch() {
        facetModels = [MONFacetModel]()
        filteredIds = dataSource.map( {$0.searchID} )
        filterItemsWithText("")
    }

}

extension MONFacetSearchModel: MONFacetModelDelegate {
    
    func finalizedFacet(prevFacet: MONFacetModel, nextFacet: MONFacetModel) {
        facetModels.append(prevFacet)
        minimalObjectIdSet()
        
        currentSearch = nextFacet
        currentSearch.delegate = self
        
        delegate?.facetFinalized(prevFacet)
    }
}
