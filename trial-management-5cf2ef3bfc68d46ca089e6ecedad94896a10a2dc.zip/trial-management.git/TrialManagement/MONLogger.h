//
//  MONLogger.h
//  TrialManagement
//
//  Created by WAIDMANN, ALAN [AG/1000] on 1/29/15.
//  Copyright (c) 2015 Monsanto. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MONLogger : NSObject

+ (void)logError:(NSString *)message;
+ (void)logInfo:(NSString *)message;

@end
