#import "TMCountiesModel.h"

@interface TMCountiesModel()
@property (nonatomic) NSArray *dataArray;
@end

@implementation TMCountiesModel

- (instancetype)initWithArray:(NSArray*)array {
	self = [super init];
	if(self) {
		self.dataArray = array;
	}
	return self;
}

- (NSInteger)numberOfItems {
	return self.dataArray.count;
}

- (NSString *)nameForItemAtIndex:(NSInteger)index {
	return [self objectForItemAtIndex:index].name;
}

- (TMCounty *)objectForItemAtIndex:(NSInteger)index {
	return ((TMCounty*)[self.dataArray objectAtIndex:index]);
}

- (TMCounty*)countyForCountyName:(NSString*)countyName {
	return [[self.dataArray filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"name == %@",countyName]] firstObject];
}

- (NSString *)nameForItem:(id)item {
    return [[self dataArray] containsObject:item] ? ((TMCounty *)item).name : @"";
}

- (NSInteger)indexForItem:(id)item {
    return [[self dataArray] indexOfObject:item];
}
@end
