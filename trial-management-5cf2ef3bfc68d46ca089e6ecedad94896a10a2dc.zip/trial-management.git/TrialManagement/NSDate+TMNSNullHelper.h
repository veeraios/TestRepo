@interface NSDate (TMNSNullHelper)
-(id)safeDate;
@end
