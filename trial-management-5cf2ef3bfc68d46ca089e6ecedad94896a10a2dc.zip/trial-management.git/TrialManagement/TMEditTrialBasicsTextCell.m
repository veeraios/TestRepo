#import "TMEditTrialBasicsTextCell.h"
#import "UIColor+MONThemeColorProvider.h"

@implementation TMEditTrialBasicsTextCell

- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
		
		self.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;

		self.titleLabel.textAlignment = NSTextAlignmentCenter;
		self.textField.enabled = YES;
		self.textField.textColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeText];
		self.textField.layer.cornerRadius = 2.0;
		[self.textField.layer setBorderWidth:1.0];
		[self setPlaceholderText:@"Not Entered"];
		[self.textField.layer setBorderColor:[UIColor colorForThemeComponentType:MONThemeComponentTypeBorder].CGColor];

    }
    return self;
}
- (void)layoutSubviews {
	[super layoutSubviews];
	self.titleLabel.frame = CGRectMake(0,
									   0,
									   CGRectGetWidth(self.bounds),
									   68.0);
	
	self.textField.frame = CGRectMake(CGRectGetMinX(self.titleLabel.frame) + 10.0,
									 CGRectGetMaxY(self.titleLabel.frame),
									 CGRectGetWidth(self.bounds) - 20.0,
									50.0);
}

- (void)setKeyboardType:(UIKeyboardType)keyboardType {
	self.textField.keyboardType = keyboardType;
}
@end
