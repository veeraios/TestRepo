@interface MONHardware : NSObject

typedef NS_ENUM(NSInteger, MONHardwareType) {
    MONHardwareTypeUnknown          = -1,
    MONHardwareTypeIpad     = 0,
    MONHardwareTypeIpadMini = 1,
    MONHardwareTypeIphone = 2,
	MONHardwareTypeIpod = 3,
};

+ (MONHardwareType)currentDeviceType;
+ (NSUInteger)totalMemory;
+ (NSUInteger)userMemory;
+ (CGFloat)activeMemory;
+ (CGFloat)usedMemory;
+ (CGFloat)freeMemory;
@end
