#import "TMReferenceListDataModel.h"
#import "MONTextFieldCardCollectionViewCell.h"

@interface TMEditTrialBasicsTextCell : MONTextFieldCardCollectionViewCell

@property (nonatomic) id<TMDataModel> cellModel;
- (void)setKeyboardType:(UIKeyboardType)keyboardType;
@end
