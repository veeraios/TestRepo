#import "MONLabeledPopoverButton.h"
#import "MONPopoverTableViewController.h"
#import "MONDimensions.h"
#import "MONTextFieldButton.h"
#import "UIColor+MONThemeColorProvider.h"
#import "MONUIConvenienceFunctions.h"

NSString * const MONLabeledPopoverButtonDidShowPopover = @"MONLabeledPopoverButtonDidShowPopover";

static const CGFloat VerticalSpacing = 3.0;

@interface MONLabeledPopoverButton ()<UIPopoverControllerDelegate, MONPopoverTableViewControllerObserver, MONPopoverTextFieldDelegate>

@property (nonatomic) MONTextFieldButton *button;
@property (nonatomic) UIPopoverController *cellPopoverController;
@property (nonatomic) UITextField *textField;
@property (nonatomic) CGFloat labelWidth;

@end

@implementation MONLabeledPopoverButton

- (id)init{
	return [self initWithModel:nil placeHolderText:@""];
}

- (instancetype)initWithModel:(id<TMReferenceListDataModel>)model placeHolderText:(NSString *)placeHolderText {
    self = [super init];
    if (self) {
        self.layer.cornerRadius = 2.0;
        self.model = model;
        
        self.textField = nil;
        
        self.button = [[MONTextFieldButton alloc] init];
        [self.button setPlaceholderText:placeHolderText];
        [self.button addTarget:self action:@selector(buttonTapped) forControlEvents:UIControlEventTouchUpInside];
        self.controlView = self.button;
    }
    return self;
}

- (void)layoutSubviews {
	[super layoutSubviews];
	
	if (self.labelLocation == MONLabeledControlLabelLocationLeft) {
		self.button.frame = CGRectMake(CGRectGetMaxX(self.label.frame) + MONDimensionsSmallPadding,
										  0.0,
										  CGRectGetWidth(self.bounds) - CGRectGetMaxX(self.label.frame) - MONDimensionsSmallPadding,
										  CGRectGetHeight(self.bounds));
	} else if (self.labelLocation == MONLabeledControlLabelLocationTop) {
		self.button.frame = CGRectMake(0.0,
									   CGRectGetMaxY(self.label.frame) + VerticalSpacing,
									   CGRectGetWidth(self.bounds),
									   CGRectGetHeight(self.bounds) - CGRectGetMaxY(self.label.frame));
	} else if (self.labelLocation == MONLabeledControlLabelLocationNone) {
		self.button.frame = CGRectMake(0.0,
										  0.0,
										  CGRectGetWidth(self.bounds),
										  CGRectGetHeight(self.bounds));
	}
	self.button.frame = MONRectRoundedToScreenScale(self.button.frame);
}

- (CGSize)sizeThatFits:(CGSize)size {
	CGSize sizeThatFits = CGSizeMake(size.width, 0.0);
	[self.button sizeToFit];
	sizeThatFits.height = CGRectGetHeight(self.button.frame);
	
	if(self.labelLocation == MONLabeledControlLabelLocationTop) {
		sizeThatFits.height += CGRectGetHeight(self.label.frame) + VerticalSpacing;
	}

	return sizeThatFits;
}

- (void)setTextColor:(UIColor *)textColor {
	[self.button setTitleColor:textColor forState:UIControlStateNormal];
}

- (void)setTextFieldText:(NSString *)textFieldText {
	[self setButtonText:textFieldText];
}

- (void)setButtonText:(NSString *)buttonText {
	[self.button setTitle:buttonText forState:UIControlStateNormal];
}

- (void)setAsReadOnly {
    [self.button setTitleColor:[UIColor colorForThemeComponentType:MONThemeComponentTypeDisabledText] forState:UIControlStateNormal];
    [self.button setEnabled:NO];
}

- (void)showBorder:(BOOL)showBorder {
	if(showBorder) {
		[self.layer setBorderWidth:1.0];
		[self.layer setBorderColor:[UIColor colorForThemeComponentType:MONThemeComponentTypeBorder].CGColor];
	} else {
		[self.layer setBorderWidth:0.0];
		[self.layer setBorderColor:[UIColor clearColor].CGColor];
	}
	
}

- (void)buttonTapped {
	[[NSNotificationCenter defaultCenter] postNotificationName:MONLabeledPopoverButtonDidShowPopover object:self];
    MONPopoverTableViewController *tableViewController = [[MONPopoverTableViewController alloc] initWithModel:self.model];
    [tableViewController escAddObserver:self];
    self.cellPopoverController = [[UIPopoverController alloc] initWithContentViewController:tableViewController];
    [self presentPopover:self.cellPopoverController];
}

- (void)presentPopover:(UIPopoverController*)popoverController {
    popoverController.delegate = self;
    [popoverController setPopoverContentSize:CGSizeMake(300, 200)];
    CGRect popoverPresetingRect = CGRectInset(self.button.frame, 5.0, 5.0);
    [popoverController presentPopoverFromRect:popoverPresetingRect inView:self permittedArrowDirections:UIPopoverArrowDirectionLeft | UIPopoverArrowDirectionRight animated:YES];
}

- (void)didSelectRowIndex:(NSInteger)rowIndex {
    NSString *selectedText = [self.model nameForItemAtIndex:rowIndex];
	[self setButtonText:selectedText];
	[self.cellPopoverController dismissPopoverAnimated:YES];
	[self.popoverDelegate valueWasSelected:self selectedValue:selectedText selectedIndex:rowIndex];
}

@end
