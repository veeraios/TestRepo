#import <UIKit/UIKit.h>

@interface TMEditTrialPlantingView : UIView

- (instancetype)initWithCollectionView:(UICollectionView *)collectionView;

@end
