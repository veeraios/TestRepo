#import "MONRepository.h"
#import "TMDataSyncProtocol.h"
#import "TMEntry.h"
#import <Foundation/Foundation.h>

@protocol TMEntryRepositoryProtocol <NSObject, MONRepositoryProtocol>

- (TMEntry *)createEntryWithEntryId:(NSNumber *)entryId
							 number:(NSNumber *)number
							product:(TMProduct *)product
						  treatment:(TMTreatment *)treatment;
@end

@interface TMEntryRepository : MONRepository<TMEntryRepositoryProtocol>

@end
