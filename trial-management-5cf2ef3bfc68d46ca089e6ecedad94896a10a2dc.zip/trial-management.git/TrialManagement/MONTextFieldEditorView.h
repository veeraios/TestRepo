#import <ESCObservable/ESCObservable.h>
#import <UIKit/UIKit.h>

@protocol MONTextFieldEditorViewObserver <NSObject>

- (void)textFieldEditorTextDidChange:(NSString *)text;

@end


@interface MONTextFieldEditorView : UIView<ESCObservable>

- (void)setHeaderText:(NSString *)headerText;
- (void)setText:(NSString *)text;

@end
