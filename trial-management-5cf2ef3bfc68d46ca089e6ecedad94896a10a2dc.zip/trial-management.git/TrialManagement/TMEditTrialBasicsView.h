#import <UIKit/UIKit.h>

@interface TMEditTrialBasicsView : UIView

- (instancetype)initWithCollectionView:(UICollectionView *)collectionView headerButtons:(NSArray *)buttons;
- (void)setHeaderText:(NSString *)headerText;

@end
