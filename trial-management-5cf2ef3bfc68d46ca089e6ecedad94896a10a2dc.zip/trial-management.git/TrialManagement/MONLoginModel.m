#import "MONLoginModel.h"

@interface MONLoginModel ()<ESCObservableInternal>

@property (nonatomic) MONLoginService *loginService;

@end

@implementation MONLoginModel

- (id)init {
	MONLoginService *loginService = [[MONLoginService alloc] init];
	return [self initWithLoginService:loginService];
}

- (instancetype)initWithLoginService:(MONLoginService *)loginService {
	self = [super init];
	if (self) {
		[self escRegisterObserverProtocol:@protocol(MONLoginModelObserver)];
		self.loginService = loginService;
	}
	return self;
}

- (void)submitLogin {
	
	__block __weak MONLoginModel *weakSelf = self;
	[self.loginService loginWithUsername:self.username
								password:self.password
							successBlock:^{
								[weakSelf.escNotifier loginSucceeded];
							}
							failureBlock:^(NSError *error) {
								[weakSelf.escNotifier loginFailedWithError:(NSError *)error];
							}];
}

- (BOOL)userIsAuthenticated {
	return [self.loginService userIsAuthenticated];
}

- (void)setUsername:(NSString *)username {
	_username = username;
}

- (void)setPassword:(NSString *)password {
	_password = password;
}

- (void)logout {
	[self.loginService logout];
}

@end
