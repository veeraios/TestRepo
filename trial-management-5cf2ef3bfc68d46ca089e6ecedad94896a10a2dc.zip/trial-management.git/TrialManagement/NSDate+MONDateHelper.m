#import "NSDate+MONDateHelper.h"

@implementation NSDate (MONDateHelper)

+(NSDate*)dateFromMonth:(NSInteger)month day:(NSInteger)day year:(NSInteger)year {
	NSCalendar *calendar = [NSCalendar currentCalendar];
	NSDateComponents *components = [[NSDateComponents alloc] init];
	[components setDay:day];
	[components setMonth:month];
	[components setYear:year];
	return [calendar dateFromComponents:components];
}

-(NSDate*)startOfDate {
	NSDate *startOfDate = nil;
	[[NSCalendar currentCalendar] rangeOfUnit:NSCalendarUnitDay startDate:&startOfDate interval:NULL forDate:self];
	return startOfDate;
}

-(NSDate*)dateWithAddedDays:(NSInteger)days {
	NSDate *startOfDate = [self startOfDate];
	
	NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
	NSDateComponents *addComponents = [[NSDateComponents alloc] init];
	addComponents.day =days;
	
	return [calendar dateByAddingComponents:addComponents toDate:startOfDate options:0];
	
}

+(NSDate*)currentDateWithAddedDays:(NSInteger)days {
	
	NSDate *startOfToday = [[NSDate date] startOfDate];
	
	NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
	NSDateComponents *addComponents = [[NSDateComponents alloc] init];
	addComponents.day =days;
	
	return [calendar dateByAddingComponents:addComponents toDate:startOfToday options:0];
	
}

+(NSDate*)currentDateWithYearsFrom:(NSInteger)year {
	NSDate *today = [[NSDate alloc] init];
	NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
	NSDateComponents *addComponents = [[NSDateComponents alloc] init];
	addComponents.year =year;
	
	return [calendar dateByAddingComponents:addComponents toDate:today options:0];
	
}

+(NSArray*)splitDatesByInterval:(NSDate*)startDate endDate:(NSDate*)endDate interval:(NSInteger)interval {
	NSMutableArray *array = [[NSMutableArray alloc] init];
	NSTimeInterval diff = ceil( [endDate timeIntervalSinceDate:startDate]) / interval;
	
	NSTimeInterval nextDate = [startDate timeIntervalSince1970];
	while ((nextDate += diff) && nextDate < [endDate timeIntervalSince1970]) {
		[array addObject:[NSDate dateWithTimeIntervalSince1970:nextDate]];
	}
	return array;
}

+(NSDate*)midPointBetweenStartDate:(NSDate*)startDate endDate:(NSDate*)endDate {
	return [NSDate dateWithTimeInterval:[endDate timeIntervalSinceDate:startDate] / 2 sinceDate:startDate];
}

@end
