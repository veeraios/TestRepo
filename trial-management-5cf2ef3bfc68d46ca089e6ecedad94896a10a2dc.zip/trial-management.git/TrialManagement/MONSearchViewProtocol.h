#import "MONSingleSearchView.h"

@protocol MONSearchViewProtocol <NSObject>
- (void)setNumberOfSearchResults:(NSUInteger)numberOfSearchResults;
@property (nonatomic,weak) id<MONSingleSearchDelegate> delegate;
@property (nonatomic) UITableView *searchResultsTableView;

@optional
-(void)doneSearching;
@end
