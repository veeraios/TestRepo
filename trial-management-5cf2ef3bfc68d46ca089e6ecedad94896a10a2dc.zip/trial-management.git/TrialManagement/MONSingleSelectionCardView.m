#import "MONSingleSelectionCardView.h"
#import "MONButton.h"
#import "MONFonts.h"
#import "MONDimensions.h"
#import "MONLabel.h"
#import "MONUIConvenienceFunctions.h"

static NSString * const ButtonText = @"SELECT";
static const CGFloat SelectedTextSize = 12.0;
static const CGFloat TitleVerticalOffset = 8.0;
static const CGFloat SelectedTextLabelVerticalOffset = 4.0;
static const CGFloat TitleLabel2VerticalOffset = 10.0;
static const CGFloat SelectButtonOriginYOffset = 10.0;

@interface MONSingleSelectionCardView ()

@property (nonatomic) MONLabel *titleLabel;
@property (nonatomic) MONLabel *titleLabel2;
@property (nonatomic) MONLabel *selectionLabel;
@property (nonatomic) MONButton *selectOptionsbutton;
@property (nonatomic) UITapGestureRecognizer *tapGestureRecognizer;
@end

@implementation MONSingleSelectionCardView

- (id)init {
	if (self = [super init]) {		
		self.titleLabel = [self titleLabelHelper];
		
		self.titleLabel2 = [self titleLabelHelper];
		[self addSubview:self.titleLabel2];
		
		[self.contentContainerView addSubview:self.titleLabel];
		
		self.selectionLabel = [[MONLabel alloc] init];
		self.selectionLabel.textSize = SelectedTextSize;
		self.selectionLabel.textAlignment = NSTextAlignmentCenter;
		[self.contentContainerView addSubview:self.selectionLabel];

		self.selectOptionsbutton = [[MONButton alloc] init];
		[self.selectOptionsbutton setTitle:ButtonText forState:UIControlStateNormal];
        [self.selectOptionsbutton addTarget:self action:@selector(selectOptionsButtonTapped) forControlEvents:UIControlEventTouchUpInside];
		[self.contentContainerView addSubview:self.selectOptionsbutton];
	}
	return self;
}

- (void)setIsReadOnly:(BOOL)isReadOnly {
	_isReadOnly = isReadOnly;
	if(isReadOnly) {
		self.selectOptionsbutton.hidden = YES;
		self.selectOptionsbutton.enabled = NO;
	} else {
		self.selectOptionsbutton.hidden = NO;
		self.selectOptionsbutton.enabled = YES;
	}
}

- (MONLabel *)titleLabelHelper {
	MONLabel *label = [[MONLabel alloc] init];
	label.textSize = MONFontsHeaderTextSize;
	label.numberOfLines = 1;
	label.textAlignment = NSTextAlignmentCenter;
	label.font = [UIFont fontWithName:OpenSans size:MONFontsHeaderTextSize];
	return label;
}

- (void)layoutSubviews {
	[super layoutSubviews];
	
	[self.titleLabel sizeToFit];
	CGSize titleLabelSize = self.titleLabel.frame.size;
	self.titleLabel.frame = CGRectMake(0.0,
									   MONDimensionsLargePadding - TitleVerticalOffset,
									   CGRectGetWidth(self.bounds),
									   titleLabelSize.height);
	
	[self.titleLabel2 sizeToFit];
	CGSize titleLabel2Size = self.titleLabel2.frame.size;
	self.titleLabel2.frame = CGRectMake(0.0,
									   CGRectGetMaxY(self.titleLabel.frame) - TitleLabel2VerticalOffset,
									   CGRectGetWidth(self.bounds),
									   titleLabel2Size.height);
	
	[self.selectOptionsbutton sizeToFit];
	CGSize buttonSize = self.selectOptionsbutton.frame.size;
	self.selectOptionsbutton.frame = CGRectMake((CGRectGetMaxX(self.contentContainerView.bounds) - buttonSize.width) / 2.0,
								   CGRectGetMaxY(self.contentContainerView.bounds) - buttonSize.height - SelectButtonOriginYOffset,
								   buttonSize.width,
								   buttonSize.height);

	[self.selectionLabel sizeToFit];
	CGSize selectionLabelSize = self.selectionLabel.frame.size;
	self.selectionLabel.frame = CGRectMake(MONUIScreenRoundToScreenScale((CGRectGetWidth(self.contentContainerView.bounds) - selectionLabelSize.width) / 2.0),
										   CGRectGetMinY(self.selectOptionsbutton.frame) - selectionLabelSize.height - MONDimensionsSmallPadding + SelectedTextLabelVerticalOffset,
										   selectionLabelSize.width,
										   selectionLabelSize.height);
	
}

- (void)setTitle:(NSString *)title {
	NSRange newlineRange = [title rangeOfString:@"\n"];
	if (newlineRange.location != NSNotFound) {
		NSString *firstLine = [title substringWithRange:NSMakeRange(0, newlineRange.location)];
		NSUInteger location = newlineRange.location + newlineRange.length;
		NSUInteger length = [title length] - location;
		NSString *secondLine = [title substringWithRange:NSMakeRange(location, length)];
		self.titleLabel.text = [firstLine uppercaseString];
		self.titleLabel2.text = [secondLine uppercaseString];
	} else {
		self.titleLabel.text = title;
		self.titleLabel2.text = nil;
	}
	[self setNeedsLayout];
}

-(NSString*)selectedText {
	return self.selectionLabel.text;
}

- (void)setSelectedText:(NSString *)selectedText {
	self.selectionLabel.text = [selectedText uppercaseString];
	[self setNeedsLayout];
}

- (void)selectOptionsButtonTapped {
    [self.delegate selectOptionsButtonTapped];
}
@end
