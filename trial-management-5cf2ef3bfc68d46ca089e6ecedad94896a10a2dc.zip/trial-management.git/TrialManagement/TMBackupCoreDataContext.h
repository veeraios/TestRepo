@import CoreData;
#import "MONCoreDataContext.h"
#import "TMBackupCoreDataContextProtocol.h"

@interface TMBackupCoreDataContext : MONCoreDataContext<TMBackupCoreDataContextProtocol>
@end
