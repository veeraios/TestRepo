#import "TMReferenceDataListGenericModel.h"
#import "TMCounty.h"
#import "TMReferenceDataFilterListModel.h"

@interface TMCountiesModel : TMReferenceDataListGenericModel<TMReferenceDataFilterListModel>

- (instancetype)initWithArray:(NSArray*)array;
- (TMCounty*)countyForCountyName:(NSString*)countyName;

@end
