#import "MONTextView.h"
#import "MONFonts.h"
#import "MONDimensions.h"
#import "MONCardContainerView.h"
#import "UIColor+MONThemeColorProvider.h"

//static const CGFloat DefaultHeight = 55.0;
static const CGFloat DefaultHeight = 45.0;
static const CGFloat TextViewOffsetX = 5.0;
//static const CGFloat DefaultWidth = 30.0;

@interface MONTextView () <UITextViewDelegate>

@property (nonatomic) MONCardContainerView *cardContainerView;
@property (nonatomic) UITextView *textView;

@end

@implementation MONTextView

- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.cardContainerView = [[MONCardContainerView alloc] init];
        [self addSubview:self.cardContainerView];
        self.textView = [[UITextView alloc] init];
        self.textView.delegate=self;
        
        self.textView.backgroundColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeBackground];
        self.textView.font = [UIFont fontWithName:OpenSans size:14.0];
        self.textView.textColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeText];
        self.textView.keyboardAppearance = UIKeyboardAppearanceDark;
        [self.cardContainerView.contentContainerView addSubview:self.textView];
    }
    return self;
}



-(void)setTextViewDelegate:(id<UITextViewDelegate>)textViewDelegate {
    self.textView.delegate = textViewDelegate;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    
    self.cardContainerView.frame = self.bounds;
    
    [self.textView sizeToFit];
    self.textView.frame = CGRectMake(TextViewOffsetX,
                                     0.0,
                                     CGRectGetWidth(self.cardContainerView.contentContainerView.bounds) - 2.0 * (MONDimensionsTinyPadding - TextViewOffsetX),
                                     CGRectGetHeight(self.cardContainerView.contentContainerView.bounds));
}



- (CGSize)sizeThatFits:(CGSize)size {
    CGSize sizeThatFits = CGSizeMake(size.width, DefaultHeight);
    //CGSize sizeThatFits = CGSizeMake(DefaultWidth, DefaultHeight);
    return sizeThatFits;
}

- (NSString *)text {
    return self.textView.text;
}

- (void)setText:(NSString *)text {
    self.textView.text = text;
}
-(void)textViewDidChange:(UITextView *)textView
{
    [self.monTextViewDelegate monTextViewTextDidChange:self];
    
    
}
-(void)textViewDidEndEditing:(UITextView *)textView
{
    [self.monTextViewDelegate monTextViewDidEndEditing:self];
}
- (void)setEditable:(BOOL)editable {
    [self.textView setEditable:editable];
        //[self.textField setEnabled:enabled];
        if(editable) {
            UIColor *color = [UIColor colorForThemeComponentType:MONThemeComponentTypeBackground];
            self.textView.backgroundColor = color;
            self.cardContainerView.backgroundColor = color;
        } else {
            [self setLockedColor];
        }
}
- (BOOL)enabled {
    return self.isUserInteractionEnabled;
}
//
//- (void)setEnabled:(BOOL)enabled {
//    [self.textField setEnabled:enabled];
//    if(enabled) {
//        UIColor *color = [UIColor colorForThemeComponentType:MONThemeComponentTypeBackground];
//        self.textField.backgroundColor = color;
//        self.cardContainerView.backgroundColor = color;
//    } else {
//        [self setLockedColor];
//    }
//}
- (void)setLockedColor {
    UIColor *lockedColor= [UIColor colorForThemeComponentType:MONThemeComponentTypeLockedBackground] ;
    
    self.textView.backgroundColor = lockedColor;
    self.textView.backgroundColor = lockedColor;
    self.cardContainerView.backgroundColor = lockedColor;
}

- (BOOL)becomeFirstResponder {
   // return YES;
    return [self.textView becomeFirstResponder];
}

- (BOOL)resignFirstResponder {
    // return YES;
    return [self.textView resignFirstResponder];
}

@end
