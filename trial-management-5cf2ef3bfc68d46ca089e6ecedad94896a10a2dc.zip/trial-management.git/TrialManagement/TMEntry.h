//
//  TMEntry.h
//  TrialManagement
//
//  Created by Jason Ludwig on 6/26/14.
//  Copyright (c) 2014 Monsanto. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class TMObservation, TMPendingRequestedProduct, TMProduct, TMTreatment, TMTrial;

@interface TMEntry : NSManagedObject

@property (nonatomic, retain) NSNumber * entryId;
@property (nonatomic, retain) NSNumber * number;
@property (nonatomic, retain) TMPendingRequestedProduct *pendingRequestedProduct;
@property (nonatomic, retain) TMProduct *product;
@property (nonatomic, retain) TMTreatment *treatment;
@property (nonatomic, retain) TMTrial *trial;
@property (nonatomic, retain) NSSet *observations;
@end

@interface TMEntry (CoreDataGeneratedAccessors)

- (void)addObservationsObject:(TMObservation *)value;
- (void)removeObservationsObject:(TMObservation *)value;
- (void)addObservations:(NSSet *)values;
- (void)removeObservations:(NSSet *)values;

@end
