#import <Foundation/Foundation.h>
#import <CoreGraphics/CoreGraphics.h>

@interface NSValue (ASYConvenienceMethods)

+ (id)valueWithBool:(BOOL)value;
+ (id)valueWithInt:(int)value;
+ (id)valueWithNSUInteger:(NSUInteger)value;
+ (id)valueWithNSInteger:(NSInteger)value;
+ (id)valueWithDouble:(double)value;
+ (id)valueWithCGFloat:(CGFloat)value;
+ (id)valueWithCGPoint:(CGPoint)value;
+ (id)valueWithCGRect:(CGRect)value;
+ (id)valueWithCGSize:(CGSize)value;

@end
