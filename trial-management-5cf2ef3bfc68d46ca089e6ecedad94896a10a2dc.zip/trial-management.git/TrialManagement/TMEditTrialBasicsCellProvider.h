#import "TMTrialModel.h"

@protocol TMEditTrialBasicsCellProviderDelegate <NSObject>
-(void)reloadFinished;
@end

@interface TMEditTrialBasicsCellProvider : NSObject<UICollectionViewDataSource>
-(instancetype)initWithTrialModel:(TMTrialModel*)trialModel;
-(void)filterTechAgronomistDataByDSM:(NSString*)dsm;
-(void)filterTechAgronomistDataByTA:(NSString*)ta;
-(void)filterAccordingToProtocolByBrand;
-(void)filterAccordingToProtocolByCrop;
@property (nonatomic,weak) id<TMEditTrialBasicsCellProviderDelegate> delegate;
@end

@interface TMEditTrialBasicsCellModel : NSObject
@property (nonatomic) BOOL isCellReadOnly;
@property (nonatomic) NSString* selectedText;
@property (nonatomic) NSString* cellTitle;
@property (nonatomic) id<TMDataModel> cellModel;
-(instancetype)initWithTitle:(NSString*)cellTitle model:(id<TMDataModel>)model selectedText:(NSString*)selectedText;
@end

