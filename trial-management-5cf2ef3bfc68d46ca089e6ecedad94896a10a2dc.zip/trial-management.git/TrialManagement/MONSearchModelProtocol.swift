import UIKit

@objc protocol MONSearchModelProtocol: class {
    func setAllSearchItems(items: [AnyObject]?)
    func filterItemsWithText(filterText: String)
    func filteredItemAtIndex(index: Int) -> AnyObject?
    func filteredItems() -> [AnyObject]?
    func itemsWereFiltered() -> Bool
    func cancelSearch()
}
