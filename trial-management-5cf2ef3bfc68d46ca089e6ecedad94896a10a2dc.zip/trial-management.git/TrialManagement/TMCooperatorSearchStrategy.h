#import "MONReferenceSearchableModel.h"
#import "MONHeaderViewProtocol.h"
#import "MONSearchViewProtocol.h"
#import "MONSearchStrategy.h"

@interface TMCooperatorSearchStrategy : NSObject <MONSearchStrategy>

@property(readonly, nonatomic) CooperatorCategory cooperatorCategory;

- (instancetype)initWithCooperatorCategory:(CooperatorCategory)cooperatorCategory;

@end