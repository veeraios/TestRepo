//
//  TMCooperatorSearchViewController.swift
//  TrialManagement
//
//  Created by GADIRAJU, PRANEETH [AG/1000] on 5/21/15.
//  Copyright (c) 2015 Monsanto. All rights reserved.
//
@objc protocol TMCooperatorSearchViewControllerDelegate {
    func addNewCooperator(cooperator: TMCooperatorModel)
}

class TMCooperatorSearchViewController: MONSingleSearchViewController, TMAddNewCooperatorDelegate, MONSingleSearchDelegate {
    var isExceptionPlotType = false
    var cooperatorValidationRequired = false
    var cooperatorCategory = CooperatorCategory.Grower

    var delegate: TMCooperatorSearchViewControllerDelegate?
    
    init(searchStrategy: TMCooperatorSearchStrategy, criteria:[String:String], isExceptionPlotType:Bool, cooperatorValidationRequired:Bool) {
        super.init(searchStrategy: searchStrategy, criteria: criteria)
        cooperatorCategory = searchStrategy.cooperatorCategory
        self.isExceptionPlotType = isExceptionPlotType
        self.cooperatorValidationRequired = cooperatorValidationRequired
    }

    required init(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: NSBundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
    }

    override func viewDidAppear(animated: Bool) {
        super.viewDidAppear(animated)

        let cooperatorType = (cooperatorCategory == .Grower ? "Grower" : "Dealer")
        MONGoogleAnalytics.trackView("Trial - Grower Information - " + cooperatorType + " Search")
    }

    //MARK: - TMAddNewCooperatorDelegate methods
    func addNewCooperator(cooperator: TMCooperatorModel) {
        delegate?.addNewCooperator(cooperator)
    }
    
    //MARK: - MONSingleSearchDelegate methods
    func requestNewButtonTapped(category: CooperatorCategory) {
        let cooperatorModel: TMCooperatorModel = cooperatorCategory == .Grower ? TMGrowerModel() : TMDealerModel()
        let cooperatorUpdateViewController = TMCooperatorUpdateViewController(cooperator: cooperatorModel, isExceptionPlotType: isExceptionPlotType, cooperatorValidationRequired: cooperatorValidationRequired, operation: CooperatorOperation.Add)
        cooperatorUpdateViewController.cooperatorAddNewCooperatorDelegate = self
        let navigationController = UINavigationController(rootViewController: cooperatorUpdateViewController)
        navigationController.modalPresentationStyle = UIModalPresentationStyle.PageSheet
        self.presentViewController(navigationController, animated: true, completion: {})
    }

}
