#import "MONTabSettingsObject.h"

@implementation MONTabSettingsObject

- (void)setGlobalTitle:(NSString *)globalTitle {
	[self.delegate globalTitleChanged:globalTitle];
}

- (void)setTabTitle:(NSString *)tabTitle index:(NSUInteger)index {
	[self.delegate tabTitleChanged:tabTitle index:index];
}

- (void)setTabTitle:(NSString *)tabTitle viewController:(UIViewController *)viewController {
	[self.delegate tabTitleChanged:tabTitle viewController:viewController];
}

- (void)gotoNextTab {
	[self.delegate gotoNextTab];
}

@end
