#import "TMCoordinatesButton.h"
#import "MONFonts.h"
#import "MONDimensions.h"
#import "MONUIConvenienceFunctions.h"
#import "MONColors.h"

@implementation TMCoordinatesButton

- (instancetype)init {
	if (self = [super init]) {
		self.backgroundColor = [MONColors midnightBlueColor];
		self.titleLabel.textAlignment = NSTextAlignmentCenter;
		self.titleLabel.font = [UIFont fontWithName:OpenSans size:14.0];
		self.titleLabel.numberOfLines = 2;
		self.imageView.contentMode = UIViewContentModeCenter;
	}
	return self;
}

- (void)setHighlighted:(BOOL)highlighted {
	[super setHighlighted:highlighted];
	self.backgroundColor = highlighted ? [MONColors belizeHoleColor] : [MONColors midnightBlueColor];
}

- (void)layoutSubviews {
	[super layoutSubviews];
	
	[self.titleLabel sizeToFit];
	[self.imageView sizeToFit];
	
	CGFloat contentHeight = MAX(CGRectGetHeight(self.titleLabel.frame), CGRectGetHeight(self.imageView.frame));
	
	self.titleLabel.frame = CGRectMake(MONDimensionsTinyPadding,
									   MONUIScreenRoundToScreenScale((CGRectGetMaxY(self.bounds) - contentHeight) / 2.0),
									   CGRectGetWidth(self.titleLabel.frame),
									   contentHeight);
	
	self.imageView.frame = CGRectMake(CGRectGetMaxX(self.bounds) - CGRectGetWidth(self.imageView.frame) - MONDimensionsTinyPadding,
									  MONUIScreenRoundToScreenScale((CGRectGetMaxY(self.bounds) - contentHeight) / 2.0),
									  CGRectGetWidth(self.imageView.frame),
									  contentHeight);
}

@end
