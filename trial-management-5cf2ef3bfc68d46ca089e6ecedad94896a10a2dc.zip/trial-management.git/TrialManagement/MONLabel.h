#import <UIKit/UIKit.h>

@interface MONLabel : UILabel

@property (nonatomic) CGFloat textSize;
@property (nonatomic) NSString *fontName;
@property (nonatomic) UIFont *font;

+ (MONLabel *)defaultLabelWithText:(NSString *)text;

@end
