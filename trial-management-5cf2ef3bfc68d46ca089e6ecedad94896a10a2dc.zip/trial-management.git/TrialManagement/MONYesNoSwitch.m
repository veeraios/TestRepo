#import "MONYesNoSwitch.h"

@implementation MONYesNoSwitch

- (instancetype)init {
    self = [super initWithItems:@[@"YES",@"NO"]];
	if (self) {
		[self setWidth:100 forSegmentAtIndex:0];
		[self setWidth:100 forSegmentAtIndex:1];
	}
	return self;
}

- (BOOL)switchValue {
	return self.selectedSegmentIndex == 0;
}

- (void)setSwitchValue:(BOOL)value {
	[self setSelectedSegmentIndex:!value];
}

@end
