class TMCooperatorsFilter: NSObject, MONFilter {
  func filteredArrayFromArray(itemsArray: [AnyObject]!, filterText: String!) -> [AnyObject]! {
    let filter = "self.cooperator CONTAINS[cd] %@ || self.state CONTAINS[cd] %@ || self.city CONTAINS[cd] %@ || self.postalCode CONTAINS[cd] %@"
    if let predicate = NSPredicate(format: filter, filterText, filterText, filterText, filterText) {
      return itemsArray.filter( {predicate.evaluateWithObject($0)} )
    }
    return []
  }
}