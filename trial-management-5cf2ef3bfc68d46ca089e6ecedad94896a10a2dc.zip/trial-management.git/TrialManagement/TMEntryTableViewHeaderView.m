#import "TMEntryTableViewHeaderView.h"
#import "MONUIConvenienceFunctions.h"
#import "MONDimensions.h"
#import "MONLabel.h"
#import "UIColor+MONThemeColorProvider.h"

static const CGFloat ProductLabelOriginY = 228.0;
static const CGFloat RMLabelOriginY = 470.0;
static const CGFloat TraitLabelOriginY = 578.0;

@interface TMEntryTableViewHeaderView ()

@property (nonatomic) MONLabel *brandLabel;
@property (nonatomic) MONLabel *productLabel;
@property (nonatomic) MONLabel *rmLabel;
@property (nonatomic) MONLabel *traitLabel;
@property (nonatomic) UIView *bottomBorderView;

@end

@implementation TMEntryTableViewHeaderView

- (instancetype)init {
	self = [super init];
	if (self) {
		self.backgroundColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeBackground];
		
		self.brandLabel = [self defaultLabelWithText:@"Brand"];
		[self addSubview:self.brandLabel];
		
		self.productLabel = [self defaultLabelWithText:@"Product"];
		[self addSubview:self.productLabel];
		
		self.rmLabel = [self defaultLabelWithText:@"RM"];
		[self addSubview:self.rmLabel];
		
		self.traitLabel = [self defaultLabelWithText:@"Trait"];
		[self addSubview:self.traitLabel];
		
		self.bottomBorderView = [[UIView alloc] init];
		self.bottomBorderView.backgroundColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeBorder];
		[self addSubview:self.bottomBorderView];
	}
	return self;
}

- (MONLabel *)defaultLabelWithText:(NSString *)text {
	MONLabel *label = [[MONLabel alloc] init];
	label.text = text;
	return label;
}

- (void)layoutSubviews {
	[super layoutSubviews];
	
	CGRect contentRect = CGRectInset(self.bounds, MONDimensionsSmallPadding, MONDimensionsSmallPadding);
	
	[self.brandLabel sizeToFit];
	self.brandLabel.frame = CGRectMake(CGRectGetMinX(contentRect),
									   MONUIScreenRoundToScreenScale((CGRectGetMaxY(self.bounds) - CGRectGetHeight(self.brandLabel.frame)) / 2.0),
									   CGRectGetWidth(self.brandLabel.frame),
									   CGRectGetHeight(self.brandLabel.frame));
	
	[self.productLabel sizeToFit];
	self.productLabel.frame = CGRectMake(CGRectGetMinX(contentRect) + ProductLabelOriginY,
										 CGRectGetMinY(self.brandLabel.frame),
										 CGRectGetWidth(self.productLabel.frame),
										 CGRectGetHeight(self.productLabel.frame));
	
	[self.rmLabel sizeToFit];
	self.rmLabel.frame = CGRectMake(CGRectGetMinX(contentRect) + RMLabelOriginY,
									CGRectGetMinY(self.brandLabel.frame),
									CGRectGetWidth(self.rmLabel.frame),
									CGRectGetHeight(self.rmLabel.frame));
	
	[self.traitLabel sizeToFit];
	self.traitLabel.frame = CGRectMake(CGRectGetMinX(contentRect) + TraitLabelOriginY,
									   CGRectGetMinY(self.brandLabel.frame),
									   CGRectGetWidth(self.traitLabel.frame),
									   CGRectGetHeight(self.traitLabel.frame));
	
	self.bottomBorderView.frame = CGRectMake(0.0, CGRectGetMaxY(self.bounds), CGRectGetWidth(self.bounds), MONDimensionsThinBorderWidth);
}

@end
