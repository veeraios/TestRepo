//
//  TMCounty.h
//  TrialManagement
//
//  Created by Jason Ludwig on 8/13/14.
//  Copyright (c) 2014 Monsanto. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class TMState, TMTrial;

@interface TMCounty : NSManagedObject

@property (nonatomic, retain) NSNumber * countyId;
@property (nonatomic, retain) NSString * name;
@property (nonatomic, retain) NSString * fipscode;
@property (nonatomic, retain) TMState *state;
@property (nonatomic, retain) NSSet *trialEmailCounties;
@property (nonatomic, retain) NSSet *trialPostCards;
@property (nonatomic, retain) NSSet *trials;
@end

@interface TMCounty (CoreDataGeneratedAccessors)

- (void)addTrialEmailCountiesObject:(TMTrial *)value;
- (void)removeTrialEmailCountiesObject:(TMTrial *)value;
- (void)addTrialEmailCounties:(NSSet *)values;
- (void)removeTrialEmailCounties:(NSSet *)values;

- (void)addTrialPostCardsObject:(TMTrial *)value;
- (void)removeTrialPostCardsObject:(TMTrial *)value;
- (void)addTrialPostCards:(NSSet *)values;
- (void)removeTrialPostCards:(NSSet *)values;

- (void)addTrialsObject:(TMTrial *)value;
- (void)removeTrialsObject:(TMTrial *)value;
- (void)addTrials:(NSSet *)values;
- (void)removeTrials:(NSSet *)values;

@end
