#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger, TMMarketingSubmissionType) {
    PostCard,
    Email
};
