#import "TMTrialModel.h"

@interface TMHarvestActionService : NSObject
- (void)postSubmitToMarketing:(TMTrialModel*)trialModel completionBlock:(void (^)(NSDictionary *, NSError *))completionBlock;
- (void)postRelinquished:(TMTrialModel*)trialModel submitToMarketing:(BOOL)submitToMarketing completionBlock:(void (^)(NSDictionary *, NSError *))completionBlock;
- (void)postCancelTrial:(NSNumber*)trialId completionBlock:(void (^)(NSDictionary *, NSError *))completionBlock;
@end
