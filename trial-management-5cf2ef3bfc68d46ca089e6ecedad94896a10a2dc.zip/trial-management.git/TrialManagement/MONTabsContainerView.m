#import "MONTabsContainerView.h"
#import "MONTabButton.h"
#import "MONTabMenuButton.h"
#import "MONDimensions.h"
#import "MONTabModel.h"

@interface MONTabsContainerView ()

@property (nonatomic) NSArray *buttons;

@end

@implementation MONTabsContainerView

- (instancetype)initWithTabModels:(NSArray *)tabModels {
	self = [super init];
	if (self) {
		NSMutableArray *tabButtons = [NSMutableArray array];
		for (MONTabModel *tabModel in tabModels) {
			MONTabButton *tabButton = nil;
			if (tabModel.tabType == TabTypeMenu) {
				tabButton = [self tabMenuButton];
			} else {
				tabButton = [self tabButton];
			}
			[tabButton setTitle:tabModel.tabTitle forState:UIControlStateNormal];
			[tabButton addTarget:self action:@selector(tabTapped:) forControlEvents:UIControlEventTouchUpInside];
			[self addSubview:tabButton];
			[tabButtons addObject:tabButton];
		}
		self.buttons = tabButtons;
	}
	return self;
}

- (MONTabButton *)tabMenuButton {
	MONTabMenuButton *tabMenuButton = [[MONTabMenuButton alloc] init];
	return tabMenuButton;
}

- (MONTabButton *)tabButton {
	MONTabButton *tabButton = [[MONTabButton alloc] init];
	return tabButton;
}

- (void)tabTapped:(MONTabButton *)tabButton {
	[self setSelectedButton:tabButton];
	NSUInteger indexOfButton = [self.buttons indexOfObject:tabButton];
	[self.delegate tabTappedAtIndex:indexOfButton];
}

- (void)layoutSubviews {
	[super layoutSubviews];

	CGFloat buttonOriginX = 0.0;
	for (MONTabButton *button in self.buttons) {
		[button sizeToFit];
		button.frame = CGRectMake(buttonOriginX,
								  0.0,
								  CGRectGetWidth(button.frame),
								  CGRectGetHeight(button.frame));
		buttonOriginX += CGRectGetWidth(button.frame) + MONDimensionsSmallPadding;
	}
}

- (CGSize)sizeThatFits:(CGSize)size {
	CGSize sizeThatFits;
	MONTabButton *button = [[MONTabButton alloc] init];
	[button sizeToFit];
	CGFloat buttonWidth = CGRectGetWidth(button.frame);
	
	CGFloat totalButtonWidth = 0.0;
	NSUInteger tabCount = [self.buttons count];
	if (tabCount > 0) {
		totalButtonWidth = buttonWidth * tabCount + MONDimensionsSmallPadding * (tabCount - 1);
	}
	
	sizeThatFits.width = MAX(totalButtonWidth, size.width);
	sizeThatFits.height = CGRectGetHeight(button.frame);
	
	return sizeThatFits;
}

- (void)setSelectedButton:(UIButton *)selectedButton {
	for (UIButton *button in self.buttons) {
		if (![button isEqual:selectedButton]) {
			[button setSelected:NO];
		} else {
			[button setSelected:YES];
		}
	}
}

- (void)setSelectedTabAtIndex:(NSUInteger)index {
	NSUInteger buttonIndex = 0;
	for (UIButton *button in self.buttons) {
		button.selected = (index == buttonIndex) ? YES : NO;
		buttonIndex++;
	}
}

@end
