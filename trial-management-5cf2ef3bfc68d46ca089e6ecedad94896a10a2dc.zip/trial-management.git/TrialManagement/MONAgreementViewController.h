#import <UIKit/UIKit.h>

@protocol MONSignatureDelegate <NSObject>

-(void)signatureImageCreated:(UIImage*)signatureImage;

@end
@interface MONAgreementViewController : UIViewController
@property (nonatomic, weak) id<MONSignatureDelegate> signatureDelegate;
-(void)signatureTapped;
@end
