#import <Foundation/Foundation.h>

@interface MONSafeString : NSObject

+ (NSString *)safeStringForString:(NSString *)string;

@end
