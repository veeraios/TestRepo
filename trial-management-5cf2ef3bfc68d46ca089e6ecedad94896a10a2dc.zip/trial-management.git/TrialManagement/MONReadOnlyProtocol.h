#import <Foundation/Foundation.h>

@protocol MONReadOnlyProtocol <NSObject>

- (void)setAsReadOnly;

@end
