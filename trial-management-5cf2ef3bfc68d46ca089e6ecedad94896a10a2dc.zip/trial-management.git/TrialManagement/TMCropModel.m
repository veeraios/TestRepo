#import "TMCropModel.h"
#import "TMCrop.h"

@interface TMCropModel ()

@property (nonatomic) NSArray *dataArray;
@end


@implementation TMCropModel
-(instancetype)initWithDataSource:(NSArray*)dataSource {
	self = [super init];
	if (self) {
		self.dataArray = dataSource;
	}
	return self;
}

- (NSString *)nameForItemAtIndex:(NSInteger)index {
	TMCrop *dataObject = (TMCrop*)[self.dataArray objectAtIndex:index];
	return dataObject.name;
}
@end
