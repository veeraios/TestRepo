#import "MONButton.h"

@interface MONBorderedButton : MONButton

- (void)setBorderWidth:(CGFloat)borderWidth;

@end
