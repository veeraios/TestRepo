//
//  MONMergeEngine.swift
//  TrialManagement
//
//  Created by WAIDMANN, ALAN [AG/1000] on 1/15/15.
//  Copyright (c) 2015 Monsanto. All rights reserved.
//

import UIKit

typealias NestedDict = [String:AnyObject]

class MONMergeEngine{
    enum CopyOnSide {
        case Left
        case Right
        case Neither
    }

    private var allChanges: [MONChange]
    let changeLogLeft: NestedDict
    let changeLogRight: NestedDict
    
    init(changeLogLeft logLeft: NestedDict, changeLogRight logRight: NestedDict) {
        changeLogLeft = logLeft
        changeLogRight = logRight
        allChanges = [MONChange]()
    }
    
    func identifiedChanges() -> [MONChange] {
        traverseNestedDicts(self.changeLogLeft, logRight:self.changeLogRight, path:"", traversingWithCopyOnSide:.Neither)
        MONLogger.logInfo("***** Change log from MONMergeEngine ******")
        allChanges.forEach( {MONLogger.logInfo($0.description)} )
        MONLogger.logInfo("*******************************************")
        return allChanges
    }
    
    private func traverseNestedDicts<T>(logLeft:[String:T], logRight:[String:T], path:String, traversingWithCopyOnSide:CopyOnSide) {
        
        let logLeftKeys = logLeft.keys.array
        let logRightKeys = logRight.keys.array
        
        let totalKeySet = logRightKeys + logLeftKeys.filter({logRight.indexForKey($0) == nil})
        
        for key in totalKeySet {
            let appendedPath = path + (countElements(path)==0 ? "" : ".") + key
            switch (logLeft[key],logRight[key]) {
                
            case (let logLeftValue as NestedDict, let logRightValue as NestedDict):
                traverseNestedDicts(logLeftValue, logRight:logRightValue, path:appendedPath, traversingWithCopyOnSide:traversingWithCopyOnSide)

            case (let logLeftValue as NestedDict,nil):
                traverseNestedDicts(logLeftValue, logRight:logLeftValue, path:appendedPath, traversingWithCopyOnSide:.Right)
                
            case (nil,let logRightValue as NestedDict):
                traverseNestedDicts(logRightValue, logRight:logRightValue, path:appendedPath, traversingWithCopyOnSide:.Left)
                
            case let (logLeftValue,logRightValue) where logLeftValue != nil && logRightValue != nil:
                let isConflicting = (logLeftValue! as NSObject) != (logRightValue! as NSObject)
                allChanges.append(MONChange(path:appendedPath,
                    leftValue:(traversingWithCopyOnSide == .Left ? nil:logLeftValue),
                    rightValue:(traversingWithCopyOnSide == .Right ? nil:logRightValue),
                    resolvedValue:(isConflicting ? nil:logLeftValue)))
                
            case let (logLeftValue,nil):
                allChanges.append(MONChange(path:appendedPath, leftValue:logLeftValue, rightValue:nil, resolvedValue:logLeftValue))
                
            case let (nil, logRightValue):
                allChanges.append(MONChange(path:appendedPath, leftValue:nil, rightValue:logRightValue, resolvedValue:logRightValue))
                
            default:
                MONLogger.logError("Error: Could not continue to parse nested logs.")
            }
        }
    }

}
