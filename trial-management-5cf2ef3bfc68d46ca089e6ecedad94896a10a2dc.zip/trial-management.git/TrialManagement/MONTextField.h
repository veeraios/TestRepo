#import <UIKit/UIKit.h>

@class MONTextField;
@protocol MONTextFieldDelegate <NSObject>

- (void)monTextFieldTextDidChange:(MONTextField *)textField;
- (void)monTextFieldDidEndEditing:(MONTextField *)textField;

@end

@interface MONTextField : UIView
@property (nonatomic) NSString *text;
@property (nonatomic, weak) id<UITextFieldDelegate> delegate;
@property (nonatomic, weak) id<MONTextFieldDelegate> monTextFieldDelegate;

- (BOOL)enabled;
- (void)setEnabled:(BOOL)enabled;
- (void)setText:(NSString *)text;
- (void)setPlaceholderText:(NSString *)placeholderText;
- (void)setTextColor:(UIColor *)textColor;
- (void)setPlaceholderTextColor:(UIColor *)placeHolderTextColor;
- (void)setKeyboardType:(UIKeyboardType)keyboardType;
- (void)setAutocorrectionType:(UITextAutocorrectionType)autocorrectionType;
- (void)setLockedColor;
@end
