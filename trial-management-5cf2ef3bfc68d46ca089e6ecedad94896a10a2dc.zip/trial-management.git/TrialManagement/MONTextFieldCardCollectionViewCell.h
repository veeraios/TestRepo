#import <UIKit/UIKit.h>
#import "MONSelectionCardCollectionViewCell.h"
#import "MONLabel.h"

@interface MONTextFieldCardCollectionViewCell : UICollectionViewCell<MONSelectionCardCollectionViewCell, UITextFieldDelegate>

@property (nonatomic) MONLabel *titleLabel;
@property (nonatomic) UITextField *textField;

- (void)setPlaceholderText:(NSString *)placeholderText;
-(BOOL)textFieldIsEmpty;
@property (nonatomic) NSString *selectedText;

@end
