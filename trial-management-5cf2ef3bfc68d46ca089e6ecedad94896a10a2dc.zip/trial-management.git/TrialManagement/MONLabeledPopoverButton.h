#import "MONLabeledTextField.h"
#import "TMReferenceListDataModel.h"
#import "MONPopoverTextField.h"
#import "MONLabeledControl.h"
#import "MONReadOnlyProtocol.h"
#import <UIKit/UIKit.h>

extern NSString * const MONLabeledPopoverButtonDidShowPopover;

@interface MONLabeledPopoverButton : MONLabeledControl<MONReadOnlyProtocol>

@property (nonatomic) id<TMReferenceListDataModel> model;
@property (nonatomic, weak) id<MONPopoverTextFieldDelegate> popoverDelegate;

- (instancetype)initWithModel:(id<TMReferenceListDataModel>)model placeHolderText:(NSString *)placeHolderText;
- (void)setButtonText:(NSString *)buttonText;
- (void)setTextColor:(UIColor *)textColor;
- (void)setTextFieldText:(NSString *)textFieldText;
- (void)presentPopover:(UIPopoverController*)popoverController;
@end
