#import "NSValue+ASYHelperMethods.h"

@implementation NSValue (ASYConvenienceMethods)

+ (id)valueWithBool:(BOOL)value {
	return [self valueWithBytes:&value objCType:@encode(BOOL)];
}

+ (id)valueWithInt:(int)value {
	return [self valueWithBytes: &value objCType:@encode(int)];
}

+ (id)valueWithNSUInteger:(NSUInteger)value {
	return [self valueWithBytes: &value objCType:@encode(NSUInteger)];
}

+ (id)valueWithNSInteger:(NSInteger)value {
	return [self valueWithBytes:&value objCType:@encode(NSInteger)];
}

+ (id)valueWithDouble:(double)value {
	return [self valueWithBytes:&value objCType:@encode(double)];
}

+ (id)valueWithCGFloat:(CGFloat)value {
	return [self valueWithBytes:&value objCType:@encode(CGFloat)];
}

+ (id)valueWithCGPoint:(CGPoint)value {
	return [self valueWithBytes:&value objCType:@encode(CGPoint)];
}

+ (id)valueWithCGRect:(CGRect)value {
	return [self valueWithBytes:&value objCType:@encode(CGRect)];
}

+ (id)valueWithCGSize:(CGSize)value {
	return [self valueWithBytes:&value objCType:@encode(CGSize)];
}

@end
