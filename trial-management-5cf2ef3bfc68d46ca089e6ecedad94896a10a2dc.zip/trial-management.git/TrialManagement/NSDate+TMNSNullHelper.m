#import "NSDate+TMNSNullHelper.h"

@implementation NSDate (TMNSNullHelper)

-(id)safeDate {
	if(self == nil) {
		return [NSNull null];
	}
	return self;
}

@end
