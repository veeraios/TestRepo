#import "MONTabViewController.h"
#import "MONTabView.h"

@interface MONTabViewController ()<MONTabViewDelegate, MONTabSettingsObjectDelegate>

@property (nonatomic) MONTabView *tabsView;
@property (nonatomic) NSArray *viewControllers;
@property (nonatomic) NSMutableArray *tabNames;
@property (nonatomic) NSUInteger selectedIndex;
@property (nonatomic) MONTabSettingsObject *tabSettingsObject;
@property (nonatomic) NSArray *tabModels;

@end

@implementation MONTabViewController

- (instancetype)initWithTabModels:(NSArray *)tabModels {
	self = [super init];
	if (self) {
		self.tabModels = tabModels;
		
		self.tabSettingsObject = [[MONTabSettingsObject alloc] init];
		self.tabSettingsObject.delegate = self;	
		
		NSMutableArray *viewControllers = [NSMutableArray array];
		for (MONTabModel *tabModel in self.tabModels) {
			UIViewController<MONTabController> *viewController = tabModel.tabViewController;
			viewController.tabSettingsObject = self.tabSettingsObject;
			[viewControllers addObject:viewController];
		}
		self.viewControllers = viewControllers;
	}
	return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
	
	self.edgesForExtendedLayout = UIRectEdgeNone;

	self.tabsView = [[MONTabView alloc] init];
	self.tabsView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
	self.tabsView.delegate = self;
	[self.view addSubview:self.tabsView];
}

- (void)viewWillAppear:(BOOL)animated {
	[super viewWillAppear:animated];

	[self.tabsView setTabModels:self.tabModels];
	[self.tabsView setSelectedViewController:[self.viewControllers objectAtIndex:self.selectedIndex]];
	[self.tabsView setSelectedTabAtIndex:self.selectedIndex];
	
	self.tabsView.frame = self.view.bounds;
}

- (void)setSelectedIndex:(NSUInteger)index {
	_selectedIndex = index;
	if (index < [self.viewControllers count]) {
		UIViewController *selectedViewController = [self.viewControllers objectAtIndex:index];
		self.title = selectedViewController.title;
		[self addChildViewController:selectedViewController];
		[self.tabsView setSelectedViewController:selectedViewController];
		[self.tabsView setSelectedTabAtIndex:index];
	}
}

- (void)showMenuForTabModel:(MONTabModel *)tabModel {
	UIViewController *viewController = tabModel.tabViewController;
	viewController.modalPresentationStyle = UIModalPresentationOverFullScreen;
	[self.navigationController presentViewController:viewController animated:YES completion:nil];
}

#pragma mark - MONTabViewDelegate Methods

- (void)tabTappedAtIndex:(NSUInteger)index {
	MONTabModel *tabModel = self.tabModels[index];
	if (tabModel.tabType == TabTypeMenu) {
		[self showMenuForTabModel:tabModel];
	} else {
		[self setSelectedIndex:index];
	}
}

#pragma mark - MONTabSettingsObjectDelegate Methods

- (void)globalTitleChanged:(NSString *)globalTitle {
	self.title = globalTitle;
}

- (void)tabTitleChanged:(NSString *)tabTitle index:(NSUInteger)index {
	MONTabModel *tabModel = [self.tabModels objectAtIndex:index];
	tabModel.tabTitle = tabTitle;

}

- (void)tabTitleChanged:(NSString *)tabTitle viewController:(UIViewController *)viewController {
	NSUInteger index = [self.viewControllers indexOfObject:viewController];
	[self tabTitleChanged:tabTitle index:index];
	[self.tabsView setTabModels:self.tabModels];
	[self.tabsView setSelectedTabAtIndex:self.selectedIndex];
}

- (void)gotoNextTab {
	[self setSelectedIndex:self.selectedIndex + 1];
}

@end
