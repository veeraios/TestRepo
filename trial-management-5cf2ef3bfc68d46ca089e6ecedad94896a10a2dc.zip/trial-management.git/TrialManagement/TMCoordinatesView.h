#import <UIKit/UIKit.h>
#import "TMCoordinatesLocationEnum.h"

@protocol TMCoordinatesViewDelegate <NSObject>
- (void) evt_updatedLocation:(TMCoordinatesLocation)location latitude:(NSDecimalNumber *)latitude longitude:(NSDecimalNumber *)longitude;
- (void) evt_doneUpdatingValue:(NSString *)value;
- (void) evt_updateToCurrentLocation:(TMCoordinatesLocation)location;
@end

@interface TMCoordinatesView : UIView

@property (nonatomic, weak) NSObject<TMCoordinatesViewDelegate> *delegate;

- (id)init UNAVAILABLE_ATTRIBUTE;
- (instancetype)initWithTitle:(NSString *)title location:(TMCoordinatesLocation)location;
- (void) clearCoordinates;
- (void) setCoordinates:(NSString *)latitude longitude:(NSString*)longitude;

@end
