#import <ESCObservable/ESCObservable.h>
#import "MONTextFieldEditorView.h"
#import "MONLabel.h"
#import "MONDimensions.h"
#import "MONFonts.h"
#import "MONTextField.h"
#import "UIColor+MONThemeColorProvider.h"

static const NSInteger CharacterMax = 15;
static const CGFloat HeaderLabelOffset = 7.0;

@interface MONTextFieldEditorView ()<UITextFieldDelegate, ESCObservableInternal>

@property (nonatomic) UILabel *errorLabel;
@property (nonatomic) MONLabel *headerLabel;
@property (nonatomic) MONTextField *textField;
@property (nonatomic) CGRect keyboardFrame;

@end

@implementation MONTextFieldEditorView

- (id)initWithFrame:(CGRect)frame {
	self = [super initWithFrame:frame];
	if (self) {
		[self escRegisterObserverProtocol:@protocol(MONTextFieldEditorViewObserver)];
		
		self.backgroundColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeBackground];
		
		self.headerLabel = [[MONLabel alloc] init];
		self.headerLabel.font = [UIFont fontWithName:OpenSansLight size:MONFontsHeaderTextSize];
		
		[self addSubview:self.headerLabel];
		
		self.errorLabel = [[UILabel alloc] init];
		self.errorLabel.font = [UIFont fontWithName:OpenSansLight size:12];
		self.errorLabel.textColor = [UIColor redColor];
		self.errorLabel.text = [NSString  stringWithFormat: @"max character size %ld",(long)CharacterMax];
		self.errorLabel.alpha = 0;
		[self addSubview:self.errorLabel];

		self.textField = [[MONTextField alloc] init];
		self.textField.delegate = self;
		self.textField.layer.borderColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeBorder].CGColor;
		[self.textField setPlaceholderText:@"Add a short description here (15 characters max)"];
		[self.textField setPlaceholderTextColor:[UIColor colorForThemeComponentType:MONThemeComponentTypePlaceholderText]];

		self.textField.layer.borderWidth = MONDimensionsThinBorderWidth;
		self.textField.layer.cornerRadius = MONDimensionsCornerRadius;
		[self addSubview:self.textField];
		
		[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
	}
	return self;
}

-(void)dealloc {
	[[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)layoutSubviews {
	[super layoutSubviews];
	
	[self.headerLabel sizeToFit];
	self.headerLabel.frame = CGRectMake(MONDimensionsSmallPadding,
										MONDimensionsLargePadding - HeaderLabelOffset,
										CGRectGetWidth(self.headerLabel.frame),
										CGRectGetHeight(self.headerLabel.frame));

	[self.textField sizeToFit];
	self.textField.frame = CGRectMake(MONDimensionsSmallPadding,
									  CGRectGetMaxY(self.headerLabel.frame) + MONDimensionsSmallPadding,
									  CGRectGetWidth(self.bounds) - 2.0 * MONDimensionsSmallPadding,
									  CGRectGetHeight(self.textField.frame));
	
	self.errorLabel.frame = CGRectMake(MONDimensionsSmallPadding+5.0,
									  CGRectGetMaxY(self.textField.frame),
									  180,
									  20);

	
}

- (BOOL)becomeFirstResponder {
	return [self.textField becomeFirstResponder];
}

- (void)setHeaderText:(NSString *)headerText {
	self.headerLabel.text = [headerText uppercaseString];
}

- (void)setText:(NSString *)text {
	self.textField.text = text;
}

#pragma mark - UITextFieldDelegate Methods

-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    if([textField.text length]>CharacterMax-1 && [string length] > range.length) {
		[UIView animateWithDuration:0.3
						 animations:^{
							 self.errorLabel.alpha = 1.0;
						 }];
		return NO;
	} else {
		[UIView animateWithDuration:0.3
						 animations:^{
							 self.errorLabel.alpha = 0.0;
						 }];
		
		return YES;
	}
}

-(void)textFieldDidEndEditing:(UITextField *)textField {
	[self.escNotifier textFieldEditorTextDidChange:textField.text];
}
#pragma mark - UIKeyboardDidShowNotification Methods

- (void)keyboardWillShow:(NSNotification *)notification {
	NSValue *keyboardFrameValue = [notification.userInfo objectForKey:UIKeyboardFrameEndUserInfoKey];
	CGRect keyboardFrame = [keyboardFrameValue CGRectValue];
	keyboardFrame = [self convertRect:keyboardFrame fromView:nil];
	
	self.keyboardFrame = keyboardFrame;
}

#pragma mark - UIKeyboardDidHideNotification Methods

- (void)keyboardWillHide:(NSNotification *)notification {
	
}


@end
