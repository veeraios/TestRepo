#import "MONLoginService.h"
#import <ESCObservable/ESCObservable.h>
#import <Foundation/Foundation.h>

@protocol MONLoginModelObserver <NSObject>

- (void)loginSucceeded;
- (void)loginFailedWithError:(NSError *)error;

@end

@interface MONLoginModel : NSObject<ESCObservable>

@property (nonatomic) NSString *username;
@property (nonatomic) NSString *password;

- (instancetype)initWithLoginService:(MONLoginService *)loginService;
- (void)submitLogin;
- (BOOL)userIsAuthenticated;
- (void)logout;

@end
