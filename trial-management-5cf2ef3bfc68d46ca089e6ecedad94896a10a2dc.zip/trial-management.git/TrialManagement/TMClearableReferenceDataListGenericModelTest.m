#import <XCTest/XCTest.h>
#import "TMClearableReferenceDataListGenericModel.h"

static NSString * const testPlaceholderText = @"PlaceholderText";
static NSString * const testDataFirstValue = @"TestData1";
static NSString * const testDataSecondValue = @"TestData2";

@interface TMClearableReferenceDataListGenericModelTest : XCTestCase
@property (nonatomic) TMClearableReferenceDataListGenericModel *testObject;
@property (nonatomic) NSArray *testDataArray;

@end

@implementation TMClearableReferenceDataListGenericModelTest

- (void)setUp {
    [super setUp];
    self.testDataArray = @[testDataFirstValue,testDataSecondValue];
    
    self.testObject = [[TMClearableReferenceDataListGenericModel alloc] initWithDataArray:self.testDataArray
                                                                                nameBlock:^NSString *(NSInteger index) {
                                                                           if (index == 0) {
                                                                                        return testDataSecondValue;
                                                                                    } else {
                                                                                        return testDataFirstValue;
                                                                                    }
                                                                                }
                                                                          placeholderText:testPlaceholderText];
}

- (void)testNameForItemAtIndex_ReturnsPlaceholderForFirstIndex {
    XCTAssertEqualObjects(testPlaceholderText, [self.testObject nameForItemAtIndex:0]);
}

- (void)testNameForItemAtIndex_ReturnsValueBasedOnNameBlockLogic {
    XCTAssertEqualObjects(testDataFirstValue, [self.testObject nameForItemAtIndex:2]);
    XCTAssertEqualObjects(testDataSecondValue, [self.testObject nameForItemAtIndex:1]);
}

- (void)testObjectAtIndex_ReturnsValueBasedOnDataArrayOrder {
    XCTAssertEqualObjects(testDataFirstValue, [self.testObject objectAtIndex:1]);
    XCTAssertEqualObjects(testDataSecondValue, [self.testObject objectAtIndex:2]);
}

- (void)testNumberOfItems_ReturnsNumberOfItemsInDataArrayPlusOne {
    XCTAssertEqual(3, [self.testObject numberOfItems]);
}

@end
