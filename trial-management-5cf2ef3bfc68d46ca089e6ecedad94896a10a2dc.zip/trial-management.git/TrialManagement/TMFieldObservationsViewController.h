#import "MONTabController.h"
#import "TMPersistenceViewController.h"
#import "TMTrialModel.h"

@interface TMFieldObservationsViewController : TMPersistenceViewController<MONTabController>

- (instancetype)init UNAVAILABLE_ATTRIBUTE;
- (instancetype)initWithTrialModel:(TMTrialModel *)trialModel;

@end
