
#import <Foundation/Foundation.h>
#import "MONContextProtocol.h"

@interface MONDifferenceDetectionEngine : NSObject

- (instancetype)initWithBackupContext:(id<MONContextProtocol>)backupContext andDataModelTraversalRules:(NSDictionary *)traversalRules;
- (NSDictionary *)changesDetectedBetweenObject:(NSManagedObject *)object andBackupObject:(NSManagedObject *)backupObject;

@end
