#import "TMReferenceListDataModel.h"
#import "MONLabeledTextField.h"

@protocol MONPopoverTextFieldDelegate <NSObject>
@optional
-(void)valueWasSelected:(id)sender selectedValue:(NSString*)selectedValue selectedIndex:(NSInteger)selectedIndex;
-(void)valueWasSelected:(id)sender selectedObject:(id)selectedObject selectedIndex:(NSInteger)selectedIndex;
@end

@interface MONPopoverTextField : MONLabeledTextField

@property (nonatomic, weak) id<MONPopoverTextFieldDelegate> popoverDelegate;
@property (nonatomic) id<TMReferenceListDataModel> model;

- (instancetype)initWithModel:(id<TMReferenceListDataModel>)model title:(NSString*)title placeHolderText:(NSString*)placeHolderText selectedIndex:(NSInteger)selectedIndex;
- (void)showBorder:(BOOL)showBorder;
- (void)monLabeledTextFieldTextDidChange:(MONLabeledTextField *)labeledTextField;
- (void)setLabelLocation:(MONLabeledTextFieldLocation)location;
@end
