#import <UIKit/UIKit.h>

@interface MONTitleValueVerticalLabels : UIView

- (void)setTitleText:(NSString *)titleText;
- (void)setValueText:(NSString *)valueText;
- (void)setTextColor:(UIColor *)textColor;

@end
