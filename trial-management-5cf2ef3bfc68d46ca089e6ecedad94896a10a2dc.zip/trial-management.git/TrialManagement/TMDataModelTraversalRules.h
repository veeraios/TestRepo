//
//  TMDataModelTraversalMergeRulesHolder.h
//  TrialManagement
//
//  Created by GADIRAJU, PRANEETH [AG/1000] on 1/6/15.
//  Copyright (c) 2015 Monsanto. All rights reserved.
//

@interface TMDataModelTraversalRules : NSObject
- (id)init UNAVAILABLE_ATTRIBUTE;
+(id)sharedInstance;
@property (nonatomic,readonly) NSDictionary *dataModelTraversalRulesDictionary;
@property (nonatomic,readonly) NSSet *dataModelTransactionalTableRules;
@end
