#import "TMReferenceDataListGenericModel.h"
#import "TMProductRepository.h"
#import <ESCObservable/ESCObservable.h>
#import <Foundation/Foundation.h>

@protocol TMFilterProductsModelDelegate <NSObject>

- (void)searchPerformed;

@end

@interface TMFilterProductsModel : TMReferenceDataListGenericModel

@property (nonatomic, weak) NSObject<TMFilterProductsModelDelegate> *delegate;

- (instancetype)initWithProductRepository:(id<TMProductRepositoryProtocol>)productRepository;
- (NSArray *)searchResults;
- (void)setBrandSearchText:(NSString *)brandSearchText;
- (void)setProductSearchText:(NSString *)productSearchText;
- (void)setCropId:(NSNumber *)cropId;
- (void)setTraitsSearchText:(NSString *)traitsSearchText;
- (void)setRmSearchText:(NSString *)rmSearchText;
- (void)setRmVarianceSearchText:(NSString *)rmVarianceSearchText;

@end
