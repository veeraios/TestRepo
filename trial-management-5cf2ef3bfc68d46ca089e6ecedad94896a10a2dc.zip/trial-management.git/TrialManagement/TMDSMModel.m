#import "TMDSMModel.h"

@interface TMDSMModel ()
@property (nonatomic) NSArray *dataArray;
@end

@implementation TMDSMModel
-(instancetype)initWithDataSource:(NSArray*)dataSource {
	self = [super init];
	if (self) {		
		self.dataArray=dataSource;
	}
	return self;
}

- (NSString *)nameForItemAtIndex:(NSInteger)index {
	return [self.dataArray objectAtIndex:index];
}
@end
