#import <ESCObservable/ESCObservable.h>
#import <UIKit/UIKit.h>
#import "MONSelectionCardCollectionViewCell.h"
#import "MONLabel.h"

@class MONTextViewCardCollectionViewCell;
@protocol MONTextViewCardCollectionViewCell <NSObject>

- (void)textViewCardCellTapped:(MONTextViewCardCollectionViewCell *)textViewCardCell;

@end

@interface MONTextViewCardCollectionViewCell : UICollectionViewCell<ESCObservable, MONSelectionCardCollectionViewCell>

@property (nonatomic) MONLabel *titleLabel;
@property (nonatomic) UITextView *textView;

- (void)setPlaceholderText:(NSString *)placeholderText;

@property (nonatomic) NSString *selectedText;

@end
