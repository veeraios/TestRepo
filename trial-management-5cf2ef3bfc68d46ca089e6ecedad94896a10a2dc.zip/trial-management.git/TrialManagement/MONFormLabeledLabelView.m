#import "MONFormLabeledLabelView.h"
#import "MONLabel.h"
#import "MONDimensions.h"
#import "MONFonts.h"

static const CGFloat DefaultHeight = 35.0;

@interface MONFormLabeledLabelView ()

@property (nonatomic) MONLabel *textLabel;
@property (nonatomic) MONLabel *valueLabel;
@property (nonatomic) CGFloat labelWidth;

@end

@implementation MONFormLabeledLabelView

- (id)initWithFrame:(CGRect)frame {
	self = [super initWithFrame:frame];
	if (self) {
		self.textLabel = [[MONLabel alloc] init];
		self.textLabel.textAlignment = NSTextAlignmentRight;
		[self addSubview:self.textLabel];
		
		self.valueLabel = [[MONLabel alloc] init];
		self.valueLabel.font = [UIFont fontWithName:OpenSans size:14.0];
		[self addSubview:self.valueLabel];
	}
	return self;
}

- (void)layoutSubviews {
	[super layoutSubviews];
	
	[self.textLabel sizeToFit];
	CGFloat labelWidth = self.labelWidth > 0.0 ? self.labelWidth : CGRectGetWidth(self.textLabel.frame);
	self.textLabel.frame = CGRectMake(0.0, 0.0, labelWidth, CGRectGetHeight(self.bounds));
	
	self.valueLabel.frame = CGRectMake(CGRectGetMaxX(self.textLabel.frame) + 2.0 * MONDimensionsSmallPadding,
									  0.0,
									  CGRectGetWidth(self.bounds) - CGRectGetMaxX(self.textLabel.frame) - 2.0 * MONDimensionsSmallPadding,
									  CGRectGetHeight(self.bounds));
	
}

- (CGSize)sizeThatFits:(CGSize)size {
	CGSize sizeThatFits = CGSizeMake(size.width, DefaultHeight);
	return sizeThatFits;
}

- (void)setLabelText:(NSString *)labelText {
	self.textLabel.text = labelText;
}

- (void)setValueText:(NSString *)valueText {
	self.valueLabel.text = valueText;
}

@end
