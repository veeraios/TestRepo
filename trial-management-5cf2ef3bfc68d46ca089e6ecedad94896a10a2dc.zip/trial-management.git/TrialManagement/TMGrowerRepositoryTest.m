#import "TMGrowerRepository.h"
#import "TMGrower.h"
#import "NSManagedObject+TMCoreDataTestHelper.h"
#import "TMWorkingCoreDataContext.h"
#import "TMUserManager.h"

@interface TMGrowerRepositoryTest : XCTestCase
@end

@implementation TMGrowerRepositoryTest

-(void)setUpUserForImportTest:(NSObject<MONRepositoryProtocol>*)repo {
	//todo: move to import Test helpers
	TMUserManager *manager = [TMUserManager sharedInstance];
	manager.currentUsername = @"test";
	TMUser *user = [TMUser create];
	user.userId = manager.currentUsername;
	[user.managedObjectContext save:nil];
	id mock = [OCMockObject partialMockForObject:repo];
	[[[mock stub] andReturn:user] currentUser];
}

- (void)testSyncFromService {
	TMWorkingCoreDataContext *context = [[TMWorkingCoreDataContext alloc] init];
	id mockContext = [OCMockObject partialMockForObject:context];
	[[mockContext stub] saveContext];

	TMGrowerRepository *repo = [[TMGrowerRepository alloc] initWithContext:context withModel:[TMGrower class]];
	[self setUpUserForImportTest:repo];
	
	[repo syncFromService:@[
							@{
		@"id": @879543688397324,
		@"name": @"\"Krolevetskuy komb. zavod\"",
		@"city": @"Krolevets",
		@"address": @"123 Fake St.|PO Box Inf.",
		@"state": @"CO",
		@"country": @"USA",
		@"postalCode": @"76566",
		@"phoneNumber": [NSNull null],
		@"faxNumber": [NSNull null],
		@"email": [NSNull null],
		@"accountId": [NSNull null],
		@"category": @"Grower"
	}] completionBlock:nil];
	
	TMGrower *actual = [[context find:NSStringFromClass([TMGrower class]) where:@"growerId = 879543688397324"] firstObject];
	XCTAssert(actual != nil);
	XCTAssertEqualObjects(actual.name,  @"\"Krolevetskuy komb. zavod\"");
	XCTAssertEqualObjects(actual.city, @"Krolevets");
	XCTAssertEqualObjects(actual.address1, @"123 Fake St.");
    XCTAssertEqualObjects(actual.address2, @"PO Box Inf.");
	XCTAssertEqualObjects(actual.state, @"CO");
	XCTAssertEqualObjects(actual.country, @"USA");
	XCTAssertEqualObjects(actual.postalCode, @"76566");
	XCTAssertEqualObjects(actual.phoneNumber, @"");
	XCTAssertEqualObjects(actual.faxNumber, @"");
	XCTAssertEqualObjects(actual.email, @"");
	XCTAssertEqualObjects(actual.accountId, @"");
	XCTAssertEqualObjects(actual.category, @"Grower");
	
}

-(void)testSearchGrower {
	TMWorkingCoreDataContext *context = [[TMWorkingCoreDataContext alloc] init];
	TMGrower *growerToFind = [context attachObject:[TMGrower class]];
	growerToFind.name = @"123123123test123123123123123123";
	id mockContext = [OCMockObject partialMockForObject:context];
	[[mockContext stub] saveContext];
	
	TMGrowerRepository *repo = [[TMGrowerRepository alloc] initWithContext:context withModel:[TMGrower class]];
	NSArray *result = [repo searchGrower:growerToFind.name];
	XCTAssertEqual(1, [result count]);
	XCTAssertEqualObjects(growerToFind, [result objectAtIndex:0]);
}
@end
