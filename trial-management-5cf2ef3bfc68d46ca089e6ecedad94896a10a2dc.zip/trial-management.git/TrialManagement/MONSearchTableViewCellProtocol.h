#import "MONSearchResult.h"

@protocol MONSearchTableViewCellProtocol <NSObject>
- (void)setSearchResult:(id<MONSearchResult>)searchResult;

@optional
- (void)setSelected:(BOOL)selected;
- (void)useAlternateBackgroundColor:(BOOL)useAlternateBackgroundColor;
@end
