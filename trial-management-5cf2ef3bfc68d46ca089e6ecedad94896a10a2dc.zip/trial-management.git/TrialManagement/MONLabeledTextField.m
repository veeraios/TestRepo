#import "MONLabeledTextField.h"
#import "MONTextField.h"
#import  "MONTextView.h"

@interface MONLabeledTextField ()<MONTextViewDelegate, UITextFieldDelegate,UITextViewDelegate>

@property (nonatomic) BOOL shouldDismissKeyboardWithReturnKey;
@property (nonatomic) BOOL allowOnlyNumbers;
@property (nonatomic) MONTextView *textField;

@end

@implementation MONLabeledTextField

- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.textField = [[MONTextView alloc] init];
        self.textField.monTextViewDelegate = self;
        //self.textField.textViewDelegate = self;
        self.controlView = self.textField;
        
        self.shouldDismissKeyboardWithReturnKey = YES;
        [super setLabelLocation:MONLabeledControlLabelLocationLeft];
    }
    return self;
}

- (void)shouldDismissKeyboardWithReturnKey:(BOOL)value {
    self.shouldDismissKeyboardWithReturnKey = value;
}

- (void)setLabelLocation:(MONLabeledTextFieldLocation)location {
    MONLabeledControlLabelLocation labeledControlLabelLocation;
    switch (location) {
        case MONLabeledTextFieldLocationLeft:
            labeledControlLabelLocation = MONLabeledControlLabelLocationLeft;
            break;
        case MONLabeledTextFieldLocationTop:
            labeledControlLabelLocation = MONLabeledControlLabelLocationTop;
            break;
        case MONLabeledTextFieldLocationHide:
            labeledControlLabelLocation = MONLabeledControlLabelLocationNone;
            break;
        default:
            break;
    }
    [super setLabelLocation:labeledControlLabelLocation];
}

- (NSString *)textFieldText {
    return self.textField.text;
}
-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    if(self.shouldDismissKeyboardWithReturnKey) {
        [textField resignFirstResponder];
    }
    return YES;
}

- (void)setTextFieldText:(NSString *)textFieldText {
    self.textField.text = textFieldText;
}

- (void)setKeyboardType:(UIKeyboardType)keyboardType {
    //[self.textField setKeyboardType:keyboardType];
}
- (void)setLabelText:(NSString *)labelText {
    self.label.text = labelText;
}

- (void)setLockedColor {
    [self.textField setLockedColor];
}

- (void)setTextFieldPlaceholderText:(NSString *)placeholderText {
    //[self.textField setPlaceholderText:placeholderText];
}

- (void)setValueText:(NSString *)valueText {
    [self setTextFieldText:valueText];
}

- (void)setAutocorrectionType:(UITextAutocorrectionType)autocorrectionType {
    //[self.textField setAutocorrectionType:autocorrectionType];
}

- (BOOL)enabled {
    //return YES;
    
    return self.textField.isUserInteractionEnabled;
}

- (void)setEnabled:(BOOL)enabled {
    [self.textField setEditable:enabled];
}

- (BOOL)becomeFirstResponder {
    return [self.textField becomeFirstResponder];
}

- (BOOL)resignFirstResponder {
    return [self.textField resignFirstResponder];
}

- (void)allowOnlyNumbers:(BOOL)value {
    self.allowOnlyNumbers = value;
}

#pragma mark - UITextFieldDelegate Methods

-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    if([self.delegate respondsToSelector:@selector(monLabeledTextField:shouldChangeCharactersInRange:replacementString:)]) {
        return [self.delegate monLabeledTextField:self shouldChangeCharactersInRange:range replacementString:string];
    } else if(self.allowOnlyNumbers) {
        NSArray *excludedNumericOperators = @[@".", @"-"];
        
        NSString *resultingString = [[self textFieldText] stringByReplacingCharactersInRange:range withString: string];
        if ([resultingString length] == 0 || ([excludedNumericOperators containsObject:[resultingString substringToIndex:1]])) {
            return YES;
        }
        NSScanner *scan = [NSScanner scannerWithString: resultingString];
        return [scan scanDouble: nil] && [scan isAtEnd];
    }
    return YES;
}

-(void)textFieldDidBeginEditing:(UITextField *)textField {
    if([self.delegate respondsToSelector:@selector(monLabeledTextFieldDidBeginEditing:)]) {
        [self.delegate monLabeledTextFieldDidBeginEditing:self];
    }
    if([self.delegate respondsToSelector:@selector(monLabeledTextFieldTextDidChange:)]) {
        [self.delegate monLabeledTextFieldTextDidChange:self];
    }
}

#pragma mark - MONTextFieldDelegate Methods

- (void)monTextFieldTextDidChange:(MONTextField *)textField {
    if([self.delegate respondsToSelector:@selector(monLabeledTextFieldTextDidChange:)]) {
        [self.delegate monLabeledTextFieldTextDidChange:self];
    }
}

- (void)monTextFieldDidEndEditing:(MONTextField *)textField {
    if([self.delegate respondsToSelector:@selector(monLabeledTextFieldTextDidEndEditing:)]) {
        [self.delegate monLabeledTextFieldTextDidEndEditing:self];
    }
}


- (void)monTextViewTextDidChange:(MONTextView *)textField {
    if([self.delegate respondsToSelector:@selector(monLabeledTextFieldTextDidChange:)]) {
        [self.delegate monLabeledTextFieldTextDidChange:self];
    }
}

- (void)monTextViewDidEndEditing:(MONTextView *)textField {
    if([self.delegate respondsToSelector:@selector(monLabeledTextFieldTextDidEndEditing:)]) {
        [self.delegate monLabeledTextFieldTextDidEndEditing:self];
    }
}

@end
