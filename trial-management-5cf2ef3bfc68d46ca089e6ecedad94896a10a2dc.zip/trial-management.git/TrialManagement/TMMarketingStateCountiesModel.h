#import "TMStatesModel.h"
#import "TMMarketingSubmissionType.h"

@interface TMMarketingStateCountiesModel : NSObject
@property (readonly, nonatomic) TMMarketingSubmissionType marketingSubmission;

- (instancetype)initWithStatesModel:(TMStatesModel *)statesModel plotStateName:(NSString*)plotStateName previouslySelectedCounties:(NSArray*)previouslySelectedCounties marketingSubmission:(TMMarketingSubmissionType)marketingSubmission;
- (instancetype)initWithStatesModel:(TMStatesModel *)statesModel maxSelections:(NSInteger)maxSelections plotStateName:(NSString*)plotStateName previouslySelectedCounties:(NSArray*)previouslySelectedCounties marketingSubmission:(TMMarketingSubmissionType)marketingSubmission;
- (TMStatesModel*)statesModel;
- (NSString*)plotStateName;
- (NSInteger)indexForPlotStateName;
- (NSArray*)selectedCounties;
- (void)selectCounty:(NSInteger)countyIndex forStateIndex:(NSInteger)stateIndex;
- (void)deselectCounty:(NSInteger)index forStateIndex:(NSInteger)stateIndex;
- (BOOL)canSelectMoreCounties;
- (NSInteger)numberOfCountiesForStateIndex:(NSInteger)stateIndex;
- (NSString*)countyNameForCountyIndex:(NSInteger)index stateIndex:(NSInteger)stateIndex;
- (BOOL)isPreviouslySelected:(NSInteger)index stateIndex:(NSInteger)stateIndex;
@end
