//
//  TMMergeTrialModel.swift
//  TrialManagement
//
//  Created by SINGH, SUPREET [AG/1000] on 1/21/15.
//  Copyright (c) 2015 Monsanto. All rights reserved.
//

protocol TMMergeTrialModelDelegate: class {
    func resolveAllConflicts(side: TMMergeSide)
}

class TMMergeTrialModel: NSObject {
    weak var delegate: TMMergeTrialModelDelegate?
    let trial: TMTrial
    let mergeGroups: [TMMergeGroup]
    
    required init(trial: TMTrial, mergeGroups: [TMMergeGroup]) {
        self.trial = trial
        self.mergeGroups = mergeGroups
        super.init()
    }
    
    func totalConflicts() -> Int {
        return mergeGroups.count
    }

    func conflictResolved(side: TMMergeSide, subsection: TMMergeSubsection, section: TMMergeSection) {
        if let matchingMergeGroup = mergeGroups.findFirst({$0.section == section && $0.subsection == subsection}) {
            matchingMergeGroup.resolved = true
            matchingMergeGroup.mergeValues.forEach({$0.resolvedValue = (side == .Left) ? $0.webValue : $0.mobileValue})
            resolveAllConflicts(side)
        }
    }
    
    func resolveAllConflicts(side: TMMergeSide) {
        mergeGroups.forEach({
            $0.resolved = true
            $0.mergeValues.forEach({(mergeValue) -> () in
                mergeValue.resolvedValue = (side == .Left) ? mergeValue.webValue : mergeValue.mobileValue})
        })
        delegate?.resolveAllConflicts(side)
    }
    
    func saveResolvedValuesToContext(context: MONContextProtocol) {
        mergeGroups.forEach( { [unowned self] in
            TMMergePathValueSetter(context: context, inclusionRules: TMDataModelTraversalRules.sharedInstance().dataModelTransactionalTableRules, mergeGroup: $0, rootObject: self.trial).setAllResolvedValues()
        })
    }
}
