//
//  NSManagedObject+MONClone.h
//  TrialManagement
//
//  Created by GADIRAJU, PRANEETH [AG/1000] on 12/8/14.
//  Copyright (c) 2014 Monsanto. All rights reserved.
//

#import <CoreData/CoreData.h>

@interface NSManagedObject (MONClone)
-(NSManagedObject *)cloneInContext:(NSManagedObjectContext *)context
       withDataModelTraversalRules:(NSDictionary *)dataModelTraversalRulesDictionary;
@end
