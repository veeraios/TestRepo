//
//  TMCooperatorModel.swift
//  TrialManagement
//
//  Created by GADIRAJU, PRANEETH [AG/1000] on 5/2/15.
//  Copyright (c) 2015 Monsanto. All rights reserved.
//

@objc protocol TMCooperatorModel {
    func hasRequiredInformation() -> Bool
    func title() -> String
    func isNew() -> Bool
    func cooperator() -> NSManagedObject
    var name:String {get set}
    var accountId:String {get set}
    var email:String {get set}
    var phone:String {get set}
    var address1:String {get set}
    var address2:String {get set}
    var city:String {get set}
    var state:String {get set}
    var postalCode:String {get set}
}
