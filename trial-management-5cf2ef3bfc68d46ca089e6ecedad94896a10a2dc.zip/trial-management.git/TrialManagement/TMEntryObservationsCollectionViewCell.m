#import "TMEntryObservationsCollectionViewCell.h"
#import "MONLabel.h"
#import "MONTitleValueVerticalLabels.h"
#import "MONColors.h"
#import "TMEntryCollectionCellContentView.h"
#import "MONDimensions.h"
#import "UIColor+MONThemeColorProvider.h"

static const CGFloat ContentHorizontalPadding = 26.0;
static const CGFloat NumberLabelFontSize = 32.0;
static const CGFloat NumberContainerWidth = 55.0;
static const CGFloat HeaderDefaultHeight = 64.0;
static NSString * const BrandTitle = @"Brand";
static NSString * const ProductTitle = @"Product";

@interface TMEntryObservationsCollectionViewCell ()

@property (nonatomic) MONCardContainerView *backgroundCardContainerView;
@property (nonatomic) MONCardContainerView *entryHeaderCardContainerView;
@property (nonatomic) UIView *numberContainerView;
@property (nonatomic) MONLabel *numberLabel;
@property (nonatomic) MONTitleValueVerticalLabels *brandTitleLabel;
@property (nonatomic) MONTitleValueVerticalLabels *productTitleLabel;
@property (nonatomic) TMObservationsEditContainerView *observationsEditContainerView;

@end

@implementation TMEntryObservationsCollectionViewCell

- (id)initWithFrame:(CGRect)frame {
	self = [super initWithFrame:frame];
	if (self) {
		self.backgroundCardContainerView = [[MONCardContainerView alloc] init];
		[self.contentView addSubview:self.backgroundCardContainerView];
		
		self.entryHeaderCardContainerView = [[MONCardContainerView alloc] init];
		self.entryHeaderCardContainerView.layer.cornerRadius = 0.0;
		[self.backgroundCardContainerView addSubview:self.entryHeaderCardContainerView];
		
		self.numberContainerView = [[UIView alloc] init];
		self.numberContainerView.backgroundColor = [MONColors midnightBlueColor];
		[self.entryHeaderCardContainerView.contentContainerView addSubview:self.numberContainerView];
		
		self.numberLabel = [[MONLabel alloc] init];
		self.numberLabel.textSize = NumberLabelFontSize;
		self.numberLabel.textColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeSelectedText];
		self.numberLabel.textAlignment = NSTextAlignmentCenter;
		[self.numberContainerView addSubview:self.numberLabel];
		
		self.brandTitleLabel = [[MONTitleValueVerticalLabels alloc] init];
		[self.brandTitleLabel setTitleText:BrandTitle];
		[self.entryHeaderCardContainerView.contentContainerView addSubview:self.brandTitleLabel];
		
		self.productTitleLabel = [[MONTitleValueVerticalLabels alloc] init];
		[self.productTitleLabel setTitleText:ProductTitle];
		[self.entryHeaderCardContainerView.contentContainerView addSubview:self.productTitleLabel];
	}
	return self;
}

- (void)layoutSubviews {
	[super layoutSubviews];
	self.backgroundCardContainerView.frame = self.contentView.bounds;
	
	self.entryHeaderCardContainerView.frame = CGRectMake(0.0,
														 0.0,
														 CGRectGetWidth(self.backgroundCardContainerView.bounds),
														 HeaderDefaultHeight);
	
	CGSize observationsEditContainerViewSize = [self.observationsEditContainerView sizeThatFits:CGSizeMake(CGRectGetWidth(self.bounds) - 2.0 * MONDimensionsSmallPadding, CGFLOAT_MAX)];
	self.observationsEditContainerView.frame = CGRectMake(MONDimensionsSmallPadding,
														CGRectGetMaxY(self.entryHeaderCardContainerView.frame) + MONDimensionsLargePadding,
														observationsEditContainerViewSize.width,
														observationsEditContainerViewSize.height);
	
	self.numberContainerView.frame = CGRectMake(0.0,
												0.0,
												NumberContainerWidth,
												CGRectGetHeight(self.entryHeaderCardContainerView.contentContainerView.bounds));
	
	[self.numberLabel sizeToFit];
	self.numberLabel.frame = CGRectMake(0.0,
										0.0,
										CGRectGetWidth(self.numberContainerView.bounds),
										CGRectGetHeight(self.numberContainerView.bounds));
		
	self.brandTitleLabel.frame = CGRectMake(CGRectGetMaxX(self.numberContainerView.frame) + ContentHorizontalPadding,
											0.0,
											165.0f,
											CGRectGetHeight(self.entryHeaderCardContainerView.contentContainerView.bounds));
	self.productTitleLabel.frame = CGRectMake(CGRectGetMaxX(self.brandTitleLabel.frame),
											  0.0,
											  165.0f,
											  CGRectGetHeight(self.entryHeaderCardContainerView.contentContainerView.bounds));

}

- (CGSize)sizeThatFits:(CGSize)size {
	CGSize sizeThatFits = CGSizeMake(size.width, 0.0);
	
	sizeThatFits.height += HeaderDefaultHeight;
	
	CGSize observationsEditContainerViewSize = [self.observationsEditContainerView sizeThatFits:CGSizeMake(size.width, CGFLOAT_MAX)];
	sizeThatFits.height += observationsEditContainerViewSize.height;
	sizeThatFits.height += 2.0 * MONDimensionsLargePadding;
	
	return sizeThatFits;
}

- (void)setEntryModel:(TMEntryModel*)entryModel {
	[self setObservationsEditContainerView:[[TMObservationsEditContainerView alloc] initWithEntryModel:entryModel]];
	[self setNumber:[entryModel entryNumber]];
	[self setBrand:[entryModel brandName]];
	[self setProduct:[entryModel productName]];
}

- (void)setReadOnly {
    [self.observationsEditContainerView setAsReadOnly];
}

- (void)setNumber:(NSInteger)number {
	self.numberLabel.text = [NSString stringWithFormat:@"%ld", (long)number];
	[self setNeedsLayout];
}

- (void)setBrand:(NSString *)brand {
	[self.brandTitleLabel setValueText:brand];
}

- (void)setProduct:(NSString *)product {
	[self.productTitleLabel setValueText:product];
}

- (void)setObservationsEditContainerView:(TMObservationsEditContainerView *)observationsEditContainerView {
	[_observationsEditContainerView removeFromSuperview];
	
	_observationsEditContainerView = observationsEditContainerView;
	
	[self.backgroundCardContainerView addSubview:observationsEditContainerView];
}

@end
