#import "TMNetworkService.h"

extern NSString *const PingServicePath;
@interface TMConnectivity : NSObject

-(instancetype)initWithNetworkService:(TMNetworkService*)service;
-(void)isServiceReachableWithCompletionBlock:(void(^)(BOOL))completionBlock;

@end
