#import "TMReferenceDataListGenericModel.h"

@interface TMCropModel : TMReferenceDataListGenericModel
-(instancetype)initWithDataSource:(NSArray*)dataSource;
@end
