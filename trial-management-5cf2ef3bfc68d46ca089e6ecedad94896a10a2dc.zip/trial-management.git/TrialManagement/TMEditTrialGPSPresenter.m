#import "TMEditTrialGPSPresenter.h"
#import "TrialManagement-Swift.h"

@interface TMEditTrialGPSPresenter()<TMEditTrialGPSViewDelegate, TMEditTrialGPSModelDelegate>

@property (nonatomic, weak) TMEditTrialGPSView *editTrialGPSView;
@property (nonatomic) TMEditTrialGPSModel *editTrialGPSModel;
@property (nonatomic) TMTrialModel *trialModel;
@end

@implementation TMEditTrialGPSPresenter

- (instancetype)initWithEditTrialGPSView:(TMEditTrialGPSView *)editTrialGPSView trialModel:(TMTrialModel *)trialModel {
	if(self = [super init]) {
		self.editTrialGPSView = editTrialGPSView;
		self.editTrialGPSView.delegate = self;
        
        self.trialModel = trialModel;
        
        self.editTrialGPSModel = [[TMEditTrialGPSModel alloc] initWithTrialModel:trialModel];
		self.editTrialGPSModel.delegate = self;
	}
	return self;
}

- (void)updateToLocationWithCoordinates:(NSDictionary *)coordinates {
    [self.editTrialGPSView setCurrentLatitude:[coordinates[[TMConstants latitude]] doubleValue] longitude:[coordinates[[TMConstants longitude]] doubleValue] isAccuracyAcceptable: [self.editTrialGPSModel isAccuracyAcceptable:[coordinates[[TMConstants locationAccuracy]] doubleValue]]];
}

- (void)deleteInvalidCoordinatesAndStopUserTracking {
    [self.editTrialGPSModel deleteInvalidCoordinates];
    [self.editTrialGPSView stopTrackingUserLocation];
}

- (void)setCoordinatesAndUserLocation {
    [self.editTrialGPSView startTrackingUserLocation];

    [self.editTrialGPSModel setAllCoordinates];
    [self.editTrialGPSView setCoordinates:self.trialModel.latitude1 longitude1:self.trialModel.longitude1
                                latitude2:self.trialModel.latitude2 longitude2:self.trialModel.longitude2
                                latitude3:self.trialModel.latitude3 longitude3:self.trialModel.longitude3
                                latitude4:self.trialModel.latitude4 longitude4:self.trialModel.longitude4];
}

#pragma mark - TMEditTrialGPSViewDelegate Methods

- (void) evt_updatedLocation:(TMCoordinatesLocation)location latitude:(NSDecimalNumber *)latitude longitude:(NSDecimalNumber *)longitude {
	[self.editTrialGPSModel updateLocation:location latitude:latitude longitude:longitude];
}

- (void) evt_doneUpdatingValue:(NSString *)value; {
    [self.editTrialGPSModel doneUpdatingValue:value];
}

- (void) evt_updateToCurrentLocation:(TMCoordinatesLocation)location {
    [self.editTrialGPSModel updateToCurrentLocation:location];
}

- (void) evt_deleteAllGPSPoints {
	[self.editTrialGPSModel deleteAllGPSPoints];
}

#pragma mark - TMEditTrialGPSModelDelegate Methods

- (void) evt_addAnnotation:(MKPointAnnotation *)annotation {
	[self.editTrialGPSView addAnnotation:annotation];
}

- (void) evt_removeAnnotation:(MKPointAnnotation *)annotation {
	[self.editTrialGPSView removeAnnotation:annotation];
}

- (void) evt_addPolygon:(MKPolygon *)polygon {
	[self.editTrialGPSView addOverlay:polygon];
}

- (void) evt_removePolygon:(MKPolygon *)polygon {
	[self.editTrialGPSView removeOverlay:polygon];
}

- (void) evt_updateZoomRect:(MKMapRect)zoomRect {
    [self.editTrialGPSView updateZoomRect:zoomRect];
}

- (void) evt_updateToCurrentLocation:(TMCoordinatesLocation)location latitude:(NSString *)latitude longitude:(NSString *)longitude {
    [self.editTrialGPSView setLatitude:latitude longitude:longitude forLocation:location];
}

@end
