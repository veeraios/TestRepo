#import "MONTabController.h"
#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger, TabType) {
	TabTypeNavigation,
	TabTypeMenu
};

@interface MONTabModel : NSObject

@property (nonatomic) UIViewController<MONTabController> *tabViewController;
@property (nonatomic) NSString *tabTitle;
@property (nonatomic) TabType tabType;

@end
