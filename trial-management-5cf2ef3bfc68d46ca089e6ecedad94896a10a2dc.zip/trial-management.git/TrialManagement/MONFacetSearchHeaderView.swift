import UIKit

class MONFacetSearchHeaderView: MONHeaderView {

    private let expandSearchButton = UIButton()
    private let searchFieldController: MONFacetSearchFieldController
    private var displaySearchField = false
    
    init(searchFieldController: MONFacetSearchFieldController) {
        expandSearchButton.setImage(UIImage(named: "ui-icon-search-light"), forState: .Normal)
        self.searchFieldController = searchFieldController
        self.searchFieldController.view.alpha = 0.0
        self.searchFieldController.view.userInteractionEnabled = false

        super.init(frame: CGRect.zeroRect)
        
        addSubview(searchFieldController.view)
        self.searchFieldController.displayDelegate = self
        expandSearchButton.addTarget(self, action: "expandSearchButtonTapped", forControlEvents: .TouchUpInside)
    }
    
    required init(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()

        self.searchFieldController.view.frame = CGRectMake (
            CGRectGetMaxX(headerLabel.frame),
            CGRectGetMinY(headerLabel.frame) - 5,
            CGRectGetMaxX(expandSearchButton.frame) - CGRectGetMaxX(headerLabel.frame),
            CGRectGetHeight(headerLabel.frame) + 10
        )
    }

    override func setRightButtons(rightButtons: [AnyObject]!) {
        let completeRightButtons = [expandSearchButton] + rightButtons
        super.setRightButtons(completeRightButtons)
    }
    
    func displaySearchField(shouldDisplay: Bool, animated: Bool) {
        shouldDisplay ? searchFieldController.becomeFirstResponder() : searchFieldController.resignFirstResponder()
        let duration = animated ? 0.5 : 0.0
        shouldDisplay ? expandSearchButton(duration) : closeSearchButton(duration)
    }
    
    func expandSearchButtonTapped() {
        expandSearchButton(0.5)
    }
    
    func expandSearchButton(duration: NSTimeInterval) {
        
        let animationBlock: ()->() = { [unowned self] in
            self.expandSearchButton.enabled = false
            self.expandSearchButton.alpha = 0.0
            
            self.searchFieldController.view.alpha = 1.0
            self.searchFieldController.view.userInteractionEnabled = true
        }
    
        let completionBlock: Bool -> ()  = { [unowned self] completed in
            let isFirstResponder = completed ? self.searchFieldController.becomeFirstResponder() : self.searchFieldController.resignFirstResponder()
        }
        
        UIView.animateWithDuration(duration,
            delay: 0.0,
            options: .CurveEaseInOut,
            animations: animationBlock,
            completion: completionBlock )
    }
}

extension MONFacetSearchHeaderView: MONFacetSearchFieldDisplayDelegate {
    
    func closeSearchButtonTapped() {
        closeSearchButton(0.5)
    }
    
    func closeSearchButton(duration: NSTimeInterval) {
        let animationBlock: ()->() = { [unowned self] in
            self.expandSearchButton.enabled = true
            self.expandSearchButton.alpha = 1.0
        
            self.searchFieldController.view.alpha = 0.0
            self.searchFieldController.view.userInteractionEnabled = false
        }
        
        let completionBlock: Bool -> ()  = { [unowned self] completed in
            let isFirstResponder = completed ? self.searchFieldController.resignFirstResponder() : self.searchFieldController.becomeFirstResponder()
        }
        
        UIView.animateWithDuration(duration,
            delay: 0.0,
            options: .CurveEaseInOut,
            animations: animationBlock,
            completion: completionBlock)
    }
}
