#import "MONFilterModel.h"

@interface MONFilterModel ()<ESCObservableInternal>

@property (nonatomic) NSArray *allItemsArray;
@property (nonatomic) id<MONFilter>filter;
@property (nonatomic) NSArray *filteredItems;

@end

@implementation MONFilterModel

- (id)initWithFilter:(id<MONFilter>)filter {
	self = [super init];
	if (self) {
		[self escRegisterObserverProtocol:@protocol(MONFilterModelObserver)];
		
		self.filter = filter;
	}
	return self;
}

- (void)filterItemsWithText:(NSString *)filterText {
	if ([filterText isEqualToString:@""]) {
		self.filteredItems = self.allItemsArray;
	} else {
		self.filteredItems = [self.filter filteredArrayFromArray:self.allItemsArray filterText:filterText];
	}
	[self.escNotifier filterUpdated];
}

- (id)filteredItemAtIndex:(NSInteger)index {
	return [self.filteredItems objectAtIndex:index];
}

- (void)cancelFilter {
	self.filteredItems = self.allItemsArray;
	[self.escNotifier filterCancelled];
}

- (void)setAllItemsArray:(NSArray *)allItemsArray {
	_allItemsArray = allItemsArray;
	self.filteredItems = allItemsArray;
	[self.escNotifier filterUpdated];
}

- (BOOL)itemsWereFiltered {
    return self.allItemsArray.count != self.filteredItems.count;
}

@end
