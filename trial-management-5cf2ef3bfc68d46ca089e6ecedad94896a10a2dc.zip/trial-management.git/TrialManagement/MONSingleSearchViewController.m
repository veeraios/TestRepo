#import "MONSingleSearchViewController.h"

static const CGFloat SearchResultHeaderRowHeight = 40.0;
static const CGFloat SearchResultRowHeight = 44.0;

static NSString * const TableCellReuseIdentifier = @"MONEntryTableViewCell";

@interface MONSingleSearchViewController ()<UITableViewDataSource, UITableViewDelegate, MONSingleSearchDelegate>
@property (nonatomic,readwrite) UITableViewCell<MONSearchTableViewCellProtocol>* selectedItem;
@property (nonatomic) UIBarButtonItem *cancelButton;
@property (nonatomic) id<MONReferenceSearchableModel> singleSearchModel;
@property (nonatomic) NSArray *searchResults;
@property (nonatomic) UIView *tableHeaderCell;
@property (nonatomic) UIView<MONSearchViewProtocol>* searchView;
@property (nonatomic) id selectedModel;
@property (nonatomic) NSDictionary *criteria;
@property (nonatomic) NSTimer *searchTimer;
@end

@implementation MONSingleSearchViewController
- (instancetype)initWithSearchStrategy:(id<MONSearchStrategy>)strategy criteria:(NSDictionary*)criteria {
	self = [super init];
	if(self) {
		self.tableHeaderCell = strategy.tableViewHeader;
		self.singleSearchModel = strategy.searchModel;
		self.searchView = strategy.searchView;
        self.searchView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        self.criteria = criteria;
	}
	return self;
}

- (void)viewDidLoad {
	[super viewDidLoad];
	self.edgesForExtendedLayout = UIRectEdgeNone;
	
	[self.view addSubview:self.searchView];

	self.searchView.delegate = self;
	self.searchView.searchResultsTableView.dataSource = self;
	self.searchView.searchResultsTableView.delegate = self;
	[self.view addSubview:self.searchView];
	
	self.searchResults = [NSArray array];
    [self searchWithText:@""];
}

- (void)viewWillAppear:(BOOL)animated {
	[super viewWillAppear:animated];
	self.searchView.frame = self.view.bounds;
	[self.searchView setNeedsLayout];
}

#pragma mark - UITableViewDelegate Methods

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
	return self.tableHeaderCell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
	return SearchResultHeaderRowHeight;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
	return SearchResultRowHeight;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	UITableViewCell<MONSearchTableViewCellProtocol> *cell = (UITableViewCell<MONSearchTableViewCellProtocol>*)[tableView cellForRowAtIndexPath:indexPath];
	[cell setSelected:YES];
	self.selectedItem = cell;
	self.selectedModel =  [self.singleSearchModel modelAtIndex:indexPath.row];
}

- (void)tableView:(UITableView *)tableView didDeselectRowAtIndexPath:(NSIndexPath *)indexPath {
	UITableViewCell<MONSearchTableViewCellProtocol> *cell = (UITableViewCell<MONSearchTableViewCellProtocol>*)[tableView cellForRowAtIndexPath:indexPath];
	[cell setSelected:NO];
	self.selectedItem = [self.singleSearchModel modelAtIndex:indexPath.row];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	UITableViewCell<MONSearchTableViewCellProtocol> *cell = (UITableViewCell<MONSearchTableViewCellProtocol> *)[tableView dequeueReusableCellWithIdentifier:@"MONSearchTableViewCellProtocol" forIndexPath:indexPath];
	
	[cell setSearchResult:[self.searchResults objectAtIndex:indexPath.row]];
	
	if (indexPath.row % 2 == 0) {
		[cell useAlternateBackgroundColor:YES];
	} else {
		[cell useAlternateBackgroundColor:NO];
	}	
	return cell;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
	return [self.searchResults count];
}

- (void)search:(NSTimer*)theTimer {
       __weak __block MONSingleSearchViewController *weakSelf = self;
    [self.singleSearchModel search:(NSString *)[theTimer userInfo] criteria:self.criteria searchResultsBlock:^(NSArray *searchResuts, NSError *error) {
        if(!error) {
            [weakSelf.searchView setNumberOfSearchResults:[searchResuts count]];
            weakSelf.searchResults = searchResuts;
            [weakSelf.searchView doneSearching];
        }
    }];
}

#pragma mark - TMSearchGrowersDelegate Methods
- (void)searchWithText:(NSString*)searchText {
    if (self.searchTimer && [self.searchTimer isValid]) {
        [self.searchTimer invalidate];
        self.searchTimer = nil;
    }
    self.searchTimer = [NSTimer scheduledTimerWithTimeInterval:0.4 target:self selector:@selector(search:) userInfo:searchText repeats:NO];
}

@end
