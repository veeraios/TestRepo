//
//  TMMergeManageViewController.swift
//  TrialManagement
//
//  Created by SINGH, SUPREET [AG/1000] on 1/15/15.
//  Copyright (c) 2015 Monsanto. All rights reserved.
//

import UIKit

class TMMergeManageViewController: UIViewController, TMMergeUIOptionsDelegate {
    var delegate: TMMergeUIOptionsDelegate?
    private let mergeManageView: TMMergeManageView
    private let mergeManagePresenter: TMMergeManagePresenter

    init(mergeTrialModel: TMMergeTrialModel, mergeTrialViewModel: TMMergeTrialViewModel) {
        mergeManageView = TMMergeManageView(mergeTrialViewModel)
        mergeManagePresenter = TMMergeManagePresenter(mergeTrialModel, mergeManageView, mergeTrialViewModel)
        super.init(nibName: nil, bundle: nil)
        mergeManagePresenter.delegate = self
        view.addSubview(mergeManageView)
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        mergeManageView.frame = view.bounds
    }
    
    func close() {
        delegate?.close()
    }
   
    func saveResolvedValues() {
        delegate?.saveResolvedValues()
    }
    
    required init(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
