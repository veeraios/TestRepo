#import "TMCooperatorSearchResult.h"
#import "TMGrower.h"

@interface TMCooperatorSearchResult ()
@property(nonatomic, readwrite) NSString *cooperator;
@property(nonatomic, readwrite) NSString *country;
@property(nonatomic, readwrite) NSString *state;
@property(nonatomic, readwrite) NSString *city;
@property(nonatomic, readwrite) NSString *postalCode;
@property(nonatomic) NSManagedObject *searchModelItem;
@end

@implementation TMCooperatorSearchResult
- (instancetype)initWithCooperator:(NSManagedObject *)cooperator cooperatorCategory:(CooperatorCategory)cooperatorCategory {
  TMGrower *grower = Grower == cooperatorCategory ? (TMGrower *) cooperator : nil;
  TMDealer *dealer = Dealer == cooperatorCategory ? (TMDealer *) cooperator : nil;
  if (self = [super init]) {
    self.cooperator = (Grower == cooperatorCategory ? grower.name : dealer.name);
    self.country = (Grower == cooperatorCategory ? grower.country : dealer.country);
    self.state = (Grower == cooperatorCategory ? grower.state : dealer.state);
    self.city = (Grower == cooperatorCategory ? grower.city : dealer.city);
    self.postalCode = (Grower == cooperatorCategory ? grower.postalCode : dealer.postalCode);
    self.searchModelItem = (Grower == cooperatorCategory ? grower : dealer);
  }
  return self;
}

@end