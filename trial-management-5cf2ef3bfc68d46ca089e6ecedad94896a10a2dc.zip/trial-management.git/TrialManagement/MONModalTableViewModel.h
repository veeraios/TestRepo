@protocol MONModalTableViewModel <NSObject>
- (NSInteger)numberOfItems;
- (NSString *)nameForItemAtIndex:(NSInteger)index;
- (id)objectForItemAtIndex:(NSInteger)index;
@end