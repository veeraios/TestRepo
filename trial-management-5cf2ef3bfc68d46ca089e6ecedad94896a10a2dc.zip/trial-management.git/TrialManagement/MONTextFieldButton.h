#import <UIKit/UIKit.h>

@interface MONTextFieldButton : UIButton

- (void)setPlaceholderText:(NSString *)placeholderText;

@end
