#import "TMHarvestInfoViewController.h"
#import "MONFonts.h"
#import "MONDimensions.h"

@interface TMHarvestInfoViewController ()

@property (nonatomic) UITextField *headerTextField;
@property (nonatomic) UITextView *infoTextView;

@property (nonatomic) UITextField *noteHeaderField;
@property (nonatomic) UITextView *noteTextView;

@end

@implementation TMHarvestInfoViewController

- (instancetype)initWithCropName:(NSString *)cropName {
    self = [super init];
    if (self) {
        self.headerTextField = [[UITextField alloc]init];
        [self.headerTextField setFont:[UIFont fontWithName:OpenSansBold size:14]];
        [self.headerTextField setText:@"There are two ways to enter Yield data:"];
        [self.headerTextField setEnabled:NO];
        [self.view addSubview:self.headerTextField];
        
        self.infoTextView = [[UITextView alloc]init];
        [self.infoTextView setBackgroundColor:[UIColor whiteColor]];
        [self.infoTextView setFont:[UIFont fontWithName:OpenSans size:14]];
        [self.infoTextView setScrollEnabled:NO];
        [self.infoTextView setEditable:NO];
        [self.infoTextView setText:@"The yield value is automatically calculated if all plot level values (dimensions, plot weight, and moisture) are entered and saved. Alternatively, you may enter a yield value and moisture directly. Two yield values must be present before the plot statistics are available."];
        [self.view addSubview:self.infoTextView];
        
        self.noteHeaderField = [[UITextField alloc]init];
        [self.noteHeaderField setFont:[UIFont fontWithName:OpenSansBold size:14]];
        [self.noteHeaderField setText:@"Note for Cotton and Silage:"];
        [self.noteHeaderField setEnabled:NO];
        
        self.noteTextView = [[UITextView alloc]init];
        [self.noteTextView setBackgroundColor:[UIColor whiteColor]];
        [self.noteTextView setFont:[UIFont fontWithName:OpenSans size:14]];
        [self.noteTextView setScrollEnabled:NO];
        [self.noteTextView setEditable:NO];
        [self.noteTextView setText:@"The final yield values are dependent on lab assay or HVI data and will not appear until a process has completed outside of Trial Management."];
        
        if ([cropName isEqualToString:@"CORN-SILAGE"] || [cropName isEqualToString:@"COTTON"]) {
            [self.view addSubview:self.noteHeaderField];
            [self.view addSubview:self.noteTextView];
        }
        
        [self.view setBackgroundColor:[UIColor whiteColor]];
    }
    return self;
}

- (void)viewWillAppear:(BOOL)animated {
	[super viewWillAppear:animated];
	
    CGSize textViewSize = CGSizeMake(CGRectGetWidth(self.view.bounds) - (MONDimensionsSmallPadding * 2.0), MAXFLOAT);
    
    [self.headerTextField sizeToFit];
    [self.noteHeaderField sizeToFit];
    
    CGSize infoViewSize = [self.infoTextView sizeThatFits:textViewSize];
    CGSize noteViewSize = [self.noteTextView sizeThatFits:textViewSize];
    
    self.headerTextField.frame = CGRectMake(MONDimensionsSmallPadding, MONDimensionsSmallPadding, CGRectGetWidth(self.view.bounds), CGRectGetHeight(self.headerTextField.bounds));
    
    self.infoTextView.frame = CGRectMake(MONDimensionsSmallPadding,
                                         CGRectGetMaxY(self.headerTextField.frame),
                                         infoViewSize.width,
                                         infoViewSize.height);
    
    self.noteHeaderField.frame = CGRectMake(MONDimensionsSmallPadding,
                                            CGRectGetMaxY(self.infoTextView.frame) + MONDimensionsSmallPadding,
                                            CGRectGetWidth(self.view.bounds),
                                            CGRectGetHeight(self.noteHeaderField.bounds));
    
    self.noteTextView.frame = CGRectMake(MONDimensionsSmallPadding,
                                         CGRectGetMaxY(self.noteHeaderField.frame),
                                         noteViewSize.width,
                                         noteViewSize.height);
}

@end
