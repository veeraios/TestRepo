#import "MONTabMenuButton.h"
#import "MONDimensions.h"
#import "UIColor+MONThemeColorProvider.h"

@implementation MONTabMenuButton

- (id)initWithFrame:(CGRect)frame {
	self = [super initWithFrame:frame];
	if (self) {
		[self setTitleColor:[UIColor colorForThemeComponentType:MONThemeComponentTypeText] forState:UIControlStateNormal];
		self.backgroundColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeBackground];
		self.layer.borderColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeTabMenuButtonBorder].CGColor;
		self.layer.borderWidth = MONDimensionsThickBorderWidth;
	}
	return self;
}

- (void)setSelected:(BOOL)selected {
	self.backgroundColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeBackground];
}


@end
