//
//  TMProductsSearchTable.h
//  TrialManagement
//
//  Created by SINGH, SUPREET [AG/1000] on 11/10/14.
//  Copyright (c) 2014 Monsanto. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "TMFilterProductsModel.h"

@protocol TMFilterProductsTableSelectionDelegate <NSObject>

- (void)didSelectProduct;

@end

@interface TMFilterProductsTable : NSObject<UITableViewDataSource, UITableViewDelegate>

-(instancetype)init UNAVAILABLE_ATTRIBUTE;
-(instancetype)initWithFilterProductsModel:(TMFilterProductsModel *)filterProductsModel;

@property (nonatomic,weak) id<TMFilterProductsTableSelectionDelegate> delegate;
@end
