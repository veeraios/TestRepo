#import "TMGlobalMenuItemButton.h"
#import "MONDimensions.h"
#import "MONFonts.h"
#import "UIColor+MONThemeColorProvider.h"

@interface TMGlobalMenuItemButton()

@property (nonatomic) UIImageView *lockImage;

@end

@implementation TMGlobalMenuItemButton

- (instancetype)initWithTitle:(NSString *)title image:(UIImage *)image {
	self = [super init];
	if (self) {
		self.backgroundColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeTabButtonBackground];
		self.titleLabel.font = [UIFont fontWithName:OpenSansSemibold size:12.0];
        self.imageView.contentMode = UIViewContentModeCenter;
		self.titleLabel.textAlignment = NSTextAlignmentCenter;
		self.titleLabel.numberOfLines = 0;
        [self setTitle:title forState:UIControlStateNormal];
		[self setImage:image forState:UIControlStateNormal];
        self.lockImage = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"ui-icon-lock"]];
        self.lockImage.alpha = 0;
        [self addSubview:self.lockImage];
	}
	return self;
}

- (void)layoutSubviews {
	[super layoutSubviews];
	
	self.imageView.frame = CGRectMake(0.0, MONDimensionsSmallPadding, CGRectGetWidth(self.bounds), CGRectGetHeight(self.imageView.frame));
	
	self.titleLabel.frame = CGRectMake(0.0,
									   CGRectGetMaxY(self.imageView.frame),
									   CGRectGetWidth(self.bounds),
									   CGRectGetHeight(self.bounds) - CGRectGetMaxY(self.imageView.frame));
    
    self.lockImage.frame = CGRectMake(CGRectGetMaxX(self.bounds) / 2.0 - CGRectGetWidth(self.lockImage.frame) / 2.0,
                                      CGRectGetMaxY(self.bounds) / 2.0 - CGRectGetHeight(self.lockImage.frame) / 2.0,
                                      CGRectGetWidth(self.lockImage.frame), CGRectGetHeight(self.lockImage.frame));
}

- (void)setSelected:(BOOL)selected {
	[super setSelected:selected];
	self.backgroundColor = selected ? [UIColor colorForThemeComponentType:MONThemeComponentTypeSelectedTabButtonBackground] : [UIColor colorForThemeComponentType:MONThemeComponentTypeTabButtonBackground];
}

-(void)setEnabled:(BOOL)enabled {
    [super setEnabled:enabled];
    if (!enabled) {
        self.alpha = 0.6;
        self.lockImage.alpha = 1;
    } else {
        self.alpha = 1;
        self.lockImage.alpha = 0;
    }
}

@end
