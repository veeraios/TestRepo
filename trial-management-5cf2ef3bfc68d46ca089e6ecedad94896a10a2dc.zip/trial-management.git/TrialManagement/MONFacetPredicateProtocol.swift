import Foundation

@objc protocol MONFacetPredicateProtocol: class {
    func facetPredicateWithText(text: String?) -> NSPredicate
}