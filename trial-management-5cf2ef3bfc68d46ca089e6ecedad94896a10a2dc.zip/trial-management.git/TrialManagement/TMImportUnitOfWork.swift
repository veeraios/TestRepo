//
//  TMImportUnitOfWork.swift
//  TrialManagement
//
//  Created by GADIRAJU, PRANEETH [AG/1000] on 1/22/15.
//  Copyright (c) 2015 Monsanto. All rights reserved.
//

private let _sharedInstance = TMImportUnitOfWork()

@objc protocol TMImportUnitOfWorkProtocol{
    var trialRepository:TMTrialRepositoryProtocol {get}
}
@objc class TMImportUnitOfWork:TMImportUnitOfWorkProtocol {
    var context:TMImportCoreDataContextProtocol

    class var sharedInstance: TMImportUnitOfWork {
        return _sharedInstance
    }
    
    var trialRepository:TMTrialRepositoryProtocol {
        get{
          return TMTrialRepository(context: context, withModel:TMTrial.self)
        }
    }
    
    init() {
       context = TMTrialImportCoreDataContext()
    }
    
    func findTrial(trialId:Int64) -> TMTrial? {
        let predicate = NSPredicate(format:"trialId = '\(trialId)'")!
        let entity: NSManagedObject? = (context.findWithPredicate("TMTrial", wherePredicate: predicate, orderBy: "trialId", ascending: false))?.first as? NSManagedObject
        return entity as? TMTrial
    }
	
	func deleteTrial(trial:TMTrial){
	    context.deleteTrial(trial)
	}

	
    func mainThreadObjectContext() -> NSManagedObjectContext {
        return context.mainObjectContext()
    }
}
