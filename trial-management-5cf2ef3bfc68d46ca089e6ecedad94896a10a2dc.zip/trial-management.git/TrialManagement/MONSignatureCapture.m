#import "MONSignatureCapture.h"

@interface MONSignatureCapture ()

@property (assign) BOOL hasContent;
@property (nonatomic) UIBezierPath *bezierPath;
@property (nonatomic) NSMutableArray *signaturePaths;
@property (nonatomic) NSMutableArray *currentPath;
@property (nonatomic) CGPoint previousPoint;
@end

@implementation MONSignatureCapture


- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.bezierPath = [UIBezierPath bezierPath];
        self.signaturePaths = [[NSMutableArray alloc] init];
        self.hasContent = NO;
        UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(pan:)];
        pan.maximumNumberOfTouches = pan.minimumNumberOfTouches = 1;
        [self addGestureRecognizer:pan];
        self.pathColor = [UIColor blackColor];
        self.backgroundColor = [UIColor whiteColor];
    }
    return self;
}

- (void)drawRect:(CGRect)rect {
    [self.pathColor setStroke];
    [self.bezierPath stroke];
}

- (void)pan:(UIPanGestureRecognizer *)pan {
    CGPoint currentPoint = [pan locationInView:self];
    CGPoint midPoint = [self makeMidPoint:self.previousPoint point:currentPoint];
    if (pan.state == UIGestureRecognizerStateBegan) {
        [self.bezierPath moveToPoint:currentPoint];
        self.currentPath = [NSMutableArray arrayWithObject:[NSValue valueWithCGPoint:currentPoint]];
    } else if (pan.state == UIGestureRecognizerStateChanged) {
        [self.bezierPath addQuadCurveToPoint:midPoint controlPoint:self.previousPoint];
        [self.currentPath addObject:[NSValue valueWithCGPoint:midPoint]];
        [self.currentPath addObject:[NSValue valueWithCGPoint:currentPoint]];
    } else if (pan.state == UIGestureRecognizerStateEnded) {
        if (self.currentPath != nil) {
            [self.signaturePaths addObject: self.currentPath];
            self.hasContent = YES;
        }
    }
    self.previousPoint = currentPoint;
    [self setNeedsDisplay];
}

-(CGPoint)makeMidPoint:(CGPoint)p1 point:(CGPoint) p2 {
	CGFloat x =  (p1.x + p2.x) / 2.0;
	CGFloat y = (p1.y + p2.y) / 2.0;
	return CGPointMake(x, y);
}

- (UIImage*)signatureImage {
    UIGraphicsBeginImageContext(self.bounds.size);
    [self.layer renderInContext:UIGraphicsGetCurrentContext()];
    UIImage *currentImageContext = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return currentImageContext;
}

- (void)clearImage {
	self.hasContent = NO;
    self.bezierPath = [UIBezierPath bezierPath];
    self.signaturePaths = [[NSMutableArray alloc] init];
    [self setNeedsDisplay];
}

-(void)saveImage:(NSString*)path as:(SignatureCaptureImageType) type {
	if(self.hasContent == NO) {
		return;
	}
	NSData * binaryImageData = nil;
	if(type == SignatureCapturePNG) {
		binaryImageData = UIImagePNGRepresentation([self signatureImage]);
	} else if(type == SignatureCaptureJPEG ) {
		binaryImageData = UIImageJPEGRepresentation([self signatureImage], 1);
	}
	if(binaryImageData != nil) {
		[binaryImageData writeToFile:path atomically:YES];
	}
}

- (NSString*)stringFromSignaturePath {
    NSString *rtnString = @"";
    for (NSArray *pathArray in self.signaturePaths) {
        for(NSValue *pointValue in pathArray){
			rtnString = [rtnString stringByAppendingString:NSStringFromCGPoint([pointValue CGPointValue])];
        }
    }
    return rtnString;
}
@end
