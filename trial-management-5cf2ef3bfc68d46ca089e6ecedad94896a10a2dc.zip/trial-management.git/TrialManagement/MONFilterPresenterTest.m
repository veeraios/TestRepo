#import "MONFilterPresenter.h"

@interface MONFilterPresenterTest : XCTestCase

@property (nonatomic) MONFilterPresenter *testObject;
@property (nonatomic) id mockFilterView;
@property (nonatomic) id mockFilterModel;
@property (nonatomic) id mockFilter;

@end

@implementation MONFilterPresenterTest

- (void)setUp {
	[super setUp];
	
    //Note: Partial mocks are temporary workaround after updating Pods, when ESCObservable is removed entirely from project
    //should switch back to niceMocks.
    self.mockFilter = [OCMockObject niceMockForProtocol:@protocol(MONFilter)];
    
    self.mockFilterView = [OCMockObject partialMockForObject:[[MONFilterView alloc] initWithFrame:CGRectZero]];
    [self.mockFilterView escRegisterObserverProtocol:@protocol(MONFilterViewObserver)];
	
    self.mockFilterModel = [OCMockObject partialMockForObject:[[MONFilterModel alloc]initWithFilter:self.mockFilter]];
    [self.mockFilterModel escRegisterObserverProtocol:@protocol(MONFilterModelObserver)];
	
	self.testObject = [[MONFilterPresenter alloc] initWithFilterView:self.mockFilterView filterModel:self.mockFilterModel];
}

- (void)testFilterViewTextDidChange_NotifiesModel {
	NSString *expectedFilterText = @"abc1234";
	[[self.mockFilterModel expect] filterItemsWithText:expectedFilterText];
	
	[[self.mockFilterView escNotifier] filterTextDidChange:expectedFilterText];
	
	[self.mockFilterModel verify];
}

- (void)testCancelButtonTapped_NotifiesModel {
	[[self.mockFilterModel expect] cancelFilter];
	
	[[self.mockFilterView escNotifier] filterCloseButtonTapped];
	
	[self.mockFilterModel verify];
}

- (void)testFilterCancelled_SetsViewFilterTextToEmptyString {
	[[self.mockFilterView expect] setFilterText:@""];
	
	[[self.mockFilterModel escNotifier] filterCancelled];
	
	[self.mockFilterView verify];
}

@end
