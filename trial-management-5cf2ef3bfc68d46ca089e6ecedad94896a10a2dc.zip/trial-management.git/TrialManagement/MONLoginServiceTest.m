#import "MONLoginService.h"
#import <MNetworking/MNetWAMAccessManager.h>

@interface MONLoginServiceTest : XCTestCase

@property (nonatomic) MONLoginService *testObject;
@property (nonatomic) id mockWAMAccessManager;

@end

@implementation MONLoginServiceTest

- (void)setUp {
	[super setUp];
	
	self.mockWAMAccessManager = [OCMockObject niceMockForClass:[MNetWAMAccessManager class]];
	
	self.testObject = [[MONLoginService alloc] initWithNetAccessManager:self.mockWAMAccessManager];
}

- (void)testLoginWithUsername_DelegatesToWAMAccessManager {
	NSString *expectedUsername = @"username";
	NSString *expectedPassword = @"password";
	void (^expectedSuccessBlock)(void) = ^{};
	void (^expectedFailureBlock)(NSError *) = ^(NSError *error){};
	[[self.mockWAMAccessManager expect] loginWithUsername:expectedUsername password:expectedPassword successBlock:expectedSuccessBlock failureBlock:expectedFailureBlock];
	
	[self.testObject loginWithUsername:expectedUsername password:expectedPassword successBlock:expectedSuccessBlock failureBlock:expectedFailureBlock];
	
	[self.mockWAMAccessManager verify];
}

- (void)testUserIsAuthenticated_DelegatesToWAMAccessManager {
	[[self.mockWAMAccessManager expect] isLoggedIn];
	
	[self.testObject userIsAuthenticated];
	
	[self.mockWAMAccessManager verify];
}

- (void)testLogout_DelegatesToWAMAccessManager {
	[[self.mockWAMAccessManager expect] logout];
	
	[self.testObject logout];
	
	[self.mockWAMAccessManager verify];
}

@end
