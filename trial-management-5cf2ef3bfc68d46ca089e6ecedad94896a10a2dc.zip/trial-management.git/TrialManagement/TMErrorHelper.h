@interface TMErrorHelper : NSObject

+ (BOOL)isServiceError:(NSError *)error;

+ (NSString *)extractErrorMessage:(NSError *)error;

@end
