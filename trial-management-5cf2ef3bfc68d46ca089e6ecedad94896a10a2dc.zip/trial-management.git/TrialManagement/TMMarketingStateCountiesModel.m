#import "TMMarketingStateCountiesModel.h"

const NSInteger TM_NO_SELECTION_LIMIT = -1;

@interface TMMarketingStateCountiesModel()
@property (readwrite, nonatomic) TMMarketingSubmissionType marketingSubmission;
@property (nonatomic) NSMutableArray *selectedCountiesArray;
@property (nonatomic) TMStatesModel *statesModel;
@property (nonatomic) NSInteger maxSelections;
@property (nonatomic) TMState *plotState;
@property (nonatomic) NSArray *previouslySelectedCounties;
@end

@implementation TMMarketingStateCountiesModel
- (instancetype)initWithStatesModel:(TMStatesModel *)statesModel plotStateName:(NSString*)plotStateName previouslySelectedCounties:(NSArray*)previouslySelectedCounties marketingSubmission:(TMMarketingSubmissionType)marketingSubmission {
	return [self initWithStatesModel:statesModel maxSelections:TM_NO_SELECTION_LIMIT plotStateName:plotStateName previouslySelectedCounties:previouslySelectedCounties marketingSubmission:marketingSubmission];
}

- (instancetype)initWithStatesModel:(TMStatesModel *)statesModel maxSelections:(NSInteger)maxSelections plotStateName:(NSString*)plotStateName previouslySelectedCounties:(NSArray*)previouslySelectedCounties marketingSubmission:(TMMarketingSubmissionType)marketingSubmission {
	self = [super init];
	if(self) {
		self.marketingSubmission = marketingSubmission;
		if(previouslySelectedCounties && [previouslySelectedCounties count] > 0) {
			self.selectedCountiesArray = [[NSMutableArray alloc] initWithArray:previouslySelectedCounties];
		} else {
			self.selectedCountiesArray = [NSMutableArray array];
		}
		self.statesModel = statesModel;
		self.maxSelections = maxSelections;
		self.plotState = [self.statesModel stateForStateName:plotStateName];
	}
	return self;
}

- (NSString*)plotStateName {
	return self.plotState.name;
}

- (NSInteger)indexForPlotStateName {
	NSInteger index = [self.statesModel indexForStateName:self.plotState.name];
	if(self.plotState == nil || [self.plotState.name length ] == 0 || index == NSNotFound) {
		return 0; //if they haven't selected a plot state, pre-default the first one
	}
	return index;
}

- (NSArray*)selectedCounties {
	return self.selectedCountiesArray;
}

- (BOOL)canSelectMoreCounties {
	if(self.maxSelections == TM_NO_SELECTION_LIMIT) {
		return true;
	}
	return self.maxSelections > [self.selectedCountiesArray count];
}

- (void)selectCounty:(NSInteger)countyIndex forStateIndex:(NSInteger)stateIndex {
	[self.selectedCountiesArray addObject:[[self.statesModel countiesForStateIndex:stateIndex] objectAtIndex:countyIndex]];
}

- (BOOL)isPreviouslySelected:(NSInteger)index stateIndex:(NSInteger)stateIndex {
	return [self.selectedCountiesArray containsObject: [[self.statesModel countiesForStateIndex:stateIndex] objectAtIndex:index]];
}

- (NSString*)countyNameForCountyIndex:(NSInteger)index stateIndex:(NSInteger)stateIndex {
	return  [[self.statesModel countiesForStateIndex:stateIndex] nameForItemAtIndex:index];
}

- (NSInteger)numberOfCountiesForStateIndex:(NSInteger)stateIndex {
	return [[self.statesModel countiesForStateIndex:stateIndex] numberOfItems];
}

- (void)deselectCounty:(NSInteger)index forStateIndex:(NSInteger)stateIndex {
	TMCountiesModel *countiesModel = [self.statesModel countiesForStateIndex:stateIndex];
	TMCounty *foo = [countiesModel objectAtIndex:index];
	[self.selectedCountiesArray removeObject:foo];
}

@end
