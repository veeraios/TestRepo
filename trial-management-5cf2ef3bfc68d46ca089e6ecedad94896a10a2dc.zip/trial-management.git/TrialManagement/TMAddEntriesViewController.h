#import "TMSelectedEntriesModel.h"
#import "TMTrialModel.h"

@interface TMAddEntriesViewController : UIViewController

- (instancetype)initWithSelectedEntriesModel:(TMSelectedEntriesModel *)selectedEntriesModel trialModel:(TMTrialModel *)trialModel;
- (void)addSelectedProductsIfNotAdded;

@end
