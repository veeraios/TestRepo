#import "TMDealerRepository.h"
#import "TMDealer.h"
#import "NSManagedObject+TMCoreDataTestHelper.h"
#import "TMWorkingCoreDataContext.h"
#import "TMUserManager.h"

@interface TMDealerRepositoryTest : XCTestCase
@end

@implementation TMDealerRepositoryTest

-(void)setUpUserForImportTest:(NSObject<MONRepositoryProtocol>*)repo {
	//todo: move to import Test helpers
	TMUserManager *manager = [TMUserManager sharedInstance];
	manager.currentUsername = @"test";
	TMUser *user = [TMUser create];
	user.userId = manager.currentUsername;
	[user.managedObjectContext save:nil];
	id mock = [OCMockObject partialMockForObject:repo];
	[[[mock stub] andReturn:user] currentUser];
}

- (void)testSyncFromService {
	TMWorkingCoreDataContext *context = [[TMWorkingCoreDataContext alloc] init];
	id mockContext = [OCMockObject partialMockForObject:context];
	[[mockContext stub] saveContext];

	TMDealerRepository *repo = [[TMDealerRepository alloc] initWithContext:context withModel:[TMDealer class]];
	[self setUpUserForImportTest:repo];
	
	[repo syncFromService:@[
							@{
								@"id": @879543688397324,
								@"name": @"\"Krolevetskuy komb. zavod\"",
								@"city": @"Krolevets",
								@"address": @"123 Fake St.|PO Box Inf.",
								@"state": @"CO",
								@"country": @"USA",
								@"postalCode": @"76566",
								@"phoneNumber": [NSNull null],
								@"faxNumber": [NSNull null],
								@"email": [NSNull null],
								@"accountId": [NSNull null],
								@"category": @"Dealer"
								}] completionBlock:nil];
	
	TMDealer *actual = [[context find:NSStringFromClass([TMDealer class]) where:@"dealerId = 879543688397324"] firstObject];
	XCTAssert(actual != nil);
	XCTAssertEqualObjects(actual.name,  @"\"Krolevetskuy komb. zavod\"");
	XCTAssertEqualObjects(actual.city, @"Krolevets");
	XCTAssertEqualObjects(actual.address1, @"123 Fake St.");
    XCTAssertEqualObjects(actual.address2, @"PO Box Inf.");
	XCTAssertEqualObjects(actual.state, @"CO");
	XCTAssertEqualObjects(actual.country, @"USA");
	XCTAssertEqualObjects(actual.postalCode, @"76566");
	XCTAssertEqualObjects(actual.phoneNumber, @"");
	XCTAssertEqualObjects(actual.faxNumber, @"");
	XCTAssertEqualObjects(actual.email, @"");
	XCTAssertEqualObjects(actual.accountId, @"");
	XCTAssertEqualObjects(actual.category, @"Dealer");
	
}

-(void)testSearchDealer {
	TMWorkingCoreDataContext *context = [[TMWorkingCoreDataContext alloc] init];
	TMDealer *dealerToFind = [context attachObject:[TMDealer class]];
	dealerToFind.name = @"123123123test123123123123123123";
	id mockContext = [OCMockObject partialMockForObject:context];
	[[mockContext stub] saveContext];
	
	TMDealerRepository *repo = [[TMDealerRepository alloc] initWithContext:context withModel:[TMDealer class]];
	NSArray *result = [repo searchDealer:dealerToFind.name];
	XCTAssertEqual(1, [result count]);
	XCTAssertEqualObjects(dealerToFind, [result objectAtIndex:0]);
}
@end
