#import <CoreData/CoreData.h>

@interface NSManagedObject (MONFilename)

- (NSString *)filenameFromObjectId;

@end
