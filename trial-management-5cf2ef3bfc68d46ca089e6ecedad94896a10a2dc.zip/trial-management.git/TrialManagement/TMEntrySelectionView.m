//
//  TMEntrySelectionView.m
//  TrialManagement
//
//  Created by SINGH, SUPREET [AG/1000] on 11/10/14.
//  Copyright (c) 2014 Monsanto. All rights reserved.
//

#import "TMEntrySelectionView.h"
#import "MONButton.h"
#import "MONLabel.h"
#import "MONLabeledTextField.h"
#import "MONFonts.h"
#import "MONDimensions.h"
#import "MONBorderedButton.h"
#import "UIColor+MONThemeColorProvider.h"
#import "TrialManagement-Swift.h"

static const CGFloat HeaderLabelOffset = 7.0;
static const CGFloat LeftLabelWidth = 60.0;
static const CGFloat LeftLabeledTextFieldWidth = LeftLabelWidth + 280.0;
static const CGFloat RightLabelWidth = 125.0;

@interface TMEntrySelectionView ()<MONLabeledTextFieldDelegate>

@property (nonatomic) UITapGestureRecognizer *tapGestureRecognizer;
@property (nonatomic) MONLabel *searchCriteriaHeaderLabel;
@property (nonatomic) MONLabeledTextField *brandLabeledTextField;
@property (nonatomic) MONLabeledTextField *productLabeledTextField;
@property (nonatomic) MONLabeledTextField *traitsLabeledTextField;
@property (nonatomic) MONLabeledTextField *rmLabeledTextField;
@property (nonatomic) MONLabeledTextField *rmVarianceLabeledTextField;
@property (nonatomic) UIView *dividerBorderView;
@property (nonatomic) TMQueuedProductsSearchResultsHeaderView *searchResultsHeaderView;
@property (nonatomic) UITableView *searchResultsTableView;
@property (nonatomic, weak) NSObject<TMFilterProductsViewDelegate> *filterProductsViewDelegate;
@property (nonatomic) BOOL willReplaceEntry;
@property (nonatomic) NSTimer *searchTimer;
@end

@implementation TMEntrySelectionView

- (instancetype)initWithSearchResultsTableView:(UITableView *)searchResultsTableView selectedBrand:(NSString *)selectedBrand willReplaceEntry:(BOOL)willReplaceEntry {
    self = [super init];
    if (self) {
        self.willReplaceEntry = willReplaceEntry;
        
        self.backgroundColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeBackground];
        
        self.tapGestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(mainViewTapped)];
        self.tapGestureRecognizer.cancelsTouchesInView = NO;
        [self addGestureRecognizer:self.tapGestureRecognizer];
        
        self.searchCriteriaHeaderLabel = [[MONLabel alloc] init];
        self.searchCriteriaHeaderLabel.text = self.willReplaceEntry ? @"SEARCH AND REPLACE PRODUCT" : @"SEARCH PRODUCTS";
        self.searchCriteriaHeaderLabel.font = [UIFont fontWithName:OpenSansLight size:MONFontsHeaderTextSize];
        [self addSubview:self.searchCriteriaHeaderLabel];
        
        self.brandLabeledTextField = [self labeledTextFieldWithLabelText:@"Brand"];
        [self.brandLabeledTextField setValueText:selectedBrand];
        [self addSubview:self.brandLabeledTextField];
        
        self.productLabeledTextField = [self labeledTextFieldWithLabelText:@"Product"];
        [self addSubview:self.productLabeledTextField];
        
        self.traitsLabeledTextField = [self labeledTextFieldWithLabelText:@"Trait(s)"];
        [self addSubview:self.traitsLabeledTextField];
        
        self.rmLabeledTextField = [self labeledTextFieldWithLabelText:@"RM"];
        [self.rmLabeledTextField setKeyboardType:UIKeyboardTypeDecimalPad];
        [self.rmLabeledTextField allowOnlyNumbers:YES];
        [self addSubview:self.rmLabeledTextField];
        
        self.rmVarianceLabeledTextField = [self labeledTextFieldWithLabelText:@"+/-"];
        [self.rmVarianceLabeledTextField setKeyboardType:UIKeyboardTypeDecimalPad];
        [self.rmVarianceLabeledTextField allowOnlyNumbers:YES];
        [self addSubview:self.rmVarianceLabeledTextField];
        
        self.dividerBorderView = [[UIView alloc] init];
        self.dividerBorderView.backgroundColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeBorder];
        [self addSubview:self.dividerBorderView];
        
        if (self.willReplaceEntry) {
            self.searchResultsHeaderView = [[TMQueuedProductsSearchResultsHeaderView alloc] initWithAvailableProductsTitle:@"AVAILABLE PRODUCTS TO REPLACE"];
        } else {
            self.searchResultsHeaderView = [[TMQueuedProductsSearchResultsHeaderView alloc] initWithAvailableProductsTitle:@"AVAILABLE PRODUCTS" queuedProductsTitle:@"ADDED PRODUCTS"];
        }
        
        if (!self.willReplaceEntry) {
            MONBorderedButton *requestNewProductButton = [[MONBorderedButton alloc] init];
            [requestNewProductButton addTarget:self action:@selector(requestNewProductButtonTapped) forControlEvents:UIControlEventTouchUpInside];
            [requestNewProductButton setTitle:@"REQUEST NEW" forState:UIControlStateNormal];
            
            MONButton *addProductButton = [[MONButton alloc] init];
            [addProductButton setTitle:@"Add" forState:UIControlStateNormal];
            [addProductButton addTarget:self action:@selector(addProductsButtonTapped) forControlEvents:UIControlEventTouchUpInside];
            
            [self.searchResultsHeaderView setRightButtons:@[requestNewProductButton,addProductButton]];
        }
        
        [self addSubview:self.searchResultsHeaderView];
        
        self.searchResultsTableView = searchResultsTableView;
        self.searchResultsTableView.backgroundColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeBackground];
        self.searchResultsTableView.separatorInset = UIEdgeInsetsZero;
        self.searchResultsTableView.separatorColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeBorder];
        self.searchResultsTableView.layer.borderColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeBorder].CGColor;
        self.searchResultsTableView.layer.borderWidth = MONDimensionsThinBorderWidth;
        self.searchResultsTableView.layer.cornerRadius = MONDimensionsCornerRadius;
        [self addSubview:self.searchResultsTableView];
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    
    CGRect contentRect = UIEdgeInsetsInsetRect(self.bounds, UIEdgeInsetsMake(MONDimensionsLargePadding, MONDimensionsSmallPadding, MONDimensionsSmallPadding, MONDimensionsSmallPadding));
    
    [self.searchCriteriaHeaderLabel sizeToFit];
    self.searchCriteriaHeaderLabel.frame = CGRectMake(CGRectGetMinX(contentRect),
                                                      CGRectGetMinY(contentRect) - HeaderLabelOffset,
                                                      CGRectGetWidth(self.searchCriteriaHeaderLabel.frame),
                                                      CGRectGetHeight(self.searchCriteriaHeaderLabel.frame));
    
    CGSize brandLabeledTextFieldSize = [self.brandLabeledTextField sizeThatFits:contentRect.size];
    [self.brandLabeledTextField setLabelWidth:LeftLabelWidth];
    self.brandLabeledTextField.frame = CGRectMake(CGRectGetMinX(contentRect),
                                                  CGRectGetMaxY(self.searchCriteriaHeaderLabel.frame) + MONDimensionsSmallPadding,
                                                  CGRectGetWidth(contentRect),
                                                  brandLabeledTextFieldSize.height);
    
    CGSize productLabeledTextFieldSize = [self.productLabeledTextField sizeThatFits:contentRect.size];
    [self.productLabeledTextField setLabelWidth:LeftLabelWidth];
    self.productLabeledTextField.frame = CGRectMake(CGRectGetMinX(contentRect),
                                                    CGRectGetMaxY(self.brandLabeledTextField.frame) + MONDimensionsLargePadding,
                                                    LeftLabeledTextFieldWidth,
                                                    productLabeledTextFieldSize.height);
    
    CGSize traitsLabeledTextFieldSize = [self.traitsLabeledTextField sizeThatFits:contentRect.size];
    [self.traitsLabeledTextField setLabelWidth:RightLabelWidth];
    self.traitsLabeledTextField.frame = CGRectMake(CGRectGetMaxX(self.productLabeledTextField.frame),
                                                   CGRectGetMaxY(self.brandLabeledTextField.frame) + MONDimensionsLargePadding,
                                                   CGRectGetWidth(contentRect) - CGRectGetWidth(self.productLabeledTextField.frame),
                                                   traitsLabeledTextFieldSize.height);
    
    CGSize rmLabeledTextFieldSize = [self.rmLabeledTextField sizeThatFits:contentRect.size];
    [self.rmLabeledTextField setLabelWidth:LeftLabelWidth];
    self.rmLabeledTextField.frame = CGRectMake(CGRectGetMinX(contentRect),
                                               CGRectGetMaxY(self.productLabeledTextField.frame) + MONDimensionsLargePadding,
                                               LeftLabeledTextFieldWidth,
                                               rmLabeledTextFieldSize.height);
    
    CGSize rmPlusMinusLabeledTextFieldSize = [self.rmVarianceLabeledTextField sizeThatFits:contentRect.size];
    [self.rmVarianceLabeledTextField setLabelWidth:RightLabelWidth];
    self.rmVarianceLabeledTextField.frame = CGRectMake(CGRectGetMaxX(self.rmLabeledTextField.frame),
                                                       CGRectGetMaxY(self.traitsLabeledTextField.frame) + MONDimensionsLargePadding,
                                                       CGRectGetWidth(contentRect) - CGRectGetWidth(self.rmLabeledTextField.frame),
                                                       rmPlusMinusLabeledTextFieldSize.height);
    
    self.dividerBorderView.frame = CGRectMake(CGRectGetMinX(contentRect),
                                              CGRectGetMaxY(self.rmLabeledTextField.frame) + MONDimensionsLargePadding,
                                              CGRectGetWidth(contentRect),
                                              MONDimensionsThinBorderWidth);
    
    [self.searchResultsHeaderView sizeToFit];
    self.searchResultsHeaderView.frame = CGRectMake(CGRectGetMinX(contentRect),
                                                    CGRectGetMaxY(self.dividerBorderView.frame),
                                                    CGRectGetWidth(contentRect),
                                                    CGRectGetHeight(self.searchResultsHeaderView.frame));
    
    self.searchResultsTableView.frame = CGRectMake(CGRectGetMinX(contentRect),
                                                   CGRectGetMaxY(self.searchResultsHeaderView.frame),
                                                   CGRectGetWidth(contentRect),
                                                   CGRectGetHeight(contentRect) - CGRectGetMaxY(self.searchResultsHeaderView.frame) + MONDimensionsLargePadding);
}

- (void)setFilterProductsViewDelegate:(NSObject<TMFilterProductsViewDelegate> *)filterProductsViewDelegate {
    _filterProductsViewDelegate = filterProductsViewDelegate;
}

- (void)refreshTableWithNumberOfResults:(NSUInteger)numberOfResults {
    [self setNumberOfSearchResults:numberOfResults];
    [self.searchResultsTableView reloadData];
    [self.dataRefreshDelegate tableDataWasRefreshed];
}

- (MONLabeledTextField *)labeledTextFieldWithLabelText:(NSString *)labelText {
    MONLabeledTextField *labeledTextField = [[MONLabeledTextField alloc] init];
    labeledTextField.delegate = self;
    labeledTextField.label.text = labelText;
    labeledTextField.label.textAlignment = NSTextAlignmentRight;
    [labeledTextField setAutocorrectionType:UITextAutocorrectionTypeNo];
    return labeledTextField;
}

- (void)setNumberOfSearchResults:(NSUInteger)numberOfSearchResults {
    [self.searchResultsHeaderView setNumberOfAvailableProducts:numberOfSearchResults];
}

- (void)resignFirstResponderOnAllFields {
    [self.brandLabeledTextField resignFirstResponder];
    [self.productLabeledTextField resignFirstResponder];
    [self.traitsLabeledTextField resignFirstResponder];
    [self.rmLabeledTextField resignFirstResponder];
    [self.rmVarianceLabeledTextField resignFirstResponder];
}

- (void)mainViewTapped {
    [self resignFirstResponderOnAllFields];
}

- (void)incrementSelectedProducts:(NSUInteger)productCount {
    [self.searchResultsHeaderView incrementQueuedProducts:productCount];
}

-(void)filterProductsBySearchCriteria:(NSTimer *)theTimer {
    MONLabeledTextField *labeledTextField = (MONLabeledTextField *)[theTimer userInfo];
    if (labeledTextField == self.brandLabeledTextField) {
        [self.filterProductsViewDelegate brandSearchTextChanged:[self.brandLabeledTextField textFieldText]];
    } else if (labeledTextField == self.productLabeledTextField) {
        [self.filterProductsViewDelegate productSearchTextChanged:[self.productLabeledTextField textFieldText]];
    } else if (labeledTextField == self.traitsLabeledTextField) {
        [self.filterProductsViewDelegate traitsSearchTextChanged:[self.traitsLabeledTextField textFieldText]];
    } else if (labeledTextField == self.rmLabeledTextField) {
        [self.filterProductsViewDelegate rmSearchTextChanged:[self.rmLabeledTextField textFieldText]];
    } else if (labeledTextField == self.rmVarianceLabeledTextField) {
        [self.filterProductsViewDelegate rmVarianceSearchTextChanged:[self.rmVarianceLabeledTextField textFieldText]];
    }
}

#pragma mark - TMAddNewEntriesSelectionViewDelegate

- (void)addProductsButtonTapped {
    [self.addNewEntriesSelectionViewDelegate addProductsButtonTapped];
}

- (void)requestNewProductButtonTapped {
    [self.addNewEntriesSelectionViewDelegate requestNewButtonTapped];
}

#pragma mark - MONLabeledTextFieldDelegate Methods

- (void)monLabeledTextFieldTextDidChange:(MONLabeledTextField *)labeledTextField {
    if (self.searchTimer && [self.searchTimer isValid]) {
        [self.searchTimer invalidate];
        self.searchTimer = nil;
    }
    self.searchTimer = [NSTimer scheduledTimerWithTimeInterval:0.4 target:self selector:@selector(filterProductsBySearchCriteria:) userInfo:labeledTextField repeats:NO];
    
}

@end
