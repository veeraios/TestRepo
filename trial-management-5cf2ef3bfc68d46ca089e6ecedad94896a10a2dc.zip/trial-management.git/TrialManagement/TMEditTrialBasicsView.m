#import "TMEditTrialBasicsView.h"
#import "MONDimensions.h"
#import "MONHeaderView.h"
#import "UIColor+MONThemeColorProvider.h"

@interface TMEditTrialBasicsView ()

@property (nonatomic) MONHeaderView *headerView;
@property (nonatomic) UICollectionView *collectionView;

@end

@implementation TMEditTrialBasicsView

- (instancetype)initWithCollectionView:(UICollectionView *)collectionView headerButtons:(NSArray *)buttons {
	self = [super init];
	if (self) {
		self.collectionView = collectionView;
		self.collectionView.backgroundColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeBackground];
		self.collectionView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
		[self addSubview:self.collectionView];
		
		self.headerView = [[MONHeaderView alloc] init];
		[self.headerView setRightButtons:buttons];
		[self addSubview:self.headerView];
	}
	return self;
}

- (void)layoutSubviews {
	[super layoutSubviews];

	[self.headerView sizeToFit];
	self.headerView.frame = CGRectMake(0.0, 0.0, CGRectGetWidth(self.bounds), CGRectGetHeight(self.headerView.frame));
	
	self.collectionView.frame = CGRectMake(MONDimensionsSmallPadding,
										   CGRectGetMaxY(self.headerView.frame) + MONDimensionsSmallPadding,
										   CGRectGetWidth(self.bounds) - 2.0 * MONDimensionsSmallPadding,
										   CGRectGetHeight(self.bounds) - CGRectGetMaxY(self.headerView.frame) - MONDimensionsSmallPadding);
}

- (void)setHeaderText:(NSString *)headerText {
	[self.headerView setTitle:headerText];
}

@end
