#import <UIKit/UIKit.h>

@interface MONDefaultStyles : UIView

+ (void)setupDefaultStyles;

@end
