#import "TMReferenceDataListGenericModel.h"
#import "TMUserManager.h"
#import "TMTrialModel.h"

static NSString *const TMRelinquishTrialMessage = @"Relinquish Trial";
static NSString *const TMCancelTrialMessage = @"Cancel Trial";

@protocol TMHarvestActionOptionsListModelProtocol <NSObject>
-(void)relinquishComplete;
-(void)cancelTrialComplete;
@end
@interface TMHarvestActionOptionsListModel : TMReferenceDataListGenericModel
@property (nonatomic, weak) id<TMHarvestActionOptionsListModelProtocol> delegate;
- (instancetype)initWithUserRole:(TMUserRole)userRole trialModel:(TMTrialModel*)trialModel;
- (void)performActionForItemAtIndex:(NSInteger)index;
- (BOOL)harvestActionsAvailable;
@end
