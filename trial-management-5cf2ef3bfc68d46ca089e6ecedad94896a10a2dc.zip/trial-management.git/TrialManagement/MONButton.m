#import "MONButton.h"
#import "MONFonts.h"
#import "UIColor+MONThemeColorProvider.h"

static const CGFloat DefaultMinimumWidth = 100.0;
static const CGFloat DefaultHeight = 28.0;
static const CGFloat DefaultCornerRadius = 5.0;
static const CGFloat DefaultFontSize = 14.0;
static const CGFloat DefaultContentPaddingHorizontal = 14.0;

@implementation MONButton

- (id)initWithTitle:(NSString*)title {
	self = [self init];
	if (self) {
		[self setTitle:title forState:UIControlStateNormal];
	}
	return self;
}
- (id)initWithFrame:(CGRect)frame {
	self = [super initWithFrame:frame];
	if (self) {
		self.backgroundColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeButtonBackground];
		self.layer.cornerRadius = DefaultCornerRadius;
		self.contentEdgeInsets = UIEdgeInsetsMake(4.0, DefaultContentPaddingHorizontal, 4.0, DefaultContentPaddingHorizontal);
		
		self.titleLabel.font = [UIFont fontWithName:OpenSans size:DefaultFontSize];
		self.titleLabel.textAlignment = NSTextAlignmentCenter;
	}
	return self;
}

- (CGSize)sizeThatFits:(CGSize)size {
	CGSize sizeThatFits = [super sizeThatFits:size];
	if (sizeThatFits.width < DefaultMinimumWidth) {
		sizeThatFits.width = DefaultMinimumWidth;
	}
	if (sizeThatFits.height < DefaultHeight) {
		sizeThatFits.height = DefaultHeight;
	}
	return sizeThatFits;
}

- (void)setTitle:(NSString *)title forState:(UIControlState)state {
	[super setTitle:[title uppercaseString] forState:state];
}

-(void)setReadOnly:(BOOL)value {
	[super setUserInteractionEnabled:!value];
	[super setEnabled:!value];
}
@end
