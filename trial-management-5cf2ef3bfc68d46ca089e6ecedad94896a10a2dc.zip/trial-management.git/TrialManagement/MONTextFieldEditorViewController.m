#import "MONTextFieldEditorViewController.h"
#import "MONTextFieldEditorView.h"

@interface MONTextFieldEditorViewController ()<MONTextFieldEditorViewObserver>

@property (nonatomic) MONTextFieldEditorView *textFieldEditorView;
@property (nonatomic) NSString *headerText;

@end

@implementation MONTextFieldEditorViewController

- (void)viewDidLoad {
	[super viewDidLoad];
	
	self.edgesForExtendedLayout = NO;
	
	self.textFieldEditorView = [[MONTextFieldEditorView alloc] init];
    self.textFieldEditorView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
	[self.textFieldEditorView escAddObserver:self];
	[self.view addSubview:self.textFieldEditorView];
}

- (void)viewWillAppear:(BOOL)animated {
	[super viewWillAppear:animated];
	
	[self.textFieldEditorView setHeaderText:self.headerText];
	self.textFieldEditorView.frame = self.view.bounds;
	
	[self.textFieldEditorView setText:self.enteredText];
	[self.textFieldEditorView becomeFirstResponder];
}

- (void)setEnteredText:(NSString *)enteredText {
	_enteredText = enteredText;
	[self.textFieldEditorView setText:[self trimText:enteredText]];
}

- (NSString *)trimText:(NSString *)textToTrim {
	return [textToTrim stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
}

#pragma mark - MONTextFieldEditorViewObserver Methods

- (void)textFieldEditorTextDidChange:(NSString *)text {
	_enteredText = text;
}

@end
