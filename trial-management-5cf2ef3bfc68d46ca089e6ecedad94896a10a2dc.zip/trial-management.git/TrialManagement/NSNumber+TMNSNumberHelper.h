@interface NSNumber (TMNSNumberHelper)

- (NSString *)roundedString:(NSInteger)decimalPlaces;
- (NSString *)roundedStringToTwoDecimalPlaces;
- (id)safeNumber;
- (NSString *)roundedStringWithPrefixPadding:(NSInteger)decimalPlaces;
-(NSString*)jsonBool;
@end
