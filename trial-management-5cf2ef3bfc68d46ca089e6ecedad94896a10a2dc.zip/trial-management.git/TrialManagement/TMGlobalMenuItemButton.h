#import <UIKit/UIKit.h>

@interface TMGlobalMenuItemButton : UIButton

- (instancetype)init UNAVAILABLE_ATTRIBUTE;
- (instancetype)initWithTitle:(NSString *)title image:(UIImage *)image;

@end
