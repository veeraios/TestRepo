#import "MONTabController.h"
#import "TMTrialModel.h"
#import "TMPersistenceViewController.h"

@interface TMMarketingViewController : TMPersistenceViewController<MONTabController>
- (instancetype)initWithTrialModel:(TMTrialModel *)trialModel;
@end
