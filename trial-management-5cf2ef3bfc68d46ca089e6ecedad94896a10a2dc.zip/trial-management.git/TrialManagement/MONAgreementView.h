#import "MONCardContainerView.h"

@protocol MONAgreementDelegate <NSObject>

- (void)signatureTapped;
- (void)signatureDateChanged:(NSDate*)date;
- (void)signatureAgreementChanged:(BOOL)value;
- (void)cooperatorReleaseChanged:(BOOL)value;

@end

@interface MONAgreementView : MONCardContainerView
@property (nonatomic,weak) id<MONAgreementDelegate>delegate;
- (void)setCropName:(NSString *)cropName brandName:(NSString *)brandName;
- (void)setGrowerNameToSignature:(NSString*)growerName;
- (void)setSignatureImage:(UIImage*)signatureImage;
- (void)setSignatureDate:(NSDate*)date;
- (void)setSignatureIsAgreed:(BOOL)value;
- (void)setCooperatorRelease:(BOOL)value;
@end
