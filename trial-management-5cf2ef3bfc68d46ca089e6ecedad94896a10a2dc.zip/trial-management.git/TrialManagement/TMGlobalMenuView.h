#import "TMGlobalMenuModel.h"
#import <UIKit/UIKit.h>
#import "TMTrialInfoCardView.h"

typedef NS_ENUM(NSInteger, TMGlobalMenuButtonType) {
	TMGlobalMenuButtonTypeNone,
	TMGlobalMenuButtonTypeTrialSetup,
	TMGlobalMenuButtonTypeObservations,
	TMGlobalMenuButtonTypeHarvest,
	TMGlobalMenuButtonTypeMarketing
};

@protocol TMGlobalMenuViewDelegate <NSObject>

- (void)setupTrialButtonTapped;
- (void)observationsButtonTapped;
- (void)contactSupportButtonTapped;
- (void)closeButtonTapped;
- (void)harvestButtonTapped;
- (void)marketingButtonTapped;
@end

@interface TMGlobalMenuView : UIVisualEffectView

@property (nonatomic) id<TMGlobalMenuViewDelegate> delegate;
@property (nonatomic) TMTrialInfoCardView *trialInfoCardView;
@property (nonatomic) UITextView *infoTextView;
@property (nonatomic) UITextField *headerTextField;

- (instancetype)initWithGlobalMenuModel:(TMGlobalMenuModel *)globalMenuModel;
- (void)setSelectedGlobalMenuButtonType:(TMGlobalMenuButtonType)globalMenuButtonType;
- (void)enableDisableButtonsAsNeeded;

@end
