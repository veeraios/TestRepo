#import "MONLoginModel.h"

@interface MONLoginModel ()

@property (nonatomic) MONLoginService *loginService;

@end

@interface MONLoginModelTest : XCTestCase

@property (nonatomic) MONLoginModel *testObject;
@property (nonatomic) id mockLoginService;
@property (nonatomic) id mockLoginModelObserver;

@end

@implementation MONLoginModelTest

- (void)setUp {
	[super setUp];

	self.mockLoginService = [OCMockObject niceMockForClass:[MONLoginService class]];

	self.testObject = [[MONLoginModel alloc] initWithLoginService:self.mockLoginService];

	self.mockLoginModelObserver = [OCMockObject niceMockForProtocol:@protocol(MONLoginModelObserver)];
	[self.testObject escAddObserver:self.mockLoginModelObserver];
}

- (void)testInit_SetsLoginService {
	self.testObject = [[MONLoginModel alloc] init];
	
	XCTAssertNotNil(self.testObject.loginService);
	XCTAssertEqualObjects([self.testObject.loginService class], [MONLoginService class]);
}

- (void)testSubmitLogin_CallsLoginOnLoginService {
	self.testObject = [[MONLoginModel alloc] initWithLoginService:self.mockLoginService];
	NSString *expectedUsername = @"thisUsername";
	NSString *expectedPassword = @"somePassword";
	self.testObject.username = expectedUsername;
	self.testObject.password = expectedPassword;
	[[self.mockLoginService expect] loginWithUsername:expectedUsername
											 password:expectedPassword
										 successBlock:[OCMArg any]
										 failureBlock:[OCMArg any]];
	
	[self.testObject submitLogin];
	
	[self.mockLoginService verify];
}

- (void)testSubmitLogin_NotifiesObserversOnSuccess {
	[[self.mockLoginModelObserver expect] loginSucceeded];
	
	[[[self.mockLoginService stub] andDo:^(NSInvocation *invocation) {
		void (^successBlock)(void) = nil;
		[invocation getArgument:&successBlock atIndex:4];
		successBlock();
		[self.mockLoginModelObserver verify];
	}] loginWithUsername:[OCMArg any] password:[OCMArg any] successBlock:[OCMArg any] failureBlock:[OCMArg any]];
	
	[self.testObject submitLogin];
}

- (void)testSubmitLogin_NotifiesObserversOnFailure {
	id mockExpectedError = [OCMockObject niceMockForClass:[NSError class]];;
	
	[[self.mockLoginModelObserver expect] loginFailedWithError:mockExpectedError];
	
	[[[self.mockLoginService stub] andDo:^(NSInvocation *invocation) {
		void (^failureBlock)(NSError *) = nil;
		[invocation getArgument:&failureBlock atIndex:5];
		failureBlock(mockExpectedError);
		[self.mockLoginModelObserver verify];
	}] loginWithUsername:[OCMArg any] password:[OCMArg any] successBlock:[OCMArg any] failureBlock:[OCMArg any]];
	
	[self.testObject submitLogin];
}

- (void)testUserIsAuthenticated_DelegatesToLoginService {
	[[self.mockLoginService expect] userIsAuthenticated];
	
	[self.testObject userIsAuthenticated];
	
	[self.mockLoginService verify];
}

- (void)testLogout_DelegatesToLoginService {
	[[self.mockLoginService expect] logout];
	
	[self.testObject logout];
	
	[self.mockLoginService verify];
}

@end
