//
//  TMImportDataPopulator.swift
//  TrialManagement
//
//  Created by GADIRAJU, PRANEETH [AG/1000] on 1/23/15.
//  Copyright (c) 2015 Monsanto. All rights reserved.
//

public class TMImportDataPopulator : NSObject {
    private let importContext:MONContextProtocol
    private let workingContext:MONContextProtocol
    
    init(importContext:MONContextProtocol, workingContext:MONContextProtocol) {
        self.importContext = importContext;
        self.workingContext = workingContext;
    }
    
    func populateDataInTheImportContext(entityName:String, identifier: AnyObject?, propertyName: String) -> NSManagedObject? {
        if let entityIdentifier: AnyObject = identifier? {
            return populateImportContextWith(entityName, predicate: NSPredicate(format:"\(propertyName) = \"\(entityIdentifier)\"")!)
        } else {
           return nil 
        }
        
    }
    
    func populateImportContextWith(entityName: String, predicate: NSPredicate) -> NSManagedObject? {
        let entity = self.workingContext.findWithPredicate(entityName, wherePredicate: predicate, propertyToFetch: []).first as? NSManagedObject
        
        if let context = self.importContext as? TMImportCoreDataContextProtocol {
             return entity != nil ? context.cloneObject(entity! as NSManagedObject) : nil
        } else {
            return nil
        }
    }
    
    func cloneEntities(entity:AnyClass) -> [NSManagedObject] {
        var clonedEntities = [NSManagedObject]()
        var allEntities = self.workingContext.getObjects(entity)
        
        if let context = self.importContext as? TMImportCoreDataContextProtocol {
            if let entities = allEntities? {
                for entity in entities {
                    clonedEntities.append(context.cloneObject(entity as NSManagedObject))
                }
            }
        }
        
        return clonedEntities
    }
}
