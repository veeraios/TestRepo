#import "MONSingleSearchView.h"
#import "MONButton.h"
#import "MONTextField.h"
#import "MONLabeledTextField.h"
#import "UIColor+MONThemeColorProvider.h"
#import "MONFonts.h"
#import "MONDimensions.h"
#import "MONBorderedButton.h"

static const CGFloat HeaderLabelOffset = 7.0;

@interface MONSingleSearchView ()<MONLabeledTextFieldDelegate>

@property (nonatomic) UITapGestureRecognizer *tapGestureRecognizer;
@property (nonatomic) MONLabel *searchCriteriaHeaderLabel;
@property (nonatomic) MONTextField *searchTextField;
@property (nonatomic) MONButton *searchButton;
@property (nonatomic) MONBorderedButton *requestNewButton;
@property (nonatomic) MONHeaderView *searchResultsHeaderView;
@property (nonatomic) UITableView *searchResultsTableView;

@end

@implementation MONSingleSearchView

- (instancetype)initWithSearchResultsTableView:(UITableView *)searchResultsTableView pageTitle:(NSString*)pageTitle tableTitle:(NSString*)tableTitle {
	self = [super init];
	if (self) {
		self.backgroundColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeBackground];
		
		self.tapGestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(mainViewTapped)];
		self.tapGestureRecognizer.cancelsTouchesInView = NO;
		[self addGestureRecognizer:self.tapGestureRecognizer];
		
		self.searchCriteriaHeaderLabel = [[MONLabel alloc] init];
		self.searchCriteriaHeaderLabel.text = pageTitle;
		self.searchCriteriaHeaderLabel.font = [UIFont fontWithName:OpenSansLight size:MONFontsHeaderTextSize];
		[self addSubview:self.searchCriteriaHeaderLabel];
		
		self.searchTextField = [[MONTextField alloc] init];
		[self.searchTextField setPlaceholderText:@"Enter Keywords"];
		[self.searchTextField setPlaceholderTextColor:[UIColor colorForThemeComponentType:MONThemeComponentTypeBorder]];
		[self addSubview:self.searchTextField];
		
		self.searchButton = [[MONButton alloc] init];
		[self.searchButton setTitle:@"Search" forState:UIControlStateNormal];
		[self.searchButton addTarget:self action:@selector(searchButtonTapped) forControlEvents:UIControlEventTouchUpInside];
		[self addSubview:self.searchButton];
		
		self.requestNewButton = [[MONBorderedButton alloc] init];
		[self.requestNewButton setTitle:@"REQUEST NEW" forState:UIControlStateNormal];
		[self.requestNewButton addTarget:self action:@selector(requestNewButtonTapped) forControlEvents:UIControlEventTouchUpInside];
		
		self.searchResultsHeaderView = [[MONHeaderView alloc] init];
		[self.searchResultsHeaderView showNumberOfItems:YES];
		[self.searchResultsHeaderView setTitle:tableTitle];
		[self.searchResultsHeaderView setRightButtons:@[self.requestNewButton]];
		[self addSubview:self.searchResultsHeaderView];
		
		self.searchResultsTableView = searchResultsTableView;
		self.searchResultsTableView.backgroundColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeBackground];
		self.searchResultsTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
		self.searchResultsTableView.layer.borderColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeBorder].CGColor;
		self.searchResultsTableView.layer.borderWidth = MONDimensionsThinBorderWidth;
		self.searchResultsTableView.layer.cornerRadius = MONDimensionsCornerRadius;
		[self addSubview:self.searchResultsTableView];
		
	}
	return self;
}

- (void)layoutSubviews {
	[super layoutSubviews];
	
	CGRect contentRect = UIEdgeInsetsInsetRect(self.bounds, UIEdgeInsetsMake(MONDimensionsLargePadding, MONDimensionsSmallPadding, MONDimensionsSmallPadding, MONDimensionsSmallPadding));
	
	[self.searchCriteriaHeaderLabel sizeToFit];
	self.searchCriteriaHeaderLabel.frame = CGRectMake(CGRectGetMinX(contentRect),
													  CGRectGetMinY(contentRect) - HeaderLabelOffset,
													  CGRectGetWidth(self.searchCriteriaHeaderLabel.frame),
													  CGRectGetHeight(self.searchCriteriaHeaderLabel.frame));
	
	CGSize growerLabelSize = [self.searchTextField sizeThatFits:contentRect.size];
	self.searchTextField.frame = CGRectMake(CGRectGetMinX(contentRect),
											CGRectGetMaxY(self.searchCriteriaHeaderLabel.frame) + MONDimensionsSmallPadding,
											CGRectGetWidth(contentRect),
											growerLabelSize.height);
	
	[self.searchButton sizeToFit];
	self.searchButton.frame = CGRectMake(CGRectGetMaxX(contentRect) - CGRectGetWidth(self.searchButton.frame),
										 CGRectGetMaxY(self.searchTextField.frame) + MONDimensionsSmallPadding,
										 CGRectGetWidth(self.searchButton.frame),
										 CGRectGetHeight(self.searchButton.frame));
	
	[self.searchResultsHeaderView sizeToFit];
	self.searchResultsHeaderView.frame = CGRectMake(CGRectGetMinX(contentRect),
													CGRectGetMaxY(self.searchButton.frame) + MONDimensionsSmallPadding,
													CGRectGetWidth(self.searchResultsHeaderView.frame),
													CGRectGetHeight(self.searchResultsHeaderView.frame));
	
	[self.requestNewButton sizeToFit];
	self.requestNewButton.frame = CGRectMake(CGRectGetMaxX(self.searchResultsHeaderView.frame) + HeaderLabelOffset, CGRectGetMinY(self.searchResultsHeaderView.frame)- HeaderLabelOffset, CGRectGetWidth(self.requestNewButton.frame), CGRectGetHeight(self.requestNewButton.frame));
	
	
	self.searchResultsTableView.frame = CGRectMake(CGRectGetMinX(contentRect),
												   CGRectGetMaxY(self.searchResultsHeaderView.frame),
												   CGRectGetWidth(contentRect),
												   CGRectGetHeight(contentRect) - CGRectGetMaxY(self.searchResultsHeaderView.frame) + MONDimensionsLargePadding);
}

- (void)setNumberOfSearchResults:(NSUInteger)numberOfSearchResults {
	[self.searchResultsHeaderView setNumberOfItems:numberOfSearchResults];
}

- (void)mainViewTapped {
	[self resignFirstResponderOnAllFields];
}

- (void)searchButtonTapped {
	[self resignFirstResponderOnAllFields];
	[self.delegate searchWithText:self.searchTextField.text];
}

-(void)requestNewButtonTapped {
}

- (void)resignFirstResponderOnAllFields {
	[self.searchTextField resignFirstResponder];
}

@end
