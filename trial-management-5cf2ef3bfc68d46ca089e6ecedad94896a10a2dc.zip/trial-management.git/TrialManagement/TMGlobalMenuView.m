#import "TMGlobalMenuView.h"
#import "MONLabel.h"
#import "TMGlobalMenuItemButton.h"
#import "MONFonts.h"
#import "MONColors.h"
#import "MONDimensions.h"
#import "MONBorderedButton.h"
#import	"UIColor+MONThemeColorProvider.h"
#import "MONUIConvenienceFunctions.h"

static const CGFloat TrailInfoCardViewOffsetY = 8.0;
static const CGFloat SupportPhoneNumberOffsetY = 3.0;
static const CGFloat SupportEmailButtonOffsetY = 5.0;
static const CGFloat ButtonWidth = 110.0;
static const CGFloat ButtonHeight = 100.0;

@interface TMGlobalMenuView ()

@property (nonatomic) TMGlobalMenuModel *globalMenuModel;
@property (nonatomic) MONLabel *titleLabel;
@property (nonatomic) TMGlobalMenuItemButton *setupTrialButton;
@property (nonatomic) TMGlobalMenuItemButton *observationsButton;
@property (nonatomic) TMGlobalMenuItemButton *contactSupportButton;
@property (nonatomic) TMGlobalMenuItemButton *harvestButton;
@property (nonatomic) TMGlobalMenuItemButton *marketingButton;
@property (nonatomic) MONLabel *supportPhoneNumberAndVersionLabel;
@property (nonatomic) MONBorderedButton *closeButton;


@end

@implementation TMGlobalMenuView

- (instancetype)initWithGlobalMenuModel:(TMGlobalMenuModel *)globalMenuModel {
    self = [super initWithEffect:[UIBlurEffect effectWithStyle:UIBlurEffectStyleDark]];
	if (self) {
		self.globalMenuModel = globalMenuModel;
		
		self.titleLabel = [[MONLabel alloc] init];
		self.titleLabel.text = @"TRIAL ACTIVITIES";
        [self.titleLabel setTextColor:[UIColor colorForThemeComponentType:MONThemeComponentTypeSelectedText]];
		self.titleLabel.textAlignment = NSTextAlignmentCenter;
		self.titleLabel.font = [UIFont fontWithName:OpenSansLight size:MONFontsHeaderTextSize];
		[self.contentView addSubview:self.titleLabel];
		
		self.trialInfoCardView = [[TMTrialInfoCardView alloc] init];
		[self.trialInfoCardView setStatus:self.globalMenuModel.status];
		[self.trialInfoCardView setTitle:self.globalMenuModel.trialName];
		[self.trialInfoCardView setGrower:self.globalMenuModel.growerName];
		[self.trialInfoCardView setDistrictSalesManager:self.globalMenuModel.salesManagerName];
		[self.trialInfoCardView setCrop:self.globalMenuModel.cropName];
		[self.trialInfoCardView setPlotDescription:self.globalMenuModel.plotTypeDescription];
		[self.trialInfoCardView setBackgroundColor:[UIColor clearColor]];
		[self.trialInfoCardView setTextColor:[MONColors boneColor]];
		[self.trialInfoCardView setBorderColor:[MONColors boneColor]];
		[self.contentView addSubview:self.trialInfoCardView];
		
		self.setupTrialButton = [[TMGlobalMenuItemButton alloc] initWithTitle:@"Setup" image:[UIImage imageNamed:@"ui-icon-flyover-setup"]];
		[self.setupTrialButton addTarget:self action:@selector(setupTrialButtonTapped) forControlEvents:UIControlEventTouchUpInside];
        [self.contentView addSubview:self.setupTrialButton];
		
		self.observationsButton = [[TMGlobalMenuItemButton alloc] initWithTitle:@"Observations" image:[UIImage imageNamed:@"ui-icon-flyover-observations"]];
		[self.observationsButton addTarget:self action:@selector(observationsButtonTapped) forControlEvents:UIControlEventTouchUpInside];
		[self.contentView addSubview:self.observationsButton];
		
		self.harvestButton = [[TMGlobalMenuItemButton alloc] initWithTitle:@"Harvest" image:[UIImage imageNamed:@"ui-icon-flyover-harvest"]];
		[self.harvestButton addTarget:self action:@selector(harvestButtonTapped) forControlEvents:UIControlEventTouchUpInside];
		[self.contentView addSubview:self.harvestButton];

		self.marketingButton = [[TMGlobalMenuItemButton alloc] initWithTitle:@"Marketing" image:[UIImage imageNamed:@"ui-icon-flyover-marketing"]];
		[self.marketingButton addTarget:self action:@selector(marketingButtonTapped) forControlEvents:UIControlEventTouchUpInside];
		[self.contentView addSubview:self.marketingButton];

		self.contactSupportButton = [[TMGlobalMenuItemButton alloc] initWithTitle:@"Contact\nSupport" image:[UIImage imageNamed:@"ui-icon-flyover-help"]];
		[self.contactSupportButton addTarget:self action:@selector(contactSupportButtonTapped) forControlEvents:UIControlEventTouchUpInside];
		[self.contentView addSubview:self.contactSupportButton];
		
		self.supportPhoneNumberAndVersionLabel = [[MONLabel alloc] init];
		self.supportPhoneNumberAndVersionLabel.numberOfLines = 2;
		self.supportPhoneNumberAndVersionLabel.textAlignment = NSTextAlignmentCenter;
        NSString *version = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"];
		self.supportPhoneNumberAndVersionLabel.text = [NSString stringWithFormat:@"1-888-711-7717 (Option 3)\nVersion %@", version];
		self.supportPhoneNumberAndVersionLabel.textColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeSelectedText];
		self.supportPhoneNumberAndVersionLabel.fontName = OpenSans;
		[self.contentView addSubview:self.supportPhoneNumberAndVersionLabel];
		
		self.closeButton = [[MONBorderedButton alloc] init];
		[self.closeButton setTitle:@"Close Menu" forState:UIControlStateNormal];
		[self.closeButton setTitleColor:[UIColor colorForThemeComponentType:MONThemeComponentTypeTextAlternate] forState:UIControlStateNormal];
		[self.closeButton.layer setBorderColor:[UIColor colorForThemeComponentType:MONThemeComponentTypeThickBorderAlternate].CGColor];
		[self.closeButton addTarget:self action:@selector(closeButtonTapped) forControlEvents:UIControlEventTouchUpInside];
		[self.contentView addSubview:self.closeButton];
		
		self.headerTextField = [[UITextField alloc]init];
		
		[self.headerTextField setTextColor:[MONColors boneColor]];
		[self.headerTextField setFont:[UIFont fontWithName:OpenSansExtraboldItalic size:14]];
		[self.headerTextField setText:@"  Icons locked for following reasons:"];
		[self.headerTextField setHidden:YES];
		[self.headerTextField setEnabled:NO];
		[self.headerTextField setBackgroundColor:[UIColor colorForThemeComponentType:MONThemeComponentTypeHighlight]];
		[self.contentView addSubview:self.headerTextField];
		
		self.infoTextView = [[UITextView alloc]init];
		[self.infoTextView setTextColor:[MONColors boneColor]];
		[self.infoTextView setFont:[UIFont fontWithName:OpenSansItalic size:14]];
		[self.infoTextView setEditable:NO];
		[self.infoTextView setHidden:YES];
		[self.infoTextView setBackgroundColor:[UIColor colorForThemeComponentType:MONThemeComponentTypeHighlight]];
		
		[self.contentView addSubview:self.infoTextView];
		
    }
	return self;
}

- (void)layoutSubviews {
	[super layoutSubviews];
	
	[self.titleLabel sizeToFit];
	self.titleLabel.frame = CGRectMake(0.0, 45.0, CGRectGetWidth(self.bounds), CGRectGetHeight(self.titleLabel.frame));
	
	CGSize trialInfoCardViewSize = [self.trialInfoCardView sizeThatFits:CGSizeMake(315.0, 150.0)];
	self.trialInfoCardView.frame = CGRectMake(MONUIScreenRoundToScreenScale((CGRectGetWidth(self.bounds) - trialInfoCardViewSize.width) / 2.0),
											  CGRectGetMaxY(self.titleLabel.frame) + MONDimensionsLargePadding - TrailInfoCardViewOffsetY,
											  trialInfoCardViewSize.width,
											  trialInfoCardViewSize.height);
    
    CGFloat setupTrialButtonOriginX = self.marketingButton.hidden ? (CGRectGetWidth(self.bounds) - (ButtonWidth * 3 + MONDimensionsLargePadding * 2.0)) / 2.0 :
                                                                     (CGRectGetWidth(self.bounds) - (ButtonWidth * 4 + MONDimensionsLargePadding * 3.0)) / 2.0;
    self.setupTrialButton.frame = CGRectMake(setupTrialButtonOriginX,
											 CGRectGetMaxY(self.trialInfoCardView.frame) + MONDimensionsLargePadding,
											 ButtonWidth,
											 ButtonHeight);
	
	self.observationsButton.frame = CGRectMake(CGRectGetMaxX(self.setupTrialButton.frame) + MONDimensionsLargePadding,
											 CGRectGetMaxY(self.trialInfoCardView.frame) + MONDimensionsLargePadding,
											 ButtonWidth,
											 ButtonHeight);
	
	
	self.harvestButton.frame = CGRectMake(CGRectGetMaxX(self.observationsButton.frame) + MONDimensionsLargePadding,
											   CGRectGetMaxY(self.trialInfoCardView.frame) + MONDimensionsLargePadding,
											   ButtonWidth,
											   ButtonHeight);
	
	
	CGSize headerTextFieldSize = [self.headerTextField sizeThatFits:self.bounds.size];
	
	self.headerTextField.frame = CGRectMake((CGRectGetWidth(self.bounds) - headerTextFieldSize.width) / 2.0,
										CGRectGetMaxY(self.observationsButton.frame) + MONDimensionsLargePadding,
										headerTextFieldSize.width,
										headerTextFieldSize.height);
	
	
	CGSize infoTextViewSize = [self.infoTextView sizeThatFits:self.bounds.size];
	self.infoTextView.frame = CGRectMake((CGRectGetWidth(self.bounds) - headerTextFieldSize.width) / 2.0,
										CGRectGetMaxY(self.headerTextField.frame),
										headerTextFieldSize.width,
										infoTextViewSize.height);

	
	self.marketingButton.frame = CGRectMake(CGRectGetMaxX(self.harvestButton.frame) + MONDimensionsLargePadding,
										  CGRectGetMaxY(self.trialInfoCardView.frame) + MONDimensionsLargePadding,
										  ButtonWidth,
										  ButtonHeight);

	
	CGSize closeButtonSize = [self.closeButton sizeThatFits:self.bounds.size];
	self.closeButton.frame = CGRectMake((CGRectGetWidth(self.bounds) - closeButtonSize.width) / 2.0,
										 CGRectGetHeight(self.bounds) - closeButtonSize.height - MONDimensionsLargePadding,
										 closeButtonSize.width,
										 closeButtonSize.height);
	
	
	

	[self.supportPhoneNumberAndVersionLabel sizeToFit];
	self.supportPhoneNumberAndVersionLabel.frame = CGRectMake(MONUIScreenRoundToScreenScale((CGRectGetWidth(self.bounds) - CGRectGetWidth(self.supportPhoneNumberAndVersionLabel.frame)) / 2.0),
												 CGRectGetMinY(self.closeButton.frame) - CGRectGetHeight(self.supportPhoneNumberAndVersionLabel.frame) - MONDimensionsLargePadding + SupportPhoneNumberOffsetY,
												 CGRectGetWidth(self.supportPhoneNumberAndVersionLabel.frame),
												 CGRectGetHeight(self.supportPhoneNumberAndVersionLabel.frame));
	
	self.contactSupportButton.frame = CGRectMake((CGRectGetWidth(self.bounds) - ButtonWidth) / 2.0,
												 CGRectGetMinY(self.supportPhoneNumberAndVersionLabel.frame) - ButtonHeight - SupportEmailButtonOffsetY,
												 ButtonWidth,
												 ButtonHeight);
	
	}

- (void)setSelectedGlobalMenuButtonType:(TMGlobalMenuButtonType)globalMenuButtonType {
//	Refactor note: maybe we can rid of the enums and do pointer reference comparision with the button?
	switch (globalMenuButtonType) {
		case TMGlobalMenuButtonTypeTrialSetup:
			[self.setupTrialButton setSelected:YES];
			[self.observationsButton setSelected:NO];
			[self.harvestButton setSelected:NO];
			break;
		case TMGlobalMenuButtonTypeObservations:
			[self.setupTrialButton setSelected:NO];
			[self.observationsButton setSelected:YES];
			[self.harvestButton setSelected:NO];
			break;
		case TMGlobalMenuButtonTypeHarvest:
			[self.setupTrialButton setSelected:NO];
			[self.observationsButton setSelected:NO];
			[self.harvestButton setSelected:YES];
			break;
		default:
			[self.setupTrialButton setSelected:NO];
			[self.observationsButton setSelected:NO];
			[self.harvestButton setSelected:NO];
			break;
	}
}

- (void)enableDisableButtonsAsNeeded {
    [self.observationsButton setEnabled:[self.globalMenuModel isBasicTrialInfoFilled]];
    [self.harvestButton setEnabled:[self.globalMenuModel isBasicTrialInfoFilled]];
    if ([self.globalMenuModel isEligibleForMarketing]) {
        [self.marketingButton setHidden:NO];
        [self.marketingButton setEnabled:[self.globalMenuModel isBasicTrialInfoFilled]];
    } else {
        [self.marketingButton setHidden:YES];
    }
    [self setNeedsLayout];
}

- (void)marketingButtonTapped {
	[self.delegate marketingButtonTapped];
}

- (void)harvestButtonTapped {
	[self.delegate harvestButtonTapped];
}

- (void)setupTrialButtonTapped {
	[self.delegate setupTrialButtonTapped];
}

- (void)observationsButtonTapped {
	[self.delegate observationsButtonTapped];
}

- (void)contactSupportButtonTapped {
	[self.delegate contactSupportButtonTapped];
}

- (void)closeButtonTapped {
	[self.delegate closeButtonTapped];
}

- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event {
	UIView *view = [super hitTest:point withEvent:event];
	return view;
}

@end
