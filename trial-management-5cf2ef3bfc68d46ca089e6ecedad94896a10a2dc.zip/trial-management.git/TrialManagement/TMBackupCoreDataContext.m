#import "TMBackupCoreDataContext.h"
#import "NSManagedObject+MONClone.h"
#import "NSManagedObject+MONCascadeDelete.h"
#import "TMTrial.h"
#import "TMDataModelTraversalRules.h"
#import "TrialManagement-Swift.h"

NSString * const MONBackupCoreDataSqliteDatabase = @"TrialManagementBackup.sqlite";

@implementation TMBackupCoreDataContext

- (id) init {
    self  = [super init];
    if (self) {
        [self createManagedObjectContextWithDatabaseName:MONBackupCoreDataSqliteDatabase migrationModel:[[TMDataModelMigration alloc] init] andUndoManager:YES];
    }
    return self;
}

- (void) cloneTrial:(TMTrial *)trial {
    NSManagedObject *clonedObject = [self findById:trial.trialId forProperty:@"trialId" withClassName:NSStringFromClass([TMTrial class])];
    
    if(!clonedObject && trial.trialId) {
        [trial cloneInContext: [self mainThreadObjectContext]
  withDataModelTraversalRules: [[TMDataModelTraversalRules sharedInstance] dataModelTraversalRulesDictionary]];
        
        [self saveChanges];
    }
}

- (void) deleteTrial:(TMTrial *)trial {
    NSManagedObject *clonedObject = [self findById:trial.trialId forProperty:@"trialId" withClassName:NSStringFromClass([TMTrial class])];
    
    if(clonedObject) {
        [clonedObject deleteWithRefData];
        [self saveChanges];
    }
}

- (NSManagedObject *) findById:(NSNumber *)identifier forProperty:(NSString *)propertyName withClassName:(NSString *)className {
    NSPredicate *predicate = [NSPredicate predicateWithFormat: [propertyName stringByAppendingString:@" == %@"], identifier];
    
    NSArray *results = [self findWithPredicate:className wherePredicate:predicate orderBy:propertyName ascending:NO];
    
    return [results count] ? [results firstObject] : nil;
}



@end
