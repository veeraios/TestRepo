#import "TMDeltaSyncManager.h"
#import "NSDate+MONDateHelper.h"

static NSString * const kTMLastSyncKey = @"TMlastSyncKey";
static NSString * const kTMForceSyncReferenceCallsKey = @"TMForceSyncReferenceCallsKey";
static NSInteger const kStartingTrialsMonth = 1;
static NSInteger const kStartingTrialsDay = 1;
static NSInteger const kSevenDaysAgo = -7;

@interface TMDeltaSyncManager()

@property (nonatomic) NSDate *lastSync;
@property (nonatomic) NSDate *lastToDate;
@property (nonatomic) NSSet *forceSyncReferenceCalls;

@end

@implementation TMDeltaSyncManager

- (instancetype)init {
	self = [super init];
	if(self) {
		self.lastSync = [self retrieveLastSyncDate];
        self.forceSyncReferenceCalls = [self retreiveForceSyncReferenceCalls];
	}
	return self;
}

- (void)saveSyncTime:(NSDate *)syncDate {
	self.lastSync = syncDate;
    [[NSUserDefaults standardUserDefaults] setObject:syncDate forKey:kTMLastSyncKey];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

- (NSDate *)retrieveLastSyncDate {
    id value =  [[NSUserDefaults standardUserDefaults] objectForKey:kTMLastSyncKey];
    return value ? (NSDate *)value : [self minimumDeltaDate];
}

- (NSDate *)minimumDeltaDate {
    return [NSDate dateFromMonth:1 day:1 year:1970];
}

- (NSDate *)currentDateWithDelta:(NSInteger)hours {
	NSDateComponents *addComponents = [[NSDateComponents alloc] init];
	addComponents.hour = hours;
	return [[[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian]
								 dateByAddingComponents:addComponents toDate:self.lastSync options:0];
}

- (BOOL)shouldSyncWithThreshold:(NSInteger)hours {
	NSDate *currentTime = [NSDate date];
	NSDate *deltaTime = [self currentDateWithDelta:hours];
	return [currentTime compare:deltaTime] == NSOrderedDescending;
}

- (BOOL)isFirstTimeSync {
	return [self.lastSync isEqualToDate:[self minimumDeltaDate]] && self.lastToDate == nil;
}

- (NSTimeInterval)fromDateTimeInterval {
	return [self.lastSync timeIntervalSince1970];
}

- (NSDate *)notificationFireDate {
	return [self.lastSync dateWithAddedDays:2];

	//For Team testing
//	NSDate *notificationFireDate = [self.lastSync dateByAddingTimeInterval:60];
//	return notificationFireDate;

}

- (NSDate *)firstTimeTrialSyncDate {
    NSInteger prevYear = [[NSCalendar currentCalendar] component:NSCalendarUnitYear fromDate: [[NSDate alloc] init]] - 1;
	return [NSDate dateFromMonth:kStartingTrialsMonth day:kStartingTrialsDay year:prevYear];
}

- (NSTimeInterval)trialsToDateTimeInterval {
	self.lastToDate = [[NSDate date] dateWithAddedDays:2];
	return ceil([self.lastToDate timeIntervalSince1970]);
}

- (NSTimeInterval)fromDateTimeIntervalWithAWeekBack {
    return [self isFirstTimeSync] ? [self fromDateTimeInterval] : [[self.lastSync dateWithAddedDays:kSevenDaysAgo] timeIntervalSince1970];
}

- (void)saveForceSyncReferenceCalls:(NSSet *)referenceCalls {
    self.forceSyncReferenceCalls = referenceCalls;
    [[NSUserDefaults standardUserDefaults] setObject:referenceCalls.allObjects forKey:kTMForceSyncReferenceCallsKey];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

- (NSSet *)retreiveForceSyncReferenceCalls {
    self.forceSyncReferenceCalls = [NSSet setWithArray:[[NSUserDefaults standardUserDefaults] objectForKey:kTMForceSyncReferenceCallsKey]];
    return self.forceSyncReferenceCalls;
}

- (BOOL)shouldForceSyncForUpgrade {
    return self.forceSyncReferenceCalls.count != 0 && self.forceSyncReferenceCalls;
}

@end
