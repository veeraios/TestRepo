#import "TMCooperatorSearchResultsTableViewHeaderView.h"
#import "MONDimensions.h"
#import "MONUIConvenienceFunctions.h"
#import "UIColor+MONThemeColorProvider.h"
#import "MONFonts.h"
#import "MONLabel.h"
#import "TMCooperatorTableViewCellFieldDimensions.h"

@interface TMCooperatorSearchResultsTableViewHeaderView ()

@property (nonatomic) MONLabel *cooperatorLabel;
@property (nonatomic) MONLabel *stateLabel;
@property (nonatomic) MONLabel *cityLabel;
@property (nonatomic) MONLabel *postalCodeLabel;
@property (nonatomic) UIView *bottomBorderView;

@end

@implementation TMCooperatorSearchResultsTableViewHeaderView

- (id)initWithFrame:(CGRect)frame {
	self = [super initWithFrame:frame];
	if (self) {
		self.backgroundColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeBackground];
		
		self.cooperatorLabel = [self defaultLabelWithText:@"Cooperator"];
		[self addSubview:self.cooperatorLabel];
		
		self.stateLabel = [self defaultLabelWithText:@"State"];
		[self addSubview:self.stateLabel];
		
		self.cityLabel = [self defaultLabelWithText:@"City"];
		[self addSubview:self.cityLabel];
		
		self.postalCodeLabel = [self defaultLabelWithText:@"Postal Code"];
		[self addSubview:self.postalCodeLabel];
		
		self.bottomBorderView = [[UIView alloc] init];
		self.bottomBorderView.backgroundColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeBorder];
		[self addSubview:self.bottomBorderView];
	}
	return self;
}

- (MONLabel *)defaultLabelWithText:(NSString *)text {
	MONLabel *label = [[MONLabel alloc] init];
	label.text = text;
	label.fontName = OpenSans;
	return label;
}

- (void)layoutSubviews {
  [super layoutSubviews];

  [self layoutLabelWithLabel:self.cooperatorLabel offsetLabel:nil labelWidthPercent:CooperatorLabelWidthPercent];
  [self layoutLabelWithLabel:self.stateLabel offsetLabel:self.cooperatorLabel labelWidthPercent:StateLabelWidthPercent];
  [self layoutLabelWithLabel:self.cityLabel offsetLabel:self.stateLabel labelWidthPercent:CityLabelWidthPercent];
  [self layoutLabelWithLabel:self.postalCodeLabel offsetLabel:self.cityLabel labelWidthPercent:PostalCodeLabelWidthPercent];

  self.bottomBorderView.frame = CGRectMake(0.0, CGRectGetMaxY(self.bounds), CGRectGetWidth(self.bounds), MONDimensionsThinBorderWidth);
}

- (void)layoutLabelWithLabel:(MONLabel *)label offsetLabel:(MONLabel *)offsetLabel labelWidthPercent:(CGFloat)labelWidthPercent {
  [label sizeToFit];
  CGRect rectInset = CGRectInset(self.bounds, MONDimensionsSmallPadding, MONDimensionsSmallPadding);
  label.frame = CGRectMake(
      CGRectGetMinX(rectInset) + (offsetLabel ? CGRectGetMaxX(offsetLabel.frame) : 0),
      MONUIScreenRoundToScreenScale((CGFloat) ((CGRectGetMaxY(self.bounds) - CGRectGetHeight(label.frame)) / 2.0)),
      (CGRectGetWidth(rectInset) / 100 * labelWidthPercent) - (offsetLabel ? MONDimensionsSmallPadding : 0),
      CGRectGetHeight(label.frame)
  );
}

@end