//
//  TMCrop.h
//  TrialManagement
//
//  Created by WAIDMANN, ALAN [AG/1000] on 7/15/15.
//  Copyright (c) 2015 Monsanto. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class TMObservationCalculation, TMObservationReferenceData, TMProtocol, TMReportReferenceData, TMRowSpacingUnitOfMeasure, TMTrait, TMTreatment, TMTrial, TMUnitOfMeasure, TMUser;

@interface TMCrop : NSManagedObject

@property (nonatomic, retain) NSNumber * cropId;
@property (nonatomic, retain) NSString * name;
@property (nonatomic, retain) NSDecimalNumber * relativeMaturityIncrement;
@property (nonatomic, retain) NSNumber * relativeMaturityMax;
@property (nonatomic, retain) NSNumber * relativeMaturityMin;
@property (nonatomic, retain) NSSet *observationCalculations;
@property (nonatomic, retain) NSSet *observationReferenceData;
@property (nonatomic, retain) NSSet *protocols;
@property (nonatomic, retain) NSSet *reportReferenceData;
@property (nonatomic, retain) NSSet *rowSpacingUnitOfMeasures;
@property (nonatomic, retain) NSSet *traits;
@property (nonatomic, retain) NSSet *treatments;
@property (nonatomic, retain) NSSet *trials;
@property (nonatomic, retain) NSSet *unitOfMeasures;
@property (nonatomic, retain) NSSet *users;
@end

@interface TMCrop (CoreDataGeneratedAccessors)

- (void)addObservationCalculationsObject:(TMObservationCalculation *)value;
- (void)removeObservationCalculationsObject:(TMObservationCalculation *)value;
- (void)addObservationCalculations:(NSSet *)values;
- (void)removeObservationCalculations:(NSSet *)values;

- (void)addObservationReferenceDataObject:(TMObservationReferenceData *)value;
- (void)removeObservationReferenceDataObject:(TMObservationReferenceData *)value;
- (void)addObservationReferenceData:(NSSet *)values;
- (void)removeObservationReferenceData:(NSSet *)values;

- (void)addProtocolsObject:(TMProtocol *)value;
- (void)removeProtocolsObject:(TMProtocol *)value;
- (void)addProtocols:(NSSet *)values;
- (void)removeProtocols:(NSSet *)values;

- (void)addReportReferenceDataObject:(TMReportReferenceData *)value;
- (void)removeReportReferenceDataObject:(TMReportReferenceData *)value;
- (void)addReportReferenceData:(NSSet *)values;
- (void)removeReportReferenceData:(NSSet *)values;

- (void)addRowSpacingUnitOfMeasuresObject:(TMRowSpacingUnitOfMeasure *)value;
- (void)removeRowSpacingUnitOfMeasuresObject:(TMRowSpacingUnitOfMeasure *)value;
- (void)addRowSpacingUnitOfMeasures:(NSSet *)values;
- (void)removeRowSpacingUnitOfMeasures:(NSSet *)values;

- (void)addTraitsObject:(TMTrait *)value;
- (void)removeTraitsObject:(TMTrait *)value;
- (void)addTraits:(NSSet *)values;
- (void)removeTraits:(NSSet *)values;

- (void)addTreatmentsObject:(TMTreatment *)value;
- (void)removeTreatmentsObject:(TMTreatment *)value;
- (void)addTreatments:(NSSet *)values;
- (void)removeTreatments:(NSSet *)values;

- (void)addTrialsObject:(TMTrial *)value;
- (void)removeTrialsObject:(TMTrial *)value;
- (void)addTrials:(NSSet *)values;
- (void)removeTrials:(NSSet *)values;

- (void)addUnitOfMeasuresObject:(TMUnitOfMeasure *)value;
- (void)removeUnitOfMeasuresObject:(TMUnitOfMeasure *)value;
- (void)addUnitOfMeasures:(NSSet *)values;
- (void)removeUnitOfMeasures:(NSSet *)values;

- (void)addUsersObject:(TMUser *)value;
- (void)removeUsersObject:(TMUser *)value;
- (void)addUsers:(NSSet *)values;
- (void)removeUsers:(NSSet *)values;

@end
