#import "MONLabel.h"
#import "MONFonts.h"
#import "UIColor+MONThemeColorProvider.h"

static const CGFloat DefaultTextSize = 14.0;

@interface MONLabel ()

@end

@implementation MONLabel

- (id)initWithFrame:(CGRect)frame {
	self = [super initWithFrame:frame];
	if (self) {
		_textSize = DefaultTextSize;
		self.textColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeText];
		self.font = [UIFont fontWithName:OpenSansBold size:DefaultTextSize];
	}
	return self;
}

- (void)setTextSize:(CGFloat)textSize {
	_textSize = textSize;
	self.font = [UIFont fontWithName:self.font.fontName size:textSize];
}

- (void)setFontName:(NSString *)fontName {
	self.font = [UIFont fontWithName:fontName size:_textSize];
}

+ (MONLabel *)defaultLabelWithText:(NSString *)text {
    MONLabel *label = [[MONLabel alloc] init];
	label.text = text;
	return label;
}

@end
