#import "TMHarvestActionOptionsListModel.h"
#import "TMTrialActionListModel.h"
#import "TMTrialDataSync.h"
#import "MONMessages.h"

@interface TMHarvestActionOptionsListModel()
@property (nonatomic) NSArray *dataArray;
@property (nonatomic) NSDictionary *harvestActionsDispatchTable;
@property (nonatomic) TMTrialModel *trialModel;
@property (nonatomic) TMTrialActionListModel *harvestActionModel;
@property (nonatomic, assign) TMUserRole role;
@end

@implementation TMHarvestActionOptionsListModel
-(instancetype)initWithUserRole:(TMUserRole)userRole trialModel:(TMTrialModel*)trialModel {
	self = [super init];
	if(self) {
		self.role = userRole;
		self.dataArray = [NSArray array];
		self.trialModel = trialModel;
        self.harvestActionModel = [[TMTrialActionListModel alloc]init];
		if ([self.trialModel isEligibleForMarketing] == NO && ([self.trialModel isTrialIncomplete] || [self trialIsPendingAndCurrentUserIsTA] )) {
			self.dataArray = @[TMRelinquishTrialMessage, TMCancelTrialMessage];
		}
		self.harvestActionsDispatchTable = @{TMCancelTrialMessage: NSStringFromSelector(@selector(cancelTrial)), TMRelinquishTrialMessage : NSStringFromSelector(@selector(relinquish))};
	}
	return self;
}

- (BOOL)trialIsPendingAndCurrentUserIsTA {
	return ([self.trialModel isTrialPending] && (self.role == TMUserRoleTA || self.role == TMUserRoleSuperUser));
}

- (BOOL)harvestActionsAvailable {
	return [self.dataArray count] != 0;
}


-(void)relinquish {
	[[[TMTrialDataSync alloc] init] saveTrialThruPendingQueue:self.trialModel.trial completionBlock:^(NSDictionary * data, NSError *error){
		if([self.trialModel harvestDate] == nil) {
			[MONMessages showErrorMessageTitle:@"Harvest Date not set." subtitle:@"Harvest Date must be set prior to relinquish."];
			return;
		}
		
		if([self.trialModel isFTNTrial] && [self.trialModel hasEntryObservationsForObsName:PlotWeightObsName]) {
			[MONMessages showErrorMessageTitle:@"To relinquish remove plot Weight for FTN trial" subtitle:@"Remove plot weight to relinquish."];
			return;
		}
		
        if(![self.trialModel hasNewPendingProducts]){
            if(error == nil) {
                [self.harvestActionModel relinquish:self.trialModel submitToMarketing:NO completionBlock:^(NSError *error) {
                    if(error == nil) {
                        [self.delegate relinquishComplete];
                    }
                }];
            } else {
                [self.harvestActionModel addToPendingSyncQueue:self.trialModel.trial type:TMPendingSyncQueueItemTypeRelinquish error:error];
                [MONMessages showWarningMessageTitle:@"Trial save is in progress so the relinquish request will be queued for later. Please do manual sync to clear queue." subtitle:error.localizedDescription];
            }
        } else {
            NSString *appendedEntryNumbers = [[self.trialModel getEntryNumbersOfEntriesWithUnapprovedProducts] componentsJoinedByString:@", "];
            [MONMessages showErrorMessageTitle:@"Cannot relinquish the trial" subtitle: [NSString stringWithFormat:@"Product request for entry number(s): %@ is not complete. Please contact TPS Support: 1-888-711-7717 for further information", appendedEntryNumbers]];
        }
	}];
}

-(void)cancelTrial {
	[[[TMTrialDataSync alloc] init] saveTrialThruPendingQueue:self.trialModel.trial completionBlock:^(NSDictionary * data, NSError *error) {
		if(error == nil) {
			[self.harvestActionModel cancelTrial:self.trialModel completionBlock:^(NSError *error) {
				if(error == nil) {
					[self.delegate cancelTrialComplete];
                }
			}];
		} else {
            [self.harvestActionModel addToPendingSyncQueue:self.trialModel.trial type:TMPendingSyncQueueItemTypeCancelTrial error:error];
			[MONMessages showErrorMessageTitle:@"Trial could not be saved to the server, so the cancel trial request will be queued for later." subtitle:error.localizedDescription];
		}
	}];
}

-(NSString *)nameForItemAtIndex:(NSInteger)index {
	return [self.dataArray objectAtIndex:index];
}

- (void)performActionForItemAtIndex:(NSInteger)index {
	SEL actionToPerform = NSSelectorFromString([self.harvestActionsDispatchTable valueForKey:[self.dataArray objectAtIndex:index]]);
	
	//methodForSelector returns IMP, and IMP is an 'id',
	//therefore ARC will attempt to manage it, so we must cast the IMP as void (*)(id, SEL))
	((void (*)(id, SEL))[self methodForSelector:actionToPerform])(self, actionToPerform);
}

@end
