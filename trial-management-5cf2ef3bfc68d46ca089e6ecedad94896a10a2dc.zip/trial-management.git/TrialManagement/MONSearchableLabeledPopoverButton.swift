import UIKit

class MONSearchableLabeledPopoverButton: MONLabeledPopoverButton, UIPopoverControllerDelegate, MONSearchablePopoverDelegate {
    private var searchModel: TMReferenceDataFilterListModel?
    private let searchFilter: MONFilter?
    private var cellPopoverController: UIPopoverController?
    
    init(model: TMReferenceDataFilterListModel, filter: MONFilter, placeholderText: String) {
        super.init(model: nil, placeHolderText: placeholderText)
        searchModel = model
        searchFilter = filter
    }

    override init() {super.init()}
    override init(frame: CGRect) {super.init(frame: frame)}
    override init!(model: TMReferenceListDataModel!, placeHolderText: String!) { super.init(model: nil, placeHolderText: "")}
    required init(coder aDecoder: NSCoder) {fatalError("init(coder:) has not been implemented")}
    
    func buttonTapped() {
        if let model = searchModel {
            if let filter = searchFilter {
                let tableViewController = MONSearchablePopoverTableViewController(model: model, filter: filter, placeholderText: "Search")
                tableViewController.delegate = self
                cellPopoverController = UIPopoverController(contentViewController: tableViewController)
                presentPopover(cellPopoverController)
            }
        }
    }
    
    func didSelectFilterdRowForModel(modelIndex: Int) {
        if let selectedText = searchModel?.nameForItemAtIndex(modelIndex) {
            setButtonText(selectedText)
            cellPopoverController?.dismissPopoverAnimated(true)
            if (popoverDelegate.respondsToSelector(Selector("valueWasSelected:selectedValue:selectedIndex:"))) {
                popoverDelegate.valueWasSelected!(self, selectedValue: selectedText, selectedIndex: modelIndex)
            } else if (popoverDelegate.respondsToSelector(Selector("valueWasSelected:selectedObject:selectedIndex:"))) {
                popoverDelegate.valueWasSelected!(self, selectedObject: searchModel?.objectAtIndex(modelIndex), selectedIndex: modelIndex)
            }
        
        }
    }

    func reloadModel(model: TMReferenceDataFilterListModel) {
        searchModel = model
    }
}
