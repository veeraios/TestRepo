#import "TMCropRepository.h"
#import "TMCrop.h"
#import "TMUnitOfMeasure.h"
#import "TMRowSpacingUnitOfMeasure.h"
#import "NSArray+MONHelpers.h"

@interface TMCropRepository()
@end

@implementation TMCropRepository

-(void)syncFromService:(NSArray*)dataFromService completionBlock:(MONDataImportCompletionBlock)completionBlock {	
	__block TMUser *currentUser = [self currentUser];
	
	__block NSMutableDictionary *uomCache = [[NSMutableDictionary alloc] initWithDictionary:[[self getAll:[TMUnitOfMeasure class] prefechedProperties:@[@"unitOfMeasureId"] prefetchedRelationships:nil] dictionaryWithIndexKeyPath:@"unitOfMeasureId"]];
	
	__block NSMutableDictionary *rowSpacingCache = [[NSMutableDictionary alloc] initWithDictionary:[[self getAll:[TMRowSpacingUnitOfMeasure class] prefechedProperties:@[@"rowSpacingUnitOfMeasuresId"] prefetchedRelationships:nil] dictionaryWithIndexKeyPath:@"rowSpacingUnitOfMeasuresId"]];

	MONDataImportBlock block = ^(NSDictionary* dict, NSManagedObject *coredataModel) {
		TMCrop* cdmodel = (TMCrop*)coredataModel;
		cdmodel.cropId = [dict valueForKey:@"id"];
		cdmodel.name = [dict objectForKey:@"name"];
		cdmodel.relativeMaturityMax = [dict valueForKey:@"relativeMaturityMax"];
		cdmodel.relativeMaturityMin = [dict valueForKey:@"relativeMaturityMin"];
		cdmodel.relativeMaturityIncrement = [dict valueForKey:@"relativeMaturityIncrement"];
		[cdmodel addUsersObject:currentUser];
		
		NSArray *unitOfMeasuresArray = [dict objectForKey:@"unitOfMeasures"];
		if(unitOfMeasuresArray != nil) {
			for (NSDictionary *unitOfMeasureData in unitOfMeasuresArray) {
				NSNumber * pkValue = [unitOfMeasureData valueForKeyPath:@"id"];
				TMUnitOfMeasure *measure = [uomCache objectForKey:pkValue];
				if(measure == nil) {
					measure = [self createChild:[TMUnitOfMeasure class]];
					[uomCache setObject:measure forKey:pkValue];
				}
				measure.unitOfMeasureId = pkValue;
				measure.name = [unitOfMeasureData objectForKey:@"name"];
				
				[cdmodel addUnitOfMeasuresObject:measure];
			}
		}
		NSArray *rowSpacingArray = [dict objectForKey:@"rowSpacingUnitOfMeasures"];
		if(rowSpacingArray != nil) {
			for (NSDictionary *rowSpacingData in rowSpacingArray) {
				NSNumber * pkValue = [rowSpacingData valueForKeyPath:@"id"];
				TMRowSpacingUnitOfMeasure *rowSpacing = [rowSpacingCache objectForKey:pkValue];
				if(rowSpacing == nil) {
					rowSpacing = [self createChild:[TMRowSpacingUnitOfMeasure class]];
					[rowSpacingCache setObject:rowSpacing forKey:pkValue];
				}

				rowSpacing.rowSpacingUnitOfMeasuresId = pkValue;
				rowSpacing.name = [rowSpacingData objectForKey:@"name"];
				
				[cdmodel addRowSpacingUnitOfMeasuresObject:rowSpacing];
			}
		}
	};
	[self import:dataFromService dataServicePrimaryKey:@"name" databasePrimaryKey:@"name" dataImportBlock:block currentUser:currentUser completionBlock:completionBlock];
}

- (NSArray *)cropsForCropId:(long long)cropId {
	NSArray *matchingCrops = [self find:[NSString stringWithFormat:@"cropId == %@", [NSNumber numberWithLongLong:cropId]]];
	return matchingCrops;
}

- (NSNumber *)cropIdForCropName:(NSString *)cropName {
	NSArray *matchingCropIds = [self find:[NSString stringWithFormat:@"name contains[cd] '%@'", cropName]];
	TMCrop *crop = [matchingCropIds firstObject];
	return crop.cropId;
}

@end
