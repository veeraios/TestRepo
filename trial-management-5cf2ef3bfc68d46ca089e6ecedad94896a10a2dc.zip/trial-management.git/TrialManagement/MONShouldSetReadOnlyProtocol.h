#import <Foundation/Foundation.h>

@protocol MONShouldSetReadOnlyProtocol <NSObject>

- (void)shouldSetAsReadOnly:(BOOL)isReadOnly;

@end