import UIKit

class MONLabeledCountView: UIView {
    
    private let titleLabel: MONLabel
    private let itemCountView: MONItemCountView
    
    init(title: String, count: UInt) {
        titleLabel = MONLabel.defaultLabelWithText(title)
        itemCountView = MONItemCountView(frame: CGRect.zeroRect)
        itemCountView.setNumberOfItems(count)
        
        super.init(frame: CGRect.zeroRect)
        
        addSubview(titleLabel)
        addSubview(itemCountView)
    }

    required init(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        titleLabel.sizeToFit()
        itemCountView.sizeToFit()
        
        titleLabel.frame = CGRectMake(0.0, 0.0, CGRectGetWidth(titleLabel.bounds), CGRectGetHeight(titleLabel.bounds))
        itemCountView.frame = CGRectMake(
            CGRectGetMaxX(titleLabel.frame) + MONDimensionsSmallPadding,
            (CGRectGetMaxY(titleLabel.frame) - CGRectGetHeight(itemCountView.bounds))/2.0,
            CGRectGetWidth(itemCountView.bounds),
            CGRectGetHeight(itemCountView.bounds))
    }
    
    override func sizeThatFits(size: CGSize) -> CGSize {
        var sizeThatFits: CGSize = CGSize.zeroSize
        titleLabel.sizeToFit()
        itemCountView.sizeToFit()
        
        sizeThatFits.height = max(titleLabel.frame.height, itemCountView.frame.height)
        sizeThatFits.width = titleLabel.frame.width + itemCountView.frame.width + MONDimensionsSmallPadding
        
        return sizeThatFits
    }
    
    func setTitleFont(font: UIFont) {
        titleLabel.font = font
    }
    
    func setItemsCount(count: UInt) {
        itemCountView.setNumberOfItems(count)
    }
    
    func setItemsCountAlertColor() {
        itemCountView.setAlertColor()
    }
}
