#import "MONCardContainerView.h"
#import "UIColor+MONThemeColorProvider.h"
#import "MONDimensions.h"

@interface MONCardContainerView ()

@property (nonatomic, readwrite) UIView *contentContainerView;
@property (nonatomic) BOOL hasTransparentBackground;

@end

@implementation MONCardContainerView

- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
		self.clipsToBounds = YES;
		self.layer.cornerRadius = MONDimensionsCornerRadius;
		[self setBorderColor:[UIColor colorForThemeComponentType:MONThemeComponentTypeBorder]];
		
        self.contentContainerView = [[UIView alloc] init];
		self.contentContainerView.clipsToBounds = YES;
		self.contentContainerView.backgroundColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeBackground];
		self.contentContainerView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
		[self addSubview:self.contentContainerView];
    }
    return self;
}

- (void)layoutSubviews {
	[super layoutSubviews];
	
	self.contentContainerView.layer.cornerRadius = self.layer.cornerRadius - MONDimensionsThinBorderWidth;
	self.contentContainerView.frame = CGRectInset(self.bounds, MONDimensionsThinBorderWidth, MONDimensionsThinBorderWidth);
}

- (void)setFrame:(CGRect)frame {
	[super setFrame:frame];
}

- (void)setBackgroundColor:(UIColor *)backgroundColor {
	CGFloat colorAlpha;
	[backgroundColor getWhite:nil alpha:&colorAlpha];
	self.hasTransparentBackground = (colorAlpha < 0.01) ? YES : NO;
	
	self.contentContainerView.backgroundColor = backgroundColor;
	[self setNeedsLayout];
}

- (void)setBorderColor:(UIColor *)borderColor {
	if (self.hasTransparentBackground) {
		[self.contentContainerView.layer setBorderColor:borderColor.CGColor];
		[self.contentContainerView.layer setBorderWidth:MONDimensionsThinBorderWidth];
		[super setBackgroundColor:nil];
	} else {
		[self.contentContainerView.layer setBorderColor:nil];
		[self.contentContainerView.layer setBorderWidth:0.0];
		[super setBackgroundColor:borderColor];
	}
	[self setNeedsLayout];
}

@end
