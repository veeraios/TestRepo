#import "MONLoginPresenter.h"

@interface MONLoginPresenterTest : XCTestCase

@property (nonatomic) MONLoginPresenter *testObject;
@property (nonatomic) id mockLoginView;
@property (nonatomic) id mockLoginModel;

@end

@implementation MONLoginPresenterTest

- (void)setUp {
	[super setUp];
	
    //Note: Partial mocks are temporary workaround after updating Pods, when ESCObservable is removed entirely from project
    //should switch back to niceMocks.
    self.mockLoginView = [OCMockObject partialMockForObject:[[MONLoginView alloc] initWithFrame:CGRectZero]];
    [self.mockLoginView escRegisterObserverProtocol:@protocol(MONLoginViewObserver)];
	
    self.mockLoginModel = [OCMockObject partialMockForObject:[[MONLoginModel alloc]init]];
	self.testObject = [[MONLoginPresenter alloc] initWithLoginView:self.mockLoginView loginModel:self.mockLoginModel];
}

- (void)testUsernameTextDidChange_NotifiesModel {
	NSString *expectedUsername = @"SomeUsername";
	[[self.mockLoginModel expect] setUsername:expectedUsername];
	
	[[self.mockLoginView escNotifier] usernameTextDidChange:expectedUsername];
	
	[self.mockLoginModel verify];
}

- (void)testPasswordTextDidChange_NotifiesModel {
	NSString *expectedPassword = @"ThePassword";
	[[self.mockLoginModel expect] setPassword:expectedPassword];
	
	[[self.mockLoginView escNotifier] passwordTextDidChange:expectedPassword];
	
	[self.mockLoginModel verify];
}

- (void)testLoginButtonTapped_NotifiesModel {
	[[self.mockLoginModel expect] submitLogin];
	
	[[self.mockLoginView escNotifier] loginButtonTapped];
	
	[self.mockLoginModel verify];
}

@end
