#import <ESCObservable/ESCObservable.h>
#import <UIKit/UIKit.h>

@protocol MONFilterViewObserver <NSObject>

- (void)filterCloseButtonTapped;
- (void)filterTextDidChange:(NSString *)filterText;

@end

@interface MONFilterView : UIView<ESCObservable>

- (void)setFilterText:(NSString *)filterText;
- (void)setPlaceholderText:(NSString *)placeholderText;
- (UISearchBar *)styledSearchBar;
@end
