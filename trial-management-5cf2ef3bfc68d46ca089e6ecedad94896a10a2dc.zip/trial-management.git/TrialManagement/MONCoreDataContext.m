#import "NSManagedObjectContext+Queryable.h"
#import "MONCoreDataContext.h"
#import "TMWorkingCoreDataContext.h"

const char * MONCoreDataContextSaveBackgroundQueue = "com.alamofire.networking.reachability.change";

//NSString * const MONCoreDataModelName = @"TrialManagement";

@interface MONCoreDataContext()

@property (nonatomic) NSManagedObjectModel *managedObjectModel;
@property (nonatomic) NSPersistentStoreCoordinator *persistentStoreCoordinator;
@property (nonatomic) id<MONDataModelMigration> migrationModel;

@end

@implementation MONCoreDataContext

dispatch_queue_t background_save_queue(void);

static dispatch_queue_t coredata_background_save_queue;

dispatch_queue_t background_save_queue()
{
    if (coredata_background_save_queue == NULL)
    {
        coredata_background_save_queue = dispatch_queue_create(MONCoreDataContextSaveBackgroundQueue, 0);
    }
    return coredata_background_save_queue;
}

#pragma mark - Utils
-(NSMutableArray *)searchObjects:(NSString*)entityName
                       predicate:(NSPredicate*)predicate
                         sortKey:(NSString*)sortKey
                   sortAscending:(BOOL)sortAscending {
    
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:entityName inManagedObjectContext:self.mainThreadObjectContext];
    [request setEntity:entity];
    
    if(predicate != nil) {
        [request setPredicate:predicate];
    }
    
    if(sortKey != nil) {
        NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:sortKey ascending:sortAscending];
        NSArray *sortDescriptors = [[NSArray alloc] initWithObjects:sortDescriptor, nil];
        [request setSortDescriptors:sortDescriptors];
    }
    
    NSError *error;
    NSMutableArray *mutableFetchResults = [[self.mainThreadObjectContext executeFetchRequest:request error:&error] mutableCopy];
    return mutableFetchResults;
}

-(NSMutableArray *)getObjects:(NSString*)entityName sortKey:(NSString*)sortKey sortAscending:(BOOL)sortAscending {
    return [self searchObjects:entityName
                     predicate:nil
                       sortKey:sortKey
                 sortAscending:sortAscending];
}

-(void)removeEntities:(Class)theClass where:(NSPredicate*)predicate forUser:(TMUser*)user {
    NSFetchRequest * allEntities = [[NSFetchRequest alloc] init];
    [allEntities setEntity:[NSEntityDescription entityForName:[theClass description] inManagedObjectContext:self.mainThreadObjectContext]];
    [allEntities setIncludesPropertyValues:NO]; //only fetch the managedObjectID
    
    NSPredicate *predicateWithUserFilter = [NSCompoundPredicate andPredicateWithSubpredicates:
                                            @[predicate,[NSPredicate predicateWithFormat:@"ANY users == %@", user] ]];
    [allEntities setPredicate:predicateWithUserFilter];
    
    NSError * error = nil;
    NSArray * entities = [self.mainThreadObjectContext executeFetchRequest:allEntities error:&error];
    for (NSManagedObject * entity in entities) {
        [self.mainThreadObjectContext deleteObject:entity];
    }
}

-(void)removeAllEntities:(NSString*)entityName{
    
    NSFetchRequest * allEntities = [[NSFetchRequest alloc] init];
    [allEntities setEntity:[NSEntityDescription entityForName:entityName inManagedObjectContext:self.mainThreadObjectContext]];
    [allEntities setIncludesPropertyValues:NO]; //only fetch the managedObjectID
    
    NSError * error = nil;
    NSArray * entities = [self.mainThreadObjectContext executeFetchRequest:allEntities error:&error];
    for (NSManagedObject * entity in entities) {
        [self.mainThreadObjectContext deleteObject:entity];
    }
}


-(void)removeAllEntities:(NSString*)entityName forUser:(TMUser*)user {
    
    NSFetchRequest * allEntities = [[NSFetchRequest alloc] init];
    [allEntities setEntity:[NSEntityDescription entityForName:entityName inManagedObjectContext:self.mainThreadObjectContext]];
    [allEntities setIncludesPropertyValues:NO]; //only fetch the managedObjectID
    
    NSPredicate *filterByUser = [NSPredicate predicateWithFormat:@"ANY users == %@", user];
    [allEntities setPredicate:filterByUser];
    NSError * error = nil;
    NSArray * entities = [self.mainThreadObjectContext executeFetchRequest:allEntities error:&error];
    for (NSManagedObject * entity in entities) {
        [self.mainThreadObjectContext deleteObject:entity];
    }
}

- (NSURL *)applicationDocumentsDirectory {
    return [[[NSFileManager defaultManager] URLsForDirectory:NSDocumentDirectory inDomains:NSUserDomainMask] lastObject];
}
-(NSManagedObject*)objectForId:(NSManagedObjectID*)objectId {
    
    NSError *error = nil;
    NSManagedObject * cdObject =  [self.mainThreadObjectContext existingObjectWithID:objectId error:&error];
    
    if(error) {
        DDLogError(@"could not find object for objectId %@", objectId);
        return nil;
    }
    
    return cdObject;
}

- (NSManagedObject *)managedObjectForManagedObjectIdURIRepresentation:(NSURL *)url {
    NSManagedObjectID *managedObjectId = [self.persistentStoreCoordinator managedObjectIDForURIRepresentation:url];
    return [self objectForId:managedObjectId];
}

- (void)saveContext {
    NSError *error = nil;
    NSManagedObjectContext *managedObjectContext = self.mainThreadObjectContext;
    if (managedObjectContext != nil)
    {
        NSDate *importStart = [NSDate date];
        if([managedObjectContext hasChanges]) {
            if (NO == [managedObjectContext save:&error])
            {
                DDLogError(@"Unresolved error saving to database!!!  in [MONCoreDataContext saveContext] %@, %@", error, [error userInfo]);
                abort();
            }
        }
        NSDate *importFinish = [NSDate date];
        NSTimeInterval executionTime = [importFinish timeIntervalSinceDate:importStart];
        DDLogInfo(@"save time = %f\n", executionTime);
        
    } else {
        DDLogError(@"managedObjectContext is nil");
    }
}

#pragma mark - Protocol implementation
- (NSArray *)getAll:(Class)theClass prefechedProperties:(NSArray*)prefechedProperties prefetchedRelationships:(NSArray*)prefetchedRelationships {
    NSFetchRequest *request = [self buildBasicFetchRequestWithObjectName:[theClass description] wherePredicate:nil prefechedProperties:prefechedProperties prefetchedRelationships:prefetchedRelationships];
    
    NSError *error;
    
    NSMutableArray *mutableFetchResults = [[self.mainThreadObjectContext executeFetchRequest:request error:&error] mutableCopy];
    return mutableFetchResults;
    
}
- (NSArray*)getObjects:(Class)modelClass{
    return [self getObjects:[modelClass description] sortKey:nil sortAscending:FALSE];
}

- (id)attachObject:(Class)modelClass {
    id object = [NSEntityDescription insertNewObjectForEntityForName:[modelClass description] inManagedObjectContext:self.mainThreadObjectContext];
    return object;
}

- (void)removeManagedObject:(id)managedObject{
    [self.mainThreadObjectContext deleteObject:managedObject];
    [self saveContext];
}

- (void)saveChanges{
    [self saveContext];
}

- (void)asyncUpdateWithContext:(void (^)(NSManagedObjectContext *context))startUpdate completion:(void (^)())completion{
    
    startUpdate(self.mainThreadObjectContext);
    
    NSError *error = nil;
    if (self.mainThreadObjectContext != nil)
    {
        if ([self.mainThreadObjectContext hasChanges] && ![self.mainThreadObjectContext save:&error])
        {
            DDLogError(@"Unresolved error saving to database!!!  in [MONCoreDataContext asyncUpdateWithContext] %@, %@", error, [error userInfo]);
            abort();
        }
    }
    if (completion)
    {
        dispatch_async(dispatch_get_main_queue(), completion);
    }
    
}

-(NSInteger) count:(NSString *)objectName where:(NSString*) where {
    return [[self find:objectName where:where] count];
}

- (NSArray *)find:(NSString *)objectName where:(NSString *)where propertyToFetch:(NSArray*)propertyToFetch {
    
    NSArray* result = [[[self.mainThreadObjectContext ofType:objectName]
                        where:where] toArray];
    return result;
    
}

- (NSArray *)findWithPredicate:(NSString *)objectName wherePredicate:(NSPredicate *)wherePredicate propertyToFetch:(NSArray*)propertyToFetch {
    
    NSArray* result = [[ [[self.mainThreadObjectContext ofType:objectName]
                          wherePredicate:wherePredicate] propertyToFetch:propertyToFetch] toArray];
    return result;
}

- (NSArray *)findWithPredicate:(NSString *)objectName wherePredicate:(NSPredicate *)wherePredicate prefechedProperties:(NSArray*)prefechedProperties prefetchedRelationships:(NSArray*)prefetchedRelationships {
    NSFetchRequest *request = [self buildBasicFetchRequestWithObjectName:objectName wherePredicate:wherePredicate prefechedProperties:prefechedProperties prefetchedRelationships:prefetchedRelationships];
    
    NSError *error;
    NSMutableArray *mutableFetchResults = [[self.mainThreadObjectContext executeFetchRequest:request error:&error] mutableCopy];
    return mutableFetchResults;
}

-(NSFetchRequest *)buildBasicFetchRequestWithObjectName:(NSString *)objectName wherePredicate:(NSPredicate *)wherePredicate prefechedProperties:(NSArray*)prefechedProperties prefetchedRelationships:(NSArray*)prefetchedRelationships {
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:objectName inManagedObjectContext:self.mainThreadObjectContext];
    [request setEntity:entity];
    
    if([prefechedProperties count]) {
        [request setPropertiesToFetch:prefechedProperties];
    }
    if([prefetchedRelationships count]) {
        [request setRelationshipKeyPathsForPrefetching:prefetchedRelationships];
    }
    if(wherePredicate) {
        [request setPredicate:wherePredicate];
    }
    
    [request setReturnsObjectsAsFaults:NO];
    
    return request;
}

- (NSArray *)findWithPredicate:(NSString *)objectName wherePredicate:(NSPredicate *)wherePredicate orderBy:(NSString *)orderByAttribute ascending:(BOOL)ascending {
    
    if(ascending) {
        return [[[[self.mainThreadObjectContext ofType:objectName] wherePredicate:wherePredicate] orderBy:orderByAttribute] toArray];
    }
    else{
        return [[[[self.mainThreadObjectContext ofType:objectName] wherePredicate:wherePredicate] orderByDescending:orderByAttribute] toArray];
        
    }
}

- (NSArray *)find:(NSString *)objectName orderBy:(NSString *)orderByAttribute ascending:(BOOL)ascending{
    if (ascending) {
        NSArray* result = [[[self.mainThreadObjectContext ofType:objectName]
                            orderBy:orderByAttribute] toArray];
        return result;
    }
    else{
        NSArray* result = [[[self.mainThreadObjectContext ofType:objectName]
                            orderByDescending:orderByAttribute] toArray];
        return result;
    }
}

- (NSArray *)find:(NSString *)objectName where:(NSString *)conditions {
    NSArray* result = [[[self.mainThreadObjectContext ofType:objectName]
                        where:conditions] toArray];
    return result;
}

- (NSArray *)find:(NSString *)objectName where:(NSString *)conditions take:(int)countItem{
    NSArray* result = [[[[self.mainThreadObjectContext ofType:objectName]
                         where:conditions] take:countItem] toArray];
    return result;
}

- (NSArray *)find:(NSString *)objectName where:(NSString *)conditions orderBy:(NSString *)orderByAttribute ascending:(BOOL)ascending{
    if (ascending) {
        NSArray* result = [[[[self.mainThreadObjectContext ofType:objectName]
                             where:conditions]
                            orderBy:orderByAttribute] toArray];
        return result;
    }
    else{
        NSArray* result = [[[[self.mainThreadObjectContext ofType:objectName]
                             where:conditions]
                            orderByDescending:orderByAttribute] toArray];
        return result;
    }
}
- (NSArray *)find:(NSString *)objectName where:(NSString *)conditions orderBy:(NSString *)orderByAttribute ascending:(BOOL)ascending take:(int)countItem{
    if (ascending) {
        NSArray* result = [[[[[self.mainThreadObjectContext ofType:objectName]
                              where:conditions]
                             orderBy:orderByAttribute]
                            take:countItem]
                           toArray];
        return result;
    }
    else{
        NSArray* result = [[[[[self.mainThreadObjectContext ofType:objectName]
                              where:conditions]
                             orderByDescending:orderByAttribute]
                            take:countItem]
                           toArray];
        return result;
    }
}

- (NSArray *)fetchIdsForEntity:(NSString *)entityName withPredicate:(NSPredicate *)predicate {
    return [[[self.mainThreadObjectContext ofType:entityName] wherePredicate:predicate] fetchOnIds];
}

- (void)rollback {
    [self.mainThreadObjectContext rollback];
}

#pragma mark - Core Data stack
/**
 Returns the managed object model for the application.
 If the model doesn't already exist, it is created from the application's model.
 */
- (NSManagedObjectModel *)createManagedObjectModelWithName:(NSString *)modelName
{
    if (self.managedObjectModel != nil) {
        return self.managedObjectModel;
    } else if (self.migrationModel) {
        self.managedObjectModel = [self.migrationModel modelForCurrentVersion];
    } else {
        NSURL *modelURL = [[NSBundle mainBundle] URLForResource:modelName withExtension:@"momd"];
        self.managedObjectModel = [[NSManagedObjectModel alloc] initWithContentsOfURL:modelURL];
    }
    return self.managedObjectModel;
}

/**
 Returns the persistent store coordinator for the application.
 If the coordinator doesn't already exist, it is created and the application's store added to it.
 */
- (NSPersistentStoreCoordinator *)createPersistentStoreCoordinatorForDatabase:(NSString *)database
{
    NSURL *storeURL = [[self applicationDocumentsDirectory] URLByAppendingPathComponent:database];
    
    if (self.persistentStoreCoordinator != nil) {
        return self.persistentStoreCoordinator;
    } else if (self.migrationModel) {
        self.persistentStoreCoordinator = [self.migrationModel lightweightMigrationToCurrentVersionForStore:storeURL];
    } else {
        NSError *error = nil;
        
        NSDictionary *options = [NSDictionary dictionaryWithObjectsAndKeys:
                                 [NSNumber numberWithBool:YES], NSMigratePersistentStoresAutomaticallyOption,
                                 [NSNumber numberWithBool:YES], NSInferMappingModelAutomaticallyOption, nil];
        
        self.persistentStoreCoordinator = [[NSPersistentStoreCoordinator alloc] initWithManagedObjectModel:self.managedObjectModel];
        
        if (![self.persistentStoreCoordinator addPersistentStoreWithType:NSSQLiteStoreType configuration:nil URL:storeURL options:options error:&error])
        {
            [[NSFileManager defaultManager] removeItemAtURL:storeURL error:nil];
        }
    }
    return self.persistentStoreCoordinator;
}

/**
 Returns the managed object context for the application.
 If the context doesn't already exist, it is created and bound to the persistent store coordinator for the application.
 */
- (void)createManagedObjectContextWithDatabaseName:(NSString *)databaseName modelName:(NSString *)modelName andUndoManager:(BOOL)hasUndoManager
{
    if (self.mainThreadObjectContext != nil)
    {
        return;
    }
    
    [self createManagedObjectModelWithName:modelName];
    
    NSPersistentStoreCoordinator *coordinator = [self createPersistentStoreCoordinatorForDatabase:databaseName];
    if (coordinator != nil)
    {
        self.mainThreadObjectContext = [[NSManagedObjectContext alloc] init];
        [self.mainThreadObjectContext setPersistentStoreCoordinator:coordinator];
        [self.mainThreadObjectContext setMergePolicy:NSOverwriteMergePolicy];
        [self.mainThreadObjectContext setUndoManager:hasUndoManager ? [[NSUndoManager alloc] init] : nil];
    }
}

- (void)createManagedObjectContextWithDatabaseName:(NSString *)databaseName migrationModel:(id<MONDataModelMigration>)migrationModel andUndoManager:(BOOL)hasUndoManager {
    
    self.migrationModel = migrationModel;
    [self createManagedObjectContextWithDatabaseName:databaseName modelName:nil andUndoManager:hasUndoManager];
}
@end

