#import <Foundation/Foundation.h>
#import "MONContextProtocol.h"

@interface MONManagedObjectDifferenceLogger : NSObject

- (id)initWithNewObject:(NSManagedObject *)newObject oldObject:(NSManagedObject *)oldObject withinOldContext:(id<MONContextProtocol>)oldContext withDataModelTraversalRules:(NSDictionary *)traversalRules;
- (NSDictionary *)detectDifferencesBetweenNewAndOldObjects;

@end
