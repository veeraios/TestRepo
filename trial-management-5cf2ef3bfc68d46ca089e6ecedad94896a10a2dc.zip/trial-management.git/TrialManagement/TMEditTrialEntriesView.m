#import "TMEditTrialEntriesView.h"
#import "MONDimensions.h"
#import "MONHeaderView.h"
#import "MONPlaceholderControl.h"
#import "UIColor+MONThemeColorProvider.h"

@interface TMEditTrialEntriesView ()<ESCObservableInternal>

@property (nonatomic) MONPlaceholderControl *placeholderControl;
@property (nonatomic) UICollectionView *entriesCollectionView;
@property (nonatomic) MONHeaderView *headerView;
@property (nonatomic) BOOL hasEntries;

@end

@implementation TMEditTrialEntriesView

- (instancetype)initWithCollectionView:(UICollectionView *)collectionView headerButtons:(NSArray *)headerButtons {
    if (self = [super init]) {
		[self escRegisterObserverProtocol:@protocol(TMEditTrialEntriesViewObserver)];
		
		self.autoresizesSubviews = YES;
		
		self.placeholderControl = [[MONPlaceholderControl alloc] init];
		self.placeholderControl.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
		[self.placeholderControl setImage:[UIImage imageNamed:@"ui-add-product-bg-graphic"]];
		[self.placeholderControl setText:@"Tap anywhere in this space to start adding entries."];
		[self.placeholderControl addTarget:self action:@selector(addEntriesButtonTapped) forControlEvents:UIControlEventTouchUpInside];
		[self addSubview:self.placeholderControl];
		
        self.entriesCollectionView = collectionView;
		self.entriesCollectionView.frame = self.bounds;
		self.entriesCollectionView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
		self.entriesCollectionView.backgroundColor = [UIColor clearColor];
		self.entriesCollectionView.contentInset = UIEdgeInsetsMake(MONDimensionsSmallPadding, MONDimensionsSmallPadding, MONDimensionsSmallPadding, MONDimensionsSmallPadding);
		[self addSubview:self.entriesCollectionView];
		
		self.headerView = [[MONHeaderView alloc] init];
		[self.headerView setTitle:@"Current Entries"];
		[self.headerView showNumberOfItems:YES];
		[self addSubview:self.headerView];
		
		[self.headerView setRightButtons:headerButtons];
		
		self.backgroundColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeBackground];
	}
    return self;
}

- (void)layoutSubviews {
	[super layoutSubviews];
	
	[self.headerView sizeToFit];
	self.headerView.frame = CGRectMake(0.0, 0.0, CGRectGetWidth(self.bounds), CGRectGetHeight(self.headerView.frame));
	
	self.entriesCollectionView.frame = CGRectMake(0.0,
												  CGRectGetMaxY(self.headerView.frame),
												  CGRectGetWidth(self.bounds),
												  CGRectGetHeight(self.bounds) - CGRectGetMaxY(self.headerView.frame));
	
	self.placeholderControl.frame = CGRectMake(0.0,
											   CGRectGetMaxY(self.headerView.frame),
											   CGRectGetWidth(self.bounds),
											   CGRectGetHeight(self.bounds) - CGRectGetMaxY(self.headerView.frame));

	self.entriesCollectionView.alpha = self.hasEntries ? 1.0 : 0.0;
	self.placeholderControl.alpha = self.hasEntries ? 0.0 : 1.0;
}

- (void)showEntriesCollectionView:(BOOL)showEntriesCollectionView animated:(BOOL)animated {
	CGFloat entriesCollectionViewAlpha = showEntriesCollectionView ? 1.0 : 0.0;
	CGFloat placeholderControlAlpha = showEntriesCollectionView ? 0.0 : 1.0;
	
	void (^animationBlock)(void) = ^{
		self.entriesCollectionView.alpha = entriesCollectionViewAlpha;
		self.placeholderControl.alpha = placeholderControlAlpha;
	};
	
	if (animated) {
		[UIView animateWithDuration:0.25
							  delay:0.0
							options:UIViewAnimationOptionBeginFromCurrentState
						 animations:animationBlock
						 completion:nil];
	} else {
		animationBlock();
	}

}

- (void)setNumberOfEntries:(NSUInteger)numberOfEntries animated:(BOOL)animated {
	[self.headerView setNumberOfItems:numberOfEntries];
	self.hasEntries = numberOfEntries > 0 ? YES : NO;
	[self showEntriesCollectionView:self.hasEntries animated:animated];
}

- (void)addEntriesButtonTapped {
	[self.escNotifier addEntriesButtonTapped];
}

@end
