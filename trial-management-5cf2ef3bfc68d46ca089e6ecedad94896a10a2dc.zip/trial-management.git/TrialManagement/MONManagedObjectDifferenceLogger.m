#import "MONManagedObjectDifferenceLogger.h"
#import "NSManagedObject+UIDAccessor.h"

@interface MONManagedObjectDifferenceLogger()

@property (nonatomic) id<MONContextProtocol> oldContext;
@property (nonatomic) NSDictionary *traversalRules;
@property (nonatomic) NSManagedObject *rootOldObject;
@property (nonatomic) NSManagedObject *rootNewObject;
@end

@implementation MONManagedObjectDifferenceLogger

- (id)initWithNewObject:(NSManagedObject *)newObject oldObject:(NSManagedObject *)oldObject withinOldContext:(id<MONContextProtocol>)oldContext withDataModelTraversalRules:(NSDictionary *)traversalRules {
    self = [super init];
    if (self) {
        self.oldContext = oldContext;
        self.rootOldObject = oldObject;
        self.rootNewObject = newObject;
        self.traversalRules = traversalRules;
    }
    return self;
}

- (NSDictionary *)detectDifferencesBetweenNewAndOldObjects {
    NSDictionary *changesBetweenContext = [self detectDifferencesBetweenNewObject:self.rootNewObject andOldObject:self.rootOldObject];
    [self.oldContext rollback];
    return changesBetweenContext;
}

- (NSDictionary *)detectDifferencesBetweenNewObject:(NSManagedObject *)newObject andOldObject:(NSManagedObject *)oldObject {
    if (!newObject && !oldObject) {
        return nil;
    } else if (!newObject && oldObject) {
        return @{@"self":[NSNull null]};
    } else if (newObject && !oldObject) {
        oldObject = [self.oldContext attachObject:[newObject class]];
    }
    
    NSEntityDescription *objectEntity = [newObject entity];
    
    for (NSString *attributeName in [objectEntity attributesByName]) {
        [oldObject setValue:[newObject valueForKey:attributeName] forKey:attributeName];
    }
    
    NSMutableDictionary *changesFromWorking = [NSMutableDictionary dictionaryWithDictionary:[oldObject changedValues]];
    
    NSDictionary *relationships = [objectEntity relationshipsByName];
    NSArray *validRelationsForEntity = [self.traversalRules valueForKey:[objectEntity name]];
    
    for (NSString *relationName in relationships) {
        NSRelationshipDescription *relation = [relationships valueForKey:relationName];
        NSMutableDictionary *relationDestinationChanges = [[NSMutableDictionary alloc]init];
        
        if ([validRelationsForEntity containsObject:relationName]) {
            if ([relation isToMany]) {

                NSArray *toManyRelationNew = [[newObject valueForKey:relationName] allObjects];
                NSArray *toManyRelationOld = [[oldObject valueForKey:relationName] allObjects];
                
                __block NSMutableSet *allUIDValuesForNewAndOld = [[NSMutableSet alloc] init];
                __block NSMutableDictionary *newUIDObjectPairs = [NSMutableDictionary dictionaryWithCapacity:[toManyRelationNew count]];
                __block NSMutableDictionary *oldUIDObjectPairs = [NSMutableDictionary dictionaryWithCapacity:[toManyRelationOld count]];
                
                [toManyRelationNew enumerateObjectsUsingBlock:^(id obj,NSUInteger idx,BOOL *stop) {
                    [newUIDObjectPairs setObject:obj forKey:[obj uniqueIdentifierValue]];
                    [allUIDValuesForNewAndOld addObject:[obj uniqueIdentifierValue]];
                }];
                
                [toManyRelationOld enumerateObjectsUsingBlock:^(id obj,NSUInteger idx,BOOL *stop) {
                    [oldUIDObjectPairs setObject:obj forKey:[obj uniqueIdentifierValue]];
                    [allUIDValuesForNewAndOld addObject:[obj uniqueIdentifierValue]];
                }];
                
                
                for (NSString *uIDValue in [allUIDValuesForNewAndOld allObjects]) {
                    
                    NSDictionary *setRelationshipChanges = [self detectDifferencesBetweenNewObject:[newUIDObjectPairs valueForKey:uIDValue] andOldObject:[oldUIDObjectPairs valueForKey:uIDValue]];
                    
                    if ([setRelationshipChanges count] > 0) {
                        [relationDestinationChanges setValue:setRelationshipChanges forKey:uIDValue];
                    }
                }
                
            } else {
                relationDestinationChanges = [NSMutableDictionary dictionaryWithDictionary:[self detectDifferencesBetweenNewObject:[newObject valueForKey:relationName] andOldObject:[oldObject valueForKey:relationName]]];
            }
            
            if ([relationDestinationChanges count] > 0) {
                [changesFromWorking setValue:relationDestinationChanges forKey:relationName];
            }
        }
        
        
    }
    
    return changesFromWorking;
}


@end
