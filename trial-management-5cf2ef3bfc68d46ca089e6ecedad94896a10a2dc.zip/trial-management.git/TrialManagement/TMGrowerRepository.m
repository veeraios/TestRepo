#import "TMGrowerRepository.h"
#import "TMGrower.h"
#import "MONSafeString.h"

@implementation TMGrowerRepository

- (NSArray *)searchGrower:(NSString *)name {
	NSArray *filteredItems = nil;
	if ([name length] != 0) {
		filteredItems = [self find:[NSString stringWithFormat:@"name CONTAINS[cd] '%@' OR postalCode CONTAINS '%@' OR city CONTAINS[cd] '%@' OR state CONTAINS[cd] '%@'", name, name, name, name]];
	} else {
		filteredItems = [self getAll];
	}
	return filteredItems;
}

-(void)syncFromService:(NSArray*)dataFromService completionBlock:(MONDataImportCompletionBlock)completionBlock {	
	__block TMUser *currentUser = [self currentUser];

	MONDataImportBlock block = ^(NSDictionary* dict, NSManagedObject *coredataModel) {
        if([dict valueForKey:@"name"] && [[dict valueForKey:@"name"] length] > 0) {
            TMGrower* cdmodel = (TMGrower*)coredataModel;
            cdmodel.growerId = [dict valueForKey:@"id"];
            cdmodel.name = [dict valueForKey:@"name"];
            cdmodel.city = [dict valueForKey:@"city"];
            cdmodel.state = [dict valueForKey:@"state"];
            cdmodel.country = [dict valueForKey:@"country"];
            cdmodel.postalCode = [dict valueForKey:@"postalCode"];
            cdmodel.phoneNumber = [dict valueForKey:@"phoneNumber"];
            cdmodel.faxNumber = [dict valueForKey:@"faxNumber"];
            
            NSArray *splitAddress = [[dict valueForKey:@"address"] componentsSeparatedByString:@"|"];
            cdmodel.address1 = [splitAddress objectAtIndex:0];
            cdmodel.address2 = splitAddress.count == 2 ? [splitAddress objectAtIndex:1] : @"";
            
            cdmodel.email = [dict valueForKey:@"email"];
            cdmodel.accountId = [dict valueForKey:@"accountId"];
            cdmodel.category = [dict valueForKey:@"category"];
            
            [cdmodel addUsersObject:currentUser];
        } else {
            [self remove:coredataModel];
        }
	};
	
	[self import:dataFromService dataServicePrimaryKey:@"id" databasePrimaryKey:@"growerId" dataImportBlock:block currentUser:currentUser completionBlock:completionBlock];
}
@end
