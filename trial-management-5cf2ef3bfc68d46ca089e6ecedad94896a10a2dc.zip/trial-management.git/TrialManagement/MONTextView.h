#import <UIKit/UIKit.h>
@class MONTextView;

@protocol MONTextViewDelegate <NSObject>

- (void)monTextViewTextDidChange:(MONTextView *)textView;
- (void)monTextViewDidEndEditing:(MONTextView *)textView;

@end
@interface MONTextView : UIView

@property (nonatomic) NSString *text;
@property (nonatomic, weak) id<MONTextViewDelegate> monTextViewDelegate;
@property (nonatomic, weak) id<UITextViewDelegate> delegate;

-(void)setTextViewDelegate:(id<UITextViewDelegate>)textViewDelegate;

-(void)setEditable:(BOOL)editable;
- (void)setLockedColor;

@end