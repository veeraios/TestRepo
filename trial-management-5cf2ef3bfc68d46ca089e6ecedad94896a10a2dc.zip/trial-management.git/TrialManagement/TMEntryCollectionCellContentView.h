#import "MONCardContainerView.h"

@class TMEntryCollectionCellContentView;
@protocol TMEntryCollectionCellContentViewDelegate <NSObject>

- (void)entryCollectionCellContentAddTreatmentTapped:(UIView *)view;
- (void)deleteTreatmentButtonTapped;

@end

@interface TMEntryCollectionCellContentView : MONCardContainerView

@property (nonatomic,weak) id<TMEntryCollectionCellContentViewDelegate> delegate;

- (id)initWithFrame:(CGRect)frame asStaticCellView:(BOOL)isStaticCellView;
- (void)setIsReadOnly:(BOOL)isReadOnly;
- (void)setNumber:(NSInteger)number;
- (void)setBrand:(NSString *)brand;
- (void)setProduct:(NSString *)product;
- (void)setRMValue:(NSDecimalNumber *)rmValue;
- (void)setTrait:(NSString *)trait;
- (void)setTreatment:(NSString *)treatment;
- (void)setSelected:(BOOL)selected;

@end
