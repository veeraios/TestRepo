@import CoreData;
#import "TMUser.h"

@protocol MONContextProtocol
- (NSArray *)getObjects:(Class)modelClass;
- (id)attachObject:(Class) modelClass;
- (void)removeManagedObject:(id) managedObject;
- (void)saveChanges;
- (void)asyncUpdateWithContext:(void(^)(NSManagedObjectContext *context))startUpdate completion:(void(^)())completion;
- (NSArray *)find:(NSString *)objectName where:(NSString *)conditions;
- (NSArray *)find:(NSString *)objectName where:(NSString *)conditions take:(int) countItem;
- (NSArray *)find:(NSString *)objectName where:(NSString *)conditions orderBy:(NSString *)orderByAttribute ascending:(BOOL)ascending;
- (NSArray *)find:(NSString *)objectName where:(NSString *)conditions orderBy:(NSString *)orderByAttribute ascending:(BOOL)ascending take:(int)countItem;
- (NSInteger) count:(NSString *)objectName where:(NSString *)where;
- (NSArray *)find:(NSString *)objectName where:(NSString *)where propertyToFetch:(NSArray *)propertyToFetch;
- (NSArray *)findWithPredicate:(NSString *)objectName wherePredicate:(NSPredicate *)wherePredicate propertyToFetch:(NSArray *)propertyToFetch;
- (NSArray *)findWithPredicate:(NSString *)objectName wherePredicate:(NSPredicate *)wherePredicate prefechedProperties:(NSArray*)prefechedProperties prefetchedRelationships:(NSArray*)prefetchedRelationships;
- (NSArray *)findWithPredicate:(NSString *)objectName wherePredicate:(NSPredicate *)wherePredicate orderBy:(NSString *)orderByAttribute ascending:(BOOL)ascending;
- (NSArray *)find:(NSString *)objectName orderBy:(NSString *)orderByAttribute ascending:(BOOL)ascending;
- (NSArray *)fetchIdsForEntity:(NSString *)entityName withPredicate:(NSPredicate *)predicate;
- (NSManagedObject *)objectForId:(NSManagedObjectID *)objectId;
- (NSManagedObject *)managedObjectForManagedObjectIdURIRepresentation:(NSURL *)url;
- (void)removeAllEntities:(NSString*)entityName forUser:(TMUser*)user;
- (void)removeEntities:(Class)theClass where:(NSPredicate*)predicate forUser:(TMUser*)user;
- (void)removeAllEntities:(NSString*)entityName;
- (NSArray *)getAll:(Class)theClass prefechedProperties:(NSArray*)prefechedProperties prefetchedRelationships:(NSArray*)prefetchedRelationships;
- (void)rollback;

@end
