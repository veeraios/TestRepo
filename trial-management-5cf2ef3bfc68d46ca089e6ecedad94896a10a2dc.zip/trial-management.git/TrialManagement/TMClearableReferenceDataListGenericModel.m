//
//  TMClearableReferenceDataListGenericModel.m
//  TrialManagement
//
//  Created by SINGH, SUPREET [AG/1000] on 12/2/14.
//  Copyright (c) 2014 Monsanto. All rights reserved.
//

#import "TMClearableReferenceDataListGenericModel.h"

@interface TMClearableReferenceDataListGenericModel()

@property (nonatomic) NSArray *dataArray;
@property (nonatomic) NSString *placeholderText;
@property (nonatomic, copy) NSString*(^nameBlock)(NSInteger);

@end

@implementation TMClearableReferenceDataListGenericModel

- (instancetype)initWithDataArray:(NSArray*)dataArray nameBlock:(NSString*(^)(NSInteger))nameBlock placeholderText:(NSString *)placeholderText {
    self = [super init];
    if (self) {
        self.dataArray = dataArray;
        self.nameBlock = nameBlock;
        self.placeholderText = placeholderText;
    }
    return self;
}

- (NSString *)nameForItemAtIndex:(NSInteger)index {
    if (index == 0) {
        return self.placeholderText;
    } else {
        return self.nameBlock(index - 1);
    }
}

-(id)objectAtIndex:(NSInteger)index {
    if (index == 0) {
        return self.placeholderText;
    } else {
        return [self.dataArray objectAtIndex:index - 1];
    }
}

- (NSInteger)numberOfItems {
    return [self.dataArray count] + 1;
}

@end
