
#import "NSManagedObject+TMCoreDataTestHelper.h"
#import "TMBrand.h"
#import "TMBrandModel.h"

@interface TMBrandModelTest : XCTestCase

@property (nonatomic) TMBrandModel* testObject;

@end

@implementation TMBrandModelTest

- (void)testNameForItemAtIndexReturnsBrandName
{
	TMBrand *brand = [TMBrand create];
	brand.name = @"test";
	
	self.testObject = [[TMBrandModel alloc] initWithDataSource:@[brand]];
	NSString *actual =  [self.testObject nameForItemAtIndex:0];
	XCTAssertEqualObjects(actual,brand.name);
}

- (void)testNameForItem {
    TMBrand *brand = [TMBrand create];
    brand.name = @"testState";
    
    self.testObject = [[TMBrandModel alloc]initWithDataSource:@[brand]];
    XCTAssert([[self.testObject nameForItem:brand] isEqualToString:@"testState"]);
}

- (void)testNameForItem_itemDoesNotExist {
    TMBrand *brand = [TMBrand create];
    brand.name = @"testState";
    
    self.testObject = [[TMBrandModel alloc]initWithDataSource:@[]];
    XCTAssertFalse([[self.testObject nameForItem:brand] isEqualToString:@"testState"]);
    XCTAssert([[self.testObject nameForItem:brand] isEqualToString:@""]);
}

- (void)testIndexForItem {
    TMBrand *brand1 = [TMBrand create];
    TMBrand *brand2 = [TMBrand create];
    
    self.testObject = [[TMBrandModel alloc] initWithDataSource:@[brand1,brand2]];
    XCTAssert([self.testObject indexForItem:brand1] == 0);
    XCTAssert([self.testObject indexForItem:brand2] == 1);
}

- (void)testIndexForItem_itemDoesNotExist {
    TMBrand *brand1 = [TMBrand create];
    TMBrand *brand2 = [TMBrand create];
    
    self.testObject = [[TMBrandModel alloc] initWithDataSource:@[brand1]];
    XCTAssert([self.testObject indexForItem:brand1] == 0);
    XCTAssert([self.testObject indexForItem:brand2] == NSNotFound);
}
@end
