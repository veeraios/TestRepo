#import <Foundation/Foundation.h>

@protocol MONSingleSelectionCardCollectionViewCellModel <NSObject>

@end
