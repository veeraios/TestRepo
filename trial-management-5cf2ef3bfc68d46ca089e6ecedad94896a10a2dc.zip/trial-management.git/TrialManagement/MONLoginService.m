#import "MONLoginService.h"
#import "MSharedNetAccessManager.h"

@interface MONLoginService ()

@property (nonatomic) id<MNetAccessManager> netAccessManager;

@end

@implementation MONLoginService

- (id)init {
	id<MNetAccessManager> netAccessManager = [MSharedNetAccessManager sharedNetAccessManager];
	return [self initWithNetAccessManager:netAccessManager];
}

- (instancetype)initWithNetAccessManager:(id<MNetAccessManager>)netAccessManager {
	self = [super init];
	if (self) {
		self.netAccessManager = netAccessManager;
	}
	return self;
}

- (void)loginWithUsername:(NSString *)username
				 password:(NSString *)password
			 successBlock:(void (^)(void))successBlock
			 failureBlock:(void (^)(NSError *))failureBlock {
	//here!
	[self.netAccessManager loginWithUsername:username
									password:password
								successBlock:successBlock
								failureBlock:failureBlock];
}

- (void)logout {
	[self.netAccessManager logout];
}

- (BOOL)userIsAuthenticated {
	return [self.netAccessManager isLoggedIn];
}

@end
