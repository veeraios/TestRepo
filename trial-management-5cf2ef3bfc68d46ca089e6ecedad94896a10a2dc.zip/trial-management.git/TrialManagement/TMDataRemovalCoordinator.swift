import UIKit

enum RemovalStage: String {
    case Trial = "Trial"
    case Treatment = "Treatment"
    case PendingQueue = "Pending Queue"
}

protocol TMDataRemovalCoordinatorDelegate {
    func dataRemovalStarted()
    func dataRemovalCompleted()
    func dataRemovalFailedOnStage(stage: RemovalStage)
    func dataRemovalStageUpdated(stage: RemovalStage)
}

class TMDataRemovalCoordinator: NSObject {
    typealias StageCompletion = () -> ()
    
    var delegate: TMDataRemovalCoordinatorDelegate?
    private(set) var removalStages = [RemovalStage]()
    private var dataRemover = TMDataRemover()
    
    override init() {
        super.init()
        removalStages = [.Trial, .Treatment, .PendingQueue]
    }
    
    convenience init(dataRemover: TMDataRemover) {
        self.init()
        self.dataRemover = dataRemover
    }
    
    func startRemoval(completion: StageCompletion?) {
        delegate?.dataRemovalStarted()
        chainRemovalFunctionCallbacks(completion)()
    }
    
    private func chainRemovalFunctionCallbacks(removalCompletion: StageCompletion?) -> StageCompletion {
        let allComplete: StageCompletion = { [unowned self] in
            self.delegate?.dataRemovalCompleted()
            removalCompletion?()
        }
        
        return removalStages.reverse().reduce(allComplete, {[unowned self] (reduced, stage) -> StageCompletion in
            return {
                self.delegate?.dataRemovalStageUpdated(stage)
                self.dataRemover.removeDataFor(stage, completion: self.genericStageCompletion(stage, stageCompletion: reduced, failureCompletion: removalCompletion))
            }})
    }
    
    private func genericStageCompletion(stage: RemovalStage, stageCompletion: StageCompletion, failureCompletion: StageCompletion?) -> (DataRemovalStatus -> ()) {
        return { status in
            if (status == .Failure) {
                self.delegate?.dataRemovalFailedOnStage(stage)
                failureCompletion?()
            } else {
                stageCompletion()
            }
        }
    }
}
