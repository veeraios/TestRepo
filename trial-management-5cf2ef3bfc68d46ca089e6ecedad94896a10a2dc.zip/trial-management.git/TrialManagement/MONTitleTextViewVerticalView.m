#import "MONTitleTextViewVerticalView.h"
#import "MONLabel.h"
#import "MONTextView.h"
#import "MONFonts.h"

static const CGFloat TitleLabelOffsetY = 4.0;
static const CGFloat TextViewDefaultHeight = 55.0;
static const CGFloat TextViewTopMargin = 5.0;

@interface MONTitleTextViewVerticalView ()

@property (nonatomic) MONLabel *titleLabel;
@property (nonatomic) MONTextView *textView;

@end


@implementation MONTitleTextViewVerticalView

- (id)initWithFrame:(CGRect)frame {
	self = [super initWithFrame:frame];
	if (self) {
		self.titleLabel = [[MONLabel alloc] init];
		self.titleLabel.fontName = OpenSansBold;
		[self addSubview:self.titleLabel];
		
		self.textView = [[MONTextView alloc] init];
		[self addSubview:self.textView];
	}
	return self;
}

- (void)layoutSubviews {
	[super layoutSubviews];
	
	[self.titleLabel sizeToFit];
	self.titleLabel.frame = CGRectMake(0.0, -TitleLabelOffsetY, CGRectGetWidth(self.bounds), CGRectGetHeight(self.titleLabel.frame));
	
	self.textView.frame = CGRectMake(0.0, CGRectGetMaxY(self.titleLabel.frame) + TextViewTopMargin, CGRectGetWidth(self.bounds), TextViewDefaultHeight);
}

- (CGSize)sizeThatFits:(CGSize)size {
	CGSize sizeThatFits = CGSizeMake(size.width, 0.0);

	[self.titleLabel sizeToFit];
	sizeThatFits.height -= TitleLabelOffsetY;
	sizeThatFits.height += CGRectGetHeight(self.titleLabel.frame);
	sizeThatFits.height += TextViewTopMargin;
	sizeThatFits.height += TextViewDefaultHeight;
	
	return sizeThatFits;
}

- (void)setTitleText:(NSString *)titleText {
	self.titleLabel.text = titleText;
}

- (void)setTextViewText:(NSString *)textViewText {
	self.textView.text = textViewText;
}

- (BOOL)becomeFirstResponder {
	return [self.textView becomeFirstResponder];
}

- (BOOL)resignFirstResponder {
	return [self.textView resignFirstResponder];
}

@end
