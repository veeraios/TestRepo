//
//  MONHeaderLabel.swift
//  TrialManagement
//
//  Created by GADIRAJU, PRANEETH [AG/1000] on 7/13/15.
//  Copyright (c) 2015 Monsanto. All rights reserved.
//

import UIKit

class MONHeaderLabel: MONLabel {
    override func drawTextInRect(rect: CGRect) {
        let insets = UIEdgeInsets(top: 0, left: 10, bottom: 0, right: 10)
        super.drawTextInRect(UIEdgeInsetsInsetRect(rect, insets))
    }
}
