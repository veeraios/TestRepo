//
//  TMBrand.h
//  TrialManagement
//
//  Created by Jason Ludwig on 6/17/14.
//  Copyright (c) 2014 Monsanto. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class TMProtocol, TMTechAgronomist, TMTrial, TMUser;

@interface TMBrand : NSManagedObject

@property (nonatomic, retain) NSNumber * brandId;
@property (nonatomic, retain) NSString * name;
@property (nonatomic, retain) NSSet *protocols;
@property (nonatomic, retain) NSSet *techAgronomists;
@property (nonatomic, retain) NSSet *trials;
@property (nonatomic, retain) NSSet *users;
@end

@interface TMBrand (CoreDataGeneratedAccessors)

- (void)addProtocolsObject:(TMProtocol *)value;
- (void)removeProtocolsObject:(TMProtocol *)value;
- (void)addProtocols:(NSSet *)values;
- (void)removeProtocols:(NSSet *)values;

- (void)addTechAgronomistsObject:(TMTechAgronomist *)value;
- (void)removeTechAgronomistsObject:(TMTechAgronomist *)value;
- (void)addTechAgronomists:(NSSet *)values;
- (void)removeTechAgronomists:(NSSet *)values;

- (void)addTrialsObject:(TMTrial *)value;
- (void)removeTrialsObject:(TMTrial *)value;
- (void)addTrials:(NSSet *)values;
- (void)removeTrials:(NSSet *)values;

- (void)addUsersObject:(TMUser *)value;
- (void)removeUsersObject:(TMUser *)value;
- (void)addUsers:(NSSet *)values;
- (void)removeUsers:(NSSet *)values;

@end
