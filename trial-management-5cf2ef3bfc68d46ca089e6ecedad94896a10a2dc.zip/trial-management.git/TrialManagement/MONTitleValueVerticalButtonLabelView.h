#import "MONTitleValueVerticalLabels.h"

@class MONTitleValueVerticalButtonLabelView;
@protocol MONTitleValueVerticalButtonLabelViewDelegate <NSObject>

- (void)titleValueVerticalButtonLabelViewButtonTapped:(MONTitleValueVerticalButtonLabelView *)titleValueVerticalButtonLabelView;
- (void)iconButtonTapped;

@end

@interface MONTitleValueVerticalButtonLabelView : MONTitleValueVerticalLabels

@property (nonatomic,weak) id<MONTitleValueVerticalButtonLabelViewDelegate> delegate;

- (void)setIsReadOnly:(BOOL)isReadOnly;
- (void)setButtonText:(NSString *)buttonText;
- (void)setIconButtonImage:(UIImage *)iconButtonImage;

@end
