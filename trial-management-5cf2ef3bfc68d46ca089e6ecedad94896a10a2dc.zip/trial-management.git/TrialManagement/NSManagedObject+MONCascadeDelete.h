//
//  NSManagedObject+MONCascadeDelete.h
//  TrialManagement
//
//  Created by GADIRAJU, PRANEETH [AG/1000] on 1/7/15.
//  Copyright (c) 2015 Monsanto. All rights reserved.
//

#import <CoreData/CoreData.h>

@interface NSManagedObject (MONCascadeDelete)
- (void)deleteWithTraversal:(NSDictionary *)traversal;
- (void)deleteWithRefData;
- (void)deleteObject;
@end
