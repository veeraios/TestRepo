 //
//  TMMergeCoordinator.swift
//  TrialManagement
//
//  Created by WAIDMANN, ALAN [AG/1000] on 1/14/15.
//  Copyright (c) 2015 Monsanto. All rights reserved.
//

import UIKit
 
private var sharedMergeCoordinator:TMMergeCoordinator?
 
class TMMergeCoordinator: NSObject, TMMergeUIOptionsDelegate {

    let NewTrialTitle = "New Trial"
    var changesMadeOnPage = "NO_SUCH_PAGE"
    
    typealias ResponseCompletion = (response:[NSObject : AnyObject]!, trial:TMTrial!) -> Void
	private let trialDataSync: TMTrialDataSync
    private let tmDifferenceDetectionEngine : TMDifferenceDetectionEngine
//    private var trialResponseConverter : TMTrialResponseConverter?
	
	
    private let trialResponseConverter : TMTrialResponseConverter
	
    
    private var currentTrial : TMTrial?
    private var currentMergeTrialModel : TMMergeTrialModel?
    private var mergeEngine : MONMergeEngine?
    private var workingToBackupChangeDict, importToBackupChangeDict : [NSObject:AnyObject]?
    private let navigationController:UINavigationController
    
    init(navigationController: UINavigationController) {
        self.navigationController = navigationController
        trialDataSync = TMTrialDataSync()
        tmDifferenceDetectionEngine = TMDifferenceDetectionEngine(backupContext: TMBackupUnitOfWork.sharedInstance().backupContext)
        
		
        trialResponseConverter = TMTrialResponseConverter(importContext:TMImportUnitOfWork.sharedInstance.context, andWorkingContext: TMWorkingUnitOfWork.sharedInstance().workingContext, withImportRepo:TMImportUnitOfWork.sharedInstance.trialRepository)

        
        super.init()
        sharedMergeCoordinator = self
    }
    
    init(trial:TMTrial, dataSync:TMTrialDataSync, differenceDetectionEngine:TMDifferenceDetectionEngine, trialResponseConverter:TMTrialResponseConverter, navigationController:UINavigationController) {
        self.trialDataSync = dataSync
        self.navigationController = navigationController
        self.tmDifferenceDetectionEngine = differenceDetectionEngine
        self.trialResponseConverter = trialResponseConverter
    }
    
    class var sharedInstance: TMMergeCoordinator {
        return sharedMergeCoordinator!
    }
    
    func saveTrial(trial: TMTrial) {
        self.currentTrial = trial
        
		if(!(TMTrialModel(trial: trial).isRelinquishedOrCancelled())) {
			if(currentTrial?.trialId != nil && currentTrial?.trialId.longLongValue > 0) {
				workingToBackupChangeDict = tmDifferenceDetectionEngine.changesInCurrentContextForTrial(currentTrial!)
				if let changeDictionary = workingToBackupChangeDict? {
					if(changeDictionary.count > 0){

						
//						for (key, value) in changeDictionary {
//                            MONGoogleAnalytics.trackEvent(key.description, anAction: "Change Detection - \(trial.trialId)", aLabel: value.description)
//						}
						
						self.trialDataSync.saveTrialThruPendingQueue(currentTrial, completionBlock: nil)
						trialDataSync.getTrialById(trial, completionBlock:handleResponse(trial))

					}
				}
			} else {
				self.trialDataSync.saveTrialThruPendingQueue(currentTrial, completionBlock: nil)
			}
		}

}

    func importTrialData(trialDictionary: [NSObject : AnyObject], trial: TMTrial) {
        var user = TMWorkingUnitOfWork.sharedInstance().findUser()
        var clonedUser = user.cloneInContext(TMImportUnitOfWork.sharedInstance.mainThreadObjectContext(), withDataModelTraversalRules: nil) as TMUser
        
        TMImportUnitOfWork.sharedInstance.context.saveChanges()
        
        /** TODO MERGE: trialResponseConverter should not be an optional
        trialResponseConverter.syncDataIntoImportContext(trialDictionary, user:clonedUser, completionBlock:{ [unowned self] in
        **/
		
        trialResponseConverter.syncDataIntoImportContext(trialDictionary, user:clonedUser, completionBlock:{ [unowned self] in
           
            if let importTrial = TMImportUnitOfWork.sharedInstance.findTrial(trial.trialId.longLongValue) {
                self.importToBackupChangeDict = self.tmDifferenceDetectionEngine.changesInCurrentContextForTrial(importTrial)
				if let differenceDetected = self.importToBackupChangeDict? {
                if (differenceDetected.count > 0) {
					
					for (key, value) in differenceDetected {
                        let webDataValue = trialDictionary[key]?.description
                        if(webDataValue != nil){
                            MONGoogleAnalytics.trackEvent(key.description, anAction: "Change Detection - \(trial.trialId)", aLabel: "Web Value = \(webDataValue) and iOS = \(value.description)")
                        }
					}
				}
					
					/**
                    self.mergeEngine = MONMergeEngine(changeLogLeft:self.importToBackupChangeDict!  as NestedDict, changeLogRight:self.workingToBackupChangeDict!  as NestedDict)
                    let allChanges = self.mergeEngine?.identifiedChanges()
                    
                    let mergeTrialModelBuilder = TMMergeTrialModelBuilder(trial:trial, allChanges:allChanges!)
                    self.currentMergeTrialModel =  mergeTrialModelBuilder.populateMergeTrialModel()
                    
                    let mergeTrialViewModelBuilder = TMMergeTrialViewModelBuilder(mergeTrialModel: self.currentMergeTrialModel!, webTrial: importTrial, context: TMWorkingUnitOfWork.sharedInstance().workingContext)
                    
                    if let mergeTrialViewModel = mergeTrialViewModelBuilder.buildMergeTrialViewModel()? {
                        self.launchMergeUI(mergeTrialViewModel, mergeTrialModel: self.currentMergeTrialModel!)
                    } else {
                        self.saveResolvedValues()
                    }
				    **/
                    
                    TMImportUnitOfWork.sharedInstance.deleteTrial(importTrial)
                } else {
                    self.trialDataSync.saveTrialThruPendingQueue(self.currentTrial, completionBlock: nil)
                }
            }
        })
    }
    
    private func launchMergeUI(mergeTrialViewModel: TMMergeTrialViewModel, mergeTrialModel: TMMergeTrialModel) {
        let mergeSummaryViewController = TMMergeSummaryViewController(mergeTrialModel: mergeTrialModel, mergeTrialViewModel: mergeTrialViewModel)
        mergeSummaryViewController.delegate = self
        mergeSummaryViewController.modalPresentationStyle = UIModalPresentationStyle.OverCurrentContext
        mergeSummaryViewController.modalTransitionStyle = UIModalTransitionStyle.CrossDissolve
        self.navigationController.presentViewController(mergeSummaryViewController, animated: true, completion: nil)
    }
    
    internal func saveResolvedValues() {
        currentMergeTrialModel!.saveResolvedValuesToContext(TMWorkingUnitOfWork.sharedInstance().workingContext)
        self.trialDataSync.saveTrialThruPendingQueue(self.currentTrial, completionBlock: nil)
    }
    
    private func importHasReleventSectionChanges() -> Bool {
        if let changes = self.importToBackupChangeDict? {
           return TMMergeEditTrialSection().groups.first?.pathPrefixes.findFirst({contains(changes.keys,$0)}) != nil
        }
        return false
    }

    private func handleResponse(trial:TMTrial) -> ResponseCompletion {
        return { (response:[NSObject : AnyObject]!, trial:TMTrial!) -> Void in
            let trialName = trial.name ?? self.NewTrialTitle
			self.importTrialData(response, trial: trial)
        }
    }
    
    func close() {
        self.navigationController.dismissViewControllerAnimated(true, completion: nil)
    }

}
