#import "MSharedNetAccessManager.h"
#import "MNetAccessManagerFactory.h"

@interface MSharedNetAccessManager()
@property (nonatomic) id<MNetAccessManager> sharedNetAccessManager;
@end

@implementation MSharedNetAccessManager

+ (id<MNetAccessManager>) sharedNetAccessManager {
    static id<MNetAccessManager> _sharedNetAccessManager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _sharedNetAccessManager = [MNetAccessManagerFactory accessManagerWithGlobalSignInServiceForSharedAccessGroup];
    });
    return _sharedNetAccessManager;
}

@end
