#import "MONLoginView.h"
#import "MONLoginModel.h"
#import <Foundation/Foundation.h>

@interface MONLoginPresenter : NSObject

- (instancetype)init UNAVAILABLE_ATTRIBUTE;
- (instancetype)initWithLoginView:(MONLoginView *)loginView loginModel:(MONLoginModel *)loginModel;

@end
