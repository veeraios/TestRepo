#import "NSDictionary+TMBlocks.h"

@implementation NSDictionary (TMBlocks)

- (NSDictionary *)where:(BOOL (^)(id key, id obj))block {
    NSMutableDictionary* result = [[NSMutableDictionary alloc] init];
    [self enumerateKeysAndObjectsUsingBlock:^(id key, id obj, BOOL *stop) {
        if (block(key, obj)) {
            [result setObject:obj forKey:key];
        }
    }];
    return result;
}

@end
