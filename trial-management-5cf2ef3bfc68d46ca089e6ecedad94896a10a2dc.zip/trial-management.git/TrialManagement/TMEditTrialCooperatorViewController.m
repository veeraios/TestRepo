#import "TMEditTrialCooperatorViewController.h"
#import "MONAgreementViewController.h"
#import "TMEditTrialCooperatorView.h"
#import "MONTextFieldEditorViewController.h"
#import "MONSingleSearchViewController.h"
#import "TMCooperatorTableViewCell.h"
#import "MONButton.h"
#import "TMTabNameConstants.h"
#import "TMCooperatorOperationEnum.h"
#import "TrialManagement-Swift.h"
#import "TMCooperatorSearchStrategy.h"

NSString *const PlotState = @"PlotState";
NSString *const SelectedCooperatorMissingInfoHeader = @"Selected %@ is missing required information";
NSString *const SelectedGrowerMissingInfoError = @"Please make sure selected grower has name, address, city, state and postal code";
NSString *const SelectedDealerMissingInfoError = @"Please make sure selected dealer has name";

@interface TMEditTrialCooperatorViewController () <MONAgreementDelegate, MONSignatureDelegate, TMEditTrialCooperatorViewDelegate, TMCooperatorOptionsDelegate, TMCooperatorSearchViewControllerDelegate>

@property(nonatomic) TMEditTrialCooperatorView *cooperatorView;
@property(nonatomic) MONTextFieldEditorViewController *textViewFieldEditor;
@property(nonatomic) TMCooperatorInfoViewModel *cooperatorViewModel;
@property(nonatomic) TMCooperatorSearchViewController *searchViewController;
@property(nonatomic) MONButton *continueButton;
@property(nonatomic) TMTrialModel *trialModel;
@property(nonatomic) TMCooperatorUpdateViewController *cooperatorUpdateViewController;
@end

@implementation TMEditTrialCooperatorViewController

@synthesize tabSettingsObject = _tabSettingsObject;

- (instancetype)initWithTrialModel:(TMTrialModel *)trialModel {
  self = [super initWithTrialModel:trialModel theClass:[self class]];
  if (self) {

    self.trialModel = trialModel;
  }
  return self;
}

- (void)viewDidLoad {
  [super viewDidLoad];

  self.continueButton = [[MONButton alloc] init];
  [self.continueButton setTitle:@"Continue" forState:UIControlStateNormal];
  [self.continueButton addTarget:self action:@selector(continueButtonTapped) forControlEvents:UIControlEventTouchUpInside];
  self.continueButton.enabled = ![self.trialModel isReadOnly];
  self.continueButton.alpha = ![self.trialModel isReadOnly] ? 1.0f : 0.7f;

  self.cooperatorViewModel = [[TMCooperatorInfoViewModel alloc] init];

  self.cooperatorView = [[TMEditTrialCooperatorView alloc] initWithViewModel:self.cooperatorViewModel headerButtons:@[self.continueButton]];
  self.cooperatorView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
  self.cooperatorView.agreementDelegate = self;
  self.cooperatorView.delegate = self;
  [self.view addSubview:self.cooperatorView];

  [self.cooperatorView setGrowerName:self.trialModel.growerName];
  [self.cooperatorView setDealerName:self.trialModel.dealerName];

  [self.cooperatorView setState:self.trialModel.stateName];
  [self.cooperatorView setCounty:self.trialModel.countyName];

  [self.cooperatorView setShortDescriptionText:self.trialModel.plotTypeDescription];

  [self.cooperatorView setCooperatorSignatureDate:self.trialModel.cooperatorSignatureDate];
  [self.cooperatorView setCooperatorSignature:self.trialModel.cooperatorSignature];
  [self.cooperatorView setCooperatorRelease:self.trialModel.cooperatorRelease];

  [self.cooperatorView setAgreementSignatureImage:self.trialModel.signatureImage];
}

- (void)harvestSpatiallyTapped:(BOOL)value {
  [self.trialModel setHarvestSpatially:value];
}

- (void)viewWillAppear:(BOOL)animated {
  [super viewWillAppear:animated];

  [self.cooperatorView setCropName:self.trialModel.cropName brandName:self.trialModel.brandName];

  [self.trialModel defaultHarvestSpatiallyIfRelevant];
  [self.cooperatorView setHarvestSpatially:self.trialModel.harvestSpatially];
  self.cooperatorView.frame = self.view.bounds;
}

- (void)viewDidAppear:(BOOL)animated {
  [super viewDidAppear:animated];

  [MONGoogleAnalytics trackView:@"Trial - Grower Information"];
}

- (void)continueButtonTapped {
  [self.tabSettingsObject gotoNextTab];
}

- (void)setTitle:(NSString *)title {
  [super setTitle:title];
  [self.tabSettingsObject setGlobalTitle:title];
  if (title && ![title isEqualToString:TMTabNameNewTrial]) {
    [self.tabSettingsObject setTabTitle:TMTabNameEditTrial index:1];
  }
}

- (void)selectGrowerTapped {
  if (self.isReadOnly) {
    return;
  }
  self.searchViewController = [[TMCooperatorSearchViewController alloc] initWithSearchStrategy:[[TMCooperatorSearchStrategy alloc] initWithCooperatorCategory:Grower] criteria:@{PlotState : self.trialModel.stateAbbrv ? self.trialModel.stateAbbrv : @""} isExceptionPlotType:self.trialModel.isExceptionPlotType cooperatorValidationRequired:YES];
  self.searchViewController.delegate = self;

  UIBarButtonItem *cancelButton = [[UIBarButtonItem alloc] initWithTitle:@"Cancel" style:UIBarButtonItemStylePlain target:self action:@selector(searchCancelTapped)];
  [cancelButton setTintColor:[UIColor whiteColor]];
  self.searchViewController.navigationItem.leftBarButtonItem = cancelButton;
  UIBarButtonItem *doneButton = [[UIBarButtonItem alloc] initWithTitle:@"Done" style:UIBarButtonItemStylePlain target:self action:@selector(searchGrowerDoneButtonTapped)];
  [doneButton setTintColor:[UIColor whiteColor]];
  self.searchViewController.navigationItem.rightBarButtonItem = doneButton;


  UINavigationController *navigationController = [[UINavigationController alloc] initWithRootViewController:self.searchViewController];
  navigationController.modalPresentationStyle = UIModalPresentationPageSheet;

  [self presentViewController:navigationController animated:YES completion:nil];
}

- (void)updateGrowerInfoTapped {
  if (self.isReadOnly) {
    return;
  }

  self.cooperatorUpdateViewController = [[TMCooperatorUpdateViewController alloc] initWithCooperator:[[TMGrowerModel alloc] initWithGrower:self.trialModel.grower] isExceptionPlotType:self.trialModel.isExceptionPlotType cooperatorValidationRequired:YES operation:Update];
  self.cooperatorUpdateViewController.cooperatorUpdateViewdelegate = self;

  UINavigationController *navigationController = [[UINavigationController alloc] initWithRootViewController:self.cooperatorUpdateViewController];
  navigationController.modalPresentationStyle = UIModalPresentationPageSheet;

  [self presentViewController:navigationController animated:YES completion:nil];
}

- (void)searchCancelTapped {
  [self dismissViewControllerAnimated:YES completion:^{

  }];
}

- (void)searchGrowerDoneButtonTapped {
  __weak __block  TMEditTrialCooperatorViewController *weakSelf = self;
  [self dismissViewControllerAnimated:YES completion:^{
    if (self.searchViewController.selectedModel) {
      id <TMCooperatorModel> growerModel = [[TMGrowerModel alloc] initWithGrower:self.searchViewController.selectedModel];
      if (![growerModel hasRequiredInformation]) {
        [MONMessages showErrorMessageTitle:[NSString stringWithFormat:SelectedCooperatorMissingInfoHeader, @"grower"] subtitle:SelectedGrowerMissingInfoError];
      }
      [weakSelf.trialModel setGrower:self.searchViewController.selectedModel];
      [weakSelf.cooperatorView setGrowerName:((TMCooperatorTableViewCell *) self.searchViewController.selectedItem).cooperatorName];
    }
  }];
}

- (void)cooperatorReleaseChanged:(BOOL)value {
  [self.trialModel setCooperatorRelease:value];
}

- (void)signatureAgreementChanged:(BOOL)value {
  [self.trialModel setSignatureAgreement:value];
}

- (void)signatureDateChanged:(NSDate *)date {
  [self.trialModel setSignatureDateChanged:date];
}

- (void)stateWasSelected:(id)state {
  [self.trialModel setRelationship:state];
}

- (void)resetCounty {
  [self.trialModel removeCounty];
}

- (void)countyWasSelected:(id)county {
  [self.trialModel setRelationship:county];
}

- (void)selectDealerTapped {
  if (self.isReadOnly) {
    return;
  }

  self.searchViewController = [[TMCooperatorSearchViewController alloc] initWithSearchStrategy:[[TMCooperatorSearchStrategy alloc] initWithCooperatorCategory:Dealer] criteria:@{PlotState : self.trialModel.stateAbbrv ? self.trialModel.stateAbbrv : @""} isExceptionPlotType:self.trialModel.isExceptionPlotType cooperatorValidationRequired:NO];
  self.searchViewController.delegate = self;

  UIBarButtonItem *cancelButton = [[UIBarButtonItem alloc] initWithTitle:@"Cancel" style:UIBarButtonItemStylePlain target:self action:@selector(searchCancelTapped)];
  self.searchViewController.navigationItem.leftBarButtonItem = cancelButton;
  UIBarButtonItem *doneButton = [[UIBarButtonItem alloc] initWithTitle:@"Done" style:UIBarButtonItemStylePlain target:self action:@selector(searchDealerDoneButtonTapped)];
  self.searchViewController.navigationItem.rightBarButtonItem = doneButton;


  UINavigationController *navigationController = [[UINavigationController alloc] initWithRootViewController:self.searchViewController];
  navigationController.modalPresentationStyle = UIModalPresentationPageSheet;

  [self presentViewController:navigationController animated:YES completion:nil];
}

- (void)updateDealerInfoTapped {
  if (self.isReadOnly) {
    return;
  }
  self.cooperatorUpdateViewController = [[TMCooperatorUpdateViewController alloc] initWithCooperator:[[TMDealerModel alloc] initWithDealer:self.trialModel.dealer] isExceptionPlotType:self.trialModel.isExceptionPlotType cooperatorValidationRequired:NO operation:Update];
  self.cooperatorUpdateViewController.cooperatorUpdateViewdelegate = self;

  UINavigationController *navigationController = [[UINavigationController alloc] initWithRootViewController:self.cooperatorUpdateViewController];
  navigationController.modalPresentationStyle = UIModalPresentationPageSheet;

  [self presentViewController:navigationController animated:YES completion:nil];

}

- (void)searchDealerDoneButtonTapped {
  __weak __block  TMEditTrialCooperatorViewController *weakSelf = self;
  [self dismissViewControllerAnimated:YES completion:^{
    if (self.searchViewController.selectedModel) {
      id <TMCooperatorModel> dealerModel = [[TMDealerModel alloc] initWithDealer:self.searchViewController.selectedModel];
      if (![dealerModel hasRequiredInformation]) {
        [MONMessages showErrorMessageTitle:[NSString stringWithFormat:SelectedCooperatorMissingInfoHeader, @"dealer"] subtitle:SelectedDealerMissingInfoError];
      }
      [weakSelf.trialModel setDealer:self.searchViewController.selectedModel];
      [weakSelf.cooperatorView setDealerName:((TMCooperatorTableViewCell *) self.searchViewController.selectedItem).cooperatorName];
    }
  }];

}

- (void)shortDescriptionTapped:(NSString *)currentText {
  if (self.isReadOnly) {
    return;
  }
  self.textViewFieldEditor = [[MONTextFieldEditorViewController alloc] init];

  [self.textViewFieldEditor setEnteredText:currentText];

  [self.textViewFieldEditor setHeaderText:@"ADD PLOT DESCRIPTION"];
  [self.textViewFieldEditor setTitle:@"Plot Description"];

  UIBarButtonItem *cancelButton = [[UIBarButtonItem alloc] initWithTitle:@"Cancel" style:UIBarButtonItemStylePlain target:self action:@selector(textFieldEditorCancelButtonTapped)];
  [cancelButton setTintColor:[UIColor whiteColor]];
  self.textViewFieldEditor.navigationItem.leftBarButtonItem = cancelButton;
  UIBarButtonItem *doneButton = [[UIBarButtonItem alloc] initWithTitle:@"Done" style:UIBarButtonItemStylePlain target:self action:@selector(textFieldEditorDoneButtonTapped)];
  [doneButton setTintColor:[UIColor whiteColor]];
  self.textViewFieldEditor.navigationItem.rightBarButtonItem = doneButton;

  UINavigationController *navigationController = [[UINavigationController alloc] initWithRootViewController:self.textViewFieldEditor];
  navigationController.modalPresentationStyle = UIModalPresentationPageSheet;

  [self presentViewController:navigationController animated:YES completion:nil];
}

- (void)textFieldEditorDoneButtonTapped {
  __weak TMEditTrialCooperatorViewController *weakSelf = self;
  [self dismissViewControllerAnimated:YES completion:^{
    [weakSelf.trialModel setPlotDescription:self.textViewFieldEditor.enteredText];
    [weakSelf.cooperatorView setShortDescriptionText:self.textViewFieldEditor.enteredText];
  }];
}

- (void)textFieldEditorCancelButtonTapped {
  [self dismissViewControllerAnimated:YES completion:^{

  }];
}

- (void)signatureTapped {
  MONAgreementViewController *signatureViewController = [[MONAgreementViewController alloc] init];
  signatureViewController.signatureDelegate = self;
  UINavigationController *navigationController = [[UINavigationController alloc] initWithRootViewController:signatureViewController];
  navigationController.modalPresentationStyle = UIModalPresentationPageSheet;
  [self presentViewController:navigationController animated:YES completion:nil];
}

- (void)signatureImageCreated:(UIImage *)signatureImage {

  [self dismissViewControllerAnimated:YES completion:^{
    [self.cooperatorView setAgreementSignatureImage:signatureImage];
    [self.trialModel setSignatureImage:signatureImage];
  }];

}

- (void)updateCooperators {
  [self.cooperatorView setGrowerName:self.trialModel.growerName];
  [self.cooperatorView setDealerName:self.trialModel.dealerName];
}

- (void)addNewCooperator:(id <TMCooperatorModel>)cooperatorModel {
  [self dismissViewControllerAnimated:YES completion:^{
    if ([[cooperatorModel cooperator] isKindOfClass:[TMGrower class]]) {
      [self.trialModel setGrower:(TMGrower *) [cooperatorModel cooperator]];
    } else {
      [self.trialModel setDealer:(TMDealer *) [cooperatorModel cooperator]];
    }

    [self updateCooperators];
  }];
}

@end