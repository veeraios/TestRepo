#import "MONTabController.h"
#import "TMTrialModel.h"
#import "TMPersistenceViewController.h"

@interface TMEditTrialBasicsViewController : TMPersistenceViewController<MONTabController>

- (instancetype)initWithTrialModel:(TMTrialModel *)trialModel;

@end
