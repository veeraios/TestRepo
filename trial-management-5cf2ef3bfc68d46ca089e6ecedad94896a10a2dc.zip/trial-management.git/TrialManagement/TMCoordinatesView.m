#import "TMCoordinatesView.h"
#import "MONTextField.h"
#import "MONDimensions.h"
#import "TMCoordinatesButton.h"
#import "MONSafeString.h"

static const CGFloat IconWidth = 140.0;
static const CGFloat IconHeight = 37.0;

@interface TMCoordinatesView()<MONTextFieldDelegate, UIActionSheetDelegate>

@property (nonatomic) TMCoordinatesLocation location;
@property (nonatomic) TMCoordinatesButton *coordinatesButton;
@property (nonatomic) MONTextField *latitudeTextField;
@property (nonatomic) MONTextField *longitudeTextField;

@end

@implementation TMCoordinatesView

- (instancetype)initWithTitle:(NSString *)title location:(TMCoordinatesLocation)location {
    if (self = [super init]) {
		self.location = location;
		self.coordinatesButton = [[TMCoordinatesButton alloc] init];
		[self.coordinatesButton setTitle:title forState:UIControlStateNormal];
		[self.coordinatesButton setImage:[UIImage imageNamed:@"ui-icon-add-gps-point"] forState:UIControlStateNormal];
        [self.coordinatesButton addTarget:self action:@selector(coordinatesButtonTapped) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:self.coordinatesButton];
        
        self.latitudeTextField = [[MONTextField alloc] init];
		self.latitudeTextField.monTextFieldDelegate = self;
		self.latitudeTextField.keyboardType = UIKeyboardTypeDecimalPad;
        [self.latitudeTextField setPlaceholderText:@"Latitude"];
        [self addSubview:self.latitudeTextField];
        
        self.longitudeTextField = [[MONTextField alloc] init];
		self.longitudeTextField.monTextFieldDelegate = self;
		self.longitudeTextField.keyboardType = UIKeyboardTypeDecimalPad;
        [self.longitudeTextField setPlaceholderText:@"Longitude"];
        [self addSubview:self.longitudeTextField];
		
    }
    return self;
}

- (void) layoutSubviews {
    [super layoutSubviews];

    self.coordinatesButton.frame = CGRectMake(0.0, 0.0, IconWidth, IconHeight);
    
	self.latitudeTextField.frame = CGRectMake(CGRectGetMaxX(self.coordinatesButton.frame) + MONDimensionsTinyPadding,
                                              0.0,
                                              (CGRectGetWidth(self.bounds) - IconWidth) / 2.0 - MONDimensionsTinyPadding,
                                              CGRectGetHeight(self.bounds));

    self.longitudeTextField.frame = CGRectMake(CGRectGetMaxX(self.latitudeTextField.frame) + MONDimensionsTinyPadding,
                                               0.0,
                                               CGRectGetWidth(self.latitudeTextField.frame),
                                               CGRectGetHeight(self.bounds));
}

- (CGSize)sizeThatFits:(CGSize)size {
    CGSize sizeThatFits = size;
    sizeThatFits.height = IconHeight;
    return sizeThatFits;
}

- (void) setCoordinates:(NSString *)latitude longitude:(NSString*)longitude {
	self.latitudeTextField.text = latitude;
	self.longitudeTextField.text = longitude;
}

- (void) clearCoordinates {
	self.latitudeTextField.text = @"";
	self.longitudeTextField.text = @"";
}

- (void) coordinatesButtonTapped {
    if([self areCoordinatesEmpty]) {
       [self updateToCurrentLocation];
    } else {
        UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:nil
                                                                        delegate:self
                                                               cancelButtonTitle:@"Cancel"
                                                          destructiveButtonTitle:@"Update coordinates"
                                                               otherButtonTitles:nil];
        [actionSheet addButtonWithTitle:@"Cancel"];
        [actionSheet showFromRect:self.coordinatesButton.frame inView:self animated:YES];
    }
}

- (void)updateToCurrentLocation {
    [self.delegate evt_updateToCurrentLocation:self.location];
}

- (BOOL)areCoordinatesEmpty {
    return [[MONSafeString safeStringForString:self.latitudeTextField.text] isEqual: @""] && [[MONSafeString safeStringForString:self.longitudeTextField.text] isEqual: @""];
}

#pragma mark - UIActionSheetDelegate Methods

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex {
    if (buttonIndex == actionSheet.destructiveButtonIndex) {
        [self updateToCurrentLocation];
    }
}

#pragma mark - MONTextFieldDelegate Methods

- (void)monTextFieldTextDidChange:(MONTextField *)textField {
	[self.delegate evt_updatedLocation:self.location 
                              latitude:[NSDecimalNumber decimalNumberWithString:self.latitudeTextField.text]
							 longitude:[NSDecimalNumber decimalNumberWithString:self.longitudeTextField.text]];
}

- (void)monTextFieldDidEndEditing:(MONTextField *)textField {
    [self.delegate evt_doneUpdatingValue:textField.text];
}   

@end
