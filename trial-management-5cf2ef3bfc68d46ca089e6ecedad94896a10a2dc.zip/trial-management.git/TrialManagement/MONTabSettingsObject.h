#import <Foundation/Foundation.h>

@protocol MONTabSettingsObjectDelegate <NSObject>

- (void)globalTitleChanged:(NSString *)globalTitle;
- (void)tabTitleChanged:(NSString *)tabTitle index:(NSUInteger)index;
- (void)tabTitleChanged:(NSString *)tabTitle viewController:(UIViewController *)viewController;
- (void)gotoNextTab;

@end

@interface MONTabSettingsObject : NSObject

@property (nonatomic, weak) id<MONTabSettingsObjectDelegate> delegate;

- (void)setGlobalTitle:(NSString *)globalTitle;
- (void)setTabTitle:(NSString *)tabTitle index:(NSUInteger)index;
- (void)setTabTitle:(NSString *)tabTitle viewController:(UIViewController *)viewController;
- (void)gotoNextTab;

@end
