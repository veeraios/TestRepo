//
//  TMMergeGroupingPathPrefix.swift
//  TrialManagement
//
//  Created by WAIDMANN, ALAN [AG/1000] on 1/30/15.
//  Copyright (c) 2015 Monsanto. All rights reserved.
//

private let EntryPathHeader                 = "entries.{entryId:<entry_id>}"
private let InSeasonObservationUIDPathFull  = "entries.{entryId:<entry_id>}.observations.[observationReferenceData:{observationRefCode:<obs_type>}[category:{name:IN_SEASON}]]"
private let HarvestObservationUIDPathFull   = "entries.{entryId:<entry_id>}.observations.[observationReferenceData:{observationRefCode:<obs_type>}[category:{name:HARVEST}]]"
private let FieldObservationUIDPathFull     = "observations.[observationReferenceData:{observationRefCode:<obs_type>}[category:{name:FIELD_INFO}]]"
private let HarvestObservationUIDPathHeader = "entries.{entryId:<entry_id>}.observations.[observationReferenceData:{observationRefCode:"
private let HarvestObservationUIDPathTail   = "}[category:{name:HARVEST}]]"

private let mergeSectionToSectionSpecDictionary: [TMMergeSection: TMMergeSectionProtocol] = [
    TMMergeSection.EditTrial: TMMergeEditTrialSection(),
    TMMergeSection.AddEntries: TMMergeAddEntriesSection(),
    TMMergeSection.GrowerInfo: TMMergeGrowerInfoSection(),
    TMMergeSection.GPSInfo: TMMergeGPSInfoSection(),
    TMMergeSection.PlantingInfo: TMMergePlantingInfoSection(),
    TMMergeSection.InSeasonObservations: TMMergeInSeasonObservationsSection(),
    TMMergeSection.FieldObservations: TMMergeFieldObservationsSection(),
    TMMergeSection.HarvestData: TMMergeHarvestSection(),
    TMMergeSection.Marketing: TMMergeMarketingSection()]

private let sectionToSubSectionsDict = sectionToSubsectionsDictionary()

func sectionSpecForMergeSection(mergeSection: TMMergeSection) -> TMMergeSectionProtocol {
    return mergeSectionToSectionSpecDictionary[mergeSection]!
}

func subSectionsForSection(section:TMMergeSection) -> [TMMergeSubsection] {
    return sectionToSubSectionsDict[section]!
}

private func sectionToSubsectionsDictionary() -> [TMMergeSection:[TMMergeSubsection]] {
    var sectionToSubsectionsDict = Dictionary<TMMergeSection,[TMMergeSubsection]>()
    
    for (section,sectionStruct) in mergeSectionToSectionSpecDictionary {
        var subSections:[TMMergeSubsection] = []
        sectionStruct.groups.map({subSections.append($0.subSection)})
        sectionToSubsectionsDict[section] = subSections
    }
    
    return sectionToSubsectionsDict
}

private func buildCropDependantDisplaySpecForHarvest(plotWeight: String, testWeight: String, yield: String) -> [TMMergePathDisplaySpec] {
    let cropDisplaySpec =
    [TMMergePathDisplaySpec(label: "Plot Weight",    valueFormat: "%@ %@", valueFormatArgs:[
        HarvestObservationUIDPathHeader + plotWeight + HarvestObservationUIDPathTail + ".observationValue",
        HarvestObservationUIDPathHeader + plotWeight + HarvestObservationUIDPathTail + ".unitOfMeasure.name"]),
    TMMergePathDisplaySpec(label: "Test Weight",    valueFormat: "%@ %@", valueFormatArgs:[
        HarvestObservationUIDPathHeader + testWeight + HarvestObservationUIDPathTail + ".observationValue",
        HarvestObservationUIDPathHeader + testWeight + HarvestObservationUIDPathTail + ".unitOfMeasure.name"]),
    TMMergePathDisplaySpec(label: "Yield",          valueFormat: "%@ %@", valueFormatArgs:[
        HarvestObservationUIDPathHeader + yield + HarvestObservationUIDPathTail + ".observationValue",
        HarvestObservationUIDPathHeader + yield + HarvestObservationUIDPathTail + ".unitOfMeasure.name"])]
    
    return cropDisplaySpec
}

struct TMMergeGroupSpec {
    let subSection : TMMergeSubsection
    let pathPrefixes : [String]
    let labelPathSpecs : [TMMergePathDisplaySpec]
}

struct TMMergePathDisplaySpec {
    let label : String
    let valueFormat : String = "%@"
    let valueFormatArgs : [String]

    init(label: String, path: String) {
        self.label = label
        self.valueFormatArgs = [path]
    }
    
    init(label: String, valueFormat: String, valueFormatArgs: [String]) {
        self.label = label
        self.valueFormat = valueFormat
        self.valueFormatArgs = valueFormatArgs
    }
}

struct TMMergeEditTrialSection : TMMergeSectionProtocol {
    let section = TMMergeSection.EditTrial
    let title = "Edit Trial"
    let groups = [
        TMMergeGroupSpec(subSection: .EditTrialBasics,
        pathPrefixes: ["brand","crop","techAgronomist","plotType","plantingYear"],
        labelPathSpecs: [
            TMMergePathDisplaySpec(label: "DSM",        path: "techAgronomist.salesManagerName"),
            TMMergePathDisplaySpec(label: "TA",         path: "techAgronomist.name"),
            TMMergePathDisplaySpec(label: "Year",       path: "plantingYear"),
            TMMergePathDisplaySpec(label: "Brand",      path: "brand.name"),
            TMMergePathDisplaySpec(label: "Territory",  path: "techAgronomist.salesManagerGeographicCode"),
            TMMergePathDisplaySpec(label: "RAL",        path: "techAgronomist.agronomistLeadName"),
            TMMergePathDisplaySpec(label: "Crop",       path: "crop.name"),
            TMMergePathDisplaySpec(label: "Plot Type",  path: "plotType.name")
        ])]
    

}

struct TMMergeAddEntriesSection : TMMergeSectionProtocol {
    let section = TMMergeSection.AddEntries
    let title = "Add Entries"
    let groups = [
        TMMergeGroupSpec(subSection: .Entry,
        pathPrefixes: [EntryPathHeader + ".number", EntryPathHeader + ".product", EntryPathHeader + ".treatment"],
        labelPathSpecs: [
            TMMergePathDisplaySpec(label: "Entry #",    path: EntryPathHeader + ".number"),
            TMMergePathDisplaySpec(label: "Brand",      path: EntryPathHeader + ".product.brandName"),
            TMMergePathDisplaySpec(label: "Product",    path: EntryPathHeader + ".product.productName"),
            TMMergePathDisplaySpec(label: "RM",         path: EntryPathHeader + ".product.maturityRating"),
            TMMergePathDisplaySpec(label: "Trait",      path: EntryPathHeader + ".product.traitName"),
            TMMergePathDisplaySpec(label: "Treatment",  path: EntryPathHeader + ".treatment.chemicalName")
        ])]
}

struct TMMergeGrowerInfoSection : TMMergeSectionProtocol {
    let section = TMMergeSection.GrowerInfo
    let title = "Grower Info"
    let groups = [
          TMMergeGroupSpec(subSection: .StateAndCounty, pathPrefixes: ["state","county"],
            labelPathSpecs: [
                TMMergePathDisplaySpec(label: "Plot State",     path: "state.name"),
                TMMergePathDisplaySpec(label: "Plot County",    path: "county.name")
            ]),
          TMMergeGroupSpec(subSection: .Dealer, pathPrefixes: ["dealer"],
            labelPathSpecs: [
                TMMergePathDisplaySpec(label: "Dealer Name",    path: "dealer.name"),
                TMMergePathDisplaySpec(label: "Address",        path: "dealer.address"),
                TMMergePathDisplaySpec(label: "Phone",          path: "dealer.phoneNumber"),
                TMMergePathDisplaySpec(label: "Fax",            path: "dealer.faxNumber"),
                TMMergePathDisplaySpec(label: "Email",          path: "dealer.email")
            ]),
          TMMergeGroupSpec(subSection: .PlotDescription, pathPrefixes: ["plotDescription"],
            labelPathSpecs: [
                TMMergePathDisplaySpec(label: "Plot Description", path: "plotDescription")
            ]),
          TMMergeGroupSpec(subSection: .Grower, pathPrefixes: ["cooperator","hasSignatureFile","grower"],
            labelPathSpecs: [
                TMMergePathDisplaySpec(label: "Grower Name",        path: "grower.name"),
                TMMergePathDisplaySpec(label: "Address",            path: "grower.address"),
                TMMergePathDisplaySpec(label: "Phone",              path: "grower.phoneNumber"),
                TMMergePathDisplaySpec(label: "Fax",                path: "grower.faxNumber"),
                TMMergePathDisplaySpec(label: "Email",              path: "grower.email"),
                TMMergePathDisplaySpec(label: "Authorization Date", path: "cooperatorSignatureDate")
            ])]
}

struct TMMergeGPSInfoSection : TMMergeSectionProtocol {
    let section = TMMergeSection.GPSInfo
    let title = "GPS Info"
    let groups = [
        TMMergeGroupSpec(subSection: .FirstRowFront, pathPrefixes: ["latitude1","longitude1"],
            labelPathSpecs: [
                TMMergePathDisplaySpec(label: "First Row Front - Latitude",     path: "latitude1"),
                TMMergePathDisplaySpec(label: "First Row Front - Longitude",    path: "longitude1"),
            ]),
        TMMergeGroupSpec(subSection: .LastRowFront, pathPrefixes: ["latitude2","longitude2"],
            labelPathSpecs: [
                TMMergePathDisplaySpec(label: "Last Row Front - Latitude",      path: "latitude2"),
                TMMergePathDisplaySpec(label: "Last Row Front - Longitude",     path: "longitude2"),
            ]),
        TMMergeGroupSpec(subSection: .LastRowBack, pathPrefixes: ["latitude3","longitude3"],
            labelPathSpecs: [
                TMMergePathDisplaySpec(label: "Last Row Back - Latitude",       path: "latitude3"),
                TMMergePathDisplaySpec(label: "Last Row Back - Longitude",      path: "longitude3"),
            ]),
        TMMergeGroupSpec(subSection: .FirstRowBack, pathPrefixes: ["latitude4","longitude4"],
            labelPathSpecs: [
                TMMergePathDisplaySpec(label: "First Row Back - Latitude",      path: "latitude4"),
                TMMergePathDisplaySpec(label: "First Row Back - Longitude",     path: "longitude4"),
            ])]
}

struct TMMergePlantingInfoSection : TMMergeSectionProtocol {
    let section = TMMergeSection.PlantingInfo
    let title = "Planting Info"
    let groups = [
        TMMergeGroupSpec(subSection: .PreviousCrop, pathPrefixes: ["previousCrop"],
            labelPathSpecs: [
                TMMergePathDisplaySpec(label: "Previous Crop", path: "previousCrop.name")
            ]),
        TMMergeGroupSpec(subSection: .SoilTexture, pathPrefixes: ["soilType"],
            labelPathSpecs: [
                TMMergePathDisplaySpec(label: "Soil Texture", path: "soilType.name")
            ]),
        TMMergeGroupSpec(subSection: .TillageSystem, pathPrefixes: ["tillageMethod"],
            labelPathSpecs: [
                TMMergePathDisplaySpec(label: "Tillage Method", path: "tillageMethod.name")
            ]),
        TMMergeGroupSpec(subSection: .PlantingRate, pathPrefixes: ["plantingRate","unitOfMeasureId"],
            labelPathSpecs: [
                TMMergePathDisplaySpec(label: "Planting Rate", valueFormat: "%@ %@", valueFormatArgs: ["plantingRate","unitOfMeasure.name"])
            ]),
        TMMergeGroupSpec(subSection: .Tiled, pathPrefixes: ["tile"],
            labelPathSpecs: [
                TMMergePathDisplaySpec(label: "Tiled", path: "tile.name")
            ]),
        TMMergeGroupSpec(subSection: .NumberOfRows, pathPrefixes: ["rowsPerPlot"],
            labelPathSpecs: [
                TMMergePathDisplaySpec(label: "Number of Rows", path: "rowsPerPlot")
            ]),
        TMMergeGroupSpec(subSection: .RowSpacing, pathPrefixes: ["rowSpacing","rowSpacingUnitOfMeasure"],
            labelPathSpecs: [
                TMMergePathDisplaySpec(label: "Row Spacing", valueFormat: "%@ %@", valueFormatArgs: ["rowSpacing","rowSpacingUnitOfMeasure.name"])
            ]),
        TMMergeGroupSpec(subSection: .Irrigation, pathPrefixes: ["irrigation"],
            labelPathSpecs: [
                TMMergePathDisplaySpec(label: "Irrigation", path: "irrigation")
            ]),
        TMMergeGroupSpec(subSection: .PlantingDate, pathPrefixes: ["plantingDate"],
            labelPathSpecs: [
                TMMergePathDisplaySpec(label: "Planting Date", path: "plantingDate")
            ]),
        TMMergeGroupSpec(subSection: .Comments, pathPrefixes: ["comments"],
            labelPathSpecs: [
                TMMergePathDisplaySpec(label: "Comments", path: "comments")
            ]),
        TMMergeGroupSpec(subSection: .Directions, pathPrefixes: ["directions"],
            labelPathSpecs: [
                TMMergePathDisplaySpec(label: "Directions", path: "directions")
            ])]
}

struct TMMergeInSeasonObservationsSection : TMMergeSectionProtocol {
    let section = TMMergeSection.InSeasonObservations
    let title = "In-Season Observations"
    let groups = [
        TMMergeGroupSpec(subSection: .InSeasonObservations,
            pathPrefixes: [InSeasonObservationUIDPathFull],
            labelPathSpecs: [
                TMMergePathDisplaySpec(label: "Entry #",    path: EntryPathHeader + ".number"),
                TMMergePathDisplaySpec(label: "Brand",      path: EntryPathHeader + ".product.brandName"),
                TMMergePathDisplaySpec(label: "Product",    path: EntryPathHeader + ".product.productName"),
                TMMergePathDisplaySpec(label: "Type",       valueFormat: "%@ %@%@", valueFormatArgs: [
                    InSeasonObservationUIDPathFull + ".name",
                    InSeasonObservationUIDPathFull + ".observationValue",
                    InSeasonObservationUIDPathFull + ".unitOfMeasure.name"])
            ])]
}

struct TMMergeFieldObservationsSection : TMMergeSectionProtocol {
    let section = TMMergeSection.FieldObservations
    let title = "Field Observations"
    let groups = [
        TMMergeGroupSpec(subSection: .FieldObservations, pathPrefixes: [FieldObservationUIDPathFull],
        labelPathSpecs: [
            TMMergePathDisplaySpec(label: "Type", valueFormat: "%@ %@%@", valueFormatArgs: [
                FieldObservationUIDPathFull + ".name",
                FieldObservationUIDPathFull + ".observationValue",
                FieldObservationUIDPathFull + ".unitOfMeasure.name"])
        ])]
}

struct TMMergeHarvestSection : TMHarvestMergeSectionProtocol {
    let section = TMMergeSection.HarvestData
    let title = "Harvest Data"
    var groups = [TMMergeGroupSpec]()
    let defaultGroups = [
        TMMergeGroupSpec(subSection: .HarvestDate, pathPrefixes: ["harvestDate"],
            labelPathSpecs: [
                TMMergePathDisplaySpec(label: "Harvest Date", path: "harvestDate")
            ]),
        TMMergeGroupSpec(subSection: .HarvestObservations, pathPrefixes: [HarvestObservationUIDPathFull],
            labelPathSpecs: [
                TMMergePathDisplaySpec(label: "Entry #",            path: EntryPathHeader + ".number"),
                TMMergePathDisplaySpec(label: "Brand",              path: EntryPathHeader + ".product.brandName"),
                TMMergePathDisplaySpec(label: "Product",            path: EntryPathHeader + ".product.productName"),
                TMMergePathDisplaySpec(label: "Harvest Moisture",   valueFormat: "%@ %@", valueFormatArgs:[
                    HarvestObservationUIDPathHeader + "MST" + HarvestObservationUIDPathTail + ".observationValue",
                    HarvestObservationUIDPathHeader + "MST" + HarvestObservationUIDPathTail + ".unitOfMeasure.name"]),
                TMMergePathDisplaySpec(label: "Harvest Population", valueFormat: "%@ %@", valueFormatArgs:[
                    HarvestObservationUIDPathHeader + "HVPOP" + HarvestObservationUIDPathTail + ".observationValue",
                    HarvestObservationUIDPathHeader + "HVPOP" + HarvestObservationUIDPathTail + ".unitOfMeasure.name"]),
                TMMergePathDisplaySpec(label: "Row Length",         valueFormat: "%@ %@", valueFormatArgs:[
                    HarvestObservationUIDPathHeader + "harvestLength" + HarvestObservationUIDPathTail + ".observationValue",
                    HarvestObservationUIDPathHeader + "harvestLength" + HarvestObservationUIDPathTail + ".unitOfMeasure.name"]),
                TMMergePathDisplaySpec(label: "Row Spacing",        valueFormat: "%@ %@", valueFormatArgs:[
                    HarvestObservationUIDPathHeader + "ROWSP" + HarvestObservationUIDPathTail + ".observationValue",
                    HarvestObservationUIDPathHeader + "ROWSP" + HarvestObservationUIDPathTail + ".unitOfMeasure.name"]),
                TMMergePathDisplaySpec(label: "Rows Harvested",     valueFormat: "%@ %@", valueFormatArgs:[
                    HarvestObservationUIDPathHeader + "harvestedRows" + HarvestObservationUIDPathTail + ".observationValue",
                    HarvestObservationUIDPathHeader + "harvestedRows" + HarvestObservationUIDPathTail + ".unitOfMeasure.name"])
            ])]
    
    let cropDependantDisplaySpecs : [Crop:[TMMergePathDisplaySpec]] = [
        .CORN_SILAGE    : buildCropDependantDisplaySpecForHarvest("SLGPW", "TWT", "SYLD70" ),
        .SORGHUM        : buildCropDependantDisplaySpecForHarvest("SHW", "TWT", "YLD"),
        .COTTON         : buildCropDependantDisplaySpecForHarvest("TPYD", "LP", "LTAC"),
        .OSR_CANOLA     : buildCropDependantDisplaySpecForHarvest("GWT", "TWT", "YLD"),
        .CORN_GRAIN     : buildCropDependantDisplaySpecForHarvest("SHW", "TWT", "YLD"),
        .SOYBEANS       : buildCropDependantDisplaySpecForHarvest("HWT_LBS", "TWT", "YLD")]
    
    init() {
        groups = defaultGroups
    }
    
    init(cropName:String) {
        groups = populateMergeGroupsWithCropSpecs(cropName)
    }
    
    private func populateMergeGroupsWithCropSpecs(cropName: String) -> [TMMergeGroupSpec] {
        let cropDependentLabelSpecs =  cropDependantDisplaySpecs[Crop(rawValue: cropName)!]
        
        let modifiedGroupSpec = { (groupSpec:TMMergeGroupSpec) -> TMMergeGroupSpec in
            if(groupSpec.subSection != TMMergeSubsection.HarvestObservations) {
                return groupSpec
            } else {
                return TMMergeGroupSpec(subSection: groupSpec.subSection, pathPrefixes: groupSpec.pathPrefixes, labelPathSpecs: groupSpec.labelPathSpecs + cropDependentLabelSpecs!)
            }
        }
        
        return defaultGroups.map({modifiedGroupSpec($0)})
    }
}

struct TMMergeMarketingSection : TMMergeSectionProtocol {
    let section = TMMergeSection.Marketing
    let title = "Marketing"
    let groups = [
        TMMergeGroupSpec(subSection: .PostcardCounties, pathPrefixes: ["postCardCounties"],
            labelPathSpecs: [
                TMMergePathDisplaySpec(label: "Postcard Counties", valueFormat: "%@...", valueFormatArgs: ["postCardCounties.{countyId:<county_id>}.name"])
            ]),
        TMMergeGroupSpec(subSection: .EmailCounties, pathPrefixes: ["emailCounties"],
            labelPathSpecs: [
                TMMergePathDisplaySpec(label: "Email Counties", valueFormat: "%@...", valueFormatArgs: ["emailCounties.{countyId:<county_id>}.name"])
            ])]
}
