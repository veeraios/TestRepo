#import <Foundation/Foundation.h>
#import "TMDataSyncCoordinatorCompletionDelegate.h"

extern NSString *const SyncTechAgronomists;
extern NSString *const SyncBrands;
extern NSString *const SyncPlotTypes;
extern NSString *const SyncCrops;
extern NSString *const SyncPreviousCrops;
extern NSString *const SyncSoilTypes;
extern NSString *const SyncTillageMethods;
extern NSString *const SyncTiles;
extern NSString *const SyncTreatments;
extern NSString *const SyncStates;
extern NSString *const SyncGrowersAndDealers;
extern NSString *const SyncProducts;
extern NSString *const SyncTrials;
extern NSString *const SyncSignatureImages;
extern NSString *const SyncProtocols;
extern NSString *const SyncObservationReferenceData;
extern NSString *const SyncTraits;
extern NSString *const SyncObservationCalculationDetails;
extern NSString *const SyncReportReferenceData;
extern NSString *const PostNewRequestedProducts;
extern NSString *const PostTrialUpdates;
extern NSString *const PostNewSignatureImages;
extern NSString *const PostTrialRelinquish;
extern NSString *const PostTrialSubmitToMarketing;
extern NSString *const PostTrialCancel;

extern NSString *const DataSyncStarted;
extern NSString *const DataSyncProgress;
extern NSString *const DataSyncCompleted;
extern NSString *const DataSyncFailed;
extern NSString *const NetworkInaccessible;

@protocol TMDataSyncCoordinatorDelegate <NSObject>

- (void)dataSyncStarted;
- (void)dataSyncStageUpdated:(NSString *)stageName;
- (void)dataSyncCompleted;
- (void)dataSyncFailedForStage:(NSString *)stageName;
- (void)networkInaccessible;

@end

@interface TMDataSyncCoordinator : NSObject<TMDataSyncCoordinatorCompletionDelegate>

@property (nonatomic, weak) id<TMDataSyncCoordinatorDelegate> delegate;

- (void)syncAllData;
- (void)syncAllDataWithTimeChecks:(void (^)(UIBackgroundFetchResult))completionHandler;
- (BOOL)shouldDeltaSync;

@end
