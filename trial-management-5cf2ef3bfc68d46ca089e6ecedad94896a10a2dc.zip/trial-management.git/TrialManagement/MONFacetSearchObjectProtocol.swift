import Foundation

@objc protocol MONFacetSearchObjectProtocol: class {
    var searchID: String { get }
}