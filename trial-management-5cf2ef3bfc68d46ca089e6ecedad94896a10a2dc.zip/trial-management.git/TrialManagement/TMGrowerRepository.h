#import "MONRepository.h"
#import "TMDataSyncProtocol.h"

@protocol TMGrowerRepositoryProtocol <NSObject, MONRepositoryProtocol>
-(NSArray*)searchGrower:(NSString*)name;
@end

@interface TMGrowerRepository :  MONRepository<TMGrowerRepositoryProtocol ,TMDataSyncProtocol>
@end

