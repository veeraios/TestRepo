#import "MONLoginViewController.h"
#import "MONLoginView.h"
#import "MONLoginPresenter.h"
#import "TMWorkingUnitOfWork.h"
#import "TMUserManager.h"
#import "UIViewController+TMOrientation.h"
#import "TrialManagement-Swift.h"

NSInteger const BackgroundImageOffset = -128.0;

@interface MONLoginViewController ()<ESCObservableInternal, MONLoginModelObserver>

@property (nonatomic) MONLoginView *loginView;
@property (nonatomic) MONLoginPresenter *loginPresenter;
@property (nonatomic) MONLoginModel *loginModel;
@property (nonatomic) UIImageView *backgroundImageView;
@property (nonatomic) UIImage *backgroundImage;

@end

@implementation MONLoginViewController

- (id)init {
	self = [super init];
	if (self) {
		self.loginModel = [[MONLoginModel alloc] init];
		[self.loginModel escAddObserver:self];
	}
	return self;
}

- (void)viewDidLoad {
	[super viewDidLoad];

	[self escRegisterObserverProtocol:@protocol(MONLoginViewControllerObserver)];

	self.backgroundImage = [UIImage imageNamed:@"tractor-test-002.jpg"];
	
	self.backgroundImageView = [[UIImageView alloc] initWithImage:self.backgroundImage];
	self.backgroundImageView.contentMode = UIViewContentModeCenter;
	[self.view addSubview:self.backgroundImageView];
		
	self.loginView = [[MONLoginView alloc] init];
	self.loginView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    
	[self.view addSubview:self.loginView];
	
	self.loginPresenter = [[MONLoginPresenter alloc] initWithLoginView:self.loginView loginModel:self.loginModel];
}

- (void)viewWillAppear:(BOOL)animated {
	[super viewWillAppear:animated];
    
	self.loginView.frame = self.view.bounds;
	self.backgroundImageView.frame = [self imageFrameForCurrentSize:self.view.bounds.size];
}

- (void)viewDidAppear:(BOOL)animated {
	[super viewDidAppear:animated];

	[MONGoogleAnalytics trackView:@"Login"];
}

- (void)viewWillTransitionToSize:(CGSize)size withTransitionCoordinator:(id<UIViewControllerTransitionCoordinator>)coordinator {
    [super viewWillTransitionToSize:size withTransitionCoordinator:coordinator];
    self.backgroundImageView.frame = [self imageFrameForCurrentSize:size];
}

- (CGRect)imageFrameForCurrentSize:(CGSize)size {
	CGRect imageFrame;
    CGFloat imageWidth = MAX(self.backgroundImage.size.width, self.backgroundImage.size.height);
    
	if ([self isOrientationLandscape:size]) {
		imageFrame = CGRectMake(0.0, BackgroundImageOffset, imageWidth, imageWidth);
	} else {
		imageFrame = CGRectMake(BackgroundImageOffset, 0.0, imageWidth, imageWidth);
	}
	
	return imageFrame;
}

- (BOOL)userIsAuthenticated {
	BOOL userIsAuthenticated = [self.loginModel userIsAuthenticated];
	if (userIsAuthenticated) {
        [[TMUserManager sharedInstance] setStoredUsername];
        self.loginModel.username = [TMUserManager sharedInstance].currentUsername;
        [(TMUserRepository *)[[TMWorkingUnitOfWork sharedInstance] userRepository] saveIfNeeded:self.loginModel.username];
	}
	return userIsAuthenticated;
}

- (void)logout {
	[self.loginModel logout];
}

- (void)hideBlocker {
    [self.loginView hideBlocker];
}

#pragma mark - TMLoginModelObserver Methods

- (void)loginSucceeded {
    [self hideBlocker];
	[(TMUserRepository *)[[TMWorkingUnitOfWork sharedInstance] userRepository] saveIfNeeded:self.loginModel.username];
	[TMUserManager sharedInstance].currentUsername = self.loginModel.username;
	[self.loginView showLoginError:NO];
	[self.escNotifier loginSucceeded];
}

- (void)loginFailedWithError:(NSError *)error {
    [self hideBlocker];
    if (error) {
        [self.loginView setLoginErrorText:[error description]];
    } else {
        [self.loginView setLoginErrorText:@"Offline authentication unsuccessful, try again."];
    }
    [self.loginView showLoginError:YES];
	[self.escNotifier loginFailed];
}

@end
