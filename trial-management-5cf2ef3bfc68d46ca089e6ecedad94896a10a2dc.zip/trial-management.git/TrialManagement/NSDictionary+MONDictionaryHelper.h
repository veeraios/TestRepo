#import <Foundation/Foundation.h>

@interface NSDictionary (MONDictionaryHelper)

- (id)safeObjectForKey:(NSString *)key;
- (NSDictionary *)replaceNullObjectsWithObject:(id)replacementObject;
- (NSDictionary*)dictionaryWithOnlyValuesOfClass:(Class)theClass;
@end
