#import "MONEditTrialViewControllerFactory.h"
#import "TMEditTrialBasicsViewController.h"
#import "TMEditTrialEntriesViewController.h"
#import "TMEditTrialGPSViewController.h"
#import "TMEditTrialCooperatorViewController.h"
#import "TMEditTrialPlantingViewController.h"

@implementation MONEditTrialViewControllerFactory

+ (UIViewController *)editTrialContentViewControllerForIndex:(EditTrialType)editTrialType trialModel:(TMTrialModel *)trialModel {
	UIViewController *editTrialContentViewController = nil;
	switch (editTrialType) {
		case EditTrialTypeBasics:
			editTrialContentViewController = [[TMEditTrialBasicsViewController alloc] initWithTrialModel:trialModel];
			break;
		case EditTrialTypeEntries:
			editTrialContentViewController = [[TMEditTrialEntriesViewController alloc] initWithTrialModel:trialModel];
			break;
		case EditTrialTypeGrower:
			editTrialContentViewController = [[TMEditTrialCooperatorViewController alloc] initWithTrialModel:trialModel];
			break;
		case EditTrialTypeGPS:
			editTrialContentViewController = [[TMEditTrialGPSViewController alloc] initWithTrialModel:trialModel];
			break;
		case EditTrialTypePlanting:
			editTrialContentViewController = [[TMEditTrialPlantingViewController alloc] initWithTrialModel:trialModel];
			break;
		default:
			break;
	}
	return editTrialContentViewController;
}

@end
