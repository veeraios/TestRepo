#import "MONCardContainerView.h"
#import <UIKit/UIKit.h>

@protocol MONSingleSelectionCardViewDelegate <NSObject>

- (void)selectOptionsButtonTapped;

@end

@interface MONSingleSelectionCardView : MONCardContainerView

- (void)setTitle:(NSString *)title;
- (void)setSelectedText:(NSString *)selectedText;
- (NSString*)selectedText;
@property (nonatomic) BOOL isReadOnly;
@property (nonatomic,weak) id<MONSingleSelectionCardViewDelegate> delegate;
@end
