#import "TMCropRepository.h"
#import "TMDataSyncProtocol.h"
#import "MONRepository.h"
#import "TMUserRepository.h"

@protocol TMCropRepositoryProtocol <NSObject, MONRepositoryProtocol>

- (NSArray *)cropsForCropId:(long long)cropId;
- (NSNumber *)cropIdForCropName:(NSString *)cropName;

@end

@interface TMCropRepository :  MONRepository<TMCropRepositoryProtocol ,TMDataSyncProtocol>
@end

