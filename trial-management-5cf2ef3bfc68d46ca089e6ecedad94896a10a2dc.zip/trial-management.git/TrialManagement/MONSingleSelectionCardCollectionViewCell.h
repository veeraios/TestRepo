#import <UIKit/UIKit.h>
#import "MONSelectionCardCollectionViewCell.h"
#import "TMDataModel.h"
#import "MONSingleSelectionCardView.h"

@protocol MONSingleSelectionCardCollectionViewCellDelegate <NSObject>

- (void)selectOptionsButtonTappedOnCell:(UICollectionViewCell *)cell;

@end

@interface MONSingleSelectionCardCollectionViewCell : UICollectionViewCell<MONSelectionCardCollectionViewCell,MONSingleSelectionCardViewDelegate>
-(NSString*)selectedText;
@property (nonatomic,weak) id<MONSingleSelectionCardCollectionViewCellDelegate> delegate;
@end
