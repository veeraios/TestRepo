#import <UIKit/UIKit.h>

@interface MONTabButton : UIButton

@end
