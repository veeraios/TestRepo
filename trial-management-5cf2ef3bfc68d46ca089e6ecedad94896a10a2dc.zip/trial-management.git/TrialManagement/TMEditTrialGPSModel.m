    #import "TMEditTrialGPSModel.h"
#import "NSNumber+TMNSNumberHelper.h"
#import "MONMessages.h"
#import "NSDecimalNumber+MONNumberHelper.h"
#import "TrialManagement-Swift.h"

static const CLLocationAccuracy LocationAccuracyThirtyMeters = 30.0;
static const int CoordinatePointDecimalPrecision = 7;

@interface TMEditTrialGPSModel()

@property (nonatomic) MKPointAnnotation *firstRowFront;
@property (nonatomic) MKPointAnnotation *lastRowFront;
@property (nonatomic) MKPointAnnotation *lastRowBack;
@property (nonatomic) MKPointAnnotation *firstRowBack;
@property (nonatomic) MKPolygon *polygon;
@property (nonatomic, weak) TMTrialModel *trialModel;

@end

@implementation TMEditTrialGPSModel

- (instancetype)initWithTrialModel:(TMTrialModel *)trialModel {
	if(self=[super init]) {
		[self buildAllGPSPoints];
        self.trialModel = trialModel;
	}
	return self;
}

- (void) buildAllGPSPoints {
	self.firstRowFront = [self buildGPSPointWithTitle:@"First Row Front"];
	self.lastRowFront = [self buildGPSPointWithTitle:@"Last Row Front"];
	self.lastRowBack = [self buildGPSPointWithTitle:@"Last Row Back"];
	self.firstRowBack = [self buildGPSPointWithTitle:@"First Row Back"];
}

- (MKPointAnnotation *) buildGPSPointWithTitle:(NSString *)title {
	MKPointAnnotation *gpsPoint = [[MKPointAnnotation alloc] init];
    gpsPoint.coordinate = [TMConstants emptyLocationCoordinate];
	gpsPoint.title = title;
	return gpsPoint;
}

- (void)setAllCoordinates {
	[self updateLocation:TMCoordinatesLocationFirstRowFront latitude:[NSDecimalNumber safeDecimalNumberWithString:self.trialModel.latitude1] longitude:[NSDecimalNumber safeDecimalNumberWithString:self.trialModel.longitude1]];
	[self updateLocation:TMCoordinatesLocationLastRowFront latitude:[NSDecimalNumber safeDecimalNumberWithString:self.trialModel.latitude2] longitude:[NSDecimalNumber safeDecimalNumberWithString:self.trialModel.longitude2]];
	[self updateLocation:TMCoordinatesLocationLastRowBack latitude:[NSDecimalNumber safeDecimalNumberWithString:self.trialModel.latitude3] longitude:[NSDecimalNumber safeDecimalNumberWithString:self.trialModel.longitude3]];
	[self updateLocation:TMCoordinatesLocationFirstRowBack latitude:[NSDecimalNumber safeDecimalNumberWithString:self.trialModel.latitude4] longitude:[NSDecimalNumber safeDecimalNumberWithString:self.trialModel.longitude4]];
}

- (void) updateLocation:(TMCoordinatesLocation) location latitude:(NSDecimalNumber *) latitude longitude:(NSDecimalNumber *) longitude {
	MKPointAnnotation *targetLocation;
	switch (location) {
		case TMCoordinatesLocationFirstRowFront:
			targetLocation = self.firstRowFront;
            [self.trialModel setLatitude1:latitude longitude:longitude];
			break;
		case TMCoordinatesLocationLastRowFront:
			targetLocation = self.lastRowFront;
            [self.trialModel setLatitude2:latitude longitude:longitude];
			break;
		case TMCoordinatesLocationLastRowBack:
			targetLocation = self.lastRowBack;
            [self.trialModel setLatitude3:latitude longitude:longitude];
			break;
		default: //TMCoordinatesLocationFirstRowBack
			targetLocation = self.firstRowBack;
            [self.trialModel setLatitude4:latitude longitude:longitude];
			break;
	}
	if (latitude && longitude) {
		targetLocation.coordinate = CLLocationCoordinate2DMake([latitude doubleValue], [longitude doubleValue]);
		targetLocation.subtitle = [NSString stringWithFormat:@"Latitude: %f Longitude: %f", [latitude doubleValue], [longitude doubleValue]];
		[self.delegate evt_removeAnnotation:targetLocation];
		[self.delegate evt_addAnnotation:targetLocation];
	} else {
		[self.delegate evt_removeAnnotation:targetLocation];
	}
    [self updateZoomRect];
	[self drawPolygonIfAppropriate];
}

- (void) doneUpdatingValue:(NSString *)value {
    if(![self isCoordinateValuePrecisionAcceptable:value] && ![value isEqualToString:@""]) {
        [MONMessages showErrorMessageTitle:[NSString stringWithFormat:@"The coordinates entered were not saved."] subtitle:@"Coordinates must contain at least 4 and no more than 7 decimals"];
    }
}

- (void) updateToCurrentLocation: (TMCoordinatesLocation)location {
    if([[TMLocationServices sharedInstance] isLocationServicesAuthorizedByUser]) {
        CLLocation *currentLocation = [[TMLocationServices sharedInstance] getCurrentLocation];
        CLLocationCoordinate2D coordinate = currentLocation.coordinate;
        NSString *latitude =  [[NSNumber numberWithDouble:coordinate.latitude] roundedString:CoordinatePointDecimalPrecision];
        NSString *longitude =  [[NSNumber numberWithDouble:coordinate.longitude] roundedString:CoordinatePointDecimalPrecision];
        if([self isAccuracyAcceptable:currentLocation.horizontalAccuracy]) {
            [self.delegate evt_updateToCurrentLocation:location latitude:latitude longitude:longitude];
            [self updateLocation:location latitude:[NSDecimalNumber decimalNumberWithString:latitude] longitude:[NSDecimalNumber decimalNumberWithString:longitude]];
        } else {
            [MONMessages showErrorMessageTitle:[NSString stringWithFormat:@"Cannot update the coordinates."] subtitle:@"Please wait for accuracy to be at least 30m to updates the coordinates"];
        }
    } else {
        [MONMessages showErrorMessageTitle:[NSString stringWithFormat:@"Cannot update the coordinates."] subtitle:@"Please turn on the location services for this app"];
    }
}

- (void) updateZoomRect {
    MKMapRect newZoomRect = MKMapRectNull;
    newZoomRect = [self addToZoomRect:newZoomRect coordinate:self.firstRowFront.coordinate];
    newZoomRect = [self addToZoomRect:newZoomRect coordinate:self.lastRowFront.coordinate];
    newZoomRect = [self addToZoomRect:newZoomRect coordinate:self.lastRowBack.coordinate];
    newZoomRect = [self addToZoomRect:newZoomRect coordinate:self.firstRowBack.coordinate];
    [self.delegate evt_updateZoomRect:newZoomRect];
}

- (MKMapRect) addToZoomRect:(MKMapRect)zoomRect coordinate:(CLLocationCoordinate2D)coordinate {
    if (CLLocationCoordinate2DIsValid(coordinate)) {
        MKMapPoint point = MKMapPointForCoordinate(coordinate);
        return MKMapRectUnion(zoomRect, MKMapRectMake(point.x, point.y, 0.1, 0.1));
    } else {
        return zoomRect;
    }
}

- (void) drawPolygonIfAppropriate {
	if ([self allFourPointsValid]) {
		CLLocationCoordinate2D points[4];
		points[0] = self.firstRowFront.coordinate;
		points[1] = self.lastRowFront.coordinate;
		points[2] = self.lastRowBack.coordinate;
		points[3] = self.firstRowBack.coordinate;
		[self.delegate evt_removePolygon:self.polygon];
		self.polygon = [MKPolygon polygonWithCoordinates:points count:4];
		[self.delegate evt_addPolygon:self.polygon];
	} else {
		if (self.polygon) {
			[self.delegate evt_removePolygon:self.polygon];
			self.polygon = nil;
		}
	}
}

- (BOOL) allFourPointsValid {
	if (CLLocationCoordinate2DIsValid(self.firstRowFront.coordinate) &&
		CLLocationCoordinate2DIsValid(self.lastRowFront.coordinate) &&
		CLLocationCoordinate2DIsValid(self.lastRowBack.coordinate) &&
		CLLocationCoordinate2DIsValid(self.firstRowBack.coordinate)) {
		return true;
	} else {
		return false;
	}
}

- (BOOL) isAccuracyAcceptable:(double) accuracy {
    return accuracy <= LocationAccuracyThirtyMeters;
}

- (BOOL) isCoordinateValuePrecisionAcceptable:(NSString *) value {
    NSArray *valueComponents = [value componentsSeparatedByString:@"."];
    if(valueComponents.count < 2) {
        return false;
    }
    NSUInteger numberOfDecimalsForValue = [valueComponents[1] length];
    return numberOfDecimalsForValue >= 4 && numberOfDecimalsForValue <= 7;
}

- (void) deleteInvalidCoordinates {
    if (![self isValidLatitude:self.trialModel.latitude1 longitude:self.trialModel.longitude1]) {
        [self.trialModel setLatitude1:nil longitude:nil];
    }
    if (![self isValidLatitude:self.trialModel.latitude2 longitude:self.trialModel.longitude2]) {
        [self.trialModel setLatitude2:nil longitude:nil];
    }
    if (![self isValidLatitude:self.trialModel.latitude3 longitude:self.trialModel.longitude3]) {
        [self.trialModel setLatitude3:nil longitude:nil];
    }
    if (![self isValidLatitude:self.trialModel.latitude4 longitude:self.trialModel.longitude4]) {
        [self.trialModel setLatitude4:nil longitude:nil];
    }
}

- (BOOL) isValidLatitude:(NSString *)latitude longitude:(NSString *)longitude {
    return [self isCoordinateValuePrecisionAcceptable:latitude] && [self isCoordinateValuePrecisionAcceptable:longitude];
}

- (void) deleteAllGPSPoints {
	[self.delegate evt_removePolygon:self.polygon];
	[self.delegate evt_removeAnnotation:self.firstRowFront];
	[self.delegate evt_removeAnnotation:self.lastRowFront];
	[self.delegate evt_removeAnnotation:self.lastRowBack];
	[self.delegate evt_removeAnnotation:self.firstRowBack];
    
    [self.trialModel setLatitude1:nil longitude:nil];
    [self.trialModel setLatitude2:nil longitude:nil];
    [self.trialModel setLatitude3:nil longitude:nil];
    [self.trialModel setLatitude4:nil longitude:nil];
    
	[self buildAllGPSPoints];
}

@end
