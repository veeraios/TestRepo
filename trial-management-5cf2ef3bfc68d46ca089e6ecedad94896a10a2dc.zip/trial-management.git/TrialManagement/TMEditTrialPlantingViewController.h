#import "MONDatePicker.h"
#import "TMTrialModel.h"
#import "TMPersistenceViewController.h"
#import "MONTabController.h"

@interface TMEditTrialPlantingViewController : TMPersistenceViewController<MONDatePickerDelegate, MONTabController>
- (instancetype)initWithTrialModel:(TMTrialModel *)trialModel;
@end
