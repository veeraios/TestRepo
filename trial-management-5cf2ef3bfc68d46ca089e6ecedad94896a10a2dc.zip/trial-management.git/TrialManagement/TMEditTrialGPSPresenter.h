#import "TMEditTrialGPSView.h"
#import "TMEditTrialGPSModel.h"
#import "TMTrialModel.h"

@interface TMEditTrialGPSPresenter : NSObject

- (instancetype)init UNAVAILABLE_ATTRIBUTE;
- (instancetype)initWithEditTrialGPSView:(TMEditTrialGPSView *)editTrialGPSView trialModel:(TMTrialModel *)trialModel;
- (void)setCoordinatesAndUserLocation;
- (void)updateToLocationWithCoordinates:(NSDictionary *)coordinates;
- (void)deleteInvalidCoordinatesAndStopUserTracking;

@end
