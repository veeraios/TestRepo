

#import <Foundation/Foundation.h>

@interface MONBlocker : NSObject

+(id)sharedInstance;
//- (id)init UNAVAILABLE_ATTRIBUTE;
-(void)showBlockerWithText:(NSString *)text forView:(UIView *)view;
-(void)hideBlocker;
-(BOOL)isBlockerPresent;
-(void)updateText:(NSString *)text;


@end