//
//  NSManagedObject+UIDAccessor.m
//  DDESpike
//
//  Created by WAIDMANN, ALAN [AG/1000] on 12/22/14.
//  Copyright (c) 2014 TPS. All rights reserved.
//

#import "NSManagedObject+UIDAccessor.h"

static NSString *const UserInfoUIDKey = @"uniqueId";
static NSString *const UserInfoUIDSeparator = @",";

@implementation NSManagedObject (UIDAccessor)

- (NSString *)uniqueIdentifierValue {
    NSString *valueForUID = @"";
    NSArray *partialKeys = [[[[self entity] userInfo] valueForKey:UserInfoUIDKey] componentsSeparatedByString:UserInfoUIDSeparator];
    for (NSString *partial in partialKeys) {
        id valueForPartialKey = [self valueForKey:partial];
        if (valueForPartialKey) {
            if ([[valueForPartialKey class] isSubclassOfClass:[NSManagedObject class]]) {
                valueForUID = [valueForUID stringByAppendingString:[NSString stringWithFormat:@"[%@:%@]", partial,[valueForPartialKey uniqueIdentifierValue]]];
            } else {
                valueForUID = [valueForUID stringByAppendingString:[NSString stringWithFormat:@"{%@:%@}", partial, [valueForPartialKey description]]];
            }
        } else {
            DDLogError(@"Relationship %@ from %@ has failed", partial, [[self entity] managedObjectClassName]);
            return @"";
        }
    }
    return valueForUID;
}

@end
