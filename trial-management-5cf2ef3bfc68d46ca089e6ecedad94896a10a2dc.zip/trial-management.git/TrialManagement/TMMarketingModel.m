#import "TMMarketingModel.h"
#import "TMWorkingUnitOfWork.h"

@interface TMMarketingModel()
@property (nonatomic) TMTrialModel *trialModel;
@end

@implementation TMMarketingModel

-(instancetype) initWithTrialModel:(TMTrialModel *)trialModel {
	self = [super init];
	if (self) {
		self.trialModel = trialModel;
	}
	return self;
}
- (TMEmailTableViewModel*)emailTableViewModel {
	return [[TMEmailTableViewModel alloc] initWithCounties:[self.trialModel emailCounties]];
}
- (TMPostcardTableViewModel*)postcardTableViewModel {
	return [[TMPostcardTableViewModel alloc] initWithCounties:[self.trialModel postCardCounties]];
}

- (TMMarketingStateCountiesModel *)stateCountiesModelForSubmissionType:(TMMarketingSubmissionType)type {
    if (type == Email) {
        return [[TMMarketingStateCountiesModel alloc]
                initWithStatesModel: [self statesModel]
                plotStateName:[self.trialModel stateName]
                previouslySelectedCounties:[self.trialModel emailCounties]
                marketingSubmission:type];
    } else {
        return [[TMMarketingStateCountiesModel alloc]
                initWithStatesModel: [self statesModel]
                maxSelections:5
                plotStateName:[self.trialModel stateName]
                previouslySelectedCounties:[self.trialModel postCardCounties]
                marketingSubmission:type];
    }
}

-(TMStatesModel*)statesModel {
	return [[TMStatesModel alloc] initWithDataSource:[[[TMWorkingUnitOfWork sharedInstance] stateRepository] sortedEntitiesByName]];
}

- (void)defaultBooleanValuesIfNil {
    if ([self.trialModel webMarketing] == nil) {
        [self.trialModel setPostToWeb:YES];
    }
    if ([self.trialModel postcardMarketing] == nil) {
        [self.trialModel setPostCardMarketing:NO];
    }
    if ([self.trialModel emailMarketing] == nil) {
        [self.trialModel setEmailMarketing:NO];
    }
}

- (BOOL)shouldPostToWeb {
	return [[self.trialModel webMarketing] boolValue];
}

- (BOOL)shouldPostCard {
	return [[self.trialModel postcardMarketing] boolValue];
}

- (BOOL)shouldEmail {
	return [[self.trialModel emailMarketing] boolValue];
}

- (void)addSelectedCounties:(NSArray *)counties forSubmissionType:(TMMarketingSubmissionType)type {
    if (type == Email) {
        [self.trialModel setEmailSelectedCounties:counties];
    } else {
		[self.trialModel setPostcardSelectedCounties:counties];
        [self.trialModel addEmailSelectedCounties:counties];
    }
}

- (void)submissionChanged:(BOOL)submissionValue forSubmissionType:(TMMarketingSubmissionType)type {
    type == Email ? [self.trialModel setEmailMarketing:submissionValue] : [self.trialModel setPostCardMarketing:submissionValue];
    
    if (!submissionValue) {
        NSArray *counties = type == Email ? [self.trialModel emailCounties] : [self.trialModel postCardCounties];
        for (TMCounty *county in counties) {
            [self removeCounty:county forSubmissionType:type];
        }
    }
}


- (void)removeCounty:(TMCounty *)county forSubmissionType:(TMMarketingSubmissionType)type {
    if (type == PostCard) {
        [self.trialModel removePostcardCounty:county];
	} else {
		 [self.trialModel removeEmailCounty:county];
	}
}

@end
