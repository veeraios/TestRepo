#import <Crashlytics/Crashlytics.h>
#import "TMAppDelegate.h"
#import "TMTrialsViewController.h"
#import "MONDefaultStyles.h"
#import "MONLoginViewController.h"
#import "MONViewManagerViewController.h"
#include <execinfo.h>
#import "TMWorkingUnitOfWork.h"
#import "TMDataSyncCoordinator.h"
#import "MONMessages.h"
#import "MONBlocker.h"
#import "TrialManagement-Swift.h"

static NSString * const TMAppDelegateAppHasLaunchedPreviously = @"TMAppDelegateAppHasLaunchedPreviously";

@interface TMAppDelegate()<MONLoginViewControllerObserver>

@property (nonatomic) MONViewManagerViewController *viewManagerViewController;
@property (nonatomic) UINavigationController *navigationController;
@property (nonatomic) TMTrialsViewController *trialsViewController;
@property (nonatomic) MONLoginViewController *loginViewController;
@property (nonatomic) TMWorkingUnitOfWork  *unitOfWork;
@property (nonatomic) TMSyncOperationsCoordinator *syncCoordinator;
@property (nonatomic) TMMergeCoordinator *mergeCoordinator;
@end

@implementation TMAppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {

	[DDLog addLogger:[DDASLLogger sharedInstance]];
	[DDLog addLogger:[DDTTYLogger sharedInstance]];

    [MONGoogleAnalytics initializeTracker];
    // TODO Remove Flurry in favor of Google Analytics or is this useful beyond Google Analytics?
    [MONAnalytics startAnalyticsSession];
    
	DDFileLogger *fileLogger = [[DDFileLogger alloc] init];
	fileLogger.rollingFrequency = 60 * 60 * 24;
	fileLogger.logFileManager.maximumNumberOfLogFiles = 7;
	[DDLog addLogger:fileLogger];

	[self setUpGlobalErrorHandlers];
	
	//Test this to see if this improves memory consumption -- don't cache anything ever, next try it with a large cache size
	NSURLCache *sharedCache = [[NSURLCache alloc] initWithMemoryCapacity:0
															diskCapacity:25
																diskPath:nil];
	[NSURLCache setSharedURLCache:sharedCache];

	
	[[UITextField appearance] setKeyboardAppearance:UIKeyboardAppearanceDark];
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];

	[application setStatusBarStyle:UIStatusBarStyleLightContent];
	[MONDefaultStyles setupDefaultStyles];
		
	self.trialsViewController = [[TMTrialsViewController alloc] init];
	UIBarButtonItem *logoutBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Logout"
																			style:UIBarButtonItemStylePlain
																		   target:self
																		   action:@selector(logoutButtonTapped)];
	[logoutBarButtonItem setTintColor:[UIColor whiteColor]];
	UIBarButtonItem *refreshBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemRefresh target:self action:@selector(refreshRefData)];
	self.trialsViewController.navigationItem.leftBarButtonItems = @[logoutBarButtonItem, refreshBarButtonItem];
	
	self.navigationController = [[UINavigationController alloc] init];
	[self.navigationController pushViewController:self.trialsViewController animated:NO];
    
    self.mergeCoordinator = [[TMMergeCoordinator alloc] initWithNavigationController:self.navigationController];
	
	self.loginViewController = [[MONLoginViewController alloc] init];
	[self.loginViewController escAddObserver:self];
	
	self.viewManagerViewController = [[MONViewManagerViewController alloc] initWithLoginViewController:self.loginViewController rootViewController:self.navigationController];
    [MONMessages setDefaultViewController:self.viewManagerViewController];
	if ([self.loginViewController userIsAuthenticated]) {
    // TODO ga(‘set’, ‘&uid’, {{USER_ID}}); // Set the user ID using signed-in user_id.
		[self.viewManagerViewController pushRootViewAnimated:NO];
	} else {
		[self.viewManagerViewController popToLoginViewAnimated:NO];
	}
    
	self.syncCoordinator = [[TMSyncOperationsCoordinator alloc ] initWithViewForBlocker:self.viewManagerViewController.view];
	
	self.window.rootViewController = self.viewManagerViewController;
	
	[self.window makeKeyAndVisible];
	[Crashlytics startWithAPIKey:@"9a1cc0d42fdfa106b37123df923e91a29f0471b3"];
	
	[application registerUserNotificationSettings:[UIUserNotificationSettings settingsForTypes:(UIUserNotificationTypeSound | UIUserNotificationTypeAlert | UIUserNotificationTypeBadge) categories:nil]];
    
    [[UIApplication sharedApplication] setMinimumBackgroundFetchInterval:UIApplicationBackgroundFetchIntervalMinimum];
    [self startDeltaSync];

    return YES;
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    [self startDeltaSync];
}

- (void)startDeltaSync {
    if ([self.loginViewController userIsAuthenticated]) {
        [self.syncCoordinator syncAllDataWithTimeChecks];
    }
}

-(void)application:(UIApplication *)application performFetchWithCompletionHandler:(void (^)(UIBackgroundFetchResult))completionHandler {
    if ([self.loginViewController userIsAuthenticated]) {
        [self.syncCoordinator performBackgroundSync:completionHandler];
    }
}

- (void)applicationWillTerminate:(UIApplication *)application {
	[[TMWorkingUnitOfWork sharedInstance] saveChanges];
}

- (void)refreshRefData {
	[self.syncCoordinator syncAllData];
}

- (void)logoutButtonTapped {
    [self.trialsViewController cancelSearch];
	[self.loginViewController logout];
	[self.viewManagerViewController popToLoginViewAnimated:YES];
}

#pragma mark - MONLoginViewControllerObserver Methods

- (void)loginSucceeded {
	[self.viewManagerViewController pushRootViewAnimated:YES];
	[self.syncCoordinator syncAllDataWithTimeChecks];
}

- (void)loginFailed {
	DDLogError(@"Login Failed");
}

#pragma mark - Simple Error Logging Methods
void exceptionOccurred(NSException *exception) {
	NSMutableString *exMsg = [[NSMutableString alloc] initWithString:[[NSString alloc] initWithFormat :@"date: %@\nname: %@\nreason: %@\nuserinfo: %@\n", [NSDate date], exception.name, exception.reason, exception.userInfo]];
	
    NSArray *callStackArray = [exception callStackReturnAddresses];
    NSUInteger frameCount = [callStackArray count];
	if(frameCount > 0) {
		[exMsg appendString:@"frame:\n "];
	}
    for (int i=0; i<frameCount; i++) {
		[exMsg appendString: [[NSString alloc] initWithFormat:@"%@\n", [callStackArray objectAtIndex:i] ]];
    }
	writeMessageToErrorLog(exMsg);
}

void sighandler(int sig, siginfo_t *info, void *context) {
	
	NSMutableString *exMsg = [[NSMutableString alloc] initWithFormat:@"date: %@\n", [NSDate date]];
	void* callstack[128];
    int frames = backtrace(callstack, 128);
	char** strs = backtrace_symbols(callstack, frames);
	for (int i = 0; i < frames; i++) {
		[exMsg appendString:[[NSString alloc] initWithFormat:@"%s\n", strs[i]]];
	}
	free(strs);
	writeMessageToErrorLog(exMsg);
}

void writeMessageToErrorLog(NSString* errorMessage) {
//	DDLogCError(@"Application Crash:");
//	DDLogCError(@"*******************************************");
//	DDLogCError(errorMessage);
//	DDLogCError(@"*******************************************");
}

- (void)setUpGlobalErrorHandlers {
	NSSetUncaughtExceptionHandler(&exceptionOccurred);
	struct sigaction theSigAction;
	theSigAction.sa_sigaction = sighandler;
	theSigAction.sa_flags = SA_SIGINFO;
	sigemptyset(&theSigAction.sa_mask);
	sigaction(SIGQUIT, &theSigAction, NULL);
	sigaction(SIGILL, &theSigAction, NULL);
	sigaction(SIGTRAP, &theSigAction, NULL);
	sigaction(SIGABRT, &theSigAction, NULL);
	sigaction(SIGEMT, &theSigAction, NULL);
	sigaction(SIGFPE, &theSigAction, NULL);
	sigaction(SIGBUS, &theSigAction, NULL);
	sigaction(SIGSEGV, &theSigAction, NULL);
	sigaction(SIGSYS, &theSigAction, NULL);
	sigaction(SIGPIPE, &theSigAction, NULL);
	sigaction(SIGALRM, &theSigAction, NULL);
	sigaction(SIGXCPU, &theSigAction, NULL);
	sigaction(SIGXFSZ, &theSigAction, NULL);
}

@end
