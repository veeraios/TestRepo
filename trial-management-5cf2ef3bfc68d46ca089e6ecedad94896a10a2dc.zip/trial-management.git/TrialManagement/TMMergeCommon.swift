//
//  TMMergeGroup.swift
//  TrialManagement
//
//  Created by SINGH, SUPREET [AG/1000] on 1/21/15.
//  Copyright (c) 2015 Monsanto. All rights reserved.
//

protocol TMMergeSectionProtocol {
    var section: TMMergeSection {get}
    var title: String {get}
    var groups: [TMMergeGroupSpec] {get}
}

protocol TMHarvestMergeSectionProtocol: TMMergeSectionProtocol {
    var cropDependantDisplaySpecs: [Crop:[TMMergePathDisplaySpec]] {get}
    var defaultGroups: [TMMergeGroupSpec] {get}
}

enum TMMergeSide {
    case Left
    case Right
}

enum TMMergeSection {
    case EditTrial
    case AddEntries
    case GrowerInfo
    case GPSInfo
    case PlantingInfo
    case InSeasonObservations
    case FieldObservations
    case HarvestData
    case Marketing
}

enum TMMergeSubsection {
    case EditTrialBasics
    
    case Entry

    case SpatiallyHarvested
    case StateAndCounty
    case Dealer
    case PlotDescription
    case Grower

    case FirstRowFront
    case LastRowFront
    case LastRowBack
    case FirstRowBack

    case PreviousCrop
    case SoilTexture
    case TillageSystem
    case PlantingRate
    case Tiled
    case NumberOfRows
    case RowSpacing
    case Irrigation
    case PlantingDate
    case Comments
    case Directions

    case InSeasonObservations

    case FieldObservations

    case HarvestDate
    case HarvestObservations

    case PostToWeb
    case PostcardCounties
    case EmailCounties
}

enum Crop : String  {
    case CORN_SILAGE = "CORN-SILAGE"
    case SORGHUM = "SORGHUM"
    case COTTON = "COTTON"
    case OSR_CANOLA = "OSR-CANOLA"
    case CORN_GRAIN = "CORN-GRAIN"
    case SOYBEANS = "SOYBEANS"
}

