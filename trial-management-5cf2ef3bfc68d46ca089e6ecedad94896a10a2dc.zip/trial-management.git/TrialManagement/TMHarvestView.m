#import "TMHarvestView.h"
#import "MONHeaderView.h"
#import "MONDimensions.h"
#import "TMEntryHarvestCollectionViewCell.h"
#import "MONFonts.h"
#import "MONLabeledDateTextFieldButton.h"
#import "UIColor+MONThemeColorProvider.h"
#import "NSDate+MONDateHelper.h"
#import "TMPlotStatisticsView.h"

static const CGFloat KeyboardMarginTop = 10.0;

@interface TMHarvestView ()<UICollectionViewDataSource, UICollectionViewDelegate, MONDateTextFieldButtonDelegate, MONReadOnlyProtocol, TMEntryHarvestCollectionViewCellDelegate>

@property (nonatomic) MONHeaderView *headerView;
@property (nonatomic) UICollectionView *entriesCollectionView;
@property (nonatomic) UICollectionViewFlowLayout *collectionViewFlowLayout;
@property (nonatomic, assign) CGSize cellSize;
@property (nonatomic) MONHeaderView *submittedForApprovalDateLabel;
@property (nonatomic) MONLabeledDateTextFieldButton *harvestDateLabeledTextFieldButton;
@property (nonatomic) TMHarvestModel *harvestModel;
@property (nonatomic) UIEdgeInsets previousContentInset;
@property (nonatomic) CGFloat offsetAmount;
@property (nonatomic) UIView *currentEditingView;
@property (nonatomic) NSNotification *keyboardWillShowNotification;
@property (nonatomic) BOOL isReadOnly;
@property (nonatomic) TMPlotStatisticsView *plotStatsView;

@end

@implementation TMHarvestView

- (instancetype)initWitHarvestModel:(TMHarvestModel*)harvestModel rightHeaderButtons:(NSArray *)rightHeaderButtons leftHeaderButtons:(NSArray *)leftHeaderButtons {
	self = [super init];
	if (self) {
		self.backgroundColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeBackground];

		self.harvestModel = harvestModel;
		
		self.collectionViewFlowLayout = [[UICollectionViewFlowLayout alloc] init];
		self.collectionViewFlowLayout.minimumLineSpacing = MONDimensionsSmallPadding;
		
		self.entriesCollectionView = [[UICollectionView alloc] initWithFrame:self.bounds collectionViewLayout:self.collectionViewFlowLayout];
		self.entriesCollectionView.dataSource = self;
		self.entriesCollectionView.delegate = self;
		[self.entriesCollectionView registerClass:[TMEntryHarvestCollectionViewCell class] forCellWithReuseIdentifier: NSStringFromClass([TMEntryHarvestCollectionViewCell class])];
		
		self.entriesCollectionView.frame = self.bounds;
		self.entriesCollectionView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
		self.entriesCollectionView.backgroundColor = [UIColor clearColor];
		self.entriesCollectionView.contentInset = UIEdgeInsetsMake(MONDimensionsSmallPadding, MONDimensionsSmallPadding, MONDimensionsSmallPadding, MONDimensionsSmallPadding);
		[self addSubview:self.entriesCollectionView];
		
		self.headerView = [[MONHeaderView alloc] init];
		[self.headerView setTitle:@"Harvest Data"];
		[self.headerView setRightButtons:rightHeaderButtons];
        [self.headerView setLeftButtons:leftHeaderButtons];
		[self addSubview:self.headerView];
		
		self.submittedForApprovalDateLabel = [[MONHeaderView alloc] init];
		[self.submittedForApprovalDateLabel setFont:[UIFont fontWithName:OpenSansSemibold size:24]];
		[self addSubview:self.submittedForApprovalDateLabel];
		
		self.harvestDateLabeledTextFieldButton = [[MONLabeledDateTextFieldButton alloc] init];
		self.harvestDateLabeledTextFieldButton.dateDelegate = self;
		[self.harvestDateLabeledTextFieldButton setLabelText:@"Trial Harvest Date"];
		[self.harvestDateLabeledTextFieldButton setLabelFont:[UIFont fontWithName:OpenSans size:14]];
		[self.harvestDateLabeledTextFieldButton setMinimumDate:[[[self.harvestModel plantingDate] startOfDate] dateWithAddedDays:1]];
		[self.harvestDateLabeledTextFieldButton setMaximumDate:[[NSDate date] startOfDate]];
		[self.harvestDateLabeledTextFieldButton setPlaceholderText:@"Not Entered"];
		if([self.harvestModel harvestDate] != nil) {
			[self.harvestDateLabeledTextFieldButton setDate:[self.harvestModel harvestDate]];
		}
		[self addSubview:self.harvestDateLabeledTextFieldButton];

		
		
		self.plotStatsView = [[TMPlotStatisticsView alloc] initWithModel:[[TMPlotStatisticsModel alloc] initWithObservationModels:[self.harvestModel harvestYieldObservations] moistureObservationModels:[self.harvestModel moistureObservations]]];
		[self addSubview:self.plotStatsView];

		[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(monLabeledTextFieldDidBeginEditing:) name:@"TMObservationTextFieldDidBeginEditing" object:nil];
		[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(monDatePopoverButtonDidShowPopover) name:MONDatePopoverButtonDidShowPopover object:nil];
		[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
		[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];
	}
	return self;
}

- (void)dealloc {
	[[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (NSInteger)numberOfItemsAcross {
	BOOL isPortrait = UIInterfaceOrientationIsPortrait([[UIApplication sharedApplication] statusBarOrientation]);
	NSInteger numberOfItemsAcross = isPortrait ? 3 : 4;
	return numberOfItemsAcross;
}

- (void)setCellSizeForEntry {
	if([[self.harvestModel entryModels] count] > 0) {
		//quick hack: this is basically the logic of the harvestcontainercell. we need to find a better way to shrink grow these dynamically
		//much of the problem lies in the fact that we set the entryModels and resize the view at cellForRowAtIndexPath, while we should be setting
		//up all the view stuff at init, and cache all offscreen views, and then cellForRowAtIndexPath just reads from the cached array of views to
		//display.
		CGFloat cardWidth = CGRectGetWidth(self.bounds) - (2.0 * MONDimensionsSmallPadding);
		CGSize sizeThatFits = CGSizeMake(cardWidth, 0.0);
		TMEntryModel *model =	[[self.harvestModel entryModels] objectAtIndex:0];
		NSInteger numberOfHarvestObs = [[model harvestObservations] count];
		double numberOfRows = ceil(numberOfHarvestObs / (CGFloat)[self numberOfItemsAcross]);
		sizeThatFits.height = (numberOfRows * 60.0f + (MONDimensionsSmallPadding*(numberOfRows+2))) + ((numberOfRows) * MONDimensionsExtraLargePadding);
		self.cellSize = sizeThatFits;
	}
}

- (void)layoutSubviews {
	[super layoutSubviews];

	[self setCellSizeForEntry];
	[self.collectionViewFlowLayout setItemSize:CGSizeMake(self.cellSize.width, self.cellSize.height)];
	
	[self.headerView sizeToFit];
	self.headerView.frame = CGRectMake(0.0, 0.0, CGRectGetWidth(self.bounds), CGRectGetHeight(self.headerView.frame));
	if([self.submittedForApprovalDateLabel.title length] > 0) {
		self.submittedForApprovalDateLabel.frame = CGRectMake(170, 0.0, CGRectGetWidth(self.submittedForApprovalDateLabel.frame), CGRectGetHeight(self.headerView.frame));
	}
	
	CGSize harvestDateLabeledTextFieldButtonSize = [self.harvestDateLabeledTextFieldButton sizeThatFits:CGSizeZero];
	self.harvestDateLabeledTextFieldButton.frame = CGRectMake(CGRectGetMinX(self.headerView.frame) + MONDimensionsSmallPadding,
												 CGRectGetMaxY(self.headerView.frame) + MONDimensionsSmallPadding,
												 harvestDateLabeledTextFieldButtonSize.width,
												 harvestDateLabeledTextFieldButtonSize.height);
	
	CGSize plotStatsViewSize = [self.plotStatsView sizeThatFits:CGSizeZero];
	self.plotStatsView.frame = CGRectMake((CGRectGetMaxX(self.headerView.frame) - plotStatsViewSize.width) - (MONDimensionsSmallPadding*2),
															  CGRectGetMaxY(self.headerView.frame) + MONDimensionsSmallPadding,
															  plotStatsViewSize.width,
															  plotStatsViewSize.height);

	
	self.entriesCollectionView.frame = CGRectMake(0.0,
												  CGRectGetMaxY(self.harvestDateLabeledTextFieldButton.frame),
												  CGRectGetWidth(self.bounds),
												  CGRectGetHeight(self.bounds) - CGRectGetMaxY(self.harvestDateLabeledTextFieldButton.frame));
	
}

- (void)setAsReadOnly {
    self.isReadOnly = YES;
}

- (void)dateChanged:(NSDate*)date {
	if(date != nil) {
		[self.delegate setTrialHarvestDate:date];
	}
}

- (BOOL)isSelectedDateValid:(NSDate*)date {
	if (![self.harvestModel isValidHarvestDate:date] ) {
		if([self.harvestModel plantingDate] == nil) {
			[self.harvestDateLabeledTextFieldButton showErrorMessage:@"Planting date must be set."];
		} else if([date compare:[self.harvestModel plantingDate]] != NSOrderedDescending) {
			[self.harvestDateLabeledTextFieldButton showErrorMessage:@"Harvest must come after Planting Date."];
		}
		return NO;
	};
	return YES;
}

- (void)setSubmittedDate:(NSDate*)date animate:(BOOL)animate {
	if(date != nil ) {
		NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
		[dateFormat setDateFormat:@"MM/dd/yyyy"];
		
		if(animate && [self.submittedForApprovalDateLabel.title length] == 0) {
			[self.submittedForApprovalDateLabel setAlpha:0.0];
			[self.submittedForApprovalDateLabel setTitle:[NSString stringWithFormat:@"(SUBMITTED %@)",[dateFormat stringFromDate:date]]];
			[UIView animateWithDuration:0.5
							  delay:0.0
							options:UIViewAnimationOptionCurveEaseIn
						 animations:^{
							 [self.submittedForApprovalDateLabel setAlpha:1.0];
						 }
						 completion:^(BOOL finished) {
						 }];
		} else {
			[self.submittedForApprovalDateLabel setTitle:[NSString stringWithFormat:@"(SUBMITTED %@)",[dateFormat stringFromDate:date]]];
		}
		[self setNeedsLayout];
	}
}

- (void)refreshObservations:(NSArray*)entryModels {
	[self.harvestModel setEntryModels:entryModels];
	[self reloadData];
	[self setNeedsLayout];
}

- (void)reloadData {
	[self.collectionViewFlowLayout invalidateLayout];
	[self.entriesCollectionView reloadData];
}

- (void)monDatePopoverButtonDidShowPopover {
	[self endEditing:YES];
}

- (void)setRightHeaderButtons:(NSArray *)rightHeaderButtons
{
    [self.headerView setRightButtons:rightHeaderButtons];
    [self setNeedsLayout];
}

- (void)setLeftHeaderButtons:(NSArray *)leftHeaderButtons {
    [self.headerView setLeftButtons:leftHeaderButtons];
    [self setNeedsLayout];
}
#pragma mark - UICollectionViewDataSource Methods

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
	TMEntryModel *entryModel = [[self.harvestModel entryModels] objectAtIndex:indexPath.row];
	TMEntryHarvestCollectionViewCell *collectionViewCell = [collectionView dequeueReusableCellWithReuseIdentifier:NSStringFromClass([TMEntryHarvestCollectionViewCell class]) forIndexPath:indexPath];
	collectionViewCell.delegate = self;
	[collectionViewCell setEntryModel:entryModel];
    if (self.isReadOnly) {
        [collectionViewCell setAsReadOnly];
	} else {
    [collectionViewCell calculateYieldAndSetAsReadOnlyIfNeeded];
	}
	
	return collectionViewCell;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
	return [[self.harvestModel entryModels] count];
}

-(void)moistureWasUpdated {
	[self runPlotStats];
}

-(void)yieldWasUpdated {
	[self runPlotStats];
}

- (void)runPlotStats {
	TMPlotStatisticsModel *plotStatsModel = [[TMPlotStatisticsModel alloc] initWithObservationModels:[self.harvestModel harvestYieldObservations] moistureObservationModels:[self.harvestModel moistureObservations]];
	[self.plotStatsView updateStats:plotStatsModel];
	[self.delegate updatedPlotStatsState:[plotStatsModel areCalculationsPassed]];
}

- (BOOL)resignFirstResponder {
    return [self.currentEditingView resignFirstResponder];
}
#pragma mark - Keyboard Aware Content Methods

- (void)monLabeledTextFieldDidBeginEditing:(NSNotification *)notification {
	self.currentEditingView = (UIView *)notification.object;
	[self adjustViewForKeyboard];
}

- (void)keyboardWillShow:(NSNotification *)notification {
	self.keyboardWillShowNotification = notification;
	[self adjustViewForKeyboard];
}

- (void)adjustViewForKeyboard {
	if (!self.currentEditingView || !self.keyboardWillShowNotification) {
		return;
	}
	self.previousContentInset = self.entriesCollectionView.contentInset;
	
	CGRect keyboardEndRect = ((NSValue *)self.keyboardWillShowNotification.userInfo[UIKeyboardFrameEndUserInfoKey]).CGRectValue;
	keyboardEndRect = [self convertRect:keyboardEndRect fromView:nil];
	CGFloat keyboardMinY = CGRectGetMinY(keyboardEndRect);
	
	CGFloat insetBottom = CGRectGetMaxY(self.entriesCollectionView.frame) - keyboardMinY + MONDimensionsSmallPadding;
	
	UIEdgeInsets newContentInset = self.entriesCollectionView.contentInset;
	newContentInset.bottom = insetBottom;
	
	self.entriesCollectionView.contentInset = newContentInset;
	
	CGRect currentEditingViewFrame = [self convertRect:self.currentEditingView.bounds fromView:self.currentEditingView];
	self.offsetAmount = CGRectGetMaxY(currentEditingViewFrame) - keyboardMinY + KeyboardMarginTop;
	if (self.offsetAmount < 0.0) {
		self.offsetAmount = 0.0;
	}
}

- (void)keyboardWillHide:(NSNotification *)notification {
	self.entriesCollectionView.contentInset = self.previousContentInset;
	
	UIViewAnimationCurve keyboardAnimationCurve = [[notification.userInfo valueForKey:UIKeyboardAnimationCurveUserInfoKey] integerValue];
	NSTimeInterval keyboardAnimationDuration = [[notification.userInfo valueForKey:UIKeyboardAnimationDurationUserInfoKey] integerValue];
	[UIView animateWithDuration:keyboardAnimationDuration
						  delay:0.0
						options:(keyboardAnimationCurve << 16)
					 animations:^{
						 CGRect scrollableFrame = CGRectMake(self.entriesCollectionView.contentOffset.x, -MONDimensionsSmallPadding, self.entriesCollectionView.contentSize.width, self.entriesCollectionView.contentSize.height - CGRectGetHeight(self.entriesCollectionView.frame));
						 CGFloat newOffsetY = self.entriesCollectionView.contentOffset.y - self.offsetAmount;
						 if (newOffsetY < CGRectGetMinY(scrollableFrame)) {
							 newOffsetY = CGRectGetMinY(scrollableFrame);
						 } else if (newOffsetY > CGRectGetMaxY(scrollableFrame)) {
							 newOffsetY = CGRectGetMaxY(scrollableFrame);
						 }
						 self.entriesCollectionView.contentOffset = CGPointMake(self.entriesCollectionView.contentOffset.x, newOffsetY);
					 }
					 completion:^(BOOL finished) {
						 if (finished) {
							 self.currentEditingView = nil;
							 self.keyboardWillShowNotification = nil;
							 self.offsetAmount = 0.0;
						 }
					 }];
}

@end
