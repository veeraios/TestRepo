#import "NSManagedObject+MONFilename.h"

@implementation NSManagedObject (MONFilename)

- (NSString *)filenameFromObjectId {
	
	NSString *trialObjectIDURIRepresentation = [[[self objectID] URIRepresentation] absoluteString];
	NSRange trialClassRange = [trialObjectIDURIRepresentation rangeOfString:NSStringFromClass([self class])];
	NSString *objectIdString = [trialObjectIDURIRepresentation substringFromIndex:trialClassRange.location];
	NSCharacterSet *illegalFileNameCharacters = [NSCharacterSet characterSetWithCharactersInString:@"/\\?%:*|\"<>"];
	
    return [[objectIdString componentsSeparatedByCharactersInSet:illegalFileNameCharacters] componentsJoinedByString:@"_"];
}

@end
