//
//  MONChange.swift
//  TrialManagement
//
//  Created by WAIDMANN, ALAN [AG/1000] on 1/22/15.
//  Copyright (c) 2015 Monsanto. All rights reserved.
//

import UIKit

class MONChange : NSObject,Printable {
    let path: String
    var leftValue: Any?
    var rightValue: Any?
    var resolvedValue: Any?
    
    override var description : String {
        let pathDesc = "MONChange: \nPath: \(path) \n"
        let leftDesc = "Left: \(leftValue != nil ? leftValue! : leftValue) \n"
        let rightDesc = "Right: \(rightValue != nil ? rightValue! : rightValue) \n"
        let resolvedDesc = "Resolved: \(resolvedValue != nil ? resolvedValue! : resolvedValue) \n"
        
        return pathDesc + leftDesc + rightDesc + resolvedDesc
    }
    
    init<T>(path:String,leftValue:T?,rightValue:T?,resolvedValue:T?) {
        self.path = path
        self.leftValue = leftValue
        self.rightValue = rightValue
        self.resolvedValue = resolvedValue
        super.init()
    }
}
