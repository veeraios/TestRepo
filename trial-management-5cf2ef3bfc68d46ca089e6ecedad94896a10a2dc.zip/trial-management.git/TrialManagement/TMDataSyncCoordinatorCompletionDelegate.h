@protocol TMDataSyncCoordinatorCompletionDelegate <NSObject>

-(void)dataSyncCompletedFor:(NSString *)name;
-(void)dataSyncFailedFor:(NSString *)name;

@end
