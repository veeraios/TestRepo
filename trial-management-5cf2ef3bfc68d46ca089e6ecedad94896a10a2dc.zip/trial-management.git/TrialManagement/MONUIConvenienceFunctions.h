#import <Foundation/Foundation.h>

CGFloat MONUIScreenGetScreenScale();

CGFloat MONUIScreenRoundToScreenScale(CGFloat value);

CGRect MONRectRoundedToScreenScale(CGRect rect);

CGRect MONRectForSizeCenteredInRect(CGSize size, CGRect inRect);

