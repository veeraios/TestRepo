#import "TMEditTrialValueUOMCell.h"
#import "NSNumber+TMNSNumberHelper.h"
#import "TMObservationSelectionConstants.h"

@implementation TMEditTrialValueUOMCell

- (void)updateValue:(NSNumber *)value selectedUnitOfMeasure:(NSString *)selectedUnitOfMeasure {
	
	self.cellModel.value = value;
	self.cellModel.selectedUnitOfMeasure = selectedUnitOfMeasure;
	if (self.cellModel.value && self.cellModel.selectedUnitOfMeasure) {
		[self setSelectedText:[NSString stringWithFormat:@"%@ %@", [self.cellModel.value roundedStringToTwoDecimalPlaces], self.cellModel.selectedUnitOfMeasure]];
	} else {
		[self setSelectedText:[UnselectedText uppercaseString]];
	}
}

@end
