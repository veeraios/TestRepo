//
//  TMGlobalMenuModel.m
//  TrialManagement
//
//  Created by SINGH, SUPREET [AG/1000] on 8/11/14.
//  Copyright (c) 2014 Monsanto. All rights reserved.
//

#import "TMGlobalMenuModel.h"

@interface TMGlobalMenuModel()

@property (nonatomic, readonly) TMTrialModel *trialModel;

@end

@implementation TMGlobalMenuModel

- (instancetype)initWithTrialModel:(TMTrialModel *)trialModel {
    self = [super init];
    if (self) {
        _trialModel = trialModel;
    }
    return self;
}

- (BOOL)isEligibleForMarketing {
    return [self.trialModel isEligibleForMarketing];
}

- (BOOL) isBasicTrialInfoFilled {
    return [self.trialModel hasRequiredTrialInfoFilledIn];
}

-(NSString *)status {
    return [self.trialModel status];
}

-(NSString *)trialName {
    return [self.trialModel trialName];
}

-(NSString *)growerName {
    return [self.trialModel growerName];
}

-(NSString *)salesManagerName {
    return [self.trialModel salesManagerName];
}

-(NSString *)cropName {
    return [self.trialModel cropName];
}

-(NSString *)plotTypeDescription {
    return [self.trialModel plotTypeDescription];
}

@end
