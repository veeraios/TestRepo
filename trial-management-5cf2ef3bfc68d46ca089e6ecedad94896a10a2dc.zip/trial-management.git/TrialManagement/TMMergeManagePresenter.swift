//
//  TMMergeManagePresenter.swift
//  TrialManagement
//
//  Created by SINGH, SUPREET [AG/1000] on 2/9/15.
//  Copyright (c) 2015 Monsanto. All rights reserved.
//

import UIKit

class TMMergeManagePresenter: TMMergeManageViewDelegate, TMMergeTrialModelDelegate {
    var delegate: TMMergeUIOptionsDelegate?

    private let mergeTrialModel: TMMergeTrialModel
    private let mergeManageView: TMMergeManageView
    private let mergeTrialViewModel: TMMergeTrialViewModel
    
    init(_ mergeTrialModel: TMMergeTrialModel, _ mergeManageView: TMMergeManageView, _ mergeTrialViewModel: TMMergeTrialViewModel) {
        self.mergeTrialModel = mergeTrialModel
        self.mergeManageView = mergeManageView
        self.mergeTrialViewModel = mergeTrialViewModel
        mergeManageView.autoresizingMask = UIViewAutoresizing.FlexibleWidth | UIViewAutoresizing.FlexibleHeight
        self.mergeManageView.delegate = self
        self.mergeTrialModel.delegate = self
    }
    
    func closeFromManage() {
        delegate?.close()
    }
    
    func conflictResolved(side: TMMergeSide, subsection: TMMergeSubsection, section: TMMergeSection) {
        mergeTrialModel.conflictResolved(side, subsection: subsection, section: section)
    }
    
    func resolveAllConflicts(side: TMMergeSide) {
        mergeManageView.resolveAllConflicts(side)
    }
    
    func saveResolvedValues() {
        delegate?.saveResolvedValues()
    }
}
