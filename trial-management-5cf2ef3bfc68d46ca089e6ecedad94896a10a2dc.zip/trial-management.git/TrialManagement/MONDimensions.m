//
//  MONDimensions.m
//  TrialManagement
//
//  Created by SINGH, SUPREET [AG/1000] on 1/21/15.
//  Copyright (c) 2015 Monsanto. All rights reserved.
//
#import "MONDimensions.h"

const CGFloat MONDimensionsSegmentedCornerRadius = 5.0;
const CGFloat MONDimensionsMicroPadding = 5.0;
const CGFloat MONDimensionsTinyPadding = 10.0;
const CGFloat MONDimensionsSmallPadding = 15.0;
const CGFloat MONDimensionsLargePadding = 25.0;
const CGFloat MONDimensionsExtraLargePadding = 35.0;
const CGFloat MONDimensionsThinBorderWidth = 1.0;
const CGFloat MONDimensionsThickBorderWidth = 2.0;
const CGFloat MONDimensionsCornerRadius = 2.0;
const CGFloat MONDimensionsTableHeaderRowHeight = 40.0;
const CGFloat MONDimensionsTableRowHeight = 44.0;
const CGFloat MONDimensionsHeaderHeight = 64.0;
const CGFloat MONDimensionsIconTouchTargetWidth = 44.0;