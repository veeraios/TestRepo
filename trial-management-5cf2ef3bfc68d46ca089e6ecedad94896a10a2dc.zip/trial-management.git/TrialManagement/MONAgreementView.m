#import "MONAgreementView.h"
#import "MONLabel.h"
#import "MONFonts.h"
#import "MONDimensions.h"
#import "MONYesNoSwitch.h"
#import "MONDateTextFieldButton.h"
#import "UIColor+MONThemeColorProvider.h"
#import "MONLabeledDateTextFieldButton.h"

static const CGFloat TitleTextSize = 18.0;
static const CGFloat DefaultTextSize = 14.0;
static const CGFloat SignatureLabelTextSize = 16.0;
static const CGFloat HeaderLabelOffsetY = 7.0;
static const CGFloat SignatureBoxWidth = 333.0;
static const CGFloat SignatureBoxHeight = 78.0;
static const CGFloat DateTextFieldButtonWidth = 175.0;
static const CGFloat PlotDataFormTitleLabelOffsetY = 13.0;
static const CGFloat AgreementLabelOffsetY = 10.0;
static const CGFloat SignatureLabelOffsetY = 5.0;
static const CGFloat GrowerNameLabelOffsetY = 5.0;
static const CGFloat InfoAgreementYesNoSwitchOffsetY = 10.0;
static NSString * const PlotDataFormPrefix = @"PLOT DATA FORM: ";

@interface MONAgreementView()<MONDateTextFieldButtonDelegate>
@property (nonatomic) MONLabel *headerLabel;
@property (nonatomic) MONLabel *plotDataFormTitleLabel;
@property (nonatomic) UITextView *agreementLabel;
@property (nonatomic) MONLabel *signatureLabel;
@property (nonatomic) UIButton *signatureImageButton;
@property (nonatomic) MONLabeledDateTextFieldButton *dateTextFieldButton;
@property (nonatomic) MONYesNoSwitch *yesNoSwitch;
@property (nonatomic) MONLabel *growerNameLabel;
@property (nonatomic) MONLabel *informationAgreementLabel;
@property (nonatomic) MONYesNoSwitch *infoAgreementYesNoSwitch;

@end

@implementation MONAgreementView

- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
		self.headerLabel = [[MONLabel alloc] init];
		self.headerLabel.font = [UIFont fontWithName:OpenSansLight size:MONFontsHeaderTextSize];
		[self.headerLabel setText:@"AUTHORIZATIONS"];
		[self.contentContainerView addSubview:self.headerLabel];
		
		self.plotDataFormTitleLabel = [[MONLabel alloc] init];
		self.plotDataFormTitleLabel.font = [UIFont fontWithName:OpenSansLight size:TitleTextSize];
		[self.plotDataFormTitleLabel setText:PlotDataFormPrefix];
		[self.contentContainerView addSubview:self.plotDataFormTitleLabel];
        
       //initializing textview property
        
        self.agreementLabel = [[UITextView alloc] init];
        [self.agreementLabel setBackgroundColor:[UIColor clearColor]];
        
//		self.agreementLabel = [[MONLabel alloc] init];
//		self.agreementLabel.numberOfLines = 0;
//		self.agreementLabel.lineBreakMode = NSLineBreakByWordWrapping;
        
        // making text to link
         
        self.agreementLabel.editable = NO;
        self.agreementLabel.dataDetectorTypes = UIDataDetectorTypeLink;
        
		self.agreementLabel.font = [UIFont fontWithName:OpenSansLight size:DefaultTextSize];
		[self.agreementLabel setText:@"I hereby grant Monsanto Company, including affiliated companies and subsidiaries, assigns, and dealers/retailers, the right to use the test plot data results pertaining to my fields (in whole or in part with such changes in language as do not substantially alter the meaning), the GPS coordiantes for my fields, and/or any pictures, photographs or tapes taken in conjunction with said test plot data results in its publicity, promotions and advertising, including use on the internet. I acknowledge and agree that any such data shared with Monsanto will not be subject to The Climate Corporation's Privacy Policy (www.climate.com/legal/privacy-policy/)."];
		[self.contentContainerView addSubview:self.agreementLabel];

		self.signatureLabel = [[MONLabel alloc] init];
		self.signatureLabel.font = [UIFont fontWithName:OpenSansLight size:SignatureLabelTextSize];
		[self.signatureLabel setText:@"Grower Signature:"];
		[self.contentContainerView addSubview:self.signatureLabel];

		self.signatureImageButton = [[UIButton alloc] init];
		[self.signatureImageButton addTarget:self action:@selector(imageTapped) forControlEvents:UIControlEventTouchUpInside];
		[self.signatureImageButton.layer setBorderColor:[UIColor colorForThemeComponentType:MONThemeComponentTypeBorder].CGColor];
		[self.signatureImageButton.layer setBorderWidth:MONDimensionsThinBorderWidth];
		[self.contentContainerView addSubview:self.signatureImageButton];
		
		self.dateTextFieldButton = [[MONLabeledDateTextFieldButton alloc] init];
		self.dateTextFieldButton.dateDelegate = self;
		[self.dateTextFieldButton setLabelFont:[UIFont fontWithName:OpenSans size:DefaultTextSize]];
		[self.dateTextFieldButton setMaximumDate:[NSDate date]];
		[self.dateTextFieldButton setLabelText:@"Date*"];
		[self.dateTextFieldButton setPlaceholderText:@"MM/YY/YYYY"];
		[self.contentContainerView addSubview:self.dateTextFieldButton];
		
		self.yesNoSwitch = [[MONYesNoSwitch alloc] init];
		[self.yesNoSwitch addTarget:self action:@selector(signatureAgreementWasTapped) forControlEvents:UIControlEventValueChanged];
		[self.contentContainerView addSubview:self.yesNoSwitch];
		
		self.growerNameLabel = [[MONLabel alloc] init];
		self.growerNameLabel.font = [UIFont fontWithName:OpenSansLight size:SignatureLabelTextSize];
		self.growerNameLabel.text = @"some name";
		[self.contentContainerView addSubview:self.growerNameLabel];

		self.informationAgreementLabel = [[MONLabel alloc] init];
		self.informationAgreementLabel.numberOfLines = 0;
		self.informationAgreementLabel.lineBreakMode = NSLineBreakByWordWrapping;
		[self.informationAgreementLabel setText:@"I agree that my name, field location (including GPS coordinates) and likeness may be used in publishing test plot data results by Monsanto."];
		self.informationAgreementLabel.font = [UIFont fontWithName:OpenSansLight size:DefaultTextSize];
		[self.contentContainerView addSubview:self.informationAgreementLabel];

		self.infoAgreementYesNoSwitch = [[MONYesNoSwitch alloc] init];
		[self.infoAgreementYesNoSwitch addTarget:self action:@selector(cooperatorReleaseWasTapped) forControlEvents:UIControlEventValueChanged];
		[self.contentContainerView addSubview:self.infoAgreementYesNoSwitch];
	}
    return self;
}

- (void)layoutSubviews {
	[super layoutSubviews];
	
	[self.headerLabel sizeToFit];
	self.headerLabel.frame = CGRectMake(MONDimensionsSmallPadding,
										MONDimensionsSmallPadding - HeaderLabelOffsetY,
										CGRectGetWidth(self.headerLabel.frame),
										CGRectGetHeight(self.headerLabel.frame));
	
	[self.plotDataFormTitleLabel sizeToFit];
	self.plotDataFormTitleLabel.frame = CGRectMake(MONDimensionsSmallPadding,
														  CGRectGetMaxY(self.headerLabel.frame) - PlotDataFormTitleLabelOffsetY + MONDimensionsSmallPadding,
														  CGRectGetWidth(self.plotDataFormTitleLabel.frame),
														  CGRectGetHeight(self.plotDataFormTitleLabel.frame));
	
	CGSize agreementLabelSize = [self.agreementLabel sizeThatFits:CGSizeMake(CGRectGetWidth(self.contentContainerView.bounds) - 2.0 * MONDimensionsSmallPadding, CGFLOAT_MAX)];
	self.agreementLabel.frame = CGRectMake(MONDimensionsSmallPadding,
										   CGRectGetMaxY(self.plotDataFormTitleLabel.frame) - AgreementLabelOffsetY + MONDimensionsSmallPadding,
										   agreementLabelSize.width,
										   agreementLabelSize.height);
	
	[self.signatureLabel sizeToFit];
	self.signatureLabel.frame = CGRectMake(MONDimensionsSmallPadding,
										   CGRectGetMaxY(self.agreementLabel.frame) - SignatureLabelOffsetY + MONDimensionsSmallPadding,
										   CGRectGetWidth(self.signatureLabel.frame),
										   CGRectGetHeight(self.signatureLabel.frame));
	[self.yesNoSwitch sizeToFit];
	self.yesNoSwitch.frame = CGRectMake(CGRectGetMaxX(self.contentContainerView.bounds) - CGRectGetWidth(self.yesNoSwitch.frame) - MONDimensionsSmallPadding,
										CGRectGetMinY(self.signatureLabel.frame),
										CGRectGetWidth(self.yesNoSwitch.frame),
										CGRectGetHeight(self.yesNoSwitch.frame));
	
	self.signatureImageButton.frame = CGRectMake((CGRectGetMaxX(self.signatureLabel.frame) + MONDimensionsSmallPadding),
												 CGRectGetMinY(self.yesNoSwitch.frame),
												 SignatureBoxWidth,
												 SignatureBoxHeight);
	
	[self.dateTextFieldButton sizeToFit];
	self.dateTextFieldButton.frame = CGRectMake(CGRectGetMaxX(self.contentContainerView.bounds) - DateTextFieldButtonWidth - MONDimensionsSmallPadding,
												CGRectGetMaxY(self.signatureImageButton.frame) - CGRectGetHeight(self.dateTextFieldButton.frame),
												DateTextFieldButtonWidth,
												CGRectGetHeight(self.dateTextFieldButton.frame));
	
	
	[self.growerNameLabel sizeToFit];
	self.growerNameLabel.frame = CGRectMake(CGRectGetMaxX(self.signatureImageButton.frame) - CGRectGetWidth(self.growerNameLabel.frame),
											CGRectGetMaxY(self.signatureImageButton.frame) - GrowerNameLabelOffsetY + MONDimensionsSmallPadding,
											CGRectGetWidth(self.growerNameLabel.frame),
											CGRectGetHeight(self.growerNameLabel.frame));
	
	self.infoAgreementYesNoSwitch.frame = CGRectMake(CGRectGetMaxX(self.contentContainerView.bounds) - CGRectGetWidth(self.infoAgreementYesNoSwitch.frame) - MONDimensionsSmallPadding,
													 CGRectGetMaxY(self.growerNameLabel.frame) - InfoAgreementYesNoSwitchOffsetY + MONDimensionsLargePadding,
													 CGRectGetWidth(self.infoAgreementYesNoSwitch.frame),
													 CGRectGetHeight(self.infoAgreementYesNoSwitch.frame));

	CGSize informationAgreementLabelSize = [self.informationAgreementLabel sizeThatFits:CGSizeMake(CGRectGetMinX(self.infoAgreementYesNoSwitch.frame) - MONDimensionsLargePadding, CGFLOAT_MAX)];
	self.informationAgreementLabel.frame = CGRectMake(MONDimensionsSmallPadding,
													  CGRectGetMinY(self.infoAgreementYesNoSwitch.frame),
													  CGRectGetWidth(self.contentContainerView.bounds) - CGRectGetWidth(self.infoAgreementYesNoSwitch.frame) - MONDimensionsLargePadding - MONDimensionsSmallPadding,
													  informationAgreementLabelSize.height);
}

- (CGSize)sizeThatFits:(CGSize)size {
	CGSize sizeThatFits = CGSizeMake(size.width, 0.0);
	
	[self.headerLabel sizeToFit];
	sizeThatFits.height -= HeaderLabelOffsetY;
	sizeThatFits.height += MONDimensionsSmallPadding;
	sizeThatFits.height += CGRectGetHeight(self.headerLabel.frame);
	
	[self.plotDataFormTitleLabel sizeToFit];
	sizeThatFits.height -= PlotDataFormTitleLabelOffsetY;
	sizeThatFits.height += MONDimensionsSmallPadding;
	sizeThatFits.height += CGRectGetHeight(self.plotDataFormTitleLabel.frame);
	
	CGSize agreementLabelSize = [self.agreementLabel sizeThatFits:CGSizeMake(size.width - 2.0 * MONDimensionsSmallPadding, CGFLOAT_MAX)];
	sizeThatFits.height -= AgreementLabelOffsetY;
	sizeThatFits.height += MONDimensionsSmallPadding;
	sizeThatFits.height += agreementLabelSize.height;
	
	sizeThatFits.height -= SignatureLabelOffsetY;
	sizeThatFits.height += MONDimensionsSmallPadding;
	sizeThatFits.height += SignatureBoxHeight;
	
	[self.growerNameLabel sizeToFit];
	sizeThatFits.height -= GrowerNameLabelOffsetY;
	sizeThatFits.height += MONDimensionsSmallPadding;
	sizeThatFits.height += CGRectGetHeight(self.growerNameLabel.frame);
	
	[self.infoAgreementYesNoSwitch sizeToFit];
	CGSize informationAgreementLabelSize = [self.informationAgreementLabel sizeThatFits:CGSizeMake(size.width - CGRectGetWidth(self.infoAgreementYesNoSwitch.frame) - 2.0 * MONDimensionsSmallPadding - MONDimensionsLargePadding, CGFLOAT_MAX)];
	sizeThatFits.height -= InfoAgreementYesNoSwitchOffsetY;
	sizeThatFits.height += MONDimensionsLargePadding;
	sizeThatFits.height += MAX(CGRectGetHeight(self.infoAgreementYesNoSwitch.frame), informationAgreementLabelSize.height);
	
	sizeThatFits.height += MONDimensionsSmallPadding;	
	
	return sizeThatFits;
	
}

- (void)cooperatorReleaseWasTapped {
	[self.delegate cooperatorReleaseChanged:self.infoAgreementYesNoSwitch.switchValue];
}

- (void)signatureAgreementWasTapped {
	[self.delegate signatureAgreementChanged:self.yesNoSwitch.switchValue];
}

- (void)setSignatureIsAgreed:(BOOL)value {
	[self.yesNoSwitch setSwitchValue:value];
}

- (void)setCooperatorRelease:(BOOL)value {
	[self.infoAgreementYesNoSwitch setSwitchValue:value];
}

- (void)setSignatureDate:(NSDate *)date {
	[self.dateTextFieldButton setDate:date];
}

- (void)setGrowerNameToSignature:(NSString*)growerName {
	[self.growerNameLabel setText:growerName];
	[self setNeedsLayout];
}

- (void)setCropName:(NSString *)cropName brandName:(NSString *)brandName {
	NSString *text = [NSString stringWithFormat:@"%@ %@%@", brandName, PlotDataFormPrefix, cropName];
	[self.plotDataFormTitleLabel setText:[text uppercaseString]];
	[self setNeedsLayout];
}

- (void)imageTapped {
	[self.delegate signatureTapped];
}

- (void)setSignatureImage:(UIImage*)signatureImage {
	[self.signatureImageButton setAlpha:0.0];
	[self.signatureImageButton setImage:signatureImage forState:UIControlStateNormal];

	[UIView animateWithDuration:0.5
						  delay:0.0
						options:UIViewAnimationOptionCurveEaseIn
 					 animations:^{
						 [self.signatureImageButton setAlpha:1.0];
					 }
					 completion:nil];
}

#pragma mark - MONDateTextFieldButtonDelegate Methods

- (void)dateChanged:(NSDate*)date {
	[self.delegate signatureDateChanged:date];
}

@end
