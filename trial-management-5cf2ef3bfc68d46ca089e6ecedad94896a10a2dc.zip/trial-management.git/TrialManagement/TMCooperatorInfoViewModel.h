#import "TMStatesModel.h"

@protocol TMViewModel <NSObject>

@end

@interface TMCooperatorInfoViewModel : NSObject<TMViewModel>
@property (nonatomic,readonly) TMStatesModel *statesModel;
@end
