#import <UIKit/UIKit.h>

typedef NS_ENUM(NSInteger, SignatureCaptureImageType) {
    SignatureCapturePNG,
    SignatureCaptureJPEG,
};

@interface MONSignatureCapture : UIView

- (void)clearImage;
- (UIImage*)signatureImage;
- (NSString*)stringFromSignaturePath;
-(void)saveImage:(NSString*)path as:(SignatureCaptureImageType) type;
@property (nonatomic) UIColor *pathColor;
@property (assign,readonly) BOOL hasContent;
@property (nonatomic,readonly) NSMutableArray *signaturePaths;
@end
