#import "MONLoginPresenter.h"

@interface MONLoginPresenter ()<MONLoginViewObserver>

@property (nonatomic) MONLoginView *loginView;
@property (nonatomic) MONLoginModel *loginModel;

@end

@implementation MONLoginPresenter

- (instancetype)initWithLoginView:(MONLoginView *)loginView loginModel:(MONLoginModel *)loginModel {
	self = [super init];
	if (self) {
		self.loginView = loginView;
		[self.loginView escAddObserver:self];
		
		self.loginModel = loginModel;
	}
	return self;
}

#pragma mark - TMLoginViewObserver Methods

- (void)usernameTextDidChange:(NSString *)usernameText {
	[self.loginModel setUsername:usernameText];
}

- (void)passwordTextDidChange:(NSString *)passwordText {
	[self.loginModel setPassword:passwordText];
}

- (void)loginButtonTapped {
	[self.loginModel submitLogin];
}

@end
