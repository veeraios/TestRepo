//
//  NSManagedObject+UIDAccessor.h
//  DDESpike
//
//  Created by WAIDMANN, ALAN [AG/1000] on 12/22/14.
//  Copyright (c) 2014 TPS. All rights reserved.
//

#import <CoreData/CoreData.h>

@interface NSManagedObject (UIDAccessor)
- (NSString *)uniqueIdentifierValue;
@end
