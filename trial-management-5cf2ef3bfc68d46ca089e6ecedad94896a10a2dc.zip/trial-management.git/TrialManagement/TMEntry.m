//
//  TMEntry.m
//  TrialManagement
//
//  Created by Jason Ludwig on 6/26/14.
//  Copyright (c) 2014 Monsanto. All rights reserved.
//

#import "TMEntry.h"


@implementation TMEntry

@dynamic entryId;
@dynamic number;
@dynamic pendingRequestedProduct;
@dynamic product;
@dynamic treatment;
@dynamic trial;
@dynamic observations;

@end
