#import "MONFilterPresenter.h"

@interface MONFilterPresenter ()<MONFilterViewObserver, MONFilterModelObserver>

@property (nonatomic) MONFilterView *filterView;
@property (nonatomic) MONFilterModel *filterModel;

@end

@implementation MONFilterPresenter

- (instancetype)initWithFilterView:(MONFilterView *)filterView filterModel:(MONFilterModel *)filterModel {
	self = [super init];
	if (self) {
		self.filterView = filterView;
		[self.filterView escAddObserver:self];
		
		self.filterModel = filterModel;
		[self.filterModel escAddObserver:self];
	}
	return self;
}

#pragma mark - MONFilterViewObserver Methods

- (void)filterTextDidChange:(NSString *)filterText {
	[self.filterModel filterItemsWithText:filterText];
}

- (void)filterCloseButtonTapped {
	[self.filterModel cancelFilter];
}

#pragma mark - MONFilterModelObserver Methods

- (void)filterCancelled {
	[self.filterView resignFirstResponder];
	[self.filterView setFilterText:@""];
}

@end
