#import "NSManagedObject+TMCoreDataTestHelper.h"
#import "TMDSMModel.h"

@interface TMDSMModelTest : XCTestCase

@end

@implementation TMDSMModelTest

- (void)testNameForItemAtIndexReturnsTechAgronomistName
{
	TMDSMModel *testObj = [[TMDSMModel alloc] initWithDataSource:@[@"test"]];
	NSString *actual =  [testObj nameForItemAtIndex:0];
	XCTAssertEqualObjects(actual,@"test");
}

@end
