//
//  TMDifferenceDetectionEngine.m
//  TrialManagement
//
//  Created by GADIRAJU, PRANEETH [AG/1000] on 1/5/15.
//  Copyright (c) 2015 Monsanto. All rights reserved.
//

#import "TMDifferenceDetectionEngine.h"
#import "MONDifferenceDetectionEngine.h"
#import "TMWorkingUnitOfWork.h"
#import "TMBackupUnitOfWork.h"
#import "TMDataModelTraversalRules.h"

@interface TMDifferenceDetectionEngine()
@property (nonatomic) MONDifferenceDetectionEngine *monDifferenceDetectionEngine;
@property (nonatomic) id<MONContextProtocol> backupContext;
@end

@implementation TMDifferenceDetectionEngine

-(instancetype)initWithBackupContext:(id<MONContextProtocol>)backupContext {
    self  = [super init];
    if (self) {
        self.backupContext = backupContext;
        self.monDifferenceDetectionEngine = [[MONDifferenceDetectionEngine alloc] initWithBackupContext:backupContext andDataModelTraversalRules:[[TMDataModelTraversalRules sharedInstance] dataModelTraversalRulesDictionary]];
        
    }
    return self;
}

- (NSDictionary *)changesInCurrentContextForTrial:(TMTrial *)trial {
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"trialId == %@", trial.trialId];
    
    NSArray *results = [self.backupContext findWithPredicate:NSStringFromClass([TMTrial class]) wherePredicate:predicate orderBy:@"trialId" ascending:NO];
    
    if([results count]) {
        return [self.monDifferenceDetectionEngine changesDetectedBetweenObject:trial andBackupObject:[results firstObject]];
    }
    
    return nil;
}

@end

