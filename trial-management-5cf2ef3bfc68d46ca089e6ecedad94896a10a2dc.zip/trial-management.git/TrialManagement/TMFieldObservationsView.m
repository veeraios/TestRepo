#import "TMFieldObservationsView.h"
#import "MONHeaderView.h"
#import "MONPlaceholderControl.h"
#import "MONDimensions.h"
#import "TMFieldInfoCollectionViewCell.h"
#import "MONLabeledPopoverButton.h"

@interface TMFieldObservationsView()<UICollectionViewDataSource, UICollectionViewDelegate>

@property (nonatomic) MONHeaderView *headerView;
@property (nonatomic) MONPlaceholderControl *placeholderControl;
@property (nonatomic) TMFieldObservationModel *model;
@property (nonatomic) UICollectionView *fieldInfoCollectionView;
@property (nonatomic) UICollectionViewFlowLayout *collectionViewFlowLayout;
@property (nonatomic, assign) CGSize cellSize;

@end

@implementation TMFieldObservationsView

- (instancetype)initWithFieldObservationModel:(TMFieldObservationModel*)model headerButtons:(NSArray *)headerButtons {
    self = [super init];
    if (self) {
		self.model = model;
		
		self.collectionViewFlowLayout = [[UICollectionViewFlowLayout alloc] init];
		self.collectionViewFlowLayout.minimumLineSpacing = MONDimensionsSmallPadding;

		self.fieldInfoCollectionView = [[UICollectionView alloc] initWithFrame:self.bounds collectionViewLayout:self.collectionViewFlowLayout];
		self.fieldInfoCollectionView.dataSource = self;
		self.fieldInfoCollectionView.delegate = self;
		self.fieldInfoCollectionView.frame = self.bounds;

		[self.fieldInfoCollectionView registerClass:[TMFieldInfoCollectionViewCell class] forCellWithReuseIdentifier: NSStringFromClass([TMFieldInfoCollectionViewCell class])];
		
		self.fieldInfoCollectionView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
		self.fieldInfoCollectionView.backgroundColor = [UIColor clearColor];
		self.fieldInfoCollectionView.contentInset = UIEdgeInsetsMake(MONDimensionsSmallPadding, MONDimensionsSmallPadding, MONDimensionsSmallPadding, MONDimensionsSmallPadding);
		[self addSubview:self.fieldInfoCollectionView];
		
		self.placeholderControl = [[MONPlaceholderControl alloc] init];
		self.placeholderControl.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
		[self.placeholderControl setImage:[UIImage imageNamed:@"ui-add-observation-bg-graphic"]];
		[self.placeholderControl setText:@"Tap the plus icon to start adding field observations."];
		[self.placeholderControl addTarget:self action:@selector(addObservationModalTapped) forControlEvents:UIControlEventTouchUpInside];
		[self addSubview:self.placeholderControl];
		

		self.headerView = [[MONHeaderView alloc] init];
		[self.headerView setTitle:@"Field Observations"];
		[self.headerView setRightButtons:headerButtons];
		[self addSubview:self.headerView];
		
		[self showPlaceHolderButtonIfNoObservationsExist];
        
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(popoverButtonDidShowPopOver:) name:MONLabeledPopoverButtonDidShowPopover object:nil];
    }
    return self;
}


-(void)showPlaceHolderButtonIfNoObservationsExist {
	if([self hasFieldInfoObservations]) {
		self.placeholderControl.hidden = YES;
	}
}

-(BOOL)hasFieldInfoObservations {
	return [self.model hasObservations];
}

-(void)layoutSubviews {
    [super layoutSubviews];

	[self setCellSizeForEntry];
	[self.collectionViewFlowLayout setItemSize:CGSizeMake(self.cellSize.width, self.cellSize.height)];
	

	[self.headerView sizeToFit];
	self.headerView.frame = CGRectMake(0.0, 0.0, CGRectGetWidth(self.bounds), CGRectGetHeight(self.headerView.frame));
	
	self.fieldInfoCollectionView.frame = CGRectMake(0.0,
													CGRectGetMaxY(self.headerView.frame),
													CGRectGetWidth(self.bounds),
													CGRectGetHeight(self.bounds) - CGRectGetMaxY(self.headerView.frame));

	self.placeholderControl.frame = CGRectMake(0.0,
												   CGRectGetMaxY(self.headerView.frame),
												   CGRectGetWidth(self.bounds),
												   CGRectGetHeight(self.bounds) - CGRectGetHeight(self.headerView.frame));
}

- (void)setCellSizeForEntry {
	if([self hasFieldInfoObservations]) {
		TMFieldInfoCollectionViewCell *cellForSizing = [[TMFieldInfoCollectionViewCell alloc] init];
		[cellForSizing setModel:self.model];
		CGFloat cardWidth = CGRectGetWidth(self.bounds) - 2.0 * MONDimensionsSmallPadding;
		self.cellSize = [cellForSizing sizeThatFits:CGSizeMake(cardWidth, CGFLOAT_MAX)];
	}
}

#pragma mark - UICollectionViewDataSource Methods

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
	TMFieldInfoCollectionViewCell *collectionViewCell = [collectionView dequeueReusableCellWithReuseIdentifier:NSStringFromClass([TMFieldInfoCollectionViewCell class]) forIndexPath:indexPath];
	[collectionViewCell setModel:self.model];
	return collectionViewCell;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
	return [self hasFieldInfoObservations] ? 1 : 0;
}

- (void)addObservationModalTapped {
    [self.delegate addObservationsTapped];
}

- (void)refreshObservations:(TMFieldObservationModel*)model{
	self.model = model;
	[self showPlaceHolderButtonIfNoObservationsExist];
	[self reloadData];
	[self setNeedsLayout];
}

- (void)reloadData {
	[self.collectionViewFlowLayout invalidateLayout];
	[self.fieldInfoCollectionView reloadData];
}

#pragma mark - MONLabeledPopoverButton Notification

- (void)popoverButtonDidShowPopOver:(NSNotification *)notification {
    [self endEditing:YES];
}
@end
