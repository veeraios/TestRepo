#import "MONSafeString.h"

@implementation MONSafeString

+ (NSString *)safeStringForString:(NSString *)string {
    if(string == nil  || [string isMemberOfClass:[NSNull class]] || [string length] == 0 || [string isEqualToString:@"<null>"]) {
        return @"";
    }
    return string;
}

@end
