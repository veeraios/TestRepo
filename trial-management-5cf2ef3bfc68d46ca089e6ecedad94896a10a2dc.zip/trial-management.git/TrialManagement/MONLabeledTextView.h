#import "MONTextView.h"
#import "MONLabel.h"

@interface MONLabeledTextView : UIView
-(void)setTextViewDelegate:(id<UITextViewDelegate>)textViewDelegate;
-(void)setText:(NSString*)text;
-(void)setLabelText:(NSString*)text;
-(void)setPlaceHolderText:(NSString*)placeHolderText;
- (void)setEditable:(BOOL)editable;
@end
