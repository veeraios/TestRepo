  #import "TMHarvestEditContainerPresenter.h"
#import "TMObservationModel.h"
#import "TMObservationModelUtil.h"

@interface TMHarvestEditContainerPresenter()<TMObservationUpdateProtocol, TMYieldCalculationModelDelegate>

@property (nonatomic) NSArray *harvestObservations;
@property (nonatomic) TMHarvestEditContainerView *harvestEditContainerView;
@property (nonatomic) TMYieldCalculationModel *yieldCalculationModel;

@end

@implementation TMHarvestEditContainerPresenter

- (instancetype)initWithEntryModel:(TMEntryModel *)entryModel
                   harvestEditContainerView:(TMHarvestEditContainerView *)harvestEditContainerView {
    self = [super init];
    if (self) {
        self.harvestObservations = [entryModel harvestObservations];
        for (TMObservationModel *observationModel in self.harvestObservations) {
            observationModel.delegate = self;
        }
        self.harvestEditContainerView = harvestEditContainerView;
        self.yieldCalculationModel = [entryModel yieldCalculationModel];
        self.yieldCalculationModel.delegate = self;
        
        if ([entryModel disablePlotWeightAndYield]) {
            NSString *yieldObsRefCode = [TMObservationModelUtil observationRefCodeForObservationClass:@"Yield" observationModels:self.harvestObservations];
            NSString *plotWeightObsRefCode = [TMObservationModelUtil observationRefCodeForObservationReferenceDataName:@"Plot Weight" observationModels:self.harvestObservations];
            [self.harvestEditContainerView shouldSetAsReadOnly:YES forObsRefCode:yieldObsRefCode];
            [self.harvestEditContainerView shouldSetAsReadOnly:YES forObsRefCode:plotWeightObsRefCode];
        }
    }
    return self;
}

#pragma mark - TMObservationUpdateProtocol
- (void)observationWasUpdated:(NSString*)observationClass {
    [self.yieldCalculationModel observationWasUpdated:observationClass];
    if([[observationClass uppercaseString] isEqualToString:@"YIELD"]) {
        [self.delegate yieldWasUpdated];
    } else if([[observationClass uppercaseString] isEqualToString:@"HARVEST MOISTURE"]) {
        [self.delegate moistureWasUpdated];
    }

}

- (void)calculateYieldAndSetAsReadOnlyIfNeeded {
    [self.yieldCalculationModel calculateYieldAndSetAsReadOnlyIfNeeded];
}

#pragma mark - TMYieldCalculationModelDelegate
- (void)shouldSetAsReadOnly:(BOOL)isReadOnly forObsRefCode:(NSString *)observationRefCode {
    [self.harvestEditContainerView shouldSetAsReadOnly:isReadOnly forObsRefCode:observationRefCode];
}

- (void)autoCalculatedValue:(NSString *)value forObservation:(NSString *)observationRefCode {
    [self.harvestEditContainerView setAutoCalulatedValue:value withLabel: value ? @"Yield (Auto Calculated)" : @"Yield" forObsRefCode:observationRefCode];
    [self.delegate yieldWasUpdated];
}

@end
