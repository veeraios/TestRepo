//
//  TMMergeSummaryView.swift
//  TrialManagement
//
//  Created by SINGH, SUPREET [AG/1000] on 1/12/15.
//  Copyright (c) 2015 Monsanto. All rights reserved.
//

import UIKit

protocol TMMergeSummaryViewDelegate: class {
    func closeFromSummary()
    func manage()
}

class TMMergeSummaryView: UIVisualEffectView {
    private let totalWidth: CGFloat = 600
    private let totalHeight: CGFloat = 326
    private let buttonLeftRightPadding: CGFloat = 90
    private let labelWidth: CGFloat = 200
    private let labelHeight: CGFloat = 60
    
    weak var delegate: TMMergeSummaryViewDelegate?
    private let backgroundView: UIView
    private let headerLabel: UILabel
    private let conflictsSummaryLabel: UILabel
    private let exitButton: UIButton
    private let manageButton: UIButton
    private let exitLabel: UILabel?
    private let manageLabel: UILabel?
    
    init(numberOfTotalConflicts : Int, numberOfTrials : Int) {
        backgroundView = UIView()
        backgroundView.backgroundColor = UIColor(forThemeComponentType: MONThemeComponentTypeBackground)
        headerLabel = UILabel()
        headerLabel.backgroundColor = UIColor(forThemeComponentType: MONThemeComponentTypeNavigationBar)
        headerLabel.font = UIFont(name: OpenSansSemibold, size: 17)
        headerLabel.textColor = UIColor(forThemeComponentType: MONThemeComponentTypeNavigationBarText)
        headerLabel.textAlignment = NSTextAlignment.Center
        headerLabel.text = "Data Conflicts Exist!"
        conflictsSummaryLabel = UILabel()
        exitButton = UIButton()
        exitButton.setImage(UIImage(named: "ui-icon-exit-large"), forState: UIControlState.Normal)
        manageButton = UIButton()
        manageButton.setImage(UIImage(named: "ui-icon-manual-large"), forState: UIControlState.Normal)
        super.init(effect: UIBlurEffect(style: UIBlurEffectStyle.Dark))
        conflictsSummaryLabel.attributedText = createConflictsSummaryString(numberOfTotalConflicts, numberOfTrials: numberOfTrials)
        conflictsSummaryLabel.textAlignment = NSTextAlignment.Center
        exitLabel = TMDefaultUIFactory.createDefaultBoldLabel("I'll Fix Them Later", size: 17, numberOfLines: 2)
        exitButton.addTarget(self, action: "close", forControlEvents: UIControlEvents.TouchUpInside)
        manageLabel = TMDefaultUIFactory.createDefaultBoldLabel("Start Managing Conflicts Manually", size: 17, numberOfLines: 2)
        manageButton.addTarget(self, action: "manage", forControlEvents: UIControlEvents.TouchUpInside)
        contentView.addSubview(backgroundView)
        contentView.addSubview(headerLabel)
        contentView.addSubview(conflictsSummaryLabel)
        contentView.addSubview(exitButton)
        contentView.addSubview(manageButton)
        contentView.addSubview(exitLabel!)
        contentView.addSubview(manageLabel!)
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        backgroundView.frame = CGRectMake((bounds.width - totalWidth) / 2.0, (bounds.height - totalHeight) / 2.0, totalWidth, totalHeight)
        headerLabel.frame = CGRectMake(backgroundView.frame.minX, backgroundView.frame.minY, totalWidth, MONDimensionsTableRowHeight)
        conflictsSummaryLabel.frame = CGRectMake(backgroundView.frame.minX, headerLabel.frame.maxY + MONDimensionsTinyPadding, totalWidth, MONDimensionsTableRowHeight)
        exitButton.sizeToFit()
        exitButton.frame = CGRectMake(backgroundView.frame.minX + (totalWidth - exitButton.frame.width * 2.0 - buttonLeftRightPadding) / 2.0 ,
            conflictsSummaryLabel.frame.maxY + MONDimensionsExtraLargePadding, exitButton.frame.width, exitButton.frame.height)
        manageButton.sizeToFit()
        manageButton.frame = CGRectMake(exitButton.frame.maxX + buttonLeftRightPadding, exitButton.frame.minY, manageButton.frame.width, manageButton.frame.height)
        exitLabel?.frame = CGRectMake(exitButton.center.x - labelWidth/2.0, exitButton.frame.maxY + MONDimensionsTinyPadding, labelWidth, labelHeight)
        manageLabel?.frame = CGRectMake(manageButton.center.x - labelWidth/2.0, manageButton.frame.maxY + MONDimensionsTinyPadding, labelWidth, labelHeight)
    }
    
    private func createConflictsSummaryString(numberOfTotalConflicts: Int, numberOfTrials: Int) -> NSMutableAttributedString {
        let conflictsSummaryRawString = "\(numberOfTotalConflicts) Conflicts Affecting \(numberOfTrials) Trial"
        let conflictsSummaryString = NSMutableAttributedString(string: conflictsSummaryRawString)
        conflictsSummaryString.addAttribute("NSFont", value: UIFont(name: OpenSansSemibold, size: 32)!, range: NSMakeRange(0, countElements(conflictsSummaryRawString)))
        conflictsSummaryString.addAttribute("NSColor", value: UIColor(forThemeComponentType: MONThemeComponentTypeText), range: NSMakeRange(0, countElements(conflictsSummaryRawString) - 1))
        conflictsSummaryString.addAttribute("NSColor", value: UIColor(forThemeComponentType: MONThemeComponentTypeHighlight), range: NSMakeRange(0, countElements(numberOfTotalConflicts.description)))
        conflictsSummaryString.addAttribute("NSColor", value: UIColor(forThemeComponentType: MONThemeComponentTypeHighlight), range: NSMakeRange(countElements(numberOfTotalConflicts.description) + 21, countElements(numberOfTrials.description)))
        return conflictsSummaryString
    }

    func close() {
        delegate?.closeFromSummary()
    }
    
    func manage() {
        delegate?.manage()
    }
    
    required init(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

}
