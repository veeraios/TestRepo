#import "MONRepository.h"
#import "TMDataSyncProtocol.h"

@protocol TMDealerRepositoryProtocol <NSObject, MONRepositoryProtocol>
-(NSArray*)searchDealer:(NSString*)name;
//-(void)clearRepoCache;
@end

@interface TMDealerRepository :  MONRepository<TMDealerRepositoryProtocol ,TMDataSyncProtocol>
@end

