@interface NSArray (TMBlocks)
- (NSArray*)arrayForEach:(id (^)(id obj))block;
- (NSArray*)arrayForEach:(id (^)(id obj))block where:(BOOL (^)(id whereObj))where;
- (NSArray *)sort:(id (^)(id obj))block;
- (NSArray *)sort:(id (^)(id obj))block where:(BOOL (^)(id whereObj))where;
- (NSArray *)filter:(BOOL (^)(id whereObj))where;
- (BOOL)any:(BOOL (^)(id item))block;
- (NSArray *)where:(BOOL (^)(id item))block;
- (id)whereUnique:(BOOL (^)(id item))block;
- (id)whereUniqueOrBlock:(BOOL (^)(id item))block itemNotFoundBlock:(id (^)())itemNotFoundBlock;
- (id)whereUniqueOrNil:(BOOL (^)(id item))block;
- (id)whereUnique:(BOOL (^)(id item))block notUniqueBlock:(id (^)())notUniqueBlock;
- (id)all:(id (^)(id obj))block;
- (void)forAll:(void(^)(id obj))block;
- (id)whereOrPerformBlock:(BOOL (^)(id item))block itemNotFoundBlock:(void (^)(id item))itemNotFoundBlock;
@end
