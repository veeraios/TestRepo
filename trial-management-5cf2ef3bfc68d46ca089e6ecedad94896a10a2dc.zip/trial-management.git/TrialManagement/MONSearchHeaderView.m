#import "MONSearchHeaderView.h"
#import "MONItemCountView.h"
#import "MONDimensions.h"
#import "MONUIConvenienceFunctions.h"
#import "MONFonts.h"
#import "UIColor+MONThemeColorProvider.h"

static const CGFloat ItemCountViewLeftMargin = 10.0;
static const CGFloat HeaderLabelOffset = 7.0;

@interface MONSearchHeaderView ()

@property (nonatomic) MONItemCountView *itemCountView;
@property (nonatomic) UIView *bottomBorderView;
@property (nonatomic) CGFloat headerLabelOffset;
@property (nonatomic) BOOL numberOfItemsShown;
@property (nonatomic) NSArray *rightButtons;
@property (nonatomic) NSArray *leftButtons;

@end

@implementation MONSearchHeaderView
@synthesize headerLabel;

- (id)initWithFrame:(CGRect)frame {
	self = [super initWithFrame:frame];
	if (self) {
		self.autoresizesSubviews = YES;
		self.headerLabel = [[MONLabel alloc] init];
		self.headerLabel.font = [UIFont fontWithName:OpenSansLight size:MONFontsHeaderTextSize];
		[self addSubview:self.headerLabel];
		
		self.itemCountView = [[MONItemCountView alloc] init];
		[self addSubview:self.itemCountView];
		
		self.bottomBorderView = [[UIView alloc] init];
		self.bottomBorderView.backgroundColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeBorder];
		[self addSubview:self.bottomBorderView];
	}
	return self;
}

- (void)layoutSubviews {
	[super layoutSubviews];
	
	[self.headerLabel sizeToFit];
	self.headerLabel.frame = CGRectMake(MONDimensionsSmallPadding,
										-HeaderLabelOffset,
										CGRectGetWidth(self.headerLabel.frame),
										CGRectGetHeight(self.headerLabel.frame));
	
	if (self.numberOfItemsShown) {
		[self.itemCountView sizeToFit];
		self.itemCountView.frame = CGRectMake(CGRectGetMaxX(self.headerLabel.frame) + ItemCountViewLeftMargin,
											  0.0,
											  CGRectGetWidth(self.itemCountView.frame),
											  CGRectGetHeight(self.itemCountView.frame));
	}
	
	if (self.rightButtons) {
		CGFloat buttonOffset = 0.0;
		NSArray *reversedRightButtonsArray = [[self.rightButtons reverseObjectEnumerator] allObjects];
		for (UIButton *button in reversedRightButtonsArray) {
			[self addSubview:button];
			[button sizeToFit];
			button.frame = CGRectMake(CGRectGetMaxX(self.bounds) - CGRectGetWidth(button.frame) - MONDimensionsSmallPadding - buttonOffset,
									  0.0,
									  CGRectGetWidth(button.frame),
									  CGRectGetHeight(button.frame));
			buttonOffset += CGRectGetWidth(button.frame) + MONDimensionsSmallPadding;
		}
	}
	
    if (self.leftButtons) {
        CGFloat buttonOffset = 0.0;
        NSArray *reversedLeftButtonsArray = [[self.leftButtons reverseObjectEnumerator] allObjects];
        for (UIButton *button in reversedLeftButtonsArray) {
            [self addSubview:button];
            [button sizeToFit];
            button.frame = CGRectMake(self.headerLabel.frame.size.width + MONDimensionsSmallPadding + buttonOffset,
                                      0.0,
                                      CGRectGetWidth(button.frame),
                                      CGRectGetHeight(button.frame));
            buttonOffset += CGRectGetWidth(button.frame) + MONDimensionsSmallPadding;
        }
    }
    
	self.bottomBorderView.frame = CGRectMake(MONUIScreenRoundToScreenScale(MONDimensionsSmallPadding / 2.0),
											 CGRectGetMaxY(self.bounds) - MONDimensionsThinBorderWidth,
											 CGRectGetWidth(self.bounds) - MONDimensionsSmallPadding,
											 MONDimensionsThinBorderWidth);
}

- (void)setFont:(UIFont*)font {
	self.headerLabel.font = font;
}

- (void)showBottomBorder:(BOOL)showBottomBorder {
	self.bottomBorderView.hidden = showBottomBorder;
}

- (void)showNumberOfItems:(BOOL)showNumberOfItems {
	self.numberOfItemsShown = showNumberOfItems;
}

- (CGSize)sizeThatFits:(CGSize)size {
	CGSize sizeThatFits = size;
	[self.headerLabel sizeToFit];
	
	sizeThatFits.height = CGRectGetHeight(self.headerLabel.frame) - 2.0 * HeaderLabelOffset;
	sizeThatFits.height += MONDimensionsLargePadding;
	
	return sizeThatFits;
}

- (void)setTitle:(NSString *)title {
	self.headerLabel.text = [title uppercaseString];
}

- (void)setNumberOfItems:(NSUInteger)numberOfItems {
	[self.itemCountView setNumberOfItems:numberOfItems];
	[self setNeedsLayout];
}

- (void)setRightButtons:(NSArray *)rightButtons {
	_rightButtons = rightButtons;
	[self setButtons:rightButtons];
}


- (void)setLeftButtons:(NSArray *)leftButtons {
    _leftButtons = leftButtons;
    [self setButtons:leftButtons];
}

- (void)setButtons:(NSArray *)buttons {
    for (UIButton *button in buttons) {
        [self addSubview:button];
    }
    [self setNeedsLayout];
}

@end
