#import "MONLoginView.h"
#import "MONButton.h"
#import "MONFonts.h"
#import "MONLabel.h"
#import "MONDimensions.h"
#import "MONBlocker.h"
#import "MONColors.h"

static const CGFloat ContentHorizontalPadding = 50.0;
static const CGFloat ContentVerticalPadding = 60.0;
static const CGFloat TitleFontSize = 60.0;
static const CGFloat TextFieldWidth = 375.0;
static const CGFloat TextFieldHeight = 40.0;
static const CGFloat UsernameTextFieldOriginYOffset = 2.0;

@interface MONLoginView ()<ESCObservableInternal, UITextFieldDelegate>

@property (nonatomic) MONLabel *trialLabel;
@property (nonatomic) MONLabel *managementLabel;
@property (nonatomic) UITextField *usernameTextField;
@property (nonatomic) UITextField *passwordTextField;
@property (nonatomic) MONButton *loginButton;
@property (nonatomic) UILabel *loginErrorLabel;
@property (nonatomic) MONBlocker *blocker;

@end

@implementation MONLoginView

- (id)initWithFrame:(CGRect)frame {
	self = [super initWithFrame:frame];
	if (self) {
		[self escRegisterObserverProtocol:@protocol(MONLoginViewObserver)];
		
		self.trialLabel = [[MONLabel alloc] init];
		self.trialLabel.text = @"TRIAL";
		self.trialLabel.textColor = [MONColors boneColor];
		self.trialLabel.font = [UIFont fontWithName:RobotoThin size:TitleFontSize];
		[self addSubview:self.trialLabel];
		
		self.managementLabel = [[MONLabel alloc] init];
		self.managementLabel.text = @"MANAGEMENT";
		self.managementLabel.textColor = [MONColors boneColor];
		self.managementLabel.font = [UIFont fontWithName:RobotoBold size:TitleFontSize];
		[self addSubview:self.managementLabel];
		
		self.usernameTextField = [self defaultTextFieldWithPlaceholderText:@"Username"];
		self.usernameTextField.autocapitalizationType = UITextAutocapitalizationTypeNone;
		self.usernameTextField.keyboardType = UIKeyboardTypeEmailAddress;
		self.usernameTextField.delegate = self;
		[self.usernameTextField addTarget:self action:@selector(usernameTextFieldChanged) forControlEvents:UIControlEventEditingChanged];
		[self addSubview:self.usernameTextField];
		
		self.passwordTextField = [self defaultTextFieldWithPlaceholderText:@"Password"];
		self.passwordTextField.secureTextEntry = YES;
		self.passwordTextField.delegate = self;
		[self.passwordTextField addTarget:self action:@selector(passwordTextFieldChanged) forControlEvents:UIControlEventEditingChanged];
		[self addSubview:self.passwordTextField];
		
		self.loginButton = [[MONButton alloc] init];
		[self.loginButton setTitle:@"SIGN IN" forState:UIControlStateNormal];
		[self.loginButton addTarget:self action:@selector(loginButtonTapped) forControlEvents:UIControlEventTouchUpInside];
		[self addSubview:self.loginButton];
		
		self.loginErrorLabel = [[UILabel alloc] init];
		self.loginErrorLabel.textColor = [UIColor redColor];
		self.loginErrorLabel.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.8];
		self.loginErrorLabel.text = @"Login Failed";
		self.loginErrorLabel.numberOfLines = 0;
		self.loginErrorLabel.alpha = 0.0;
		self.loginErrorLabel.layer.cornerRadius = MONDimensionsCornerRadius;
		[self addSubview:self.loginErrorLabel];
	}
	return self;
}

- (UITextField *)defaultTextFieldWithPlaceholderText:(NSString *)placeholderText {
	UITextField *textField = [[UITextField alloc] init];
	textField.backgroundColor = [UIColor whiteColor];
	textField.font = [UIFont fontWithName:OpenSans size:20.0];
	textField.placeholder = placeholderText;
	textField.autocorrectionType = UITextAutocorrectionTypeNo;
	textField.layer.cornerRadius = MONDimensionsCornerRadius;
	textField.layer.sublayerTransform = CATransform3DMakeTranslation(10.0, 0.0, 0.0);
	textField.alpha = 0.9;
	return textField;
}

- (void)layoutSubviews {
	[super layoutSubviews];
	
	[self.trialLabel sizeToFit];
	self.trialLabel.frame = CGRectMake(ContentHorizontalPadding, ContentVerticalPadding, CGRectGetWidth(self.trialLabel.frame), CGRectGetHeight(self.trialLabel.frame));

	[self.managementLabel sizeToFit];
	self.managementLabel.frame = CGRectMake(CGRectGetMaxX(self.trialLabel.frame) + MONDimensionsLargePadding,
											ContentVerticalPadding,
											CGRectGetWidth(self.managementLabel.frame),
											CGRectGetHeight(self.managementLabel.frame));
	
	self.usernameTextField.frame = CGRectMake(ContentHorizontalPadding,
											  CGRectGetMaxY(self.trialLabel.frame) - UsernameTextFieldOriginYOffset,
											  TextFieldWidth,
											  TextFieldHeight);
	
	self.passwordTextField.frame = CGRectMake(ContentHorizontalPadding,
											  CGRectGetMaxY(self.usernameTextField.frame) + MONDimensionsSmallPadding,
											  TextFieldWidth,
											  TextFieldHeight);
	
	[self.loginButton sizeToFit];
	self.loginButton.frame = CGRectMake(CGRectGetMaxX(self.passwordTextField.frame) - CGRectGetWidth(self.loginButton.frame),
										CGRectGetMaxY(self.passwordTextField.frame) + MONDimensionsSmallPadding,
										CGRectGetWidth(self.loginButton.frame),
										CGRectGetHeight(self.loginButton.frame));
	
	[self.loginErrorLabel sizeToFit];
	self.loginErrorLabel.frame = CGRectMake(CGRectGetMinX(self.usernameTextField.frame),
											CGRectGetMaxY(self.loginButton.frame) + MONDimensionsSmallPadding,
											CGRectGetWidth(self.bounds) - 2.0 * ContentHorizontalPadding,
											CGRectGetHeight(self.loginErrorLabel.frame));
}


- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [super touchesBegan:touches withEvent:event];
    [self.usernameTextField endEditing:YES];
    [self.passwordTextField endEditing:YES];
}

- (void)usernameTextFieldChanged {
	[self.escNotifier usernameTextDidChange:self.usernameTextField.text];
	[self showLoginError:NO];
}

- (void)passwordTextFieldChanged {
	[self.escNotifier passwordTextDidChange:self.passwordTextField.text];
	[self showLoginError:NO];
}

- (void)loginButtonTapped {
	// for inducing crashes on demand
	if([@"crashthisapp" isEqualToString:self.usernameTextField.text]) {
		[(NSArray*)@(0) lastObject];
	}
	
    [self showBlocker];
	[self.escNotifier loginButtonTapped];
}

- (void)showBlocker {
    [[MONBlocker sharedInstance] showBlockerWithText:@"Signing In" forView:self];
}

- (void)hideBlocker {
    [[MONBlocker sharedInstance] hideBlocker];
}

- (void)showLoginError:(BOOL)showLoginError {
	self.loginErrorLabel.alpha = showLoginError ? 1.0 : 0.0;
}

- (void)setLoginErrorText:(NSString *)errorText {
	self.loginErrorLabel.text = errorText;
	[self setNeedsLayout];
}

#pragma mark - UITextFieldDelegate

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    if (textField == self.usernameTextField) {
        [self.passwordTextField becomeFirstResponder];
    } else {
        if ([self.usernameTextField.text length] == 0) {
            [self.usernameTextField becomeFirstResponder];
        } else if ([self.passwordTextField.text length] > 0) {
			[self loginButtonTapped];
        } else {
			[self.usernameTextField becomeFirstResponder];
		}
    }
	[textField resignFirstResponder];
    return YES;
}
@end
