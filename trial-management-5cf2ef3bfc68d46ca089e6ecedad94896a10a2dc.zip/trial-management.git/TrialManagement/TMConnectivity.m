#import "TMConnectivity.h"

NSString *const PingServicePath = @"Ping/default";

@interface TMConnectivity()

@property (nonatomic) TMNetworkService *networkService;

@end

@implementation TMConnectivity

-(instancetype)init {
	return [self initWithNetworkService:[[TMNetworkService alloc]init]];
}

-(instancetype)initWithNetworkService:(TMNetworkService*)service {
    self = [super init];
    if (self) {
        self.networkService = service;
    }
    return self;
}
-(void)isServiceReachableWithCompletionBlock:(void(^)(BOOL))completionBlock {
    [self.networkService getFromPath:PingServicePath completion:^(NSArray *data, NSError *error) {
        if (error) {
            completionBlock(NO);
        } else {
            completionBlock(YES);
        }
    }];
}

@end
