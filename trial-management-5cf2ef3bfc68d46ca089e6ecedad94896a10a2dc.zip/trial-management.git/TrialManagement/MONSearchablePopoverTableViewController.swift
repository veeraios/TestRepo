import UIKit

@objc protocol MONSearchablePopoverDelegate: class {
    func didSelectFilterdRowForModel(modelIndex: Int)
}

class MONSearchablePopoverTableViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, UISearchBarDelegate, MONFilterModelObserver {
    
    weak var delegate: MONSearchablePopoverDelegate?
    
    private let PopoverWidthOffset: CGFloat = 13.0
    private let CellReuseIdentifier = "MONSearchablePopoverTableViewCell"
    
    private let dataModel: TMReferenceDataFilterListModel
    private let filterModel: MONFilterModel
    
    private let searchBar: UISearchBar
    private let tableView: UITableView
    
    init(model: TMReferenceDataFilterListModel, filter: MONFilter, placeholderText: String) {
        dataModel = model
        filterModel = MONFilterModel(filter: filter)
        filterModel.setAllItemsArray(model.dataArray())
        
        searchBar = UISearchBar()
        searchBar.placeholder = placeholderText
        
        tableView = UITableView()
        tableView.registerClass(UITableViewCell.self, forCellReuseIdentifier: CellReuseIdentifier)
        
        super.init(nibName: nil, bundle: nil)
    }

    required init(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        filterModel.escAddObserver(self)
        searchBar.searchBarStyle = UISearchBarStyle.Minimal
        searchBar.delegate = self
        
        tableView.dataSource = self
        tableView.delegate = self
        
        view.addSubview(searchBar)
        view.addSubview(tableView)
    }

    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        
        searchBar.sizeToFit()
        searchBar.backgroundColor = UIColor.whiteColor()
        searchBar.frame = CGRectMake(0, 0, CGRectGetWidth(view.bounds) - PopoverWidthOffset, CGRectGetHeight(searchBar.bounds))
    
        tableView.sizeToFit()
        tableView.frame = CGRectMake(0, CGRectGetMaxY(searchBar.frame), CGRectGetWidth(view.bounds), CGRectGetHeight(view.bounds) - CGRectGetHeight(searchBar.bounds))
    }
    
    func filterUpdated() {
        tableView.reloadData()
    }
    
    func searchBar(searchBar: UISearchBar, textDidChange searchText: String) {
        filterModel.filterItemsWithText(searchText)
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        if let selectionDelegate = delegate {
            if let cellItem = filterModel.filteredItemAtIndex(indexPath.row) as? NSObject {
                let modelIndex = dataModel.indexForItem(cellItem)
                modelIndex != NSNotFound ? selectionDelegate.didSelectFilterdRowForModel(modelIndex) : MONLogger.logError("Value not found on model")
            }
        }
        tableView.deselectRowAtIndexPath(indexPath, animated: true)
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 50.0
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filterModel.filteredItems() != nil ? filterModel.filteredItems().count : 0
    }

    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        if let cell = tableView.dequeueReusableCellWithIdentifier(CellReuseIdentifier) as? UITableViewCell {
            if let cellItem = filterModel.filteredItemAtIndex(indexPath.row) as? NSObject {
                cell.textLabel?.text = dataModel.nameForItem(cellItem)
            }
            return cell
        }
        return UITableViewCell()
    }
    

}
