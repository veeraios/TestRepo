//
//  TMDealer.h
//  TrialManagement
//
//  Created by Jason Ludwig on 6/17/14.
//  Copyright (c) 2014 Monsanto. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class TMTrial, TMUser;

@interface TMDealer : NSManagedObject

@property (nonatomic, retain) NSString * accountId;
@property (nonatomic, retain) NSString * address1;
@property (nonatomic, retain) NSString * address2;
@property (nonatomic, retain) NSString * category;
@property (nonatomic, retain) NSString * city;
@property (nonatomic, retain) NSString * country;
@property (nonatomic, retain) NSNumber * dealerId;
@property (nonatomic, retain) NSString * email;
@property (nonatomic, retain) NSString * faxNumber;
@property (nonatomic, retain) NSString * name;
@property (nonatomic, retain) NSString * phoneNumber;
@property (nonatomic, retain) NSString * postalCode;
@property (nonatomic, retain) NSString * state;
@property (nonatomic, retain) NSSet *trials;
@property (nonatomic, retain) NSSet *users;
@end

@interface TMDealer (CoreDataGeneratedAccessors)

- (void)addTrialsObject:(TMTrial *)value;
- (void)removeTrialsObject:(TMTrial *)value;
- (void)addTrials:(NSSet *)values;
- (void)removeTrials:(NSSet *)values;

- (void)addUsersObject:(TMUser *)value;
- (void)removeUsersObject:(TMUser *)value;
- (void)addUsers:(NSSet *)values;
- (void)removeUsers:(NSSet *)values;

@end
