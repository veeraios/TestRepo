#import "TMDataSyncCoordinator.h"
#import "TMDataReferenceSync.h"
#import "TMDeltaSyncManager.h"
#import "TMPendingQueueDataSync.h"
#import "TMConnectivity.h"
#import "TMRetryMechanism.h"
#import "TrialManagement-Swift.h"

NSString * const SyncTechAgronomists = @"Tech Agronomists";
NSString * const SyncBrands = @"Brands";
NSString * const SyncPlotTypes = @"Plot Types";
NSString * const SyncCrops = @"Crops";
NSString * const SyncPreviousCrops = @"Previous Crops";
NSString * const SyncSoilTypes = @"Soil Types";
NSString * const SyncTillageMethods = @"Tillage Methods";
NSString * const SyncTiles = @"Tiles";
NSString * const SyncTreatments = @"Treatments";
NSString * const SyncStates = @"States";
NSString * const SyncGrowersAndDealers = @"Growers & Dealers";
NSString * const SyncProducts = @"Products";
NSString * const SyncTrials = @"Trials";
NSString * const SyncSignatureImages = @"Signature Images";
NSString * const SyncProtocols = @"Protocols";
NSString * const SyncObservationReferenceData = @"Observations";
NSString * const SyncTraits = @"Traits";
NSString * const SyncObservationCalculationDetails = @"Observation Calculation Data";
NSString * const SyncReportReferenceData = @"Report Constants";

NSString * const PostNewRequestedProducts = @"New Requested Products";
NSString * const PostTrialUpdates = @"Trial Updates";
NSString * const PostNewSignatureImages = @"New Signature Images";
NSString * const PostTrialRelinquish = @"Relinquish Trials";
NSString * const PostTrialSubmitToMarketing = @"Submit Trials to Marketing";
NSString * const PostTrialCancel = @"Cancel Trials";

NSString * const DataSyncStarted = @"DataSyncStarted";
NSString * const DataSyncProgress = @"DataSyncProgress";
NSString * const DataSyncCompleted = @"DataSyncCompleted";
NSString * const DataSyncFailed = @"DataSyncFailed";
NSString * const NetworkInaccessible = @"NetworkInaccessible";

NSUInteger const DefaultBatchSize = 1000;
NSUInteger const DefaultThresholdHours = 5;

@interface TMDataSyncCoordinator()

@property (nonatomic) TMDataReferenceSync *dataReferenceSync;
@property (nonatomic) TMDeltaSyncManager *deltaSyncManager;
@property (nonatomic) TMPendingQueueDataSync *pendingQueueDataSync;
@property (nonatomic) TMConnectivity *connectivity;
@property (nonatomic) TMRetryMechanism *retryMechanism;
@property (nonatomic) NSArray *fullSyncStatusHierarchy;
@property (nonatomic) NSArray *deltaSyncStatusHierarchy;
@property (nonatomic) NSArray *upgradeSyncStatusHierarchy;
@property (nonatomic) NSMutableDictionary *dataTypeToBlocksDictionary;
@property (nonatomic) NSArray *defaultThresholdItems;
@property (nonatomic) NSInteger currentSyncStage;
@property (nonatomic) BOOL fullSync;
@property (nonatomic) BOOL thresholdItemsSynced;

@property (nonatomic, weak) void (^completionHandler)(UIBackgroundFetchResult);

@end

@implementation TMDataSyncCoordinator

- (instancetype)initWithDataReferenceSync:(TMDataReferenceSync *)dataReferenceSync
		deltaSyncManager:(TMDeltaSyncManager *)deltaSyncManager
	pendingQueueDataSync:(TMPendingQueueDataSync *)pendingQueueDataSync
			connectivity: (TMConnectivity *)connectivity {
	
	self = [super init];
	if (self) {
		self.dataReferenceSync = dataReferenceSync;
		self.dataReferenceSync.delegate = self;
		self.deltaSyncManager = deltaSyncManager;
		self.pendingQueueDataSync = pendingQueueDataSync;
		self.pendingQueueDataSync.delegate = self;
		self.connectivity = connectivity;
		
		self.fullSyncStatusHierarchy = @[[NSMutableDictionary dictionaryWithDictionary:@{SyncTiles:@NO}],
									 [NSMutableDictionary dictionaryWithDictionary:@{SyncBrands:@NO, SyncPlotTypes:@NO, SyncPreviousCrops:@NO,
																					 SyncSoilTypes:@NO, SyncTillageMethods:@NO, SyncCrops:@NO, SyncStates:@NO}],
                                     [NSMutableDictionary dictionaryWithDictionary:@{SyncTechAgronomists:@NO,
                                                                                     SyncGrowersAndDealers:@NO,
																					 SyncProducts:@NO,
																					 SyncProtocols:@NO,
																					 SyncObservationReferenceData:@NO,
                                                                                     SyncTraits:@NO,
                                                                                     SyncTreatments:@NO,
                                                                                     SyncReportReferenceData:@NO}],
									 [NSMutableDictionary dictionaryWithDictionary:@{SyncObservationCalculationDetails:@NO}],
									 [NSMutableDictionary dictionaryWithDictionary:@{SyncTrials:@NO}],
									 [NSMutableDictionary dictionaryWithDictionary:@{SyncSignatureImages:@NO}],
									 [NSMutableDictionary dictionaryWithDictionary:@{PostNewRequestedProducts:@NO}],
									 [NSMutableDictionary dictionaryWithDictionary:@{PostTrialUpdates:@NO}],
									 [NSMutableDictionary dictionaryWithDictionary:@{PostNewSignatureImages:@NO}],
									 [NSMutableDictionary dictionaryWithDictionary:@{PostTrialRelinquish:@NO}],
                                     [NSMutableDictionary dictionaryWithDictionary:@{PostTrialSubmitToMarketing:@NO}],
                                     [NSMutableDictionary dictionaryWithDictionary:@{PostTrialCancel:@NO}]];
        
        self.deltaSyncStatusHierarchy = @[[NSMutableDictionary dictionaryWithDictionary:@{SyncTreatments:@NO}],
                                          [NSMutableDictionary dictionaryWithDictionary:@{SyncTechAgronomists:@NO,
                                                                                          SyncGrowersAndDealers:@NO,
                                                                                          SyncProducts:@NO}],
                                          [NSMutableDictionary dictionaryWithDictionary:@{SyncTrials:@NO}],
                                          [NSMutableDictionary dictionaryWithDictionary:@{SyncSignatureImages:@NO}],
                                          [NSMutableDictionary dictionaryWithDictionary:@{PostNewRequestedProducts:@NO}],
                                          [NSMutableDictionary dictionaryWithDictionary:@{PostTrialUpdates:@NO}],
                                          [NSMutableDictionary dictionaryWithDictionary:@{PostNewSignatureImages:@NO}],
                                          [NSMutableDictionary dictionaryWithDictionary:@{PostTrialRelinquish:@NO}],
                                          [NSMutableDictionary dictionaryWithDictionary:@{PostTrialSubmitToMarketing:@NO}],
                                          [NSMutableDictionary dictionaryWithDictionary:@{PostTrialCancel:@NO}]];
        
        self.upgradeSyncStatusHierarchy = [self buildUpgradeSyncStatusHierarchy];
        
        self.defaultThresholdItems = @[SyncTiles, SyncTechAgronomists, SyncBrands, SyncPlotTypes, SyncPreviousCrops, SyncSoilTypes, SyncTillageMethods,
                                       SyncCrops, SyncTreatments, SyncStates, SyncGrowersAndDealers, SyncProducts, SyncProtocols, SyncTraits,
                                       SyncObservationCalculationDetails, SyncTrials, SyncSignatureImages, SyncObservationReferenceData, SyncReportReferenceData];
	}
	return self;
}

- (instancetype)init {
	self = [self initWithDataReferenceSync:[[TMDataReferenceSync alloc ]init]
						  deltaSyncManager:[[TMDeltaSyncManager alloc ]init]
					  pendingQueueDataSync:[[TMPendingQueueDataSync alloc] init]
							  connectivity:[[TMConnectivity alloc]init] ];
	return self;
}

-(void)syncAllData {
	self.fullSync = YES;
    [self startSyncIfNetworkAccessible];
}

-(void)syncAllDataWithTimeChecks:(void (^)(UIBackgroundFetchResult))completionHandler {
    self.completionHandler = completionHandler;
    
    self.fullSync = [self.deltaSyncManager isFirstTimeSync];
    if (self.fullSync || [self shouldDeltaSync] || [self.deltaSyncManager shouldForceSyncForUpgrade]) {
        [self startSyncIfNetworkAccessible];
    } else {
        [self.delegate dataSyncCompleted];
        if (completionHandler) {
            completionHandler(UIBackgroundFetchResultNoData);
        }
    }
}

-(BOOL)shouldDeltaSync {
    return [self.pendingQueueDataSync hasItemsToSync] || [self.deltaSyncManager shouldSyncWithThreshold:DefaultThresholdHours];
}

-(NSArray *)buildUpgradeSyncStatusHierarchy {
    NSMutableArray *upgradeStatusHierarchy = [NSMutableArray array];
    NSSet *upgradeReferenceCalls = [self.deltaSyncManager retreiveForceSyncReferenceCalls];
    
    for (NSDictionary *schedule in self.fullSyncStatusHierarchy) {
        NSMutableDictionary *upgradeSchedule = [NSMutableDictionary dictionary];
        for (NSString *refCall in [schedule allKeys]) {
            if ([upgradeReferenceCalls containsObject:refCall]) {
                [upgradeSchedule addEntriesFromDictionary:@{refCall:@NO}];
            }
        }
        if (upgradeSchedule.count != 0) {
            [upgradeStatusHierarchy addObject:upgradeSchedule];
        }
    }
    
    return upgradeStatusHierarchy;
}

-(NSArray *)syncStatusHierarchy {
    if (self.fullSync) {
        return self.fullSyncStatusHierarchy;
    } else if ([self.deltaSyncManager shouldForceSyncForUpgrade]) {
        return self.upgradeSyncStatusHierarchy;
    } else {
        return self.deltaSyncStatusHierarchy;
    }
}

-(void)startSyncIfNetworkAccessible {
    [self.delegate dataSyncStarted];
    
    [self.connectivity isServiceReachableWithCompletionBlock:^(BOOL result) {
        if (result) {
            if ([self.deltaSyncManager isFirstTimeSync]) {
                [MONAnalytics logEvent:[MONAnalytics EventFullSync] timed:YES];
            } else if (self.fullSync) {
                [MONAnalytics logEvent:[MONAnalytics EventButtonSync] timed:YES];
            } else {
                [MONAnalytics logEvent:[MONAnalytics EventDeltaSync] timed:YES];
            }
            [self startSync];
        } else  {
            [self.delegate networkInaccessible];
        }
    }];
}

-(void)buildServiceBlocksDictionary {
    __weak TMDataSyncCoordinator *weakSelf = self;
    self.dataTypeToBlocksDictionary = [[NSMutableDictionary alloc] initWithDictionary:@{SyncTiles: ^{[_dataReferenceSync syncTiles];},
                                                                                        SyncTechAgronomists: ^{[_dataReferenceSync syncTechAgronomists];},
                                                                                        SyncBrands: ^{[_dataReferenceSync syncBrands];},
                                                                                        SyncPlotTypes: ^{[weakSelf.dataReferenceSync syncPlotTypes];},
                                                                                        SyncPreviousCrops: ^{[weakSelf.dataReferenceSync syncPreviousCrops];},
                                                                                        SyncSoilTypes: ^{[weakSelf.dataReferenceSync syncSoilTypes];},
                                                                                        SyncTillageMethods: ^{[weakSelf.dataReferenceSync syncTillageMethods];},
                                                                                        SyncCrops: ^{[weakSelf.dataReferenceSync syncCrops];},
                                                                                        SyncTreatments: ^{[weakSelf.dataReferenceSync syncTreatments];},
                                                                                        SyncStates: ^{[weakSelf.dataReferenceSync syncStates];},
                                                                                        SyncGrowersAndDealers: ^{[weakSelf.dataReferenceSync syncGrowersAndDealersFromDate:[weakSelf syncIntervalForRefData:SyncGrowersAndDealers]];},
                                                                                        SyncProducts: ^{[weakSelf.dataReferenceSync syncProductsFromDate:[weakSelf syncIntervalForRefData:SyncProducts]];},
                                                                                        SyncProtocols: ^{[weakSelf.dataReferenceSync syncProtocols];},
                                                                                        SyncObservationReferenceData: ^{[weakSelf.dataReferenceSync syncObservationReferenceData];},
                                                                                        SyncTraits: ^{ [weakSelf.dataReferenceSync syncTraits]; },
                                                                                        SyncReportReferenceData: ^{ [weakSelf.dataReferenceSync syncReportReferenceData]; },
                                                                                        SyncObservationCalculationDetails: ^{[weakSelf.dataReferenceSync syncObservationCalculationDetails];},
                                                                                        SyncTrials: ^{ [weakSelf.dataReferenceSync syncTrialsFromDate:[weakSelf syncIntervalForRefData:SyncTrials] toDate:[weakSelf.deltaSyncManager trialsToDateTimeInterval] batchSize:DefaultBatchSize];},
                                                                                        SyncSignatureImages: ^{[weakSelf.dataReferenceSync syncSignatureImages];},
                                                                                        PostNewRequestedProducts: ^{ [weakSelf.pendingQueueDataSync syncPendingRequestedProducts];},
                                                                                        PostTrialUpdates: ^{[weakSelf.pendingQueueDataSync syncPendingTrialUpdates];},
                                                                                        PostNewSignatureImages: ^{[weakSelf.pendingQueueDataSync syncPendingGrowerSignatureImages];},
                                                                                        PostTrialRelinquish: ^{[weakSelf.pendingQueueDataSync syncPendingTrialRelinqish];},
                                                                                        PostTrialSubmitToMarketing: ^{[weakSelf.pendingQueueDataSync syncPendingTrialSubmitToMarketing];},
                                                                                        PostTrialCancel: ^{[weakSelf.pendingQueueDataSync syncPendingTrialCancel];}}];
    
    self.retryMechanism = [[TMRetryMechanism alloc]initWithDataTypeToBlocksDictionary:self.dataTypeToBlocksDictionary failureBlock:^(NSString *name) {
        [self.delegate dataSyncFailedForStage:name];
        if (self.completionHandler) {
            self.completionHandler(UIBackgroundFetchResultFailed);
        }
    }];
}

- (NSTimeInterval)syncIntervalForRefData:(NSString *)refData {
    NSTimeInterval fromDate = self.fullSync ? [self.deltaSyncManager fromDateTimeIntervalWithAWeekBack] : [self.deltaSyncManager fromDateTimeInterval];
    
    NSSet *forceRefCalls = [self.deltaSyncManager retreiveForceSyncReferenceCalls];
    return [forceRefCalls containsObject:refData] ? 0.0 : fromDate;
}

-(void)startSync {
    [self.dataReferenceSync prepareForSync];
	[self buildServiceBlocksDictionary];
	[self startStage:0];
}

-(void)startStage:(NSInteger)stage {
	self.currentSyncStage = stage;
	if (stage < [self numberOfStages]) {
		NSArray *keys = [[self syncStatusHierarchy][(NSUInteger) stage] allKeys];
        NSString *currentItems = [NSString stringWithFormat:@"Syncing %@", [keys componentsJoinedByString:@", "]];
        [self.delegate dataSyncStageUpdated:currentItems];
        
		for (NSString *key in keys) {
			[self startSyncFor:key];
		}
		[self startNextStageIfReady];
	} else {
		[self everythingCompleted];
	}
}

-(NSInteger)numberOfStages {
	return [[self syncStatusHierarchy] count];
}

-(NSInteger)lastStage {
	return [[self syncStatusHierarchy] count] - 1;
}

-(void)startSyncFor:(NSString *)name {
	if (self.fullSync || ![self.defaultThresholdItems containsObject:name] || [self.deltaSyncManager shouldSyncWithThreshold:DefaultThresholdHours] || [self.deltaSyncManager shouldForceSyncForUpgrade]) {
		DDLogInfo(@"|||||||SYNC STARTED FOR : %@||||", name);
		[self dictionaryForKey:name][name] = @YES;
		void(^block)(void) = self.dataTypeToBlocksDictionary[name];
		block();
        
        if ([self.defaultThresholdItems containsObject:name]) {
            self.thresholdItemsSynced = YES;
        }
	}
}

-(void)dataSyncCompletedFor:(NSString *)name {
	DDLogInfo(@"-------SYNC COMPLETED FOR REF: %@----", name);
	self.dataTypeToBlocksDictionary[name] = [NSNull null];
    [self.retryMechanism syncCompletedFor:name];
	if ([[[self syncStatusHierarchy][(NSUInteger) self.currentSyncStage] allKeys] containsObject:name]) {
		[self handleSyncCompletion:[self syncStatusHierarchy][(NSUInteger) self.currentSyncStage] name:name nextStage:self.currentSyncStage + 1];
	} else {
		[self handleSyncCompletion:[self syncStatusHierarchy][(NSUInteger) [self lastStage]] name:name nextStage:NSIntegerMax];
	}
}

-(void)startNextStageIfReady {
	if (self.currentSyncStage < [self lastStage] && [self allDataSynced:[self syncStatusHierarchy][(NSUInteger) self.currentSyncStage]]) {
		[self startStage:self.currentSyncStage + 1];
	} else if (self.currentSyncStage == [self lastStage] && [self allDataSynced:[self syncStatusHierarchy][(NSUInteger) [self lastStage]]]) {
		[self everythingCompleted];
	}
}

-(NSMutableDictionary *)dictionaryForKey:(NSString *)key {
    for (NSMutableDictionary *dictionary in [self syncStatusHierarchy]) {
        if ([[dictionary allKeys] containsObject:key]) {
            return dictionary;
        }
    }
    return nil;
}

-(void)everythingCompleted {
    if (self.thresholdItemsSynced) {
        if (![self.deltaSyncManager shouldForceSyncForUpgrade]) {
            [self.deltaSyncManager saveSyncTime:[NSDate date]];
        }
        [self.deltaSyncManager saveForceSyncReferenceCalls:[NSSet set]];
		[[TMNotifier sharedInstance] scheduleNotificationFromDate:self.deltaSyncManager.notificationFireDate];
    }
    self.thresholdItemsSynced = NO;
    DDLogInfo(@"**********EVERYTHING COMPLETED**********");
    [MONAnalytics endTimedEvent:[MONAnalytics EventFullSync] parameters:nil];
    [MONAnalytics endTimedEvent:[MONAnalytics EventButtonSync] parameters:nil];
    [MONAnalytics endTimedEvent:[MONAnalytics EventDeltaSync] parameters:nil];
    
    [self.delegate dataSyncCompleted];
    if (self.completionHandler) {
        self.completionHandler(UIBackgroundFetchResultNewData);
    }
}

-(void)dataSyncFailedFor:(NSString *)name {
	DDLogError(@"!!!!!!!!SYNC FAILED FOR : %@!!!!!!!", name);
    [self.retryMechanism syncFailedFor:name];
}

-(void)handleSyncCompletion:(NSMutableDictionary *)dictionary name:(NSString *)name nextStage:(NSInteger)stage{
	dictionary[name] = @NO;
	if ([self allDataSynced:dictionary]) {
		[self startStage:stage];
	}
}

-(BOOL)allDataSynced:(NSDictionary *)syncStatusDictionary {
	for (id value in [syncStatusDictionary allValues]) {
		if ([((NSNumber*)value) boolValue]) {
			return NO;
		}
	}
	return YES;
}

@end