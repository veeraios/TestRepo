#import "MONTitleTextFieldVerticalView.h"
#import "MONLabel.h"
#import "MONTextField.h"
#import "MONFonts.h"

static const CGFloat TitleLabelOffsetY = 4.0;
static const CGFloat TextFieldDefaultWidth = 180.0;
static const CGFloat TextFieldTopMargin = 5.0;

@interface MONTitleTextFieldVerticalView ()

@property (nonatomic) MONLabel *titleLabel;
@property (nonatomic) MONTextField *textField;

@end

@implementation MONTitleTextFieldVerticalView

- (id)initWithFrame:(CGRect)frame {
	self = [super initWithFrame:frame];
	if (self) {
		self.titleLabel = [[MONLabel alloc] init];
		self.titleLabel.fontName = OpenSansBold;
		[self addSubview:self.titleLabel];
		
		self.textField = [[MONTextField alloc] init];
		[self addSubview:self.textField];
	}
	return self;
}

- (void)layoutSubviews {
	[super layoutSubviews];
	[self.titleLabel sizeToFit];
	CGSize textFieldSize = [self.textField sizeThatFits:CGSizeMake(TextFieldDefaultWidth, CGFLOAT_MAX)];
	
	self.titleLabel.frame = CGRectMake(0.0, -TitleLabelOffsetY, CGRectGetWidth(self.bounds), CGRectGetHeight(self.titleLabel.frame));
	
	self.textField.frame = CGRectMake(0.0, CGRectGetMaxY(self.titleLabel.frame) + TextFieldTopMargin, TextFieldDefaultWidth, textFieldSize.height);
}

- (CGSize)sizeThatFits:(CGSize)size {
	CGSize sizeThatFits = CGSizeMake(size.width, 0.0);
	[self.titleLabel sizeToFit];
	CGSize textFieldSize = [self.textField sizeThatFits:CGSizeMake(TextFieldDefaultWidth, CGFLOAT_MAX)];
	
	sizeThatFits.height -= TitleLabelOffsetY;
	sizeThatFits.height += CGRectGetHeight(self.titleLabel.frame);
	sizeThatFits.height += TextFieldTopMargin;
	sizeThatFits.height += textFieldSize.height;
	
	return sizeThatFits;
}

- (void)setTitleText:(NSString *)titleText {
	self.titleLabel.text = titleText;
}

- (void)setTextFieldText:(NSString *)textFieldText {
	self.textField.text = textFieldText;
}

- (BOOL)becomeFirstResponder {
	return [self.textField becomeFirstResponder];
}

- (BOOL)resignFirstResponder {
	return [self.textField resignFirstResponder];
}

@end
