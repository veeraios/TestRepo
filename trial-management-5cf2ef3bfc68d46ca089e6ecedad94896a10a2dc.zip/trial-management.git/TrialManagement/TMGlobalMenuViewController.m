#import "TMGlobalMenuViewController.h"
#import <MessageUI/MessageUI.h>
#import "UIColor+MONThemeColorProvider.h"
#import "MONColors.h"
#import "TMTrialDataSync.h"
#import "TrialManagement-Swift.h"

@interface TMGlobalMenuViewController ()<MFMailComposeViewControllerDelegate, TMGlobalMenuViewDelegate>

@property (nonatomic) TMGlobalMenuView *globalMenuView;
@property (nonatomic) TMTrialModel *trialModel;
@property (nonatomic) TMGlobalMenuButtonType selectedGlobalMenuButtonType;

@end

@implementation TMGlobalMenuViewController

@synthesize tabSettingsObject = _tabSettingsObject;

- (instancetype)initWithTrialModel:(TMTrialModel *)trialModel {
	self = [super init];
	if (self) {
		self.trialModel = trialModel;
        
		[[NSNotificationCenter defaultCenter] removeObserver:self name:TrialWasUpdatedNotification object:nil];
		[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(trialStatusWasUpdated:) name:TrialWasUpdatedNotification object:nil];
	}
	return self;
}

- (void)dealloc {
	[[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)viewDidLoad {
	[super viewDidLoad];

	self.globalMenuView = [[TMGlobalMenuView alloc] initWithGlobalMenuModel:[[TMGlobalMenuModel alloc]initWithTrialModel:self.trialModel]];
	self.globalMenuView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
	self.globalMenuView.frame = self.view.bounds;
	self.globalMenuView.delegate = self;
	[self.globalMenuView setSelectedGlobalMenuButtonType:self.selectedGlobalMenuButtonType];
	[self.view addSubview:self.globalMenuView];
}

- (void)viewWillAppear:(BOOL)animated {
	[super viewWillAppear:animated];

	[self.globalMenuView enableDisableButtonsAsNeeded];
	[self showTrialInfoMessage];
}

- (void)viewDidAppear:(BOOL)animated {
	[super viewDidAppear:animated];

	[MONGoogleAnalytics trackView:@"Trial - Activities Menu"];
}

- (void)showTrialInfoMessage {
	if([self.trialModel hasRequiredTrialInfoFilledIn] == NO){
		[self.globalMenuView.headerTextField setHidden:NO];
		[self.globalMenuView.infoTextView setHidden:NO];
		[self.globalMenuView.infoTextView setText:[self.trialModel trialInfoMessages]];
	} else {
		[self.globalMenuView.headerTextField setHidden:YES];
		[self.globalMenuView.infoTextView setHidden:YES];
	}
}

- (void)trialStatusWasUpdated:(NSNotification *)notification {
	TMTrial *postedTrial = ((TMTrial*)notification.userInfo[@"trial"]);
	if(postedTrial && self.trialModel.trial && postedTrial == self.trialModel.trial) {
		[self.globalMenuView.trialInfoCardView setStatus:[self.trialModel status]];
		[self.globalMenuView.trialInfoCardView setTitle:[self.trialModel trialName]];
		[self.globalMenuView.trialInfoCardView setGrower: self.trialModel.growerName];
		[self.globalMenuView.trialInfoCardView setDistrictSalesManager:self.trialModel.salesManagerName];
		[self.globalMenuView.trialInfoCardView setCrop:self.trialModel.cropName];
		[self.globalMenuView.trialInfoCardView setPlotDescription:self.trialModel.plotTypeDescription];
	}
}

- (void)setupTrialButtonTapped {
	[self.delegate setupTrialButtonTapped];
}

- (void)harvestButtonTapped {
	[self.delegate harvestButtonTapped];
}

- (void)marketingButtonTapped {
	[self.delegate marketingButtonTapped];
}

- (void)observationsButtonTapped {
	[self.delegate observationsButtonTapped];
}

- (void)contactSupportButtonTapped {
	if ([MFMailComposeViewController canSendMail]) {
		MFMailComposeViewController *mailViewController = [[MFMailComposeViewController alloc] init];
		mailViewController.mailComposeDelegate = self;
		[mailViewController setToRecipients:@[@"technology.pipeline.support@monsanto.com"]];
		[mailViewController.navigationBar setTintColor:[UIColor colorForThemeComponentType:MONThemeComponentTypeNavigationBarText]];
		[self presentViewController:mailViewController animated:YES completion:nil];
	} else {
		UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Unable to compose email" message:@"You are unable to send an email to Support at this time. You may need to set up email on this iPad." delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
		[alertView show];
		DDLogError(@"Unable to send email.");
	}
}

- (void)closeButtonTapped {
	[self.delegate closeButtonTapped];
	[self showTrialInfoMessage];
}

#pragma mark - MFMailComposeViewControllerDelegate Methods

- (void)mailComposeController:(MFMailComposeViewController *)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError *)error {
	if (error || result == MFMailComposeResultFailed) {
		DDLogError(@"Problem sending email to support. Error: %@", error);
	}
	[self dismissViewControllerAnimated:YES completion:nil];
}

@end
