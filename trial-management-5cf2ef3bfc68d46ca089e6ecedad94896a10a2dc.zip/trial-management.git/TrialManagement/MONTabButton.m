#import "MONTabButton.h"
#import "MONFonts.h"
#import "UIColor+MONThemeColorProvider.h"

static const CGFloat DefaultButtonWidth = 110.0;
static const CGFloat DefaultButtonHeight = 55.0;

@implementation MONTabButton

- (id)initWithFrame:(CGRect)frame {
	self = [super initWithFrame:frame];
	if (self) {
		self.backgroundColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeTabButtonBackground];
		self.titleLabel.font = [UIFont fontWithName:OpenSansSemibold size:12.0];
		self.titleLabel.lineBreakMode = NSLineBreakByWordWrapping;
		self.titleLabel.textAlignment = NSTextAlignmentCenter;
	}
	return self;
}

- (void)layoutSubviews {
	[super layoutSubviews];
	
	// Expand the titleLabel's frame to allow for multi-line
//	self.titleLabel.frame = CGRectInset(self.titleLabel.frame, 10.0, -10.0);
	self.titleLabel.frame = self.bounds;
}

- (CGSize)sizeThatFits:(CGSize)size {
	CGSize sizeThatFits = CGSizeMake(DefaultButtonWidth, DefaultButtonHeight);
	return sizeThatFits;
}

- (void)setSelected:(BOOL)selected {
	if (selected) {
		self.backgroundColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeSelectedTabButtonBackground];
	} else {
		self.backgroundColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeTabButtonBackground];
	}
}

@end
