#import <UIKit/UIKit.h>

@interface TMCoordinatesButton : UIButton

@end
