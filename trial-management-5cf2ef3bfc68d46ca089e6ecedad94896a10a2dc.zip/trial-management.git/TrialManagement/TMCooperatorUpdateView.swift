
protocol TMCooperatorUpdateViewDelegate {
    func updatedInformation(name: String, accountId: String, email: String, phone: String, address1: String, address2: String, city: String, zip: String)
    func selectedState(state: AnyObject)
}

class TMCooperatorUpdateView: UIView, MONPopoverTextFieldDelegate, MONLabeledTextFieldDelegate {
    var delegate: TMCooperatorUpdateViewDelegate?
    
    private var activeTextField: MONLabeledTextField?
    
    private let scrollView: UIScrollView
    private let title: String
    private let statesPopover: MONSearchableLabeledPopoverButton
    private let cooperatorInformationLabel: MONLabel

    private let nameField          = MONLabeledTextField()
    private let accountIdField     = MONLabeledTextField()
    private let emailField         = MONLabeledTextField()
    private let addressField       = MONLabeledTextField()
    private let secondAddressField = MONLabeledTextField()
    private let phoneField         = MONLabeledTextField()
    private let cityField          = MONLabeledTextField()
    private let zipField           = MONLabeledTextField()
    
    
    init(title: String, statesPopover: MONSearchableLabeledPopoverButton, addressRequired: Bool, validationRequired: Bool, operation:CooperatorOperation) {
        self.title = title
        scrollView = UIScrollView()
        scrollView.scrollEnabled = false
        scrollView.bounces = false
        
        cooperatorInformationLabel = MONLabel()
        cooperatorInformationLabel.text = operation == .Update ? "UPDATE \(self.title.uppercaseString) INFORMATION" : "ADD \(self.title.uppercaseString) INFORMATION"
        cooperatorInformationLabel.font = UIFont(name: OpenSansLight, size:24)
        
        self.statesPopover = statesPopover
        self.statesPopover.label.text = validationRequired ? "State*" : "State"
        self.statesPopover.label.textAlignment = .Right
        self.statesPopover.labelLocation = .Left
        
        super.init(frame:CGRectZero)
        
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "keyboardWillShow:", name: UIKeyboardWillShowNotification, object: nil)
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "keyboardWillHide:", name: UIKeyboardWillHideNotification, object: nil)
        
        let nameLabel       = title == "Grower" ? "Grower*" : "Dealer*"
        let accountIdLabel  = title == "Grower" ? "Grower Account (MTSA)" : "Dealer Account Id"
        let addressLabel    = addressRequired && validationRequired ? "Address (Line 1)*" : "Address (Line 1)"
        let cityLabel       = validationRequired ? "City*" : "City"
        let zipLabel        = validationRequired ? "Zip Code*" : "Zip Code"
        
        nameField           = labeledTextField(nameLabel, placeholderText: "\(self.title) Name")
        accountIdField      = labeledTextField(accountIdLabel, placeholderText: "Account ID")
        emailField          = labeledTextField("Email", placeholderText: "example@e.com")
        phoneField          = labeledTextField("Phone", placeholderText: "(000)000-0000")
        addressField        = labeledTextField(addressLabel, placeholderText: "Address (Line 1)")
        secondAddressField  = labeledTextField("Address (Line 2)", placeholderText: "Address (Line 2)")
        cityField           = labeledTextField(cityLabel, placeholderText: "City Name")
        zipField            = labeledTextField(zipLabel, placeholderText: "Enter zip (5 digits)")
        
        phoneField.setKeyboardType(.DecimalPad)
        zipField.setKeyboardType(.DecimalPad)
        zipField.allowOnlyNumbers(true)

        self.statesPopover.popoverDelegate = self;
        self.statesPopover.labelLocation = .Top
        self.statesPopover.label.textAlignment = .Left
        
        backgroundColor = UIColor(forThemeComponentType: MONThemeComponentTypeBackground)
        
        addSubview(scrollView)
        scrollView.addSubview(cooperatorInformationLabel)
        scrollView.addSubview(nameField)
        scrollView.addSubview(accountIdField)
        scrollView.addSubview(emailField)
        scrollView.addSubview(phoneField)
        scrollView.addSubview(addressField)
        scrollView.addSubview(secondAddressField)
        scrollView.addSubview(cityField)
        scrollView.addSubview(zipField)
        scrollView.addSubview(self.statesPopover)
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        let contentRect = UIEdgeInsetsInsetRect(bounds, UIEdgeInsetsMake(MONDimensionsLargePadding, MONDimensionsSmallPadding, MONDimensionsSmallPadding, MONDimensionsSmallPadding));
        scrollView.frame = bounds
        
        cooperatorInformationLabel.sizeToFit()
        cooperatorInformationLabel.frame = CGRectMake(CGRectGetMinX(contentRect),
            CGRectGetMinY(contentRect) + MONDimensionsLargePadding,
            CGRectGetWidth(cooperatorInformationLabel.frame),
            CGRectGetHeight(cooperatorInformationLabel.frame))
        
        nameField.sizeToFit()
        accountIdField.sizeToFit()
        emailField.sizeToFit()
        phoneField.sizeToFit()
        addressField.sizeToFit()
        secondAddressField.sizeToFit()
        cityField.sizeToFit()
        statesPopover.sizeToFit()
        zipField.sizeToFit()
        
        nameField.frame = CGRectMake(CGRectGetMinX(contentRect),
            CGRectGetMaxY(cooperatorInformationLabel.frame) + MONDimensionsLargePadding,
            CGRectGetWidth(contentRect)/2.0 - MONDimensionsSmallPadding,
            CGRectGetHeight(nameField.bounds))
        
        accountIdField.frame = CGRectMake(CGRectGetMidX(contentRect) + MONDimensionsSmallPadding,
            CGRectGetMaxY(cooperatorInformationLabel.frame) + MONDimensionsLargePadding,
            CGRectGetWidth(contentRect)/2.0 - MONDimensionsSmallPadding,
            CGRectGetHeight(accountIdField.bounds))
        
        emailField.frame = CGRectMake(CGRectGetMinX(contentRect),
            CGRectGetMaxY(nameField.frame) + MONDimensionsLargePadding,
            CGRectGetWidth(contentRect)/2.0 - MONDimensionsSmallPadding,
            CGRectGetHeight(emailField.bounds))
        
        phoneField.frame = CGRectMake(CGRectGetMidX(contentRect) + MONDimensionsSmallPadding,
            CGRectGetMaxY(accountIdField.frame) + MONDimensionsLargePadding,
            CGRectGetWidth(contentRect)/2.0 - MONDimensionsSmallPadding,
            CGRectGetHeight(phoneField.bounds))
        
        addressField.frame = CGRectMake(CGRectGetMinX(contentRect),
            CGRectGetMaxY(phoneField.frame) + MONDimensionsLargePadding,
            CGRectGetWidth(contentRect),
            CGRectGetHeight(addressField.frame))
        
        secondAddressField.frame = CGRectMake(CGRectGetMinX(contentRect),
            CGRectGetMaxY(addressField.frame) + MONDimensionsLargePadding,
            CGRectGetWidth(contentRect),
            CGRectGetHeight(secondAddressField.frame))
        
        cityField.frame = CGRectMake(CGRectGetMinX(contentRect),
            CGRectGetMaxY(secondAddressField.frame) + MONDimensionsLargePadding,
            (CGRectGetWidth(contentRect) - 4.0*MONDimensionsSmallPadding)/3.0,
            CGRectGetHeight(cityField.frame))
        
        statesPopover.frame = CGRectMake(CGRectGetMaxX(cityField.frame) + 2.0*MONDimensionsSmallPadding,
            CGRectGetMaxY(secondAddressField.frame) + MONDimensionsLargePadding,
            (CGRectGetWidth(contentRect) - 4.0*MONDimensionsSmallPadding)/3.0,
            CGRectGetHeight(statesPopover.frame))
        
        zipField.frame = CGRectMake(CGRectGetMaxX(statesPopover.frame) + 2.0*MONDimensionsSmallPadding,
            CGRectGetMaxY(secondAddressField.frame) + MONDimensionsLargePadding,
            (CGRectGetWidth(contentRect) - 4.0*MONDimensionsSmallPadding)/3.0,
            CGRectGetHeight(zipField.frame))
        
        scrollView.contentOffset = CGPointZero
    }
    
    func labeledTextField(labelText: String, placeholderText: String) -> MONLabeledTextField {
        let textField = MONLabeledTextField()
        textField.delegate = self
        textField.label.textAlignment = .Left
        textField.label.text = labelText
        textField.setTextFieldPlaceholderText(placeholderText)
        textField.setLabelLocation(.Top)
        return textField
    }
    
    func setName(name: String, accountId: String, email: String, phone: String, address1: String, address2: String, city: String, state: String, zip: String) {
        nameField.textFieldText = name
        accountIdField.textFieldText = accountId
        emailField.textFieldText = email
        phoneField.textFieldText = phone
        addressField.textFieldText = address1
        secondAddressField.textFieldText = address2
        cityField.textFieldText = city
        statesPopover.setTextFieldText(state)
        zipField.textFieldText = zip
    }

    required init(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    //MARK: - MONLabeledTextFieldDelegate methods
    func monLabeledTextFieldTextDidChange(labeledTextField: MONLabeledTextField!) {
        delegate?.updatedInformation(nameField.textFieldText, accountId: accountIdField.textFieldText, email: emailField.textFieldText, phone: phoneField.textFieldText, address1: addressField.textFieldText, address2: secondAddressField.textFieldText, city: cityField.textFieldText, zip: zipField.textFieldText)
    }
    
    func monLabeledTextFieldDidBeginEditing(labeledTextField: MONLabeledTextField!) {
        activeTextField = labeledTextField
    }
    
    //MARK: - MONPopoverTextFieldDelegate methods
    func valueWasSelected(sender: AnyObject!, selectedObject: AnyObject!, selectedIndex: Int) {
        delegate?.selectedState(selectedObject)
    }
    
    //MARK: - UIKeyboard Notifications
    func keyboardWillShow(notifcation: NSNotification) {
        if let keyboardSize = notifcation.userInfo?[UIKeyboardFrameBeginUserInfoKey]?.CGRectValue().size {
            let adjustedRect = CGRectMake(0,0, CGRectGetWidth(self.frame), CGRectGetHeight(self.frame) - keyboardSize.height)
            
            scrollView.contentInset = UIEdgeInsetsMake(0, 0, keyboardSize.height + MONDimensionsLargePadding, 0)
            
            scrollView.scrollEnabled = true
            scrollView.contentSize = CGSizeMake(CGRectGetWidth(scrollView.bounds), CGRectGetMaxY(cityField.frame))
            
            if let firstResponder = activeTextField {
                if (!CGRectContainsPoint(adjustedRect, firstResponder.frame.origin)) {
                    scrollView.scrollRectToVisible(firstResponder.frame, animated: true)
                }
            }
        }
    }
    
    func keyboardWillHide(notification: NSNotification) {
        scrollView.contentInset = UIEdgeInsetsZero
        scrollView.scrollRectToVisible(frame, animated: false)
        scrollView.scrollEnabled = false
    }
    
}
