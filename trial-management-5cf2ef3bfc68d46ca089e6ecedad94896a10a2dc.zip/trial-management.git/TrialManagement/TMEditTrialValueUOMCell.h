#import "MONSingleSelectionCardCollectionViewCell.h"
#import "TMValueUOMModel.h"

@interface TMEditTrialValueUOMCell : MONSingleSelectionCardCollectionViewCell

@property (nonatomic) TMValueUOMModel *cellModel;

- (void)updateValue:(NSNumber *)value selectedUnitOfMeasure:(NSString *)selectedUnitOfMeasure;

@end
