class TMFileContentConverter {
    
    class func fileContents(fileName: String, type: String) -> String? {
        if let path = NSBundle.mainBundle().pathForResource(fileName, ofType:type) {
            if let content = String(contentsOfFile:path, encoding: NSUTF8StringEncoding, error: nil) {
                return content
            }
        }
        return nil
    }
}
