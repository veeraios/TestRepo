#import "MONHardware.h"
#include <sys/sysctl.h>
#import <mach/mach.h>

@implementation MONHardware

+(MONHardwareType)currentDeviceType {
	NSString *deviceType = [self queryPlatform];

	if([[self ipadDeviceTypes] containsObject:deviceType]) {
		return MONHardwareTypeIpad;
	} else if([[self ipadMiniDeviceTypes] containsObject:deviceType]) {
		return MONHardwareTypeIpadMini;
	} else if([[self iphoneDeviceTypes] containsObject:deviceType]) {
		return MONHardwareTypeIphone;
	} else if([[self ipodTouchDeviceTypes] containsObject:deviceType]) {
		return MONHardwareTypeIpod;
	}
	return MONHardwareTypeUnknown;
}

+ (CGFloat)freeMemory {
    double totalMemory = 0.00;
    vm_statistics_data_t vmStats;
    mach_msg_type_number_t infoCount = HOST_VM_INFO_COUNT;
    kern_return_t kernReturn = host_statistics(mach_host_self(), HOST_VM_INFO, (host_info_t)&vmStats, &infoCount);
    if(kernReturn != KERN_SUCCESS) {
        return -1;
    }
    totalMemory = ((vm_page_size * vmStats.free_count) / 1024) / 1024;
    
    return totalMemory;
}

+ (CGFloat)usedMemory {
    double usedMemory = 0.00;
    vm_statistics_data_t vmStats;
    mach_msg_type_number_t infoCount = HOST_VM_INFO_COUNT;
    kern_return_t kernReturn = host_statistics(mach_host_self(), HOST_VM_INFO, (host_info_t)&vmStats, &infoCount);
    if(kernReturn != KERN_SUCCESS) {
        return -1;
    }
    usedMemory = ((vm_page_size * (vmStats.active_count + vmStats.inactive_count + vmStats.wire_count)) / 1024) / 1024;
    
    return usedMemory;
}

+ (CGFloat)activeMemory {
    double activeMemory = 0.00;
    vm_statistics_data_t vmStats;
    mach_msg_type_number_t infoCount = HOST_VM_INFO_COUNT;
    kern_return_t kernReturn = host_statistics(mach_host_self(), HOST_VM_INFO, (host_info_t)&vmStats, &infoCount);
    if(kernReturn != KERN_SUCCESS) {
        return -1;
    }
    activeMemory = ((vm_page_size * vmStats.active_count) / 1024) / 1024;
    
    return activeMemory;
}


+(NSUInteger)totalMemory {
	return [self getSysInfo:HW_PHYSMEM];
}

+(NSUInteger)userMemory {
	return [self getSysInfo:HW_USERMEM];
}

+(NSArray*)ipadDeviceTypes {
	return @[@"iPad1,1", @"iPad2,1", @"iPad2,2", @"iPad2,3", @"iPad3,1", @"iPad3,2", @"iPad3,3", @"iPad3,4", @"iPad3,5", @"iPad3,6", @"iPad4,1", @"iPad4,2", @"iPad4,3"];
}

+(NSArray*)ipadMiniDeviceTypes {
	return @[@"iPad2,5", @"iPad2,6", @"iPad2,7", @"iPad4,4", @"iPad4,5", @"iPad4,6"];
}

+(NSArray*)iphoneDeviceTypes {
	return @[@"iPhone3,1", @"iPhone3,2", @"iPhone3,3", @"iPhone5,1", @"iPhone5,2", @"iPhone5,3", @"iPhone5,4", @"iPhone6,1", @"iPhone6,2"];
}

+(NSArray*)ipodTouchDeviceTypes {
	return @[@"iPod1,1", @"iPod2,1", @"iPod3,1", @"iPod4,1", @"iPod5,1"];
}

+ (NSUInteger) getSysInfo: (uint) typeSpecifier
{
    size_t size = sizeof(int);
    int results;
    int mib[2] = {CTL_HW, typeSpecifier};
    sysctl(mib, 2, &results, &size, NULL, 0);
    return (NSUInteger) results;
}

+ (NSString *)queryPlatform {
    size_t size;
    sysctlbyname("hw.machine", NULL, &size, NULL, 0);
    char *machine = malloc(size);
    sysctlbyname("hw.machine", machine, &size, NULL, 0);
    NSString *platform = [NSString stringWithUTF8String:machine];
    free(machine);
    return platform;
}

@end
