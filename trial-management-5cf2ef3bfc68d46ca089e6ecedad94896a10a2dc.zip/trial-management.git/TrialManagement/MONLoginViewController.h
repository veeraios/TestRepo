#import <ESCObservable/ESCObservable.h>
#import <UIKit/UIKit.h>

@protocol MONLoginViewControllerObserver <NSObject>

- (void)loginSucceeded;
- (void)loginFailed;

@end

@interface MONLoginViewController : UIViewController<ESCObservable>

- (BOOL)userIsAuthenticated;
- (void)logout;

@end
