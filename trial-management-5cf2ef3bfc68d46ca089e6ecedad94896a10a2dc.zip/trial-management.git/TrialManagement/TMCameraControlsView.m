#import "TMCameraControlsView.h"
#import "MONUIConvenienceFunctions.h"
#import "MONDimensions.h"
#import "UIColor+MONThemeColorProvider.h"

static const CGFloat ControlStripWidth = 80.0;

@interface TMCameraControlsView ()<ESCObservableInternal>

@property (nonatomic) UIView *controlStripView;
@property (nonatomic) UIButton *takePictureButton;
@property (nonatomic) UIButton *showPhotoLibraryButton;
@property (nonatomic) UIButton *cancelButton;

@end

@implementation TMCameraControlsView

- (id)initWithFrame:(CGRect)frame {
	self = [super initWithFrame:frame];
	if (self) {
		[self escRegisterObserverProtocol:@protocol(TMCameraControlsViewObserver)];
		
		self.controlStripView = [[UIView alloc] init];
		self.controlStripView.backgroundColor = [[UIColor colorForThemeComponentType:MONThemeComponentTypeBackground] colorWithAlphaComponent:0.7];
		[self addSubview:self.controlStripView];
		
		self.cancelButton = [[UIButton alloc] init];
		[self.cancelButton setTitle:@"Cancel" forState:UIControlStateNormal];
		[self.cancelButton addTarget:self.escNotifier action:@selector(cameraControlsCancelButtonTapped) forControlEvents:UIControlEventTouchUpInside];
		[self.controlStripView addSubview:self.cancelButton];
		
		self.takePictureButton = [[UIButton alloc] init];
		[self.takePictureButton setTitle:@"Shoot" forState:UIControlStateNormal];
		[self.takePictureButton addTarget:self.escNotifier action:@selector(cameraControlsTakePhotoButtonTapped) forControlEvents:UIControlEventTouchUpInside];
		[self.controlStripView addSubview:self.takePictureButton];
		
		self.showPhotoLibraryButton = [[UIButton alloc] init];
		[self.showPhotoLibraryButton setTitle:@"Photo Library" forState:UIControlStateNormal];
		[self.showPhotoLibraryButton addTarget:self.escNotifier action:@selector(cameraControlsShowPhotoLibraryButtonTapped) forControlEvents:UIControlEventTouchUpInside];
		[self.controlStripView addSubview:self.showPhotoLibraryButton];
	}
	return self;
}

- (void)layoutSubviews {
	[super layoutSubviews];
	
	self.controlStripView.frame = CGRectMake(CGRectGetMaxX(self.bounds) - ControlStripWidth, 0.0, ControlStripWidth, CGRectGetHeight(self.bounds));
//	self.controlStripView.center = self.center;
	
	[self.cancelButton sizeToFit];
	self.cancelButton.frame = CGRectMake(MONUIScreenRoundToScreenScale((CGRectGetMaxX(self.controlStripView.bounds) - CGRectGetWidth(self.cancelButton.frame)) / 2.0),
										 MONDimensionsSmallPadding,
										 CGRectGetWidth(self.cancelButton.frame),
										 CGRectGetHeight(self.cancelButton.frame));

	[self.takePictureButton sizeToFit];
	self.takePictureButton.frame = CGRectMake(MONUIScreenRoundToScreenScale((CGRectGetMaxX(self.controlStripView.bounds) - CGRectGetWidth(self.takePictureButton.frame)) / 2.0),
											  MONUIScreenRoundToScreenScale((CGRectGetMaxY(self.controlStripView.bounds) - CGRectGetHeight(self.takePictureButton.frame)) / 2.0),
											  CGRectGetWidth(self.takePictureButton.frame),
											  CGRectGetHeight(self.takePictureButton.frame));
	
	[self.showPhotoLibraryButton sizeToFit];
	self.showPhotoLibraryButton.frame = CGRectMake(MONUIScreenRoundToScreenScale((CGRectGetMaxX(self.controlStripView.bounds) - CGRectGetWidth(self.showPhotoLibraryButton.frame)) / 2.0),
												   CGRectGetMaxY(self.controlStripView.bounds) - CGRectGetHeight(self.showPhotoLibraryButton.frame) - MONDimensionsSmallPadding,
												   CGRectGetWidth(self.showPhotoLibraryButton.frame),
												   CGRectGetHeight(self.showPhotoLibraryButton.frame));
	
	
	
}



@end
