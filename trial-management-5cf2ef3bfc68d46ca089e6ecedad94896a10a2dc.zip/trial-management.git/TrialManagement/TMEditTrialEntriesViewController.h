#import "MONTabController.h"
#import "TMTrialModel.h"
#import "TMPersistenceViewController.h"

@interface TMEditTrialEntriesViewController : TMPersistenceViewController<MONTabController>

- (instancetype)initWithTrialModel:(TMTrialModel *)trialModel;

@end
