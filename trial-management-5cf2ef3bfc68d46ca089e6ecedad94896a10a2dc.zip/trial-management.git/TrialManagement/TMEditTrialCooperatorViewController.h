#import "MONTabController.h"
#import "TMTrialModel.h"
#import "TMPersistenceViewController.h"

extern NSString *const PlotState;

@interface TMEditTrialCooperatorViewController : TMPersistenceViewController <MONTabController>
- (id)init UNAVAILABLE_ATTRIBUTE;

- (instancetype)initWithTrialModel:(TMTrialModel *)trialModel;
@end