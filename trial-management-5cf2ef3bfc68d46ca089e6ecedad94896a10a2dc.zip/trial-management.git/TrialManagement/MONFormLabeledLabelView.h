#import <UIKit/UIKit.h>

@interface MONFormLabeledLabelView : UIView

- (void)setLabelText:(NSString *)labelText;
- (void)setLabelWidth:(CGFloat)labelWidth;
- (void)setValueText:(NSString *)valueText;

@end
