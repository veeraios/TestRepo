#import "MONReferenceSearchableModel.h"
#import "MONSearchTableViewCellProtocol.h"
#import "MONSearchStrategy.h"

@interface MONSingleSearchViewController : UIViewController

-(instancetype)initWithSearchStrategy:(id<MONSearchStrategy>)strategy criteria:(NSDictionary*)criteria;

@property (nonatomic,readonly) UITableViewCell<MONSearchTableViewCellProtocol>* selectedItem;
@property (nonatomic,readonly) id selectedModel;
@end
