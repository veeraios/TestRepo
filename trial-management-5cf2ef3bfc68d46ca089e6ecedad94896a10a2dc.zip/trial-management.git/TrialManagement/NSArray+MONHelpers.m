#import "NSArray+MONHelpers.h"
#import "NSArray+TMBlocks.h"

@implementation NSArray (MONHelpers)
- (NSDictionary *)dictionaryWithIndexKeyPath:(NSString *)keyPath {
	NSMutableDictionary *dictionaryToReturn = [NSMutableDictionary dictionary];
	[self enumerateObjectsUsingBlock:^(id object, NSUInteger idx, BOOL *stop) {
		NSString *key = [object valueForKeyPath:keyPath];
		if (key) {
			[dictionaryToReturn setObject:object forKey:key];
		}
	}];
	return dictionaryToReturn;
}

- (NSDictionary *)dictionaryWithIndexCompoundKeyPath:(NSArray *)keyPaths {
    NSMutableDictionary *dictionaryToReturn = [NSMutableDictionary dictionary];
    [self enumerateObjectsUsingBlock:^(id object, NSUInteger idx, BOOL *stop) {
        NSString *key = @"";
        for(NSString *keyPath in keyPaths) {
            NSString *format = [key length] > 0 ? @"_%@" : @"%@";
            NSString *formattedKey = [NSString stringWithFormat:format,[object valueForKeyPath:keyPath]];
            key = [key stringByAppendingString:formattedKey];
        }
        dictionaryToReturn[key] = object;
    }];
    return dictionaryToReturn;
}

- (NSString*)commaSeparatedString {
	__block NSMutableString *rtnString = [self all:^id(NSString *obj) {
		if(!rtnString) {
			rtnString = [[NSMutableString alloc] initWithString:[NSString stringWithFormat:@"\"%@\",",obj]];
		} else {
			[rtnString appendString:[NSString stringWithFormat:@"\"%@\",",obj]];
		}
		return rtnString;
	}];
	if([rtnString hasSuffix:@","]) {
		[rtnString deleteCharactersInRange: (NSRange){[rtnString length] -1, 1}];
	}
	return rtnString;
}

-(NSDictionary*)dictionaryFromArrayOfDictionariesWith:(NSString*)key value:(NSString*)value {
	NSMutableDictionary *harvestPropertyToEntryDictionary = [[NSMutableDictionary alloc] init];
	for (NSDictionary *entryJson in self) {
		if( [entryJson valueForKey:key] != nil) {
			[harvestPropertyToEntryDictionary setObject:[entryJson valueForKey:key] forKey:[entryJson valueForKey:value]];
		}
	}
	return harvestPropertyToEntryDictionary;
}
@end
