#import "TMEditTrialValueUOMView.h"
#import "MONDimensions.h"
#import "MONFonts.h"
#import "MONLabel.h"
#import "MONTextField.h"
#import "MONSegmentedControl.h"
#import "UIColor+MONThemeColorProvider.h"

static const CGFloat HeaderLabelOffset = 40.0;
static const CGFloat TextHeight = 37.0;

@interface TMEditTrialValueUOMView()<MONTextFieldDelegate>

@property (nonatomic) MONLabel *headerLabel;
@property (nonatomic) MONTextField *textField;
@property (nonatomic) MONSegmentedControl *segmentedControl;
@property (nonatomic) NSArray *unitOfMeasures;

@end

@implementation TMEditTrialValueUOMView

- (instancetype)initWithTitle:(NSString *)title 
			   unitOfMeasures:(NSArray *)unitOfMeasures 
						value:(double)value 
		selectedUnitOfMeasure:(NSString *)selectedUnitOfMeasure {
	if (self = [super init]) {
		self.unitOfMeasures = unitOfMeasures;
		self.autoresizesSubviews = YES;
		self.backgroundColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeBackground];
		
		self.headerLabel = [[MONLabel alloc] init];
		self.headerLabel.text = [NSString stringWithFormat:@"ENTER %@",[title uppercaseString]];
		self.headerLabel.font = [UIFont fontWithName:OpenSansLight size:MONFontsHeaderTextSize];
		[self addSubview:self.headerLabel];
		
		self.textField = [[MONTextField alloc] init];
		self.textField.keyboardType = UIKeyboardTypeDecimalPad;
		self.textField.monTextFieldDelegate = self;
        [self.textField setPlaceholderText:[NSString stringWithFormat:@"Enter %@ here.",[title lowercaseString]]];
		[self addSubview:self.textField];
		
		self.segmentedControl = [[MONSegmentedControl alloc] initWithItems:self.unitOfMeasures];
		[self.segmentedControl addTarget:self
								  action:@selector(valueChanged)
						forControlEvents:UIControlEventValueChanged];
		[self addSubview:self.segmentedControl];
		
		if (value != 0.0) {
			self.textField.text = [NSString stringWithFormat:@"%f", value];
		}
		if ([self.unitOfMeasures[0] isEqualToString:selectedUnitOfMeasure]) {
			self.segmentedControl.selectedSegmentIndex = 0;
		} else {
			self.segmentedControl.selectedSegmentIndex = 1;
		}
	}
	return self;
}


- (void)layoutSubviews {
	[super layoutSubviews];

	[self.headerLabel sizeToFit];
	self.headerLabel.frame = CGRectMake(MONDimensionsLargePadding,
										MONDimensionsLargePadding + HeaderLabelOffset,
										CGRectGetWidth(self.headerLabel.frame),
										CGRectGetHeight(self.headerLabel.frame));
	
	self.textField.frame = CGRectMake(MONDimensionsLargePadding,
									  CGRectGetMaxY(self.headerLabel.frame) + MONDimensionsLargePadding,
									  CGRectGetWidth(self.bounds) / 2.0 - MONDimensionsLargePadding * 3.0,
									  TextHeight);
	
	self.segmentedControl.frame = CGRectMake(CGRectGetMaxX(self.textField.frame) + MONDimensionsLargePadding,
											 CGRectGetMinY(self.textField.frame),
											 CGRectGetWidth(self.bounds) / 2.0 - MONDimensionsLargePadding * 3.0,
											 TextHeight);
}

- (BOOL)becomeFirstResponder {
	return [self.textField becomeFirstResponder];
}

- (void)valueChanged {
	[self.delegate evt_value:self.textField.text
			   selectedUnitOfMeasure:self.unitOfMeasures[self.segmentedControl.selectedSegmentIndex]];
}

#pragma mark - MONTextFieldObserver Methods

- (void)monTextFieldTextDidChange:(MONTextField *)textField {
	[self valueChanged];
}

- (void)monTextFieldDidEndEditing:(MONTextField *)textField {
    //logic to handle once text field editing is done (tab out of the field)
}

@end
