//
//  TMMergeGroup.swift
//  TrialManagement
//
//  Created by SINGH, SUPREET [AG/1000] on 1/21/15.
//  Copyright (c) 2015 Monsanto. All rights reserved.
//

class TMMergeGroup: NSObject {
    let section: TMMergeSection
    let subsection: TMMergeSubsection
    let mergeValues: [TMMergeValue]
    let pathLabelSpecs : [TMMergePathDisplaySpec]
    var resolved = false
    
    init(section: TMMergeSection, subsection: TMMergeSubsection, mergeValues: [TMMergeValue], pathLabelSpecs:[TMMergePathDisplaySpec]) {
        self.section = section
        self.subsection = subsection
        self.mergeValues = mergeValues
        self.pathLabelSpecs = pathLabelSpecs
        super.init()
    }
}
