#import "TMDataModel.h"

@protocol MONSelectionCardCollectionViewCell <NSObject>

@property (nonatomic) BOOL isReadOnly;
@property (nonatomic) id<TMDataModel> cellModel;
- (void)setTitle:(NSString *)title;
- (void)setSelectedText:(NSString *)selectedText;

@end