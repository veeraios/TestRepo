
#import "MONDifferenceDetectionEngine.h"
#import "MONManagedObjectDifferenceLogger.h"

@interface MONDifferenceDetectionEngine()

@property (nonatomic) id<MONContextProtocol> workingContext;
@property (nonatomic) id<MONContextProtocol> backupContext;
@property (nonatomic) NSDictionary *traversalRules;

@end

@implementation MONDifferenceDetectionEngine

- (instancetype)initWithBackupContext:(id<MONContextProtocol>)backupContext andDataModelTraversalRules:(NSDictionary *)traversalRules{
    self = [super init];
    if (self) {
        self.backupContext = backupContext;
        self.traversalRules = traversalRules;
    }
    return self;
}

- (NSDictionary *)changesDetectedBetweenObject:(NSManagedObject *)object andBackupObject:(NSManagedObject *)backupObject {
    MONManagedObjectDifferenceLogger *detectDiffs = [[MONManagedObjectDifferenceLogger alloc] initWithNewObject:object oldObject:backupObject withinOldContext:self.backupContext withDataModelTraversalRules:self.traversalRules];
    NSDictionary *changeDict = [detectDiffs detectDifferencesBetweenNewAndOldObjects];
    DDLogError(@"####### Changes from %@ #######", ((NSPersistentStore *)object.managedObjectContext.persistentStoreCoordinator.persistentStores[0]).URL.pathComponents.lastObject);
    DDLogError(@"%@",changeDict);
    DDLogError(@"##### End Changes from %@ #####", ((NSPersistentStore *)object.managedObjectContext.persistentStoreCoordinator.persistentStores[0]).URL.pathComponents.lastObject);
    return changeDict;
}

@end
