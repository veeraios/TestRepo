@interface NSArray (MONHelpers)

- (NSDictionary *)dictionaryWithIndexKeyPath:(NSString *)keyPath;
- (NSDictionary *)dictionaryWithIndexCompoundKeyPath:(NSArray *)keyPaths;
- (NSString*)commaSeparatedString;
- (NSDictionary*)dictionaryFromArrayOfDictionariesWith:(NSString*)key value:(NSString*)value;
@end
