#import "MONViewManagerViewController.h"

@interface MONViewManagerViewController ()

@property (nonatomic) UIViewController *loginViewController;
@property (nonatomic) UIViewController *rootViewController;

@end

@implementation MONViewManagerViewController

- (instancetype)initWithLoginViewController:(UIViewController *)loginViewController rootViewController:(UIViewController *)rootViewController {
	self = [super init];
	if (self) {
		self.loginViewController = loginViewController;
		[self addChildViewController:self.loginViewController];
		
		self.rootViewController = rootViewController;
		[self addChildViewController:self.rootViewController];
	}
	return self;
}

- (void)popToLoginViewAnimated:(BOOL)animated {
	self.loginViewController.view.frame = self.view.bounds;
	self.loginViewController.view.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
	[self.view addSubview:self.loginViewController.view];
}

- (void)pushRootViewAnimated:(BOOL)animated {
	UIView *loginView = self.loginViewController.view;
	UIView *rootView = self.rootViewController.view;
	
	rootView.frame = CGRectMake(CGRectGetMaxX(self.view.bounds), 0.0, CGRectGetWidth(self.view.bounds), CGRectGetHeight(self.view.bounds));
	[self.view addSubview:rootView];
	
	loginView.clipsToBounds = YES;
	
	void (^animationBlock)(void) = ^{
		rootView.frame = self.view.bounds;	
		loginView.frame = CGRectMake(-CGRectGetWidth(self.view.bounds), 0.0, CGRectGetWidth(self.view.frame), CGRectGetHeight(self.view.frame));
	};
	
	void (^completionBlock)(BOOL) = ^(BOOL finished){
		if (finished) {
			[loginView removeFromSuperview];
		}	
	};
	
	if (animated) {
		[UIView animateWithDuration:0.5
							  delay:0.0
							options:UIViewAnimationOptionBeginFromCurrentState
						 animations:animationBlock
						 completion:completionBlock];
	} else {
		animationBlock();
	}

}

@end
