#import "TMFieldObservationsViewController.h"
#import "TMFieldObservationsView.h"
#import "TMObservationTypesViewController.h"
#import "UIImage+MONThemeImageProvider.h"
#import "MONButton.h"
#import "TMWorkingUnitOfWork.h"
#import "TrialManagement-Swift.h"

@interface TMFieldObservationsViewController ()<TMFieldObservationsViewDelegate>

@property (nonatomic) TMTrialModel *trialModel;
@property (nonatomic) TMFieldObservationsView *fieldObservationsView;
@property (nonatomic) TMObservationTypesViewController *observationTypesViewController;
@property (nonatomic) UIButton *addObservationsButton;
@property (nonatomic) MONButton *doneButton;

@end

@implementation TMFieldObservationsViewController

@synthesize tabSettingsObject = _tabSettingsObject;

- (instancetype)initWithTrialModel:(TMTrialModel *)trialModel {
    self = [super initWithTrialModel:trialModel theClass:[self class]];
	if (self) {
		self.trialModel = trialModel;
	}
	return self;
}

- (void)viewDidLoad {
	[super viewDidLoad];

	self.addObservationsButton = [[UIButton alloc] init];
	[self.addObservationsButton setImage:[UIImage imageForUserColorPreference:@"ui-icon-add"] forState:UIControlStateNormal];
	[self.addObservationsButton addTarget:self action:@selector(addObservationsTapped) forControlEvents:UIControlEventTouchUpInside];
	
    self.doneButton = [[MONButton alloc] init];
	[self.doneButton setTitle:@"Done" forState:UIControlStateNormal];
	[self.doneButton addTarget:self action:@selector(doneButtonTapped) forControlEvents:UIControlEventTouchUpInside];
    
	self.fieldObservationsView = [[TMFieldObservationsView alloc] initWithFieldObservationModel:[[TMFieldObservationModel alloc] initWithTrialModel:self.trialModel] headerButtons:@[self.addObservationsButton, self.doneButton]];
	self.fieldObservationsView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    self.fieldObservationsView.delegate = self;
	[self.view addSubview:self.fieldObservationsView];
}

- (void)viewWillAppear:(BOOL)animated {
	[super viewWillAppear:animated];
	self.fieldObservationsView.frame = self.view.bounds;
}

- (void)viewDidAppear:(BOOL)animated {
	[super viewDidAppear:animated];

	[MONGoogleAnalytics trackView:@"Trial - Observations - Field"];
}

- (void)addObservationsTapped {
    TMObservationTypesModel *observationTypesModel = [[TMObservationTypesModel alloc] initWithAllObservationReferenceData:[self.trialModel fieldObservationTypes] previouslySelectedObservations:[self.trialModel existingObservationTypesForTrial] observationType: Field];
	self.observationTypesViewController = [[TMObservationTypesViewController alloc] initWithObservationTypesModel:observationTypesModel];
    
	UINavigationController *navigationController = [[UINavigationController alloc] initWithRootViewController:self.observationTypesViewController];
	UIBarButtonItem *cancelButton = [[UIBarButtonItem alloc] initWithTitle:@"Cancel" style:UIBarButtonItemStylePlain target:self action:@selector(addObservationsCancelTapped)];
	self.observationTypesViewController.navigationItem.leftBarButtonItem = cancelButton;
	UIBarButtonItem *addButton = [[UIBarButtonItem alloc] initWithTitle:@"Add" style:UIBarButtonItemStylePlain target:self action:@selector(addObservationsAddTapped)];
	self.observationTypesViewController.navigationItem.rightBarButtonItem = addButton;
	
	navigationController.modalPresentationStyle = UIModalPresentationPageSheet;
	[self presentViewController:navigationController animated:YES completion:nil];
}

- (void)addObservationsAddTapped {
	[self dismissViewControllerAnimated:YES completion:^{
		[[[TMWorkingUnitOfWork sharedInstance] observationRepository] createSelectedFieldInfoObservationsForTrial:self.trialModel.trial
																		 observationTypes:self.observationTypesViewController.selectedObservationTypes];
		
		[self.fieldObservationsView refreshObservations:[[TMFieldObservationModel alloc] initWithTrialModel:self.trialModel]];

	}];
}

- (void)addObservationsCancelTapped {
	[self dismissViewControllerAnimated:YES completion:nil];
}

- (void)doneButtonTapped {
	[self.navigationController popToRootViewControllerAnimated:YES];
}

- (void)setTitle:(NSString *)title {
	[super setTitle:title];
	[self.tabSettingsObject setGlobalTitle:title];
}



@end
