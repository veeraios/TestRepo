#import <Foundation/Foundation.h>

@interface MONReflection : NSObject
+ (BOOL)class:(Class)theClass hasProperty:(NSString*)propertyString;
@end
