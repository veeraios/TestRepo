#import "TMEditTrialBasicsCellProvider.h"
#import "MONSingleSelectionCardCollectionViewCell.h"
#import "TMEditTrialBasicsListCell.h"
#import "TMTrialBasicsModel.h"
#import "TMUserManager.h"
#import "TMYearModel.h"

static NSString * const CardTitleDSM = @"DSM";
static NSString * const CardTitleTA = @"TA";
static NSString * const CardTitleYear = @"Year";
static NSString * const CardTitleBrand = @"Brand";
static NSString * const CardTitleTerritory = @"Territory";
static NSString * const CardTitleRAL = @"RAL";
static NSString * const CardTitleCrop = @"Crop";
static NSString * const CardTitlePlotType = @"Plot Type";


@implementation TMEditTrialBasicsCellModel
-(instancetype)initWithTitle:(NSString*)cellTitle model:(id<TMDataModel>)model selectedText:(NSString*)selectedText{
    if(self = [super init] ) {
		
		TMUserRole currentUserRole = [[TMUserManager sharedInstance] currentUserRole];
		if(currentUserRole == TMUserRoleDSM && [model isKindOfClass:[TMDSMModel class]]) {
			self.isCellReadOnly = YES;
		} else if(currentUserRole == TMUserRoleTA && [model isKindOfClass:[TMTAModel class]]) {
			self.isCellReadOnly = YES;
		}
		self.cellTitle = cellTitle;
        self.cellModel = model;
		self.selectedText = selectedText;
    }
    return self;
}
@end

@interface TMEditTrialBasicsCellProvider()
@property (assign) long long trialId;
@property (nonatomic) TMTrialModel *trialModel;
@property (nonatomic) TMTrialBasicsModel *trialBasicsModel;
@property (nonatomic) NSInteger tableRowUpdateCount;
@property (nonatomic) NSArray* cardTitleArray;

@end

@implementation TMEditTrialBasicsCellProvider

-(instancetype)initWithTrialModel:(TMTrialModel*)trialModel {
	self = [super init];
	if (self) {
		
		self.cardTitleArray = @[CardTitleDSM, CardTitleTA, CardTitleYear, CardTitleBrand, CardTitleTerritory, CardTitleRAL, CardTitleCrop, CardTitlePlotType];
		
		self.tableRowUpdateCount = 0;
		self.trialModel = trialModel;
		self.trialBasicsModel = [[TMTrialBasicsModel alloc] initWithTrialModel:self.trialModel];
	}
	return self;
}

-(void)filterTechAgronomistDataByTA:(NSString*)ta {
	self.tableRowUpdateCount = 0;
	[self.trialBasicsModel filterByTA:ta];
}

-(void)filterAccordingToProtocolByBrand {
	self.tableRowUpdateCount = 0;
	[self.trialBasicsModel filterAccordingToProtocolByBrand];
}

-(void)filterAccordingToProtocolByCrop {
	self.tableRowUpdateCount = 0;
	[self.trialBasicsModel filterAccordingToProtocolByCrop];
}

-(void)filterTechAgronomistDataByDSM:(NSString*)dsm {
	self.tableRowUpdateCount = 0;
	[self.trialBasicsModel filterByDSM:dsm];
}

- (TMEditTrialBasicsCellModel *)modelForCellAtIndex:(NSInteger)index {
	TMEditTrialBasicsCellModel * cellModel;

	switch (index) {
		case 0: {
			cellModel = [[TMEditTrialBasicsCellModel alloc] initWithTitle:CardTitleDSM model:self.trialBasicsModel.dsmModel selectedText:self.trialModel.salesManagerName];
			break;
		}
		case 1:
			cellModel = [[TMEditTrialBasicsCellModel alloc] initWithTitle:CardTitleTA model:self.trialBasicsModel.tasModel selectedText:self.trialModel.techAgronomistName];
			break;
		case 2:
            cellModel = [[TMEditTrialBasicsCellModel alloc] initWithTitle:CardTitleYear model:[[TMYearModel alloc] init] selectedText:self.trialModel.plantingYear];
			break;
		case 3:
			cellModel = [[TMEditTrialBasicsCellModel alloc] initWithTitle:CardTitleBrand model:self.trialBasicsModel.brandsModel selectedText:self.trialModel.brandName];
			break;
		case 4:
			cellModel = [[TMEditTrialBasicsCellModel alloc] initWithTitle:CardTitleTerritory model:self.trialBasicsModel.territoriesModel selectedText:self.trialModel.salesManagerGeographicCode];
			break;
		case 5:
			cellModel = [[TMEditTrialBasicsCellModel alloc] initWithTitle:CardTitleRAL model:self.trialBasicsModel.ralsModel selectedText:self.trialModel.ral];
			break;
		case 6:
			cellModel = [[TMEditTrialBasicsCellModel alloc] initWithTitle:CardTitleCrop model:self.trialBasicsModel.cropsModel selectedText:self.trialModel.cropName];
			break;
		case 7:
			cellModel = [[TMEditTrialBasicsCellModel alloc] initWithTitle:CardTitlePlotType model:self.trialBasicsModel.plotTypesModel selectedText:self.trialModel.plotTypeName];
			break;
		default:
			break;
	}
	return cellModel;
}

#pragma mark - UICollectionViewDataSource Methods


- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
	
	UICollectionViewCell<MONSelectionCardCollectionViewCell> * cell = nil;
	TMEditTrialBasicsCellModel * cellModel = [self modelForCellAtIndex:indexPath.row];
	if([cellModel.cellModel conformsToProtocol:@protocol(TMReferenceListDataModel) ]) {
		cell = [collectionView dequeueReusableCellWithReuseIdentifier: @"TMEditTrialBasicsListCell" forIndexPath:indexPath];
	} else {
		cell = [collectionView dequeueReusableCellWithReuseIdentifier: @"TMEditTrialBasicsTextCell" forIndexPath:indexPath];
	}
	[cell setTitle:cellModel.cellTitle];
	[cell setCellModel:cellModel.cellModel];
	[cell setSelectedText:cellModel.selectedText];
	((TMEditTrialBasicsListCell*)cell).isReadOnly = cellModel.isCellReadOnly;

	if(self.tableRowUpdateCount  == [self.cardTitleArray count] - 1) {
		//there is no way to hook into a table to inform when a table is finished reloaded.
		//this is a bit of a hack, but other paths
		//would require a large refactoring
		//this is a note to investigate making this better.
		
		[self performSelector:@selector(notifyTableIsReloaded) withObject:nil afterDelay:0.5];

		self.tableRowUpdateCount = 0;
	} else {
		self.tableRowUpdateCount += 1;
	}
	
	return cell;
}

-(void)notifyTableIsReloaded {
	[self.delegate reloadFinished];
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
	return 8;
}

@end
