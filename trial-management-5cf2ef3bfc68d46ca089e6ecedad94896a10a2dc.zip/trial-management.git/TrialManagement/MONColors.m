#import "MONColors.h"

@implementation MONColors

+ (UIColor *)boneColor {
	return [UIColor colorWithRed:245.0/255.0 green:245.0/255.0 blue:245.0/255.0 alpha:1.0];
}

+ (UIColor *)moonDustColor {
	//#969696
	return [UIColor colorWithWhite:0.588 alpha:1.0];
}

+ (UIColor *)belizeHoleColor {
	//#2980b9
	return [UIColor colorWithRed:0.160 green:0.501 blue:0.725 alpha:1.0];
}

+ (UIColor*)lockedColor {
	return [UIColor colorWithRed:210.0/255.0 green:210.0/255.0 blue:210.0/255.0 alpha:1.0];
}

+ (UIColor *)freshAsphaltColor {
	//#252525
	return [UIColor colorWithWhite:0.145 alpha:1.0];
}

+ (UIColor *)freshAsphaltAlternateColor {
	//#2c2c2c
	return [UIColor colorWithWhite:0.172 alpha:1.0];
}

+ (UIColor *)midnightBlueColor {
	//#2c3e50
	return [UIColor colorWithRed:0.172 green:0.243 blue:0.313 alpha:1.0];
}

+ (UIColor *)wetAsphaltColor {
	//#34495e
	return [UIColor colorWithRed:0.203 green:0.286 blue:0.368 alpha:1.0];
}

+ (UIColor *)earlGrayColor {
	//#585858
	return [UIColor colorWithWhite:0.227 alpha:1.0];
}

+ (UIColor *)filterBackgroundColor {
	return [UIColor colorWithRed:0.18 green:0.24 blue:0.31 alpha:1.0];
}

+ (UIColor *)pomegranateColor {
	//#c0392b
	return [UIColor colorWithRed:0.752 green:0.223 blue:0.168 alpha:1.0];
}

+ (UIColor *)ashColor {
	//RGB: 211, 211, 211
	return [UIColor colorWithWhite:0.827 alpha:1.0];
}

+ (UIColor *)selectedCellColor {
	//RGB: 37, 37, 37
	return [UIColor colorWithRed:0.14509803921569f green:0.14509803921569f blue:0.14509803921569f alpha:1.0];
//	return [UIColor colorWithWhite:37/255.0f alpha:1.0];
}

+ (UIColor *)previouslySelectedCellColor {
	//RGB: 160, 160, 106
	return [UIColor colorWithWhite:0.627 alpha:1.0];
	//	return [UIColor colorWithWhite:37/255.0f alpha:1.0];
}


@end
