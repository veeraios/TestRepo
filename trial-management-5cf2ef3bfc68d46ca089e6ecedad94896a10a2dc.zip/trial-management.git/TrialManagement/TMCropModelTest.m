
#import "NSManagedObject+TMCoreDataTestHelper.h"
#import "TMCrop.h"
#import "TMCropModel.h"

@interface TMCropModelTest : XCTestCase

@end

@implementation TMCropModelTest

- (void)testNameForItemAtIndexReturnsCropName
{
	TMCrop *Crop = [TMCrop create];
	Crop.name = @"test";
	
	TMCropModel *testObj = [[TMCropModel alloc] initWithDataSource:@[Crop]];
	NSString *actual =  [testObj nameForItemAtIndex:0];
	XCTAssertEqualObjects(actual,Crop.name);
}

@end
