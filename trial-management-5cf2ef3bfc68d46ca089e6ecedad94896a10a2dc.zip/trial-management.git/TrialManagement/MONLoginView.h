#import <ESCObservable/ESCObservable.h>
#import <UIKit/UIKit.h>

@protocol MONLoginViewObserver <NSObject>

- (void)usernameTextDidChange:(NSString *)usernameText;
- (void)passwordTextDidChange:(NSString *)passwordText;
- (void)loginButtonTapped;

@end

@interface MONLoginView : UIView<ESCObservable>

- (void)setLoginErrorText:(NSString *)errorText;
- (void)showLoginError:(BOOL)showLoginError;
- (void)hideBlocker;

@end
