#import "TMTrialModel.h"
#import "TMStatesModel.h"
#import "TMEmailTableViewModel.h"
#import "TMPostcardTableViewModel.h"
#import "TMMarketingStateCountiesModel.h"
#import "TMMarketingSubmissionType.h"

@interface TMMarketingModel : NSObject
- (instancetype) initWithTrialModel:(TMTrialModel *)trialModel;
- (TMEmailTableViewModel*)emailTableViewModel;
- (TMPostcardTableViewModel*)postcardTableViewModel;
- (TMMarketingStateCountiesModel *)stateCountiesModelForSubmissionType:(TMMarketingSubmissionType)type;
- (void)defaultBooleanValuesIfNil;
- (BOOL)shouldPostToWeb;
- (BOOL)shouldPostCard;
- (BOOL)shouldEmail;
- (void)addSelectedCounties:(NSArray *)counties forSubmissionType:(TMMarketingSubmissionType)type;
- (void)submissionChanged:(BOOL)submissionValue forSubmissionType:(TMMarketingSubmissionType)type;
- (void)removeCounty:(TMCounty *)county forSubmissionType:(TMMarketingSubmissionType)type;
@end
