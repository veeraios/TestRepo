#import <Foundation/Foundation.h>

@interface NSDictionary (TMBlocks)
- (NSDictionary *)where:(BOOL (^)(id key, id obj))block;
@end
