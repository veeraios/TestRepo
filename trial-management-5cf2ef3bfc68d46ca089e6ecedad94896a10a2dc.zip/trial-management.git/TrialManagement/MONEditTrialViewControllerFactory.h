#import "TMTrialModel.h"
#import <Foundation/Foundation.h>

typedef enum {
	EditTrialTypeBasics = 0,
	EditTrialTypeEntries,
	EditTrialTypeGrower,
	EditTrialTypeGPS,
	EditTrialTypePlanting,
} EditTrialType;

@interface MONEditTrialViewControllerFactory : NSObject

+ (UIViewController *)editTrialContentViewControllerForIndex:(EditTrialType)editTrialType trialModel:(TMTrialModel *)trialModel;

@end
