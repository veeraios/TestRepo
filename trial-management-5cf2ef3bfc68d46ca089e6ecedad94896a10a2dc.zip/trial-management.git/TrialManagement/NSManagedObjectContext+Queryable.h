@import CoreData;

@interface MONQuery : NSObject

-(id)initWithType:(NSString*)type context:(NSManagedObjectContext*)theContext;
-(NSArray*)toArray;
-(NSArray*)fetchOnIds;
-(MONQuery*)orderBy:(NSString*)fieldName;
-(MONQuery*)orderByDescending:(NSString*)fieldName;
-(MONQuery*)skip:(int)numberToSkip;
-(MONQuery*)take:(int)numberToTake;
-(id)first;
-(MONQuery*) where:(NSString*)condition;
-(MONQuery*)propertyToFetch:(NSArray*)propertiesToFetch;
-(MONQuery*)wherePredicate:(NSPredicate*)predicate;
@end

@interface NSManagedObjectContext (Queryable)
-(MONQuery*)ofType:(NSString*)typeName;
@end

