#import "MONTextViewEditorViewController.h"
#import "MONTextViewEditorView.h"

@interface MONTextViewEditorViewController ()<MONTextViewEditorViewObserver>

@property (nonatomic) MONTextViewEditorView *textViewEditorView;
@property (nonatomic) NSString *headerText;

@end

@implementation MONTextViewEditorViewController

- (void)viewDidLoad {
	[super viewDidLoad];
	
	self.edgesForExtendedLayout = NO;
	
	self.textViewEditorView = [[MONTextViewEditorView alloc] init];
    self.textViewEditorView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
	[self.textViewEditorView escAddObserver:self];
	[self.view addSubview:self.textViewEditorView];
}

- (void)viewWillAppear:(BOOL)animated {
	[super viewWillAppear:animated];
	
	[self.textViewEditorView setHeaderText:self.headerText];
	self.textViewEditorView.frame = self.view.bounds;
	
	[self.textViewEditorView setText:self.enteredText];
	[self.textViewEditorView becomeFirstResponder];
}

- (void)setEnteredText:(NSString *)enteredText {
	_enteredText = enteredText;
	[self.textViewEditorView setText:[self trimText:enteredText]];
}

- (NSString *)trimText:(NSString *)textToTrim {
	return [textToTrim stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
}

#pragma mark - MONTextViewEditorViewObserver Methods

- (void)textViewEditorTextDidChange:(NSString *)text {
	_enteredText = text;
}

@end
