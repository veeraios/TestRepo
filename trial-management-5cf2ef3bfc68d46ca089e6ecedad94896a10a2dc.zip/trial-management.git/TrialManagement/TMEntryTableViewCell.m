#import "TMEntryTableViewCell.h"
#import "MONDimensions.h"
#import "MONUIConvenienceFunctions.h"
#import "MONFonts.h"
#import "MONLabel.h"
#import "UIColor+MONThemeColorProvider.h"

static const CGFloat ProductLabelOriginY = 228.0;
static const CGFloat RMLabelOriginY = 470.0;
static const CGFloat TraitLabelOriginY = 578.0;

@interface TMEntryTableViewCell ()

@property (nonatomic) MONLabel *brandLabel;
@property (nonatomic) MONLabel *productLabel;
@property (nonatomic) MONLabel *rmLabel;
@property (nonatomic) MONLabel *traitLabel;
@property (nonatomic) UIColor *unselectedBackgroundColor;

@end

@implementation TMEntryTableViewCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
	self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
	if (self) {
		self.backgroundColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeBackground];
		
		self.brandLabel = [self defaultLabel];
		[self addSubview:self.brandLabel];
		
		self.productLabel = [self defaultLabel];
		[self addSubview:self.productLabel];
		
		self.rmLabel = [self defaultLabel];
		[self addSubview:self.rmLabel];
		
		self.traitLabel = [self defaultLabel];
		[self addSubview:self.traitLabel];
	}
	return self;
}

- (MONLabel *)defaultLabel {
	MONLabel *label = [[MONLabel alloc] init];
	label.fontName = OpenSans;
	return label;
}

- (void)layoutSubviews {
	[super layoutSubviews];
	
	CGRect contentRect = CGRectInset(self.bounds, MONDimensionsSmallPadding, MONDimensionsSmallPadding);
	
	[self.brandLabel sizeToFit];
	self.brandLabel.frame = CGRectMake(CGRectGetMinX(contentRect),
									   MONUIScreenRoundToScreenScale((CGRectGetMaxY(self.bounds) - CGRectGetHeight(self.brandLabel.frame)) / 2.0),
									   CGRectGetWidth(self.brandLabel.frame),
									   CGRectGetHeight(self.brandLabel.frame));

	[self.productLabel sizeToFit];
	self.productLabel.frame = CGRectMake(CGRectGetMinX(contentRect) + ProductLabelOriginY,
									   CGRectGetMinY(self.brandLabel.frame),
									   CGRectGetWidth(self.productLabel.frame),
									   CGRectGetHeight(self.productLabel.frame));

	[self.rmLabel sizeToFit];
	self.rmLabel.frame = CGRectMake(CGRectGetMinX(contentRect) + RMLabelOriginY,
									   CGRectGetMinY(self.brandLabel.frame),
									   CGRectGetWidth(self.rmLabel.frame),
									   CGRectGetHeight(self.rmLabel.frame));

	[self.traitLabel sizeToFit];
	self.traitLabel.frame = CGRectMake(CGRectGetMinX(contentRect) + TraitLabelOriginY,
									   CGRectGetMinY(self.brandLabel.frame),
									   CGRectGetWidth(self.traitLabel.frame),
									   CGRectGetHeight(self.traitLabel.frame));
}

- (void)setBrandText:(NSString *)brandText {
	self.brandLabel.text = [brandText uppercaseString];
}

- (void)setProductText:(NSString *)productText {
	self.productLabel.text = [productText uppercaseString];
}

- (void)setRMText:(NSString *)rmText {
	self.rmLabel.text = [rmText uppercaseString];
}

- (void)setTraitText:(NSString *)traitText {
	self.traitLabel.text = [traitText uppercaseString];
}

- (void)useAlternateBackgroundColor:(BOOL)useAlternatBackgroundColor {
	if (useAlternatBackgroundColor) {
		self.unselectedBackgroundColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeBackgroundAlternate];
	} else {
		self.unselectedBackgroundColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeBackground];
	}
	
	self.backgroundColor = self.unselectedBackgroundColor;
}

- (void)setSelected:(BOOL)selected {
	[super setSelected:selected];
	
	UIColor *backgroundColor = nil;
	UIColor *textColor = nil;
	
	if (selected) {
		
		self.selectedBackgroundView = [[UIView alloc] init];
		self.selectedBackgroundView.backgroundColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeSelectedBackground];
		textColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeSelectedText];
	} else {
		backgroundColor = self.unselectedBackgroundColor;
		textColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeText];
	}
	
	self.backgroundColor = backgroundColor;
	self.brandLabel.textColor = textColor;
	self.productLabel.textColor = textColor;
	self.rmLabel.textColor = textColor;
	self.traitLabel.textColor = textColor;
}

@end
