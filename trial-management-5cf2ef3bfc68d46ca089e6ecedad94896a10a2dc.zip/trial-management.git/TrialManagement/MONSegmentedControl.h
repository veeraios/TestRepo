#import <UIKit/UIKit.h>

@interface MONSegmentedControl : UISegmentedControl

@end
