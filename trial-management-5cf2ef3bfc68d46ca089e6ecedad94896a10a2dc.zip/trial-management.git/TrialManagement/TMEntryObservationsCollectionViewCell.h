#import "TMObservationsEditContainerView.h"
#import <UIKit/UIKit.h>

@interface TMEntryObservationsCollectionViewCell : UICollectionViewCell
- (void)setEntryModel:(TMEntryModel*)entryModel;
- (void)setReadOnly;
@end
