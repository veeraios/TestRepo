#import "MONDefaultStyles.h"
#import "UIColor+MONThemeColorProvider.h"

@implementation MONDefaultStyles

+ (void)setupDefaultStyles {
	UIColor *navigationBarColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeNavigationBar];
	UIColor *navigationItemColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeNavigationBarText];
	
	[[UINavigationBar appearance] setBarTintColor:navigationBarColor];
	[[UINavigationBar appearance] setTintColor:navigationItemColor];
	[[UINavigationBar appearance] setTitleTextAttributes:@{ NSForegroundColorAttributeName : navigationItemColor }];
	[[UIBarButtonItem appearance] setTitleTextAttributes:@{ NSForegroundColorAttributeName : navigationItemColor } forState:UIControlStateNormal];
}

@end
