#import "TMFilterProductsViewProtocol.h"
#import "TMFilterProductsModel.h"
#import <Foundation/Foundation.h>

@interface TMFilterProductsPresenter : NSObject

- (instancetype)initWithFilterProductsView:(NSObject<TMFilterProductsView> *)filterProductsView addEntriesModel:(TMFilterProductsModel *)addEntriesModel;

@end
