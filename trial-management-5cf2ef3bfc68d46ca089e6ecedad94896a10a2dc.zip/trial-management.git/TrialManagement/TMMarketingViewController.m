#import "TMMarketingViewController.h"
#import "TMWorkingUnitOfWork.h"
#import "TMUserManager.h"
#import "MONPopoverButton.h"
#import "MONColors.h"
#import "UIImage+MONThemeImageProvider.h"
#import "TMMarketingView.h"
#import "TMStateCountiesTableViewController.h"
#import "TMMarketingActionOptionsListModel.h"
#import "MONMessages.h"
#import "TrialManagement-Swift.h"

@interface TMMarketingViewController () <MONPopoverButtonDelegate, TMMarketingViewProtocol, TMMarketingActionOptionsListModelProtocol, UIActionSheetDelegate>
@property (nonatomic) TMMarketingView *marketingView;
@property (nonatomic) TMTrialModel *trialModel;
@property (nonatomic) TMStatesModel *statesModel;
@property (nonatomic) TMMarketingModel *marketingModel;
@property (nonatomic) MONButton *submitButton;
@property (nonatomic) UIButton *trashButton;
@property (nonatomic) TMStateCountiesTableViewController *stateCountiesTableViewController;
@property (nonatomic) TMMarketingActionOptionsListModel *buttonModel;
@end

NSString *const GrowerInfoClickedNO = @"Make Grower Acceptance Flag as YES to relinquish";
NSString *const GrowerInfoClickedNOMessage = @"To relinquish this trial for marketing, please ensure that you have appropriate authorization from the grower to release the trial information for external marketing and go back to set the Grower Acceptance Flag as 'YES' in the Grower Information Page!";

@implementation TMMarketingViewController

@synthesize tabSettingsObject = _tabSettingsObject;

- (instancetype)initWithTrialModel:(TMTrialModel *)trialModel {
	self = [super initWithTrialModel:trialModel theClass:[self class]];
	if (self) {
		self.trialModel = trialModel;
		self.statesModel =[[TMStatesModel alloc] initWithDataSource:[[[TMWorkingUnitOfWork sharedInstance] stateRepository] sortedEntitiesByName]];
	}
	return self;
}

- (void)viewDidLoad {
	[super viewDidLoad];

    self.buttonModel = [[TMMarketingActionOptionsListModel alloc] initWithUserRole:[[TMUserManager sharedInstance] currentUserRole]  trialModel:self.trialModel];
    self.buttonModel.delegate = self;
    
    if ([self.buttonModel marketingActionsAvailable]) {
        self.submitButton = [[MONPopoverButton alloc] initWithPopoverTitle:@"Actions Available For This Trial" model:self.buttonModel buttonText:@"Submission Options"];
        ((MONPopoverButton*)self.submitButton).popoverDelegate = self;
    } else {
        [self configureSubmitButtonForDone];
    }
	
	self.trashButton = [[UIButton alloc] init];
	[self.trashButton setImage:[UIImage imageForUserColorPreference:@"ui-icon-trash-active"] forState:UIControlStateNormal];
	[self.trashButton addTarget:self action:@selector(trashButtonTapped) forControlEvents:UIControlEventTouchUpInside];

	self.marketingModel = [[TMMarketingModel alloc] initWithTrialModel:self.trialModel];
    [self.marketingModel defaultBooleanValuesIfNil];
	self.marketingView = [[TMMarketingView alloc] initWithMarketingModel:self.marketingModel headerButtons:@[self.trashButton,self.submitButton]];
	self.marketingView.delegate = self;
	self.marketingView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    
    [self.marketingView setCountiesSelectionEnabled:[self.marketingModel shouldEmail] forSubmissionType:Email];
    [self.marketingView setCountiesSelectionEnabled:[self.marketingModel shouldPostCard] forSubmissionType:PostCard];
    
	if([self.trialModel relinquished]) {
		[self.marketingView setSubmittedDate:[self.trialModel agronomistApprovalSubmittedDate] animate:YES];
	} else if([self.trialModel marketingSubmittedDate]) {
		[self.marketingView setSubmittedDate:[self.trialModel marketingSubmittedDate] animate:YES];
	}

	[self.view addSubview:self.marketingView];
}

- (void)viewDidLayoutSubviews {
	[super viewDidLayoutSubviews];
	self.submitButton.enabled = YES;
	self.submitButton.userInteractionEnabled = YES;
}

- (void)viewWillAppear:(BOOL)animated {
	[super viewWillAppear:animated];

	self.marketingView.frame = self.view.bounds;
}

- (void)viewDidAppear:(BOOL)animated {
	[super viewDidAppear:animated];

	[MONGoogleAnalytics trackView:@"Trial - Marketing - Submission"];
}

- (void)configureSubmitButtonForDone {
    self.submitButton = [[MONButton alloc] initWithTitle:@"Done"];
    [self.submitButton addTarget:self action:@selector(doneButtonTapped) forControlEvents:UIControlEventTouchUpInside];
    [self.submitButton setTintColor:[MONColors boneColor]];
}

- (BOOL)isReadOnly {
    return [super isReadOnly] && [self.trialModel isMarketingLocked];
}

- (void)setTitle:(NSString *)title {
    [super setTitle:title];
    [self.tabSettingsObject setGlobalTitle:title];
}

#pragma mark - TMMarketingActionOptionsListModelProtocol Methods

-(void)submitToMarketingComplete {
    [self configureSubmitButtonForDone];
    [self.marketingView setHeaderButtons:@[self.trashButton,self.submitButton]];
	[self.marketingView setSubmittedDate:[self.trialModel marketingSubmittedDate] animate:YES];
    [self.view setNeedsLayout];
}

-(void)relinquishComplete {
	self.buttonModel = [[TMMarketingActionOptionsListModel alloc] initWithUserRole:[[TMUserManager sharedInstance] currentUserRole]  trialModel:self.trialModel];
	self.buttonModel.delegate = self;
	if([self.buttonModel marketingActionsAvailable]) {
        self.submitButton = [[MONPopoverButton alloc] initWithPopoverTitle:@"Actions Available For This Trial" model:self.buttonModel buttonText:@"Submission Options"];
        ((MONPopoverButton*)self.submitButton).popoverDelegate = self;
	} else {
		[self configureSubmitButtonForDone];
	}
    [self.marketingView setHeaderButtons:@[self.trashButton,self.submitButton]];
	[self.marketingView setSubmittedDate:[self.trialModel agronomistApprovalSubmittedDate] animate:YES];
    [self.view setNeedsLayout];
}

-(void)cancelTrialComplete {
    [self configureSubmitButtonForDone];
    [self.marketingView setHeaderButtons:@[self.trashButton,self.submitButton]];
    [self.view setNeedsLayout];
}

- (void)doneButtonTapped {
    [self.navigationController popToRootViewControllerAnimated:YES];
}

#pragma mark - TMMarketingViewProtocol

-(void)editCountiesCancelTapped {
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)removeCounty:(TMCounty *)county forSubmissionType:(TMMarketingSubmissionType)type {
    [self.marketingModel removeCounty:county forSubmissionType:type];
	[self.marketingView setCountiesSelectionEnabled:[self.marketingModel shouldEmail] forSubmissionType:Email];
	[self.marketingView setCountiesSelectionEnabled:[self.marketingModel shouldPostCard] forSubmissionType:PostCard];
    [self.marketingView refreshTables];
}

- (void)editCountiesWasTappedForSubmissionType:(TMMarketingSubmissionType)type {
    self.stateCountiesTableViewController = [[TMStateCountiesTableViewController alloc] initWithStateCountiesModel:[self.marketingModel stateCountiesModelForSubmissionType:type]];
    UINavigationController *navigationController = [[UINavigationController alloc] initWithRootViewController:self.stateCountiesTableViewController];
    
    UIBarButtonItem *cancelButton = [[UIBarButtonItem alloc] initWithTitle:@"Cancel" style:UIBarButtonItemStylePlain target:self action:@selector(editCountiesCancelTapped)];
    self.stateCountiesTableViewController.navigationItem.leftBarButtonItem = cancelButton;
    
    UIBarButtonItem *addButton = [[UIBarButtonItem alloc] initWithTitle:@"Add" style:UIBarButtonItemStylePlain target:self action: @selector(editCountiesAddTapped:)];
    addButton.tag = type;
    self.stateCountiesTableViewController.navigationItem.rightBarButtonItem = addButton;
    
    navigationController.modalPresentationStyle = UIModalPresentationPageSheet;
    [self presentViewController:navigationController animated:YES completion:nil];
}

- (void)editCountiesAddTapped:(UIBarButtonItem *)button {
    TMMarketingSubmissionType type = button.tag;
    [self dismissViewControllerAnimated:YES completion:^{
        if (type == PostCard && ![self.marketingModel shouldEmail]) {
            [self.marketingView setCountiesSelectionEnabled:YES forSubmissionType:Email];
        }
        [self.marketingModel addSelectedCounties:[self.stateCountiesTableViewController selectedCounties] forSubmissionType:type];
        [self.marketingView refreshTables];
    }];
}

- (void)postToWebSwitchWasChanged:(BOOL)postToWebValue {
	[self.trialModel setPostToWeb:postToWebValue];
}

- (void)submissionSwitchWasChanged:(BOOL)submissionValue forSubmissionType:(TMMarketingSubmissionType)type {
    [self.marketingModel submissionChanged:submissionValue forSubmissionType:type];
    [self.marketingView setCountiesSelectionEnabled:submissionValue forSubmissionType:type];
    [self.marketingView refreshTables];
}

- (void)trashButtonTapped {
    UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:nil
															 delegate:self
													cancelButtonTitle:@"Cancel"
											   destructiveButtonTitle:@"Delete Marketing Selections"
													otherButtonTitles:nil];
	[actionSheet addButtonWithTitle:@"Cancel"];
	[actionSheet showFromRect:self.trashButton.frame inView:self.marketingView animated:YES];
}

- (void)submitButtonTapped {
	[self.navigationController popToRootViewControllerAnimated:YES];
}

#pragma mark - UIActionSheetDelegate Methods

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex {
	if (buttonIndex == actionSheet.destructiveButtonIndex) {
        [self.marketingView resetPostcardAndEmailSwitches];
	}
}

#pragma mark - MONPopoverButtonDelegate Methods

- (void)valueWasSelected:(id)sender selectedValue:(NSString*)selectedValue selectedIndex:(NSInteger)selectedIndex {
    
    NSString * message = @"This action cannot be undone!";
    UIAlertView *alertView;
    if([selectedValue isEqualToString:TMRelinqushAndSubmitToMarketingMessage])  {
        if(self.trialModel.cooperatorSignature==NO)
        {
            [MONMessages showErrorMessageTitle:[NSString stringWithFormat:GrowerInfoClickedNO] subtitle:GrowerInfoClickedNOMessage];
            
        }
        else{
            alertView = [self buildAlertViewWithTitle:TMRelinqushAndSubmitToMarketingMessage primaryButtonText:@"Relinquish & Submit" message:message];
        }
    } else if ([selectedValue isEqualToString:TMSubmitToMarketingMessage])  {
        alertView = [self buildAlertViewWithTitle:TMSubmitToMarketingMessage primaryButtonText:@"Submit" message:message];
    } else if ([selectedValue isEqualToString:TMRelinquishTrialMessage])  {
        alertView = [self buildAlertViewWithTitle:TMRelinquishTrialMessage primaryButtonText:@"Relinquish" message:message];
    } else if ([selectedValue isEqualToString:TMCancelTrialMessage])  {
        alertView = [self buildAlertViewWithTitle:TMCancelTrialMessage primaryButtonText:@"Cancel Trial" message:@""];
    }
    [alertView show];
    alertView.tag = selectedIndex;
}

- (UIAlertView *)buildAlertViewWithTitle:(NSString *)title primaryButtonText:(NSString *)primaryButtonText message:(NSString *)message {
    return [[UIAlertView alloc] initWithTitle:[NSString stringWithFormat:@"%@ Confirmation", title] message:message delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:primaryButtonText, nil];
}

#pragma mark - UIAlertViewDelegate Methods

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    if(buttonIndex == 1) {
        [self.buttonModel performActionForItemAtIndex:alertView.tag];
    }
}

@end
