extension TMTrialModel {
    func entryNumbersOfEntriesWithUnaprrovedProducts() -> [String] {
        let entryWithUnapprovedProduct = { (entryModel: TMEntryModel?) -> Bool in
            entryModel?.hasUnapprovedProduct() ?? false
        }
        
        var entryNumbersWithUnapprovedProducts = [String]()
        self.entriesForTrial().filter({  entryWithUnapprovedProduct($0 as? TMEntryModel) }).forEach({
            if let entry = $0 as? TMEntryModel {
                entryNumbersWithUnapprovedProducts.append("\(entry.entryNumber())")
            }
        })
        
        return entryNumbersWithUnapprovedProducts
    }
	
	func isRelinquishedOrCancelled() -> Bool {
        if((self.status()) != nil) {
            return self.status().caseInsensitiveContains("Relinquished") || self.status().caseInsensitiveContains("Cancelled")
        } else {
            return false
        }
	}


  }