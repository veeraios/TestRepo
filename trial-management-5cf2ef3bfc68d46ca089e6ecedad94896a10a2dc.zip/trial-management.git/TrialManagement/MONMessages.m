//
//  MONMessages.m
//  TrialManagement
//
//  Created by SINGH, SUPREET [AG/1000] on 7/1/14.
//  Copyright (c) 2014 Monsanto. All rights reserved.
//

#import "MONMessages.h"
#import "TSMessage.h"

@implementation MONMessages

+ (void)setDefaultViewController:(UIViewController *)viewController {
    [TSMessage setDefaultViewController:viewController];
    [TSMessage addCustomDesignFromFileWithName:@"MONMessagesDesign.json"];
}

+ (void)showSuccessMessageTitle:(NSString *)title subtitle:(NSString *)subtitle {
    [MONMessages showSuccessMessageTitle:title subtitle:subtitle presentOverModal:NO];
}

+ (void)showErrorMessageTitle:(NSString *)title subtitle:(NSString *)subtitle {
    [MONMessages showErrorMessageTitle:title subtitle:subtitle presentOverModal:NO];
}

+ (void)showWarningMessageTitle:(NSString *)title subtitle:(NSString *)subtitle {
    [MONMessages showWarningMessageTitle:title subtitle:subtitle presentOverModal:NO];
}

+ (void)showWarningMessageTitle:(NSString *)title subtitle:(NSString *)subtitle presentOverModal:(BOOL)presentOverModal{
    DDLogInfo(@"Warning shown to user with Title: %@, Subtitle: %@", title, subtitle);
    [TSMessage showNotificationInViewController:[MONMessages presentOnFrontmostViewController:presentOverModal]
                                          title:title
                                       subtitle:subtitle
                                          image:nil
                                           type:TSMessageNotificationTypeWarning
                                       duration:TSMessageNotificationDurationEndless
                                       callback:nil
                                    buttonTitle:nil
                                 buttonCallback:nil
                                     atPosition:[MONMessages notificationPositionForModalOverlay:presentOverModal]
                           canBeDismissedByUser:YES];
}

+ (void)showSuccessMessageTitle:(NSString *)title subtitle:(NSString *)subtitle presentOverModal:(BOOL)presentOverModal{
    [TSMessage showNotificationInViewController:[MONMessages presentOnFrontmostViewController:presentOverModal]
                                          title:title
                                       subtitle:subtitle
                                          image:nil
                                           type:TSMessageNotificationTypeSuccess
                                       duration:TSMessageNotificationDurationAutomatic
                                       callback:nil
                                    buttonTitle:nil
                                 buttonCallback:nil
                                     atPosition:[MONMessages notificationPositionForModalOverlay:presentOverModal]
                           canBeDismissedByUser:YES];
}

+ (void)showErrorMessageTitle:(NSString *)title subtitle:(NSString *)subtitle presentOverModal:(BOOL)presentOverModal{
    DDLogError(@"Error shown to user with Title: %@, Subtitle: %@", title, subtitle);
    [TSMessage showNotificationInViewController:[MONMessages presentOnFrontmostViewController:presentOverModal]
                                          title:title
                                       subtitle:subtitle
                                          image:nil
                                           type:TSMessageNotificationTypeError
                                       duration:TSMessageNotificationDurationEndless
                                       callback:nil
                                    buttonTitle:nil
                                 buttonCallback:nil
                                     atPosition:[MONMessages notificationPositionForModalOverlay:presentOverModal]
                           canBeDismissedByUser:YES];
}

+ (UIViewController *)presentOnFrontmostViewController:(BOOL)presentOnModal {
    UIViewController *defaultViewController = [TSMessage defaultViewController];
    return (defaultViewController.presentedViewController && presentOnModal) ? defaultViewController.presentedViewController : defaultViewController;
}

+ (TSMessageNotificationPosition)notificationPositionForModalOverlay:(BOOL)shouldOverlayModal {
    UIViewController *defaultViewController = [TSMessage defaultViewController];
    return (defaultViewController.presentedViewController && shouldOverlayModal) ? TSMessageNotificationPositionNavBarOverlay : TSMessageNotificationPositionTop;
}
@end
