//
//  TMEntrySelectionView.h
//  TrialManagement
//
//  Created by SINGH, SUPREET [AG/1000] on 11/10/14.
//  Copyright (c) 2014 Monsanto. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TMFilterProductsViewProtocol.h"

@protocol TMAddNewEntriesSelectionViewDelegate <NSObject>

- (void)addProductsButtonTapped;
- (void)requestNewButtonTapped;

@end

@protocol TMEntrySelectionDataRefreshDelegate <NSObject>

- (void)tableDataWasRefreshed;

@end

@interface TMEntrySelectionView : UIView<TMFilterProductsView>

@property (nonatomic, weak) NSObject<TMAddNewEntriesSelectionViewDelegate> *addNewEntriesSelectionViewDelegate;
@property (nonatomic, weak) NSObject<TMEntrySelectionDataRefreshDelegate> *dataRefreshDelegate;

- (instancetype)initWithSearchResultsTableView:(UITableView *)searchResultsTableView selectedBrand:(NSString *)selectedBrand willReplaceEntry:(BOOL)willReplaceEntry;
- (void)incrementSelectedProducts:(NSUInteger)productCount;

@end
