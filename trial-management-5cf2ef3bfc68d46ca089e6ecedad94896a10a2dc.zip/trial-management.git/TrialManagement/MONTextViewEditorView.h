#import <ESCObservable/ESCObservable.h>
#import <UIKit/UIKit.h>

@protocol MONTextViewEditorViewObserver <NSObject>

- (void)textViewEditorTextDidChange:(NSString *)text;

@end


@interface MONTextViewEditorView : UIView<ESCObservable>

- (void)setHeaderText:(NSString *)headerText;
- (void)setText:(NSString *)text;

@end
