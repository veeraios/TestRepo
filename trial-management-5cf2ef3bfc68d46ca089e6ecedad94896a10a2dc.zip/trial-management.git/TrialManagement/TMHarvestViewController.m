#import "TMHarvestViewController.h"
#import "TMHarvestView.h"
#import "TMWorkingUnitOfWork.h"
#import "TMUserManager.h"
#import "MONPopoverButton.h"
#import "TMHarvestActionOptionsListModel.h"
#import "TMTrialsViewController.h"
#import "MONColors.h"
#import "UIImage+MONThemeImageProvider.h"
#import "TMHarvestInfoViewController.h"
#import "NSArray+TMBlocks.h"
#import "MONMessages.h"
#import "TrialManagement-Swift.h"
#import "MONBlocker.h"

static const NSInteger TMNavigateToMarketingOptionSelected = 999;

@interface TMHarvestViewController () <MONPopoverButtonDelegate, TMHarvestActionOptionsListModelProtocol, TMHarvestViewDelegate, UIAlertViewDelegate, UIDocumentInteractionControllerDelegate, ReportSelectionCriteriaViewControllerDelegate>

@property (nonatomic) TMTrialModel *trialModel;
@property (nonatomic) TMHarvestView *harvestView;
@property (nonatomic) TMHarvestActionOptionsListModel *buttonModel;
@property (nonatomic) UIButton *infoButton;
@property (nonatomic) UIButton *generateReportButton;
@property (nonatomic) UIControl *doneButton;
@property (nonatomic) TMHarvestModel *harvestModel;
@property (nonatomic) UIPopoverController *infoPopoverController;
@property (nonatomic) TMTrialReportSelectionCriteriaViewController *reportSelectionCriteriaViewController;
@property (nonatomic) UIPopoverController *menuPopOverController;
@property (nonatomic) NSString *pdfReportFileName;
@end

@implementation TMHarvestViewController

@synthesize tabSettingsObject = _tabSettingsObject;

- (instancetype)initWithTrialModel:(TMTrialModel *)trialModel {
	self = [super initWithTrialModel:trialModel theClass:[self class]];
	if (self) {
		self.trialModel = trialModel;
		[[[TMWorkingUnitOfWork sharedInstance] observationRepository] createHarvestObservationsForTrial:trialModel.trial];
		self.harvestModel = [trialModel harvestModel];
        self.reportSelectionCriteriaViewController = [[TMTrialReportSelectionCriteriaViewController alloc] initWithTrialModel:trialModel];
        self.reportSelectionCriteriaViewController.delegate = self;
	}
	return self;
}

- (void)viewDidLoad {
	[super viewDidLoad];

	self.buttonModel = [[TMHarvestActionOptionsListModel alloc] initWithUserRole:[[TMUserManager sharedInstance] currentUserRole]  trialModel:self.trialModel];
	self.buttonModel.delegate = self;
	if ([self.buttonModel harvestActionsAvailable]) {
		self.doneButton = [[MONPopoverButton alloc] initWithPopoverTitle:@"Actions Available For This Trial" model:self.buttonModel buttonText:@"Submission Options"];
		((MONPopoverButton*)self.doneButton).popoverDelegate = self;
	} else {
		[self configureDoneButtonForNonRelinquishOptions];
	}
    self.infoButton = [[UIButton alloc]init];
    [self.infoButton setImage:[UIImage imageForUserColorPreference:@"ui-icon-info"] forState:UIControlStateNormal];
    [self.infoButton addTarget:self action:@selector(infoButtonTapped) forControlEvents:UIControlEventTouchUpInside];
   	
    self.generateReportButton = [[UIButton alloc] init];
    [self.generateReportButton setImage:[UIImage imageNamed:@"ui-icon-summary-light"] forState:UIControlStateNormal];
    [self.generateReportButton addTarget:self action:@selector(generateReportButtonTapped) forControlEvents:UIControlEventTouchUpInside];

    self.harvestView = [[TMHarvestView alloc] initWitHarvestModel:self.harvestModel rightHeaderButtons:@[self.generateReportButton, self.doneButton] leftHeaderButtons:[self.trialModel isReadOnly] ? @[] : @[self.infoButton]];
	
	self.harvestView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
	self.harvestView.delegate = self;
	
	if([self.trialModel isEligibleForMarketing] == NO) {
		[self.harvestView setSubmittedDate:[self.trialModel agronomistApprovalSubmittedDate] animate:NO];
	}
	[self.view addSubview:self.harvestView];
}

- (void)viewWillAppear:(BOOL)animated {
	[super viewWillAppear:animated];
	self.harvestView.frame = self.view.bounds;
}

- (void)viewDidAppear:(BOOL)animated {
	[super viewDidAppear:animated];

	[MONGoogleAnalytics trackView:@"Trial - Harvest - Data"];
}

- (void)infoButtonTapped {
    self.infoPopoverController = [[UIPopoverController alloc] initWithContentViewController:[[TMHarvestInfoViewController alloc] initWithCropName:[self.trialModel cropName]]];
    NSInteger popoverWidth = 175;
    
    if ([[self.trialModel cropName] isEqualToString:@"CORN-SILAGE"] || [[self.trialModel cropName] isEqualToString:@"COTTON"]) {
        popoverWidth = 300;
    }
    
    [self.infoPopoverController setPopoverContentSize:CGSizeMake(350, popoverWidth)];
    [self.infoPopoverController setBackgroundColor:[UIColor whiteColor]];
	[self.infoPopoverController presentPopoverFromRect:self.infoButton.frame inView:self.view permittedArrowDirections:UIPopoverArrowDirectionUp animated:YES];
}

- (void)generateReportButtonTapped {
    UINavigationController *navigationController = [[UINavigationController alloc] initWithRootViewController:self.reportSelectionCriteriaViewController];
    [self.harvestView resignFirstResponder];
    self.menuPopOverController = [[UIPopoverController alloc] initWithContentViewController:navigationController];
    self.menuPopOverController.popoverContentSize = CGSizeMake(320, 290);
    [self.menuPopOverController presentPopoverFromRect:self.generateReportButton.bounds
                         inView:self.generateReportButton
       permittedArrowDirections:UIPopoverArrowDirectionAny
                       animated:YES];
}

- (void)doneButtonTappedPromptUserForMarketing {
	UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Marketing Options Available for This Trial" message:@"Continue on to Marketing" delegate:nil cancelButtonTitle:@"Cancel" otherButtonTitles:@"Continue", nil];
	alertView.delegate = self;
	alertView.tag = TMNavigateToMarketingOptionSelected;
	[alertView show];
	
}

- (void)doneButtonTapped {
	[self.navigationController popToRootViewControllerAnimated:YES];
}

- (void)configureDoneButtonForNonRelinquishOptions
{
    self.doneButton = [[MONButton alloc] initWithTitle:@"Done"];
    [((MONButton*)self.doneButton) setReadOnly:NO];
    [self.doneButton setTintColor:[MONColors boneColor]];
	[self.doneButton addTarget:self action: ([self.trialModel isEligibleForMarketing]) ?
		@selector(doneButtonTappedPromptUserForMarketing) :
		@selector(doneButtonTapped)
			  forControlEvents:UIControlEventTouchUpInside];
}

- (void)prepareViewForPostRelinquishStatus
{
    [self configureDoneButtonForNonRelinquishOptions];
    [self.harvestView setRightHeaderButtons:@[self.generateReportButton, self.doneButton]];
    [self.harvestView setLeftHeaderButtons:@[]];
    [self.harvestView setSubmittedDate:[self.trialModel agronomistApprovalSubmittedDate] animate:YES];
    [self.view setNeedsLayout];
}

#pragma mark - TMHarvestActionOptionsListModelProtocol Methods

- (void)relinquishComplete {
    [self prepareViewForPostRelinquishStatus];
}

- (void)cancelTrialComplete {
    [self prepareViewForPostRelinquishStatus];
}

- (void)updatedPlotStatsState:(BOOL)plotStatsArePassed {
	[self.trialModel setArePlotStatsPassed:plotStatsArePassed];
}

#pragma mark - MONPopoverButtonDelegate Methods

- (void)valueWasSelected:(id)sender selectedValue:(NSString*)selectedValue selectedIndex:(NSInteger)selectedIndex {

	UIAlertView *alertView;
	if([selectedValue isEqualToString:TMRelinquishTrialMessage])  {
		alertView = [[UIAlertView alloc] initWithTitle:[NSString stringWithFormat:@"%@ Confirmation", selectedValue] message:@"This action cannot be undone!" delegate:nil cancelButtonTitle:@"Cancel" otherButtonTitles:@"Relinquish", nil];

	} else if ([selectedValue isEqualToString:TMCancelTrialMessage])  {
		alertView = [[UIAlertView alloc] initWithTitle:[NSString stringWithFormat:@"%@ Confirmation", selectedValue] message:@"" delegate:nil cancelButtonTitle:@"Cancel" otherButtonTitles:@"Cancel Trial", nil];
	}
	alertView.delegate = self;
	[alertView show];
	alertView.tag = selectedIndex;
}

#pragma mark - UIAlertViewDelegate Methods

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
	if(buttonIndex == 1) {
		if(alertView.tag == TMNavigateToMarketingOptionSelected) {
			[[[self.navigationController.viewControllers where:^BOOL(UIViewController *vc) {
				return [vc isKindOfClass:[TMTrialsViewController class]];
			}] firstObject] marketingButtonTapped];
		} else {
			[self.buttonModel performActionForItemAtIndex:alertView.tag];
		}
	}
}

-(void)viewDidLayoutSubviews {
	[super viewDidLayoutSubviews];
	self.doneButton.enabled = YES;
	self.doneButton.userInteractionEnabled = YES;
	self.generateReportButton.enabled = YES;
	self.generateReportButton.userInteractionEnabled = YES;
}

#pragma  mark - TMHarvestViewDelegate Methods

- (void)setTrialHarvestDate:(NSDate *)date {
	[self.trialModel setHarvestDate:date];
}

#pragma mark - ReportSelectionCriteriaViewControllerDelegate methods

- (void)generateReport:(NSString *)pdfFile {
    [[MONBlocker sharedInstance] showBlockerWithText:@"Generating Trial Summary Report" forView:self.view];
    self.pdfReportFileName = pdfFile;
    NSURL *url=[NSURL fileURLWithPath:pdfFile];
    UIDocumentInteractionController *documentController = [UIDocumentInteractionController interactionControllerWithURL:url];
    documentController.delegate = self;
    
    [documentController presentPreviewAnimated:YES];
}

#pragma mark - UIDocumentInteractionControllerDelegate methods

- (UIViewController *)documentInteractionControllerViewControllerForPreview:(UIDocumentInteractionController *)controller{
    return self;
}

- (CGRect)documentInteractionControllerRectForPreview:(UIDocumentInteractionController *)controller{
    return self.view.frame;
}

- (UIView *)documentInteractionControllerViewForPreview:(UIDocumentInteractionController *)controller{
    return self.view;
}

- (void)documentInteractionControllerDidEndPreview:(UIDocumentInteractionController *)controller {
    if([[NSFileManager defaultManager] fileExistsAtPath:self.pdfReportFileName]) {
        [[NSFileManager defaultManager] removeItemAtPath:self.pdfReportFileName error:nil];
    }
}

- (void)documentInteractionControllerWillBeginPreview:(UIDocumentInteractionController *)controller {
    [[MONBlocker sharedInstance] hideBlocker];
}




@end
