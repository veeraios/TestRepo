//
//  TMMergeModelPopulator.swift
//  TrialManagement
//
//  Created by SINGH, SUPREET [AG/1000] on 1/26/15.
//  Copyright (c) 2015 Monsanto. All rights reserved.
//

import UIKit

@objc class TMMergeModelPopulator: NSObject {
   
    
    func populate() -> TMMergeTrialModel {
        let mergeGroup1 = TMMergeGroup(section: TMMergeSection.EditTrial, subsection: TMMergeSubsection.EditTrialBasics, mergeValues:
                [TMMergeValue(title: "DSM", path: "dsmName", webValue: "Bobby", mobileValue: "Johnny", resolvedValue: nil),
                 TMMergeValue(title: "TA", path: "taName", webValue: "Todd Vagts", mobileValue: "Tom Gross", resolvedValue: nil)])
        
        let mergeTrialModel = TMMergeTrialModel(trial: TMTrial(), mergeGroups: [mergeGroup1])
        
        return mergeTrialModel
    }
}
