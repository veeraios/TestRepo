#import "TMFieldObservationModel.h"

@interface TMFieldInfoCollectionViewCell : UICollectionViewCell
-(void)setModel:(TMFieldObservationModel*)model;
@end
