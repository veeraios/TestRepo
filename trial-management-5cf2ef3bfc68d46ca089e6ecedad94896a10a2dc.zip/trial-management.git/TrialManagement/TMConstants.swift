import CoreLocation

private let TMLocationUpdateNotification = "TMLocationUpdatedNotification"
private let Latitude = "Latitude"
private let Longitude = "Longitude"
private let LocationAccuracy = "LocationAccuracy"
private let EmptyLocation = -1000.0

private let PersistenceViewControllerSubclassToLogName = [
    "TMEditTrialBasicsViewController"     :"EDIT_TRIAL",
    "TMEditTrialEntriesViewController"    :"ADD_ENTRIES",
    "TMEditTrialCooperatorViewController" :"COOPERATOR_INFO",
    "TMEditTrialGPSViewController"        :"GPS_INFO",
    "TMEditTrialPlantingViewController"   :"PLANTING_INFO",
    "TMObservationsViewController"        :"IN-SEASON_OBSERVATIONS",
    "TMFieldObservationsViewController"   :"FIELD_OBSERVATIONS",
    "TMHarvestViewController"             :"HARVEST_DATA",
    "TMMarketingViewController"           :"MARKETING_SUBMISSION"]

private let HarvestCategory = "HARVEST"
private let InSeasonCategory = "IN_SEASON"
private let FieldInfoCategory = "FIELD_INFO"

@objc class TMConstants {
    
    class var locationUpdatedNotification: String { return TMLocationUpdateNotification }
    
    class var latitude: String { return Latitude }
    
    class var longitude: String { return Longitude }
    
    class var locationAccuracy: String { return LocationAccuracy }
    
    class var emptyLocation: CLLocationDegrees { return EmptyLocation }
    
    class var emptyLocationCoordinate: CLLocationCoordinate2D { return CLLocationCoordinate2D(latitude: EmptyLocation, longitude: EmptyLocation) }
    
    class var ViewControllerClassToLogName: [String : String] { return PersistenceViewControllerSubclassToLogName }
    
    class var Harvest: String { return HarvestCategory }
    
    class var InSeason: String { return InSeasonCategory }
    
    class var FieldInfo: String { return FieldInfoCategory }
}
