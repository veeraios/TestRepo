#import "MONPopoverTextField.h"
#import "MONPopoverTableViewController.h"
#import "UIColor+MONThemeColorProvider.h"

@interface MONPopoverTextField()<MONLabeledTextFieldDelegate, UIPopoverControllerDelegate, MONPopoverTableViewControllerObserver>
@property (nonatomic) UIPopoverController *cellPopoverController;

@end

@implementation MONPopoverTextField
- (id)init{
	return [self initWithModel:nil title:@"" placeHolderText:@"" selectedIndex:-1];
}

- (instancetype)initWithModel:(id<TMReferenceListDataModel>)model title:(NSString*)title placeHolderText:(NSString*)placeHolderText selectedIndex:(NSInteger)selectedIndex {
    self = [super init];
    if (self) {
		self.delegate = self;
		[self setLabelText:title];
		[self setTextFieldPlaceholderText:placeHolderText];
		[self setLabelLocation:MONLabeledTextFieldLocationTop];
		self.layer.cornerRadius = 2.0;
		[self showBorder:YES];
		self.model = model;
		if(selectedIndex != NSNotFound) {
			[self setTextFieldText: [self.model nameForItemAtIndex:selectedIndex]];
		}
	
	}
    return self;
}
-(void)showBorder:(BOOL)showBorder {
	if(showBorder) {
		[self.layer setBorderWidth:0.5];
		[self.layer setBorderColor:[UIColor colorForThemeComponentType:MONThemeComponentTypeBorder].CGColor];
	} else {
		[self.layer setBorderWidth:0.0];
		[self.layer setBorderColor:[UIColor clearColor].CGColor];
	}
}

- (void)setLabelLocation:(MONLabeledTextFieldLocation)location {
	[super setLabelLocation:location];
}

- (NSAttributedString *)attributedStringForText:(NSString *)text {
	return [[NSAttributedString alloc] initWithString:text attributes:@{NSForegroundColorAttributeName : [UIColor colorForThemeComponentType:MONThemeComponentTypeText]}];
}

-(void)monLabeledTextFieldTextDidChange:(MONLabeledTextField *)labeledTextField {
	[self resignFirstResponder];
	MONPopoverTableViewController * tableViewController = [[MONPopoverTableViewController alloc] initWithModel:self.model];
	
	[tableViewController escAddObserver:self];
	
	self.cellPopoverController = [[UIPopoverController alloc] initWithContentViewController:tableViewController];
	self.cellPopoverController.delegate = self;
	
	[self.cellPopoverController setPopoverContentSize:CGSizeMake(300, 200)];
	CGRect popoverPresetingRect = CGRectInset(self.bounds, 5.0, 5.0);
	[self.cellPopoverController presentPopoverFromRect:popoverPresetingRect inView:self permittedArrowDirections:UIPopoverArrowDirectionLeft | UIPopoverArrowDirectionRight animated:YES];
}

- (void)didSelectRowIndex:(NSInteger)rowIndex{
	[self setTextFieldText: [self.model nameForItemAtIndex:rowIndex]];
	[self.cellPopoverController dismissPopoverAnimated:YES];
	[self.popoverDelegate valueWasSelected:self selectedValue:[self textFieldText] selectedIndex:rowIndex];
}

@end
