@protocol TMDeltaSyncManagerProtocol <NSObject>

- (void)saveSyncTime:(NSDate *)syncDate;
- (NSTimeInterval)fromDateTimeInterval;
- (BOOL)shouldSyncWithThreshold:(NSInteger)hours;
- (NSTimeInterval)trialsToDateTimeInterval;
- (BOOL)isFirstTimeSync;
- (NSDate*)firstTimeTrialSyncDate;
- (NSTimeInterval)fromDateTimeIntervalWithAWeekBack;
- (NSDate*)notificationFireDate;
- (void)saveForceSyncReferenceCalls:(NSSet *)referenceCalls;
- (NSSet *)retreiveForceSyncReferenceCalls;
- (BOOL)shouldForceSyncForUpgrade;
@end

@interface TMDeltaSyncManager : NSObject<TMDeltaSyncManagerProtocol>

@end
