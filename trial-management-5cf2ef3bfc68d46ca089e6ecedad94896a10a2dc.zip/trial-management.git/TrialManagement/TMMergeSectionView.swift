//
//  TMMergeSectionView.swift
//  TrialManagement
//
//  Created by SINGH, SUPREET [AG/1000] on 1/28/15.
//  Copyright (c) 2015 Monsanto. All rights reserved.
//

import UIKit

protocol TMMergeSectionViewDelegate: class {
    func sideTapped(side: TMMergeSide, subsection: TMMergeSubsection, section: TMMergeSection)
}

class TMMergeSectionView: UIView, TMMergeConflictViewDelegate {
    private let headerHeight: CGFloat = 44

    weak var delegate: TMMergeSectionViewDelegate?
    private let sectionModel: TMMergeSectionViewModel
    private let headerView: UIView
    private let headerTitleLabel: UILabel
    private let conflictsTitleLabel: UILabel
    private let conflictsCountView: MONItemCountView
    private let leftSideTitleLabel: UILabel
    private let rightSideTitleLabel: UILabel
    private let bottomBorderView: UIView
    private let conflictViews = [TMMergeConflictView]()

    init(_ sectionViewModel: TMMergeSectionViewModel) {
        sectionModel = sectionViewModel
        headerView = UIView()
        headerView.backgroundColor = UIColor(forThemeComponentType: MONThemeComponentTypeTabButtonBackground)
        headerView.layer.cornerRadius = MONDimensionsSegmentedCornerRadius
        headerTitleLabel = UILabel()
        conflictsTitleLabel = UILabel()
        conflictsTitleLabel.font = UIFont(name: OpenSansBold, size: 18)
        conflictsTitleLabel.textColor = UIColor(forThemeComponentType: MONThemeComponentTypeSelectedText)
        conflictsTitleLabel.text = "Conflicts"
        conflictsCountView = MONItemCountView()
        conflictsCountView.setAlertColor()
        leftSideTitleLabel = TMDefaultUIFactory.createDefaultLabel("Web", size: 20, numberOfLines: 1)
        rightSideTitleLabel = TMDefaultUIFactory.createDefaultLabel("iPad", size: 20, numberOfLines: 1)
        bottomBorderView = UIView()
        bottomBorderView.backgroundColor = UIColor(forThemeComponentType: MONThemeComponentTypeBorder)
        super.init(frame: CGRectZero)
        let titleRawString = String(format: "Section: %@", arguments: [sectionSpecForMergeSection(sectionViewModel.section).title])
        let titleString = NSMutableAttributedString(string: titleRawString)
        titleString.addAttribute("NSFont", value: UIFont(name: OpenSans, size: 18)!, range: NSMakeRange(0, countElements(titleRawString)))
        titleString.addAttribute("NSFont", value: UIFont(name: OpenSansBold, size: 18)!, range: NSMakeRange(0, 8))
        titleString.addAttribute("NSColor", value: UIColor(forThemeComponentType: MONThemeComponentTypeSelectedText), range: NSMakeRange(0, countElements(titleRawString)))
        headerTitleLabel.attributedText = titleString
        updateConflictsCount()
        backgroundColor = UIColor(forThemeComponentType: MONThemeComponentTypeBackground)
        addSubview(headerView)
        addSubview(headerTitleLabel)
        addSubview(conflictsTitleLabel)
        addSubview(conflictsCountView)
        addSubview(leftSideTitleLabel)
        addSubview(rightSideTitleLabel)
        addSubview(bottomBorderView)
        
        conflictViews = buildConflictViews(sectionViewModel.mergeGroups)
        conflictViews.forEach({[unowned self] in self.addSubview($0)})
    }
    
    func buildConflictViews(mergeValueModels: [TMMergeGroupViewModel]) -> [TMMergeConflictView] {
        return mergeValueModels.map({[unowned self] in
            var conflictView = TMMergeConflictView($0)
            conflictView.delegate = self
            return conflictView
        })
    }
    
    private func updateConflictsCount() {
        let conflictCount = sectionModel.mergeGroups.filter({$0.resolvedSide == nil}).count
        conflictsCountView.setNumberOfItems(UInt(conflictCount))
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        headerView.frame = CGRectMake(MONDimensionsTinyPadding, 0, bounds.width - MONDimensionsTinyPadding * 2.0, headerHeight)
        headerTitleLabel.sizeToFit()
        headerTitleLabel.frame = CGRectMake(headerView.frame.minX + MONDimensionsTinyPadding, headerView.frame.minY + MONDimensionsTinyPadding, headerTitleLabel.frame.width, headerTitleLabel.frame.height)
        conflictsTitleLabel.sizeToFit()
        conflictsTitleLabel.frame = CGRectMake(headerTitleLabel.frame.maxX + MONDimensionsSmallPadding, headerTitleLabel.frame.minY, conflictsTitleLabel.frame.width, headerTitleLabel.frame.height)
        conflictsCountView.sizeToFit()
        conflictsCountView.frame = CGRectMake(conflictsTitleLabel.frame.maxX + MONDimensionsTinyPadding, headerView.frame.minY + 12, conflictsCountView.frame.width, conflictsCountView.frame.height)
        leftSideTitleLabel.sizeToFit()
        leftSideTitleLabel.frame = CGRectMake(bounds.width / 4.0 - leftSideTitleLabel.frame.width / 2.0, headerView.frame.maxY + MONDimensionsTinyPadding, leftSideTitleLabel.frame.width, leftSideTitleLabel.frame.height)
        rightSideTitleLabel.sizeToFit()
        rightSideTitleLabel.frame = CGRectMake(bounds.width * (3.0/4.0) - rightSideTitleLabel.frame.width / 2.0, leftSideTitleLabel.frame.minY, rightSideTitleLabel.frame.width, rightSideTitleLabel.frame.height)
        bottomBorderView.frame = CGRectMake(0, leftSideTitleLabel.frame.maxY + MONDimensionsTinyPadding, bounds.width, MONDimensionsThinBorderWidth)
        
        for (index, conflictView) in enumerate(conflictViews) {
            var size = conflictView.sizeThatFits(CGSizeZero)
            if (index == 0) {
                conflictView.frame = CGRectMake(MONDimensionsTinyPadding, bottomBorderView.frame.maxY + MONDimensionsTinyPadding, headerView.frame.width, size.height)
            } else {
                conflictView.frame = CGRectMake(MONDimensionsTinyPadding, conflictViews[index-1].frame.maxY + MONDimensionsTinyPadding, headerView.frame.width, size.height)
            }
        }
    }
    
    override func sizeThatFits(size: CGSize) -> CGSize {
        var calculatedSize = CGSize(width: size.width, height: 0.0)
        for conflictView in conflictViews {
            var size = conflictView.sizeThatFits(CGSizeZero)
            calculatedSize.height = size.height + MONDimensionsTinyPadding + calculatedSize.height
        }
        headerTitleLabel.sizeToFit()
        leftSideTitleLabel.sizeToFit()
        calculatedSize.height = headerHeight + headerTitleLabel.frame.height + leftSideTitleLabel.frame.height +
            MONDimensionsThinBorderWidth + MONDimensionsTinyPadding + calculatedSize.height
        return calculatedSize;
    }
    
    func sideTapped(side: TMMergeSide, subsection: TMMergeSubsection) {
        updateConflictsCount()
        delegate?.sideTapped(side, subsection: subsection, section: sectionModel.section)
    }
    
    func updateResolvedConflicts() {
        updateConflictsCount()
        conflictViews.forEach({$0.conflictResolved()})
    }

    required init(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

}
