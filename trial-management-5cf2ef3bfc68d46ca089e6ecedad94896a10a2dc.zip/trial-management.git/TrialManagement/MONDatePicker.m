#import "MONDatePicker.h"

static void * XXContext = &XXContext;

@implementation MONDatePicker

- (id)init {
    self = [super init];
    if (self) {
		[self addTarget:self action:@selector(dateChanged) forControlEvents:UIControlEventValueChanged];
		[self addObserver:self forKeyPath:NSStringFromSelector(@selector(date)) options:NSKeyValueObservingOptionNew context:XXContext];
	}
	return self;
}

- (void)dateChanged {
    [self.delegate datePickerChanged:self newDate:self.date];
}

- (void)observeValueForKeyPath:(NSString *)keyPath
                      ofObject:(id)object
                        change:(NSDictionary *)change
                       context:(void *)context {
	
    if (context == XXContext && [keyPath isEqual:NSStringFromSelector(@selector(date))]) {
		[self dateChanged];
    }
}

- (void)dealloc {
    [self removeTarget:self action:@selector(dateChanged) forControlEvents:UIControlEventValueChanged];
	[self removeObserver:self forKeyPath:NSStringFromSelector(@selector(date))];

}
@end
