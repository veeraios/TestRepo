#import "MONTextFieldCardCollectionViewCell.h"
#import "MONCardContainerView.h"
#import "MONFonts.h"
#import "MONDimensions.h"
#import "UIColor+MONThemeColorProvider.h"

static const CGFloat SelectedTextSize = 14.0;

@interface MONTextFieldCardCollectionViewCell ()

@property (nonatomic) MONCardContainerView *backgroundView;
@property (nonatomic) NSString *placeholderText;

@end

@implementation MONTextFieldCardCollectionViewCell
@synthesize cellModel;

- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
		self.backgroundView = [[MONCardContainerView alloc] init];
		[self addSubview:self.backgroundView];
		
		self.titleLabel = [[MONLabel alloc] init];
		self.titleLabel.textSize = MONFontsHeaderTextSize;
		self.titleLabel.numberOfLines = 1;
		self.titleLabel.textAlignment = NSTextAlignmentCenter;
		self.titleLabel.font = [UIFont fontWithName:OpenSans size:MONFontsHeaderTextSize];
		[self addSubview:self.titleLabel];
		
		self.textField = [[UITextField alloc] init];
		self.textField.enabled = NO;
		self.textField.userInteractionEnabled = NO;
		self.textField.font = [UIFont fontWithName:OpenSans size:SelectedTextSize];
		self.textField.backgroundColor = [UIColor clearColor];
		self.textField.textAlignment = NSTextAlignmentCenter;
		self.textField.textColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeText];

		self.textField.delegate = self;
		[self addSubview:self.textField];
    }
    return self;
}

-(void)setIsReadOnly:(BOOL)isReadOnly {
	self.textField.enabled = !isReadOnly;
}

-(BOOL)isReadOnly {
	return !self.textField.enabled;
}


-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [self.textField resignFirstResponder];
    return YES;
}

- (void)layoutSubviews {
	[super layoutSubviews];
	
	self.backgroundView.frame = self.bounds;
	
	[self.titleLabel sizeToFit];
	self.titleLabel.frame = CGRectMake(MONDimensionsSmallPadding,
									   MONDimensionsSmallPadding,
									   CGRectGetWidth(self.titleLabel.frame),
									   CGRectGetHeight(self.titleLabel.frame));
	
	self.textField.frame = CGRectMake(CGRectGetMinX(self.titleLabel.frame),
									 CGRectGetMaxY(self.titleLabel.frame),
									 CGRectGetWidth(self.bounds) - 2.0 * MONDimensionsSmallPadding,
									 CGRectGetHeight(self.bounds) - CGRectGetMaxY(self.titleLabel.frame));
}

- (void)setTitle:(NSString *)title {
	self.titleLabel.text = title;
}

- (void)setSelectedText:(NSString *)selectedText {
	_selectedText = selectedText;
	if (nil != selectedText) {
		self.textField.text = selectedText;
	} else{
		self.textField.text = self.placeholderText;
	}
}
-(void)textFieldDidBeginEditing:(UITextField *)textField {
	if([textField.text isEqualToString:self.placeholderText]) {
		textField.text = @"";
	}
}
-(void)textFieldDidEndEditing:(UITextField *)textField {
	if([textField.text length] == 0) {
		textField.text = self.placeholderText;
	}
}
- (void)setPlaceholderText:(NSString *)placeholderText {
	_placeholderText = placeholderText;
	[self setSelectedText:self.selectedText];
}
-(BOOL)textFieldIsEmpty {
	return [self.textField.text isEqualToString:self.selectedText];
}
- (CGSize)sizeThatFits:(CGSize)size {
	CGSize sizeThatFits = CGSizeZero;
	[self.titleLabel sizeToFit];
	[self.textField sizeToFit];
	CGFloat widthNeeded = 2.0 * MONDimensionsSmallPadding;
	widthNeeded += MAX(CGRectGetWidth(self.titleLabel.frame), CGRectGetWidth(self.textField.frame));
	sizeThatFits.width += MAX(widthNeeded, size.width);
	
	sizeThatFits.height += 2.0 * MONDimensionsSmallPadding;
	sizeThatFits.height += CGRectGetHeight(self.titleLabel.frame);
	sizeThatFits.height += CGRectGetHeight(self.textField.frame);
	return sizeThatFits;
}

@end
