@interface NSArray (TMSortArray)
-(NSArray*)sortByKeyPath:(NSString*)keyPath;
-(NSArray*)sortStringArray;
-(NSArray*)sortIntegerStrings;
@end
