//
//  TMMergeManagedObjectLocator.swift
//  TrialManagement
//
//  Created by WAIDMANN, ALAN [AG/1000] on 2/25/15.
//  Copyright (c) 2015 Monsanto. All rights reserved.
//

import UIKit

class TMMergeManagedObjectLocator: NSObject {
    
    private class func constructPredicateFromPartialKeys(uidPartialKeys: [String], explicitUID: String, pathToAttributes: String, entity: NSEntityDescription) -> (NSCompoundPredicate,String) {
        var mutExplicitUID = explicitUID
        var predicate = NSCompoundPredicate.andPredicateWithSubpredicates([])
        
        for uidPartial in uidPartialKeys {
            switch entity.propertiesByName[uidPartial] {
                
            case let attribute as NSAttributeDescription:
                
                if mutExplicitUID.hasPrefix("{\(uidPartial):") {
                    let partialEndIndex = advance(mutExplicitUID.startIndex, countElements("{\(uidPartial):"))
                    let explicitUIDTail = mutExplicitUID.substringFromIndex(partialEndIndex)
                    let uidValue = explicitUIDTail.substringToIndex(explicitUIDTail.rangeOfString("}")!.startIndex)
                    
                    mutExplicitUID.removeRange(mutExplicitUID.startIndex..<(advance(mutExplicitUID.startIndex, countElements(uidPartial+uidValue)+3)))
                    if let uidIntValue = uidValue.toInt() {
                        let predicateFormat = (pathToAttributes.isEmpty ? "" : "\(pathToAttributes).") + "\(uidPartial) = %ld"
                        predicate = NSCompoundPredicate.andPredicateWithSubpredicates([predicate, NSPredicate(format: predicateFormat, uidIntValue)!])
                    } else {
                        let predicateFormat = (pathToAttributes.isEmpty ? "" : "\(pathToAttributes).") + "\(uidPartial) = %@"
                        predicate = NSCompoundPredicate.andPredicateWithSubpredicates([predicate, NSPredicate(format: predicateFormat, uidValue)!])
                    }
                }
                
            case let relationship as NSRelationshipDescription where !relationship.toMany:
                
                if mutExplicitUID.hasPrefix("[\(uidPartial):") {
                    let destEntity = relationship.destinationEntity!
                    let destUIDPartialKeys = (destEntity.userInfo![UserInfoUIDKey]! as String).componentsSeparatedByString(UserInfoUIDSeparator)
                    mutExplicitUID.removeRange(mutExplicitUID.startIndex..<(advance(mutExplicitUID.startIndex, countElements(uidPartial)+2)))
                    
                    let (partialPredicate,retExplicitUID) = constructPredicateFromPartialKeys(destUIDPartialKeys, explicitUID: mutExplicitUID, pathToAttributes: (pathToAttributes.isEmpty ? "" : "\(pathToAttributes).") + uidPartial, entity: destEntity)
                    mutExplicitUID = retExplicitUID.substringFromIndex(advance(retExplicitUID.startIndex, 1))
                    predicate = NSCompoundPredicate.andPredicateWithSubpredicates([predicate,partialPredicate])
                }
                
            default:
                MONLogger.logError("\(uidPartial) not valid partial key for \(entity.managedObjectClassName)")
            }
        }
        
        return (predicate, mutExplicitUID)
    }
    
    class func findManagedObjectWithPartialKeys(uidDescription: String, explicitUID: String, entity: NSEntityDescription, relationObjects: NSSet) -> NSManagedObject? {
        
        let (uidPredicate,_) = constructPredicateFromPartialKeys(uidDescription.componentsSeparatedByString(UserInfoUIDSeparator), explicitUID: explicitUID, pathToAttributes: "", entity: entity)
        let objects = relationObjects.filteredSetUsingPredicate(uidPredicate)
        return objects.anyObject() as? NSManagedObject
    }

}
