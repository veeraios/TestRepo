#import "TMEditTrialGPSViewController.h"
#import "TMEditTrialGPSPresenter.h"
#import "MONButton.h"
#import "TMTabNameConstants.h"
#import "TrialManagement-Swift.h"

@interface TMEditTrialGPSViewController()
@property (nonatomic) TMEditTrialGPSView *editTrialGPSView;
@property (nonatomic) TMEditTrialGPSModel *editTrialGPSModel;
@property (nonatomic) TMEditTrialGPSPresenter *editTrialGPSPresenter;
@property (nonatomic) MONButton *continueButton;
@property (nonatomic) TMTrialModel *trialModel;

@end

@implementation TMEditTrialGPSViewController

@synthesize tabSettingsObject = _tabSettingsObject;

- (instancetype)initWithTrialModel:(TMTrialModel *)trialModel {
	self = [super initWithTrialModel:trialModel theClass:[self class]];
	if (self) {
		self.trialModel = trialModel;
	}
	return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];

	self.continueButton = [[MONButton alloc] init];
	[self.continueButton setTitle:@"Continue" forState:UIControlStateNormal];
	[self.continueButton addTarget:self action:@selector(continueButtonTapped) forControlEvents:UIControlEventTouchUpInside];
	self.continueButton.enabled = ![self.trialModel isReadOnly];
	self.continueButton.alpha = ![self.trialModel isReadOnly] ? 1.0f : 0.7f;
	
    self.editTrialGPSView = [[TMEditTrialGPSView alloc] initWithHeaderButtons:@[self.continueButton]];
    self.editTrialGPSView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    [self.view addSubview:self.editTrialGPSView];

	self.editTrialGPSPresenter = [[TMEditTrialGPSPresenter alloc] initWithEditTrialGPSView:self.editTrialGPSView trialModel:self.trialModel];
    
    [[TMLocationServices sharedInstance] requestAuthorization];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(locationUpdated:) name:[TMConstants locationUpdatedNotification] object:nil];
    [[TMLocationServices sharedInstance] resumeLocationServices];
    
    self.editTrialGPSView.frame = self.view.bounds;
    //controller interacts with presenter 
    [self.editTrialGPSPresenter setCoordinatesAndUserLocation];
}

- (void)viewDidAppear:(BOOL)animated {
	[super viewDidAppear:animated];

	[MONGoogleAnalytics trackView:@"Trial - GPS Information"];
}

- (void)viewDidDisappear:(BOOL)animated {
    [self.editTrialGPSPresenter deleteInvalidCoordinatesAndStopUserTracking];
    [super viewDidDisappear:animated];
    [[TMLocationServices sharedInstance] pauseLocationServices];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:[TMConstants locationUpdatedNotification] object:nil];
}

- (void)continueButtonTapped {
	[self.tabSettingsObject gotoNextTab];
}

- (void)locationUpdated:(NSNotification *) notification {
    NSDictionary *coordinates = notification.userInfo;
    [self.editTrialGPSPresenter updateToLocationWithCoordinates:coordinates];
}

- (void)setTitle:(NSString *)title {
	[super setTitle:title];
	[self.tabSettingsObject setGlobalTitle:title];
	if (title && ![title isEqualToString:TMTabNameNewTrial]) {
		[self.tabSettingsObject setTabTitle:TMTabNameEditTrial index:1];
	}
}

@end
