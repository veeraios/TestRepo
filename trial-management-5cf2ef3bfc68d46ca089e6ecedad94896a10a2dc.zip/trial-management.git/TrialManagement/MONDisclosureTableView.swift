import UIKit

protocol MONDisclosureTableViewDelegate {
    func criteriaSelected(element:String?)
}

class MONDisclosureTableView: UIView, UITableViewDelegate, UITableViewDataSource {
    private let selectionTableView: UITableView
    private let criteriaDataArray: [String]
    var selectionViewDelegate:MONDisclosureTableViewDelegate?
    private let selectedValue:String
    
    init(criteriaDataArray:[String], selectedValue:String) {
        self.selectedValue = selectedValue
        self.criteriaDataArray = criteriaDataArray
        
        selectionTableView = UITableView()
        selectionTableView.allowsSelection = true
        selectionTableView.registerClass(UITableViewCell.self, forCellReuseIdentifier: "CellIdentifier")
        
        super.init(frame: CGRectZero)
        
        selectionTableView.delegate = self
        selectionTableView.dataSource = self
        
        addSubview(selectionTableView)
    }
    
    required init(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        selectionTableView.sizeToFit()
        selectionTableView.frame = CGRectMake(0.0, 0.0, CGRectGetWidth(frame), CGRectGetHeight(frame))
    }
    
    //MARK: - UITableViewDataSource delegate methods
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return criteriaDataArray.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        var cell = tableView.dequeueReusableCellWithIdentifier("CellIdentifier", forIndexPath:indexPath) as UITableViewCell
        let valueForCell = criteriaDataArray[indexPath.row]
        if (selectedValue == valueForCell) {
            cell.accessoryType = UITableViewCellAccessoryType.Checkmark
        }
        cell.textLabel!.text = valueForCell
        cell.textLabel!.font = UIFont(name: OpenSansLight, size: 20)
        cell.backgroundColor = UIColor(forThemeComponentType: MONThemeComponentTypeBackground)
        
        return cell
    }
    
    //MARK: - UITableViewDelegate delegate methods
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 50
    }
    
    func tableView(tableView: UITableView, willDisplayCell cell: UITableViewCell, forRowAtIndexPath indexPath: NSIndexPath) {
        cell.separatorInset = UIEdgeInsetsZero
        cell.preservesSuperviewLayoutMargins = false
        cell.layoutMargins = UIEdgeInsetsZero
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        selectionViewDelegate?.criteriaSelected(tableView.cellForRowAtIndexPath(indexPath)?.textLabel?.text)
    }
    
}
