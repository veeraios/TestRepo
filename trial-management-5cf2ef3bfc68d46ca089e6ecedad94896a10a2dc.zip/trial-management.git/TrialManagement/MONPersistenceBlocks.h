@import CoreData;

typedef NSManagedObject * (^MONDataFindBlock)(NSDictionary *searchResut);

typedef void (^MONDataImportBlock)(NSDictionary *searchResut, NSManagedObject *cdmodel);
typedef void (^MONDataStringImportBlock)(NSString *stringResult, NSManagedObject *cdmodel);
typedef void (^MONDataImportCompletionBlock)(void);
typedef void (^MONRequestCompletionBlock)(void);