#import "MONDateTextFieldButton.h"
#import "MONLabeledControl.h"

@interface MONLabeledDateTextFieldButton : MONLabeledControl
@property (nonatomic) NSDate *maximumDate;
@property (nonatomic) NSDate *minimumDate;
@property (nonatomic, weak) id<MONDateTextFieldButtonDelegate> dateDelegate;
@property (nonatomic, getter = isEnabled) BOOL enabled;
- (void)setDate:(NSDate*)date;
- (void)setLabelText:(NSString*)text;
- (void)setLabelFont:(UIFont*)font;
- (void)setPlaceholderText:(NSString *)placeholderText;
- (void)showErrorMessage:(NSString*)errorMessage;
@end
