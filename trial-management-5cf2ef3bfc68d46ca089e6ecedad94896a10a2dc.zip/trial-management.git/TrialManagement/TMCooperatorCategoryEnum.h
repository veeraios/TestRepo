//
//  TMCooperatorCategoryEnum.h
//  TrialManagement
//
//  Created by GADIRAJU, PRANEETH [AG/1000] on 5/21/15.
//  Copyright (c) 2015 Monsanto. All rights reserved.
//

typedef NS_ENUM(NSInteger, CooperatorCategory) {
    Grower,
    Dealer
};
