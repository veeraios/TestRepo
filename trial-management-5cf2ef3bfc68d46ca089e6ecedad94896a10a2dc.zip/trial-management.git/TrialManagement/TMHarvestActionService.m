#import "TMHarvestActionService.h"
#import "TMUserManager.h"

static NSString * const BaseUrl = @"Trial/%@";
static NSString * const BaseiOSUrl = @"ios/%@";
static NSString * const RelinquishUrl = @"relinquish";
static NSString * const CancelTrialUrl = @"updateStatus";
static NSString * const SubmitToMarketing = @"saveMarketingInformation";

@interface TMHarvestActionService ()
@property (nonatomic) TMNetworkService *networkService;
@end

@implementation TMHarvestActionService
- (instancetype)init {
	TMNetworkService *networkService = [[TMNetworkService alloc] init];
	return [self initWithNetworkService:networkService];
}

- (instancetype)initWithNetworkService:(TMNetworkService *)networkService {
	self = [super init];
	if (self) {
		self.networkService = networkService;
	}
	return self;
}

- (void)postCancelTrial:(NSNumber*)trialId completionBlock:(void (^)(NSDictionary *, NSError *))completionBlock {
	NSDictionary *parameters =
	@{
	  @"id": trialId,
	  @"abandoned": [NSNumber numberWithBool:YES],
	  };
	
	[self.networkService postToPath:[NSString stringWithFormat:BaseiOSUrl, CancelTrialUrl] parameters:parameters completion:completionBlock];
}


- (void)postRelinquished:(TMTrialModel*)trialModel submitToMarketing:(BOOL)submitToMarketing completionBlock:(void (^)(NSDictionary *, NSError *))completionBlock {
	NSDictionary *parameters =
	@{
	  @"experimentId": [trialModel trialId],
	  @"submitToMarketing": [NSNumber numberWithBool:submitToMarketing],
	  @"runStatistics" : [NSNumber numberWithBool:[[TMUserManager sharedInstance] currentUserRole] == TMUserRoleDSM],
	  @"marketingTO" : (submitToMarketing) ? [self marketingTO:trialModel] : [NSNull null]
	  };
	
	[self.networkService postToPath:[NSString stringWithFormat:BaseiOSUrl, RelinquishUrl] parameters:parameters completion:completionBlock];
}

- (NSDictionary*)marketingTO:(TMTrialModel*)trialModel {
	return @{
			 @"webMarketing": [NSNumber numberWithBool:[[trialModel webMarketing] boolValue]],
			 @"emailMarketing": [NSNumber numberWithBool:[[trialModel emailMarketing] boolValue]],
			 @"postcardMarketing": [NSNumber numberWithBool:[[trialModel postcardMarketing] boolValue]],
				@"emailSendToCounties":[trialModel emailCountiesFipsCode],
				@"postcardSendToCounties": [trialModel postCardCountiesFipsCode]
			 };
}

- (void)postSubmitToMarketing:(TMTrialModel*)trialModel completionBlock:(void (^)(NSDictionary *, NSError *))completionBlock {
	
	[self.networkService postToPath:[NSString stringWithFormat:BaseUrl, SubmitToMarketing]
						 parameters:@{
									  @"experimentId": [trialModel trialId],
									  @"marketingTO" : [self marketingTO:trialModel]
									  }
						 completion:completionBlock];
}
@end
