//
//  MONCoreDataContext.h
//  TrialManagement
//
//  Created by GADIRAJU, PRANEETH [AG/1000] on 12/8/14.
//  Copyright (c) 2014 Monsanto. All rights reserved.
//

@import CoreData;
#import "MONContextProtocol.h"
#import "MONDataModelMigration.h"

@interface MONCoreDataContext:NSObject<MONContextProtocol>

- (void)createManagedObjectContextWithDatabaseName:(NSString *)databaseName modelName:(NSString *)modelName andUndoManager:(BOOL)hasUndoManager;
- (void)createManagedObjectContextWithDatabaseName:(NSString *)databaseName migrationModel:(id<MONDataModelMigration>)migrationModel andUndoManager:(BOOL)hasUndoManager;
@property (nonatomic) NSManagedObjectContext *mainThreadObjectContext;
@end
