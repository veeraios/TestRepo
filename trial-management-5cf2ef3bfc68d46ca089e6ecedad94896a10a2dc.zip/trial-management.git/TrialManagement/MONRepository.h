@import CoreData;
#import "MONRepositoryProtocol.h"
#import "MONContextProtocol.h"
#import "MONPersistenceBlocks.h"
#import "TMUser.h"

@interface MONRepository :NSObject<MONRepositoryProtocol>
- (id)initWithContext:(id<MONContextProtocol>)context withModel:(Class)modeClass;
@end
