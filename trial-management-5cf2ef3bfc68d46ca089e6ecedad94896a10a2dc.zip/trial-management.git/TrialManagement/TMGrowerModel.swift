//
//  TMGrowerModel.swift
//  TrialManagement
//
//  Created by GADIRAJU, PRANEETH [AG/1000] on 5/1/15.
//  Copyright (c) 2015 Monsanto. All rights reserved.
//

class TMGrowerModel : NSObject, TMCooperatorModel {
    private let grower: TMGrower
    
    override init() {
        self.grower = TMWorkingUnitOfWork.sharedInstance().workingContext.attachObject(TMGrower) as TMGrower
        self.grower.growerId = nil
        self.grower.country = "USA"
        self.grower.category = "Grower"
    }
    
    init(grower: TMGrower) {
        self.grower = grower
    }
    
    convenience init(_ grower: TMGrower) {
        self.init(grower:grower)
    }
    
    func hasRequiredInformation() -> Bool {
        return !name.isEmpty && !address1.isEmpty && !city.isEmpty && !postalCode.isEmpty && !state.isEmpty
    }
    
    func isNew() -> Bool {
        return grower.trials.count == 0
    }
    
    func cooperator() -> NSManagedObject {
        return grower
    }
    
    func title() -> String {
        return "Grower"
    }
    
    var name:String {
        get { return MONSafeString.safeStringForString(grower.name) }
        set (growerName) {
            grower.name = growerName
            TMWorkingUnitOfWork.sharedInstance().saveChanges()
        }
    }
    
    var accountId:String {
        get { return MONSafeString.safeStringForString(grower.accountId) }
        set (growerAccountId) {
            grower.accountId = growerAccountId
            TMWorkingUnitOfWork.sharedInstance().saveChanges()
        }
    }
    
    var email:String {
        get { return MONSafeString.safeStringForString(grower.email) }
        set (growerEmail) {
            grower.email = growerEmail
            TMWorkingUnitOfWork.sharedInstance().saveChanges()
        }
    }
    
    var phone:String {
        get { return MONSafeString.safeStringForString(grower.phoneNumber) }
        set (growerPhone) {
            grower.phoneNumber = growerPhone
            TMWorkingUnitOfWork.sharedInstance().saveChanges()
        }
    }
    
    var address1:String {
        get { return MONSafeString.safeStringForString(grower.address1) }
        set (growerAddress1) {
            grower.address1 = growerAddress1
            TMWorkingUnitOfWork.sharedInstance().saveChanges()
        }
    }
    
    var address2:String {
        get { return MONSafeString.safeStringForString(grower.address2) }
        set (growerAddress2) {
            grower.address2 = growerAddress2
            TMWorkingUnitOfWork.sharedInstance().saveChanges()
        }
    }
    
    var city:String {
        get { return MONSafeString.safeStringForString(grower.city) }
        set (growerCity) {
            grower.city = growerCity
            TMWorkingUnitOfWork.sharedInstance().saveChanges()
        }
    }
    
    var state:String {
        get { return MONSafeString.safeStringForString(grower.state) }
        set (growerState) {
            grower.state = growerState
            TMWorkingUnitOfWork.sharedInstance().saveChanges()
        }
    }
    
    var postalCode:String {
        get { return MONSafeString.safeStringForString(grower.postalCode) }
        set (growerPostalCode) {
            grower.postalCode = growerPostalCode
            TMWorkingUnitOfWork.sharedInstance().saveChanges()
        }
    }
}
