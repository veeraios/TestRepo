#import <UIKit/UIKit.h>
#import "MONCardContainerView.h"
#import "MONModalTableViewModel.h"
#import "MONReadOnlyProtocol.h"

@class MONModalTableView;

@protocol MONModalTableViewDelegate <NSObject>
- (void)modalButtonWasTapped:(MONModalTableView*)caller;
- (void)removeButtonTapped:(MONModalTableView*)caller index:(NSInteger)index objectToRemove:(id)objectToRemove;
@end

@interface MONModalTableView : MONCardContainerView<MONReadOnlyProtocol>
- (instancetype)initWithHeaderView:(UIView*)headerView
						tableTitle:(NSString*)tableTitle
					   modalButton:(UIButton*)modalButton
						footerView:(UIView*)footerView
							 model:(id<MONModalTableViewModel>)model;
@property (nonatomic, weak) id<MONModalTableViewDelegate> delegate;
- (void)refreshTable:(id<MONModalTableViewModel>)model;
- (void)setModalButtonEnabled:(BOOL)enabled;
@end
