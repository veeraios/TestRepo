#import <Foundation/Foundation.h>

@interface NSArray (TMNSArrayNSNull)
- (NSArray *)replaceNullsWith:(NSString*)replaceString;
@end
