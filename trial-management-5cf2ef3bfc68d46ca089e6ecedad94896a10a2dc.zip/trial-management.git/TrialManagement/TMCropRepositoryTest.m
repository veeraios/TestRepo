#import "TMCropRepository.h"
#import "TMCrop.h"
#import "NSManagedObject+TMCoreDataTestHelper.h"
#import "TMWorkingCoreDataContext.h"
#import "TMUserManager.h"
#import "TMUnitOfMeasure.h"
#import "TMRowSpacingUnitOfMeasure.h"

@interface TMCropRepositoryTest : XCTestCase
@end

@implementation TMCropRepositoryTest

-(void)setUpUserForImportTest:(NSObject<MONRepositoryProtocol>*)repo {
	//todo: move to import Test helpers
	TMUserManager *manager = [TMUserManager sharedInstance];
	manager.currentUsername = @"test";
	TMUser *user = [TMUser create];
	user.userId = manager.currentUsername;
	[user.managedObjectContext save:nil];
	id mock = [OCMockObject partialMockForObject:repo];
	[[[mock stub] andReturn:user] currentUser];
}

- (void)testSyncFromService {
	TMWorkingCoreDataContext *context = [[TMWorkingCoreDataContext alloc] init];
	id mockContext = [OCMockObject partialMockForObject:context];
	[[mockContext stub] saveContext];
	
	TMCropRepository *repo = [[TMCropRepository alloc] initWithContext:context withModel:[TMCrop class]];
	[self setUpUserForImportTest:repo];
	
	NSDictionary *importDict = @{
								 @"id": @65601536,
								 @"name": @"CORN-GRAIN",
								 @"relativeMaturityMax": @160,
								 @"relativeMaturityMin": @65,
								 @"relativeMaturityIncrement": @1,
								 @"unitOfMeasures": @[
										 @{
											 @"id": @373267075563520,
											 @"name": @"Seeds/Acre",
											 @"minValue": @0,
											 @"maxValue": @500000
											 }
										 ],
								 @"rowSpacingUnitOfMeasures": @[
										 @{
											 @"id": @109641728,
											 @"name": @"Inches",
											 @"minValue": @0,
											 @"maxValue": @98
											 }
										 ]
								 };
	[repo syncFromService:@[importDict] completionBlock:nil];
	
	TMCrop *actual = [[context find:NSStringFromClass([TMCrop class]) where:@"name = 'CORN-GRAIN'"] firstObject];
	XCTAssert(actual != nil);
	XCTAssertEqualObjects(actual.cropId, [importDict objectForKey:@"id"]);
	XCTAssertEqualObjects(actual.name, [importDict objectForKey:@"name"]);
	XCTAssertEqualObjects(actual.relativeMaturityMax, [importDict objectForKey:@"relativeMaturityMax"]);
	XCTAssertEqualObjects(actual.relativeMaturityMin, [importDict objectForKey:@"relativeMaturityMin"]);
	XCTAssertEqualObjects(actual.relativeMaturityIncrement, [importDict objectForKey:@"relativeMaturityIncrement"]);
	XCTAssertEqual([[actual.unitOfMeasures allObjects] count], 1);
	
	TMUnitOfMeasure *uom = [[actual.unitOfMeasures allObjects] objectAtIndex:0];
	XCTAssertEqualObjects(uom.unitOfMeasureId,  @373267075563520);
	XCTAssertEqualObjects(uom.name,  @"Seeds/Acre");

	XCTAssertEqual([[actual.rowSpacingUnitOfMeasures allObjects] count], 1);
	TMRowSpacingUnitOfMeasure *rowUom = [[actual.rowSpacingUnitOfMeasures allObjects] objectAtIndex:0];
	XCTAssertEqualObjects(rowUom.rowSpacingUnitOfMeasuresId,  @109641728);
	XCTAssertEqualObjects(rowUom.name,  @"Inches");

}

-(void)testCropsForCropIds {
	TMWorkingCoreDataContext *context = [[TMWorkingCoreDataContext alloc] init];
	id mockContext = [OCMockObject partialMockForObject:context];
	[[mockContext stub] saveContext];
	TMCrop *crop = [context attachObject:[TMCrop class]];
	crop.cropId = @99966699;
	
	TMCropRepository *repo = [[TMCropRepository alloc] initWithContext:context withModel:[TMCrop class]];
	NSArray *result= [repo cropsForCropId:99966699];
	
	TMCrop *actual =  [result objectAtIndex:0];
	
	XCTAssertEqual(1, [result count]);
	XCTAssertEqualObjects(actual, crop);
}

-(void)testCropIdForCropName {
	TMWorkingCoreDataContext *context = [[TMWorkingCoreDataContext alloc] init];
	id mockContext = [OCMockObject partialMockForObject:context];
	[[mockContext stub] saveContext];
	TMCrop *crop = [context attachObject:[TMCrop class]];
	crop.name = @"cropName";
	crop.cropId = @99966699;
	
	TMCropRepository *repo = [[TMCropRepository alloc] initWithContext:context withModel:[TMCrop class]];
	XCTAssertEqualObjects(crop.cropId, [repo cropIdForCropName:@"cropName"]);
}

@end
