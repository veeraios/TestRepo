#import "MONAgreementViewController.h"
#import "MONLabel.h"
#import "MONFonts.h"
#import "MONSignatureCapture.h"
#import "UIImage+MONThemeImageProvider.h"
#import "UIColor+MONThemeColorProvider.h"

static void * XXContext = &XXContext;

@interface MONAgreementViewController ()
@property (nonatomic) MONSignatureCapture *signatureCaptureView;

@end

@implementation MONAgreementViewController

- (id)init {
    self = [super init];
    if (self) {
    }
    return self;
}
-(void)viewWillAppear:(BOOL)animated {
	[super viewWillAppear:animated];
	CGFloat width = CGRectGetWidth(self.view.bounds);
	
	self.signatureCaptureView = [[MONSignatureCapture alloc] initWithFrame:CGRectMake(10, 105, width-20, 150)];
	self.signatureCaptureView.backgroundColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeBackground];
	self.signatureCaptureView.pathColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeText];
	[self.signatureCaptureView.layer setBorderColor:[UIColor colorForThemeComponentType:MONThemeComponentTypeBorder].CGColor];
	[self.signatureCaptureView.layer setBorderWidth:1.0];
	self.view.backgroundColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeBackground];
	
	[self.view addSubview: self.signatureCaptureView];
	
	UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(10, 60, width-20, 30)];
	[self.view addSubview:headerView];
	
	MONLabel *sigTitleLabel = [[MONLabel alloc] init];
	[sigTitleLabel setText:@"ADD SIGNATURE"];
	sigTitleLabel.font = [UIFont fontWithName:OpenSansLight size:MONFontsHeaderTextSize];
	[sigTitleLabel sizeToFit];
	sigTitleLabel.frame = CGRectMake(0, 0, CGRectGetWidth(sigTitleLabel.frame),CGRectGetHeight(headerView.frame));
	[headerView addSubview:sigTitleLabel];
	
	UIButton *trashButton = [[UIButton alloc] init];
	[trashButton setImage:[UIImage imageForUserColorPreference:@"ui-icon-trash-active"] forState:UIControlStateNormal];
	[trashButton addTarget:self action:@selector(trashButtonTapped) forControlEvents:UIControlEventTouchUpInside];
	[trashButton sizeToFit];
	CGRect trashRect = CGRectMake(CGRectGetMaxX(headerView.frame) - (CGRectGetWidth(trashButton.frame)+16), CGRectGetMinY(sigTitleLabel.frame), CGRectGetWidth(trashButton.frame), CGRectGetHeight(trashButton.frame));
	trashButton.frame = trashRect;
	[headerView addSubview:trashButton];
	
	self.signatureCaptureView = [[MONSignatureCapture alloc] initWithFrame:CGRectMake(10, 105, width-20, 150)];
	self.signatureCaptureView.backgroundColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeBackground];
	self.signatureCaptureView.pathColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeText];
	[self.signatureCaptureView.layer setBorderColor:[UIColor colorForThemeComponentType:MONThemeComponentTypeBorder].CGColor];
	[self.signatureCaptureView.layer setBorderWidth:1.0];
	self.view.backgroundColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeBackground];
	
	[self.view addSubview: self.signatureCaptureView];
	
	
	UIBarButtonItem *cancelButton = [[UIBarButtonItem alloc] initWithTitle:@"Cancel" style:UIBarButtonItemStylePlain target:self action:@selector(cancelTapped)];
    [cancelButton setTintColor:[UIColor colorForThemeComponentType:MONThemeComponentTypeNavigationBarText]];
	self.navigationItem.leftBarButtonItem = cancelButton;
	UIBarButtonItem *doneButton = [[UIBarButtonItem alloc] initWithTitle:@"Done" style:UIBarButtonItemStylePlain target:self action:@selector(doneTapped)];
    [doneButton setTintColor:[UIColor colorForThemeComponentType:MONThemeComponentTypeNavigationBarText]];
	doneButton.enabled = self.signatureCaptureView.hasContent;
	
	self.navigationItem.rightBarButtonItem = doneButton;
	
	[self.signatureCaptureView addObserver:self forKeyPath:NSStringFromSelector(@selector(hasContent)) options:NSKeyValueObservingOptionNew context:XXContext];
}


- (void)viewDidLoad
{
    [super viewDidLoad];
}

- (void)didReceiveMemoryWarning {
#ifdef DEBUG
	DDLogInfo(@"MEMORY WARNING: %s", __FUNCTION__);
#endif
	[super didReceiveMemoryWarning];
}
-(void)signatureTapped {
	
}


- (void)observeValueForKeyPath:(NSString *)keyPath
                      ofObject:(id)object
                        change:(NSDictionary *)change
                       context:(void *)context {
	if (context == XXContext && [keyPath isEqual:NSStringFromSelector(@selector(hasContent))]) {
		self.navigationItem.rightBarButtonItem.enabled = ((MONSignatureCapture*)object).hasContent;
	}

}
-(void)dealloc {
	[self.signatureCaptureView removeObserver:self forKeyPath:NSStringFromSelector(@selector(hasContent))];
}

-(void)trashButtonTapped {
	[self.signatureCaptureView clearImage];
}

- (void)cancelTapped {
	[self.navigationController dismissViewControllerAnimated:YES completion:nil];
}

- (void)doneTapped {
	[self.signatureDelegate signatureImageCreated:self.signatureCaptureView.signatureImage];
}

@end
