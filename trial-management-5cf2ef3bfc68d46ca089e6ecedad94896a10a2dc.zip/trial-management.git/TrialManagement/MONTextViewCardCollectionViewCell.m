#import "MONTextViewCardCollectionViewCell.h"
#import "MONCardContainerView.h"
#import "MONFonts.h"
#import "MONDimensions.h"
#import "UIColor+MONThemeColorProvider.h"

static const CGFloat SelectedTextSize = 14.0;

@interface MONTextViewCardCollectionViewCell ()<ESCObservableInternal>

@property (nonatomic) MONCardContainerView *backgroundView;
@property (nonatomic) NSString *placeholderText;

@end



@implementation MONTextViewCardCollectionViewCell

@synthesize cellModel;

- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
		self.backgroundView = [[MONCardContainerView alloc] init];
		[self addSubview:self.backgroundView];
		
		self.titleLabel = [[MONLabel alloc] init];
		self.titleLabel.textSize = MONFontsHeaderTextSize;
		self.titleLabel.numberOfLines = 1;
		self.titleLabel.textAlignment = NSTextAlignmentCenter;
		self.titleLabel.font = [UIFont fontWithName:OpenSans size:MONFontsHeaderTextSize];
		[self addSubview:self.titleLabel];
		
		self.textView = [[UITextView alloc] init];
		self.textView.editable = NO;
		self.textView.userInteractionEnabled = NO;
		self.textView.font = [UIFont fontWithName:OpenSans size:SelectedTextSize];
		self.textView.backgroundColor = [UIColor clearColor];
		[self.textView setTextContainerInset:UIEdgeInsetsMake(0.0, 0.0, 0.0, 0.0)];
		self.textView.contentInset = UIEdgeInsetsMake(0.0, 0.0, 0.0, 0.0);
		[self addSubview:self.textView];

    }
    return self;
}

- (void)layoutSubviews {
	[super layoutSubviews];
	
	self.backgroundView.frame = self.bounds;
	
	[self.titleLabel sizeToFit];
	self.titleLabel.frame = CGRectMake(MONDimensionsSmallPadding,
									   MONDimensionsSmallPadding,
									   CGRectGetWidth(self.titleLabel.frame),
									   CGRectGetHeight(self.titleLabel.frame));
	
	self.textView.frame = CGRectMake(CGRectGetMinX(self.titleLabel.frame),
									 CGRectGetMaxY(self.titleLabel.frame),
									 CGRectGetWidth(self.bounds) - 2.0 * MONDimensionsSmallPadding,
									 CGRectGetHeight(self.bounds) - CGRectGetMaxY(self.titleLabel.frame));
}

-(void)setIsReadOnly:(BOOL)isReadOnly {
	self.textView.editable = !isReadOnly;
}

-(BOOL)isReadOnly {
	return !self.textView.editable;
}

- (void)setTitle:(NSString *)title {
	self.titleLabel.text = title;
}

- (void)setSelectedText:(NSString *)selectedText {
	_selectedText = selectedText;
	if (!selectedText || [selectedText isEqualToString:@""]) {
		self.textView.text = self.placeholderText;
		self.textView.textColor = [UIColor colorForThemeComponentType:MONThemeComponentTypePlaceholderText];
	} else {
		self.textView.text = selectedText;
		self.textView.textColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeText];
	}
}

- (void)setPlaceholderText:(NSString *)placeholderText {
	_placeholderText = placeholderText;
	[self setSelectedText:self.selectedText];
}

- (CGSize)sizeThatFits:(CGSize)size {
	CGSize sizeThatFits = CGSizeZero;
	[self.titleLabel sizeToFit];
	[self.textView sizeToFit];
	CGFloat widthNeeded = 2.0 * MONDimensionsSmallPadding;
	widthNeeded += MAX(CGRectGetWidth(self.titleLabel.frame), CGRectGetWidth(self.textView.frame));
	sizeThatFits.width += MAX(widthNeeded, size.width);
	
	sizeThatFits.height += 2.0 * MONDimensionsSmallPadding;
	sizeThatFits.height += CGRectGetHeight(self.titleLabel.frame);
	sizeThatFits.height += CGRectGetHeight(self.textView.frame);
	return sizeThatFits;
}

@end
