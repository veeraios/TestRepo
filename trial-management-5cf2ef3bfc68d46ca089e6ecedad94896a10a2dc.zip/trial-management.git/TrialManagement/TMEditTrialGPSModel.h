#import <Foundation/Foundation.h>
#import "MapKit/MapKit.h"
#import "TMCoordinatesLocationEnum.h"
#import "TMTrialModel.h"

@protocol TMEditTrialGPSModelDelegate <NSObject>

- (void) evt_addAnnotation:(MKPointAnnotation *)annotation;
- (void) evt_removeAnnotation:(MKPointAnnotation *)annotation;
- (void) evt_addPolygon:(MKPolygon *)polygon;
- (void) evt_removePolygon:(MKPolygon *)polygon;
- (void) evt_updateZoomRect:(MKMapRect)zoomRect;
- (void) evt_updateToCurrentLocation:(TMCoordinatesLocation)location latitude:(NSString *)latitude longitude:(NSString *)longitude;

@end

@interface TMEditTrialGPSModel : NSObject

- (instancetype) initWithTrialModel:(TMTrialModel *)trialModel;
- (void) updateLocation:(TMCoordinatesLocation) location latitude:(NSDecimalNumber *) latitude longitude:(NSDecimalNumber *) longitude;
- (void) doneUpdatingValue:(NSString *)value;
- (void) updateToCurrentLocation: (TMCoordinatesLocation)location;
- (void) setAllCoordinates;
- (BOOL) isAccuracyAcceptable:(double)accuracy;
- (void) deleteAllGPSPoints;
- (void) deleteInvalidCoordinates;

@property (nonatomic, weak) NSObject<TMEditTrialGPSModelDelegate> *delegate;

@end
