//
//  NSManagedObject+MONClone.m
//  TrialManagement
//
//  Created by GADIRAJU, PRANEETH [AG/1000] on 12/8/14.
//  Copyright (c) 2014 Monsanto. All rights reserved.
//

#import "NSManagedObject+MONClone.h"

static const NSDictionary *DataModelTraversalDictionary = nil;

@implementation NSManagedObject (MONClone)

-(NSManagedObject *)cloneInContext:(NSManagedObjectContext *)context
       withDataModelTraversalRules:(NSDictionary *)dataModelTraversalRulesDictionary {
    DataModelTraversalDictionary = dataModelTraversalRulesDictionary;
    
    NSManagedObject *toReturn = [self cloneInContext:context
                                     withCopiedCache:[NSMutableDictionary dictionary]];
    
    return toReturn;
}

- (NSManagedObject *)cloneInContext:(NSManagedObjectContext *)context
                    withCopiedCache:(NSMutableDictionary *)alreadyCopied {
    NSString *entityName = [[self entity] name];
    
    NSManagedObject *entityToClone = [alreadyCopied objectForKey:[self objectID]];
    if (entityToClone != nil) {
        return entityToClone;
    }
    
    entityToClone = [NSEntityDescription insertNewObjectForEntityForName:entityName inManagedObjectContext:context];
    [alreadyCopied setObject:entityToClone forKey:[self objectID]];
    
    for (NSString *attr in [[NSEntityDescription entityForName:entityName inManagedObjectContext:context] attributesByName]) {
        [entityToClone setValue:[self valueForKey:attr] forKey:attr];
    }
    
    NSDictionary *relationships = [[NSEntityDescription entityForName:entityName inManagedObjectContext:context] relationshipsByName];
    NSArray *validRelationsForEntity = [DataModelTraversalDictionary valueForKey:entityName];
    
    if(validRelationsForEntity) {
        for (NSString *relName in [relationships allKeys]){
            NSRelationshipDescription *rel = [relationships objectForKey:relName];
            NSString *keyName = rel.name;
            
            if([validRelationsForEntity containsObject:keyName]) {
                if ([rel isToMany]) {
                    NSMutableSet *sourceSet = [self mutableSetValueForKey:keyName];
                    NSMutableSet *clonedSet = [entityToClone mutableSetValueForKey:keyName];
                    for(NSManagedObject *relatedObject in sourceSet) {
                        NSManagedObject *clonedRelatedObject = [relatedObject cloneInContext:context withCopiedCache:alreadyCopied];
                        if (clonedRelatedObject != nil) {
                            [clonedSet addObject:clonedRelatedObject];
                        }
                    }
                } else {
                    NSManagedObject *relatedObject = [self valueForKey:keyName];
                    
                    if (relatedObject) {
                        NSManagedObject *clonedRelatedObject = [relatedObject cloneInContext:context withCopiedCache:alreadyCopied];
                        
                        if (clonedRelatedObject != nil) {
                            [entityToClone setValue:clonedRelatedObject forKey:keyName];
                        }
                    }
                }
            }
        }
    }
    
    return entityToClone;
}

@end
