#import "MONSearchTableViewCellProtocol.h"
#import "TMGrower.h"

@interface TMCooperatorTableViewCell : UITableViewCell <MONSearchTableViewCellProtocol>

- (void)setSearchResult:(id <MONSearchResult>)searchResult;

- (NSString *)cooperatorName;
@end