#import "TMEditTrialPlantingView.h"
#import "MONHeaderView.h"
#import "MONDimensions.h"
#import "UIColor+MONThemeColorProvider.h"

static NSString * const CardTitlePreviousCrop = @"Previous Crop";
static NSString * const CardTitleSoilTexture = @"Soil Texture";
static NSString * const CardTitleTillageSystem = @"Tillage System";
static NSString * const CardTitlePlantingRate = @"Planting Rate";
static NSString * const CardTitleUnitOfMeasurement = @"Unit of Measurement";
static NSString * const CardTitleTiled = @"Tiled";
static NSString * const CardTitleNumberOfRows = @"Number of Rows";
static NSString * const CardTitleRowSpacing = @"Row Spacing";
static NSString * const CardTitleComments = @"Comments";
static NSString * const CardTitleDirections = @"Directions";
static NSString * const CardTitlePlantingDate = @"Planting Date";

@interface TMEditTrialPlantingView ()

@property (nonatomic) UICollectionView *collectionView;
@property (nonatomic) MONHeaderView *headerView;

@end

@implementation TMEditTrialPlantingView

- (instancetype)initWithCollectionView:(UICollectionView *)collectionView {
	self = [super init];
	if (self) {
		
		self.collectionView = collectionView;
		self.collectionView.backgroundColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeBackground];
		self.collectionView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
		self.collectionView.contentInset = UIEdgeInsetsMake(MONDimensionsSmallPadding, MONDimensionsSmallPadding, MONDimensionsSmallPadding, MONDimensionsSmallPadding);
		[self addSubview:self.collectionView];
		
		self.headerView = [[MONHeaderView alloc] init];
		[self.headerView setTitle:@"Planting Information"];
		[self addSubview:self.headerView];
	}
	return self;
}

- (void)layoutSubviews {
	[super layoutSubviews];
	
	[self.headerView sizeToFit];
	self.headerView.frame = CGRectMake(0.0, 0.0, CGRectGetWidth(self.bounds), CGRectGetHeight(self.headerView.frame));

	self.collectionView.frame = CGRectMake(0.0,
										   CGRectGetMaxY(self.headerView.frame),
										   CGRectGetWidth(self.bounds),
										   CGRectGetHeight(self.bounds) - CGRectGetMaxY(self.headerView.frame));

}

@end
