//
//  TMProductsSearchTable.m
//  TrialManagement
//
//  Created by SINGH, SUPREET [AG/1000] on 11/10/14.
//  Copyright (c) 2014 Monsanto. All rights reserved.
//

#import "TMFilterProductsTable.h"
#import "TMEntryTableViewHeaderView.h"
#import "TMEntryTableViewCell.h"

static const CGFloat SearchResultHeaderRowHeight = 40.0;
static const CGFloat SearchResultRowHeight = 44.0;

@interface TMFilterProductsTable()

@property (nonatomic) TMFilterProductsModel *filterProductsModel;

@end

@implementation TMFilterProductsTable

-(instancetype)initWithFilterProductsModel:(TMFilterProductsModel *)filterProductsModel {
    self = [super init];
    if (self) {
        self.filterProductsModel = filterProductsModel;
    }
    return self;
}

#pragma mark - UITableViewDataSource Methods

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    TMEntryTableViewCell *cell = (TMEntryTableViewCell *)[tableView dequeueReusableCellWithIdentifier:NSStringFromClass([TMEntryTableViewCell class]) forIndexPath:indexPath];
    NSDictionary *entryDictionary = [self.filterProductsModel.searchResults objectAtIndex:indexPath.row];
    [cell setBrandText:[entryDictionary valueForKey:@"brandName"]];
    [cell setProductText:[entryDictionary valueForKey:@"productName"]];
    NSNumber *maturityRatingNumber = [entryDictionary valueForKey:@"maturityRating"];
    [cell setRMText:[NSString stringWithFormat:@"%.1f", [maturityRatingNumber floatValue]]];
    [cell setTraitText:[entryDictionary valueForKey:@"traitName"]];
    [cell useAlternateBackgroundColor:(indexPath.row % 2 == 0)];
    return cell;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [self.filterProductsModel.searchResults count];
}

#pragma mark - UITableViewDelegate Methods

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    return [[TMEntryTableViewHeaderView alloc] init];
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return SearchResultHeaderRowHeight;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return SearchResultRowHeight;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    [cell setSelected:YES];
    [self.delegate didSelectProduct];
}

- (void)tableView:(UITableView *)tableView didDeselectRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    [cell setSelected:NO];
}

@end
