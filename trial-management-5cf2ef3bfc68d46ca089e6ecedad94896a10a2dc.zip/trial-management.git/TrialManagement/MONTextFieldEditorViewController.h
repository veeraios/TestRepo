#import <UIKit/UIKit.h>

@interface MONTextFieldEditorViewController : UIViewController

@property (nonatomic) NSString *enteredText;

- (void)setHeaderText:(NSString *)headerText;

@end
