#import "NSObject+TMNullHelper.h"

@implementation NSObject (TMNullHelper)
-(id)safeObject {
	if(self == nil || [self isKindOfClass:[NSNull class]]) {
		return nil;
	}
	return self;
}
@end
