#import "MONDateTextFieldButton.h"
#import "MONFonts.h"
#import "MONDimensions.h"
#import "MONBorderedButton.h"

NSString * const MONDatePopoverButtonDidShowPopover = @"MONDatePopoverButtonDidShowPopover";
static const CGFloat PopupButtonWidth = 100.0f;

@interface MONDateTextFieldButton()<UITextFieldDelegate, MONDatePickerDelegate, UIPopoverControllerDelegate>
@property (nonatomic) UIPopoverController *popOverController;
@property (nonatomic, readwrite) NSDate *date;
@property (nonatomic) UIViewController *datePickerViewController;
@property (nonatomic) NSDateFormatter *dateFormatter;
@property (nonatomic) MONDatePicker *datePicker;
@property (nonatomic) MONBorderedButton *clearButton;
@property (nonatomic) MONButton *addButton;

@end

@implementation MONDateTextFieldButton

- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
		[self setPlaceholderText:@"Not Entered"];
		[self addTarget:self action:@selector(buttonTapped) forControlEvents:UIControlEventTouchUpInside];
		
		self.dateFormatter = [[NSDateFormatter alloc] init];
		[self.dateFormatter setDateFormat:@"MM-dd-yyyy"];
		
		self.datePicker	= [[MONDatePicker alloc] init];
		self.datePicker.delegate = self;
		self.datePicker.datePickerMode = UIDatePickerModeDate;

		self.datePickerViewController = [[UIViewController alloc] init];
		[self.datePickerViewController.view addSubview:self.datePicker];
		
		self.clearButton = [[MONBorderedButton alloc] init];
		[self.clearButton setBorderWidth:MONDimensionsThinBorderWidth];
		[self.clearButton addTarget:self action:@selector(clearButtonTapped) forControlEvents:UIControlEventTouchUpInside];
		[self.clearButton setTitle:@"CLEAR" forState:UIControlStateNormal];
		[self.datePickerViewController.view addSubview:self.clearButton];
		
		self.addButton = [[MONButton alloc] init];
		[self.addButton addTarget:self action:@selector(addButtonTapped) forControlEvents:UIControlEventTouchUpInside];
		[self.addButton setTitle:@"ADD" forState:UIControlStateNormal];
		[self.datePickerViewController.view addSubview:self.addButton];
	}
    return self;
}

- (void)setDate:(NSDate *)date {
	_date = date;
}

- (void)setDateTextField:(NSDate*)date {
	self.date = date;
	[self setTitle:[self formatDate:date] forState:UIControlStateNormal];
}

- (NSString *)formatDate:(NSDate *)date {
	NSString *formattedString = [self.dateFormatter stringFromDate:date];
	return formattedString;
}

- (void)clearButtonTapped {
	[self setTitle:@"" forState:UIControlStateNormal];
	self.date = nil;
    [self.popOverController dismissPopoverAnimated:YES];
}

- (void)addButtonTapped {
	if ([self.dateDelegate respondsToSelector:@selector(isSelectedDateValid:)]) {
		if (![self.dateDelegate isSelectedDateValid:self.datePicker.date]) {
			return;
		}
	}
	self.date = self.datePicker.date;
	[self.dateDelegate dateChanged:self.date];
	[self setTitle:[self formatDate:self.date] forState:UIControlStateNormal];
    [self.popOverController dismissPopoverAnimated:YES];
}

- (void)setMinimumDate:(NSDate *)minimumDate {
	self.datePicker.minimumDate = minimumDate;
}

- (void)setMaximumDate:(NSDate *)maximumDate {
	if (self.maximumDate) {
		self.date = self.maximumDate;
	} else {
		self.date = [NSDate date];
	}
	self.datePicker.maximumDate = self.date;
}

- (void)buttonTapped {
	[[NSNotificationCenter defaultCenter] postNotificationName:MONDatePopoverButtonDidShowPopover object:self];
	
	[self.clearButton sizeToFit];
	self.clearButton.frame = CGRectMake(MONDimensionsSmallPadding,
										CGRectGetMaxY(self.datePicker.frame) - MONDimensionsSmallPadding,
										PopupButtonWidth,
										CGRectGetHeight(self.clearButton.frame));
	
	[self.addButton sizeToFit];
	self.addButton.frame = CGRectMake(CGRectGetMaxX(self.datePicker.frame) - PopupButtonWidth - MONDimensionsSmallPadding,
									  CGRectGetMaxY(self.datePicker.frame) - MONDimensionsSmallPadding,
									  PopupButtonWidth,
									  CGRectGetHeight(self.addButton.frame));

	NSDate *pickerDate = self.date;
	if (self.date == nil) {
		pickerDate = [NSDate date];
	}
	[self.datePicker setDate:pickerDate];
	self.popOverController = [[UIPopoverController alloc] initWithContentViewController:self.datePickerViewController];
	self.popOverController.delegate = self;
	[self.popOverController setPopoverContentSize:CGSizeMake(CGRectGetWidth(self.datePicker.frame),
															 CGRectGetHeight(self.datePicker.frame) + CGRectGetHeight(self.clearButton.frame))];
	CGRect popoverPresetingRect = CGRectInset(self.bounds, 5.0, 5.0);
	[self.popOverController presentPopoverFromRect:popoverPresetingRect inView:self permittedArrowDirections:UIPopoverArrowDirectionLeft | UIPopoverArrowDirectionRight animated:YES];
}

- (void)showErrorMessage:(NSString *)errorMessage {
	UILabel *errorLabel = [[UILabel alloc] init];
	errorLabel.text = errorMessage;
	errorLabel.numberOfLines = 0;
	errorLabel.lineBreakMode = NSLineBreakByWordWrapping;
	errorLabel.font = [UIFont fontWithName:OpenSansLight size:16];
	errorLabel.textColor = [UIColor redColor];
	errorLabel.alpha = 1.0;
	CGSize errorLabelSizeThatFits = [errorLabel sizeThatFits:CGSizeMake(CGRectGetWidth(self.datePickerViewController.view.bounds) - 2.0 * MONDimensionsSmallPadding, CGFLOAT_MAX)];
	errorLabel.frame = CGRectMake(MONDimensionsSmallPadding,
								  CGRectGetMaxY(self.datePicker.frame) - errorLabelSizeThatFits.height - MONDimensionsSmallPadding,
								  errorLabelSizeThatFits.width,
								  errorLabelSizeThatFits.height);
	[self.datePickerViewController.view addSubview:errorLabel];
	[NSTimer scheduledTimerWithTimeInterval:5.0 target:self selector:@selector(fadeErrorLabel:) userInfo:errorLabel repeats:NO];
}

- (void)fadeErrorLabel:(NSTimer *)timer {
	UILabel *errorLabel = (UILabel*)timer.userInfo;
	[UIView animateWithDuration:0.5 animations:^{
		errorLabel.alpha = 0.0;
	}];
}

#pragma mark - MONDatePickerDelegate Methods

- (void)datePickerChanged:(MONDatePicker *)datePicker newDate:(NSDate *)newDate {
	self.date = newDate;
}

@end
