#import "MONTabController.h"
#import "TMTrialModel.h"
#import "TMPersistenceViewController.h"

@interface TMHarvestViewController : TMPersistenceViewController<MONTabController>

- (instancetype)initWithTrialModel:(TMTrialModel *)trialModel;

@end
