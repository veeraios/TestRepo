#import <UIKit/UIKit.h>

@protocol TMEditTrialValueUOMViewDelegate <NSObject>

- (void) evt_value:(NSString *)value selectedUnitOfMeasure:(NSString *)unitOfMeasure;

@end
	
@interface TMEditTrialValueUOMView : UIView

@property (nonatomic, weak) NSObject<TMEditTrialValueUOMViewDelegate> *delegate;

- (instancetype)init UNAVAILABLE_ATTRIBUTE;
- (instancetype)initWithTitle:(NSString *)title 
			   unitOfMeasures:(NSArray *)unitOfMeasures 
						value:(double)value 
	   selectedUnitOfMeasure:(NSString *)selectedUnitOfMeasure;

@end
