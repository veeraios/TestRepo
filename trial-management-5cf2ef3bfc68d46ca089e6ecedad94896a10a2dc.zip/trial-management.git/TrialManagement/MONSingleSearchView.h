#import "MONHeaderView.h"
#import "TMCooperatorCategoryEnum.h"

@protocol MONSingleSearchDelegate <NSObject>
@optional
- (void)searchWithText:(NSString*)searchText;
- (void)requestNewButtonTapped:(CooperatorCategory)category;
@end

@interface MONSingleSearchView : UIView

- (instancetype)initWithSearchResultsTableView:(UITableView *)searchResultsTableView pageTitle:(NSString*)pageTitle tableTitle:(NSString*)tableTitle;
- (void)setNumberOfSearchResults:(NSUInteger)numberOfSearchResults;
@property (nonatomic,weak) id<MONSingleSearchDelegate> delegate;
@end
