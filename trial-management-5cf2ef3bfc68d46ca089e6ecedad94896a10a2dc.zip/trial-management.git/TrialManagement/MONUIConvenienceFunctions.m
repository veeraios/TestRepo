#import "MONUIConvenienceFunctions.h"

CGFloat MONUIScreenGetScreenScale() {
	static CGFloat screenScale = 1.0;
	static dispatch_once_t onceToken;
	dispatch_once(&onceToken, ^{
		screenScale = [[UIScreen mainScreen] scale];
	});
	return screenScale;
}

CGFloat MONUIScreenRoundToScreenScale(CGFloat value) {
	CGFloat screenScale = MONUIScreenGetScreenScale();
	return roundf(value * screenScale) / screenScale;
}

CGRect MONRectRoundedToScreenScale(CGRect rect) {
	CGRect newRect = rect;
	newRect.origin.x = MONUIScreenRoundToScreenScale(CGRectGetMinX(rect));
	newRect.origin.y = MONUIScreenRoundToScreenScale(CGRectGetMinY(rect));
	newRect.size.width = MONUIScreenRoundToScreenScale(CGRectGetWidth(rect));
	newRect.size.height = MONUIScreenRoundToScreenScale(CGRectGetHeight(rect));
	return newRect;
}

CGRect MONRectForSizeCenteredInRect(CGSize size, CGRect inRect) {
	CGRect rect;
	rect.origin.x = MONUIScreenRoundToScreenScale(CGRectGetMinX(inRect) + CGRectGetWidth(inRect) / 2.0 - size.width / 2.0);
	rect.origin.y = MONUIScreenRoundToScreenScale(CGRectGetMinY(inRect) + CGRectGetHeight(inRect) / 2.0 - size.height / 2.0);
	rect.size.width = size.width;
	rect.size.height = size.height;
	return rect;
}
