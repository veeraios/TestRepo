//
//  TMMergePathValueSetter.swift
//  TrialManagement
//
//  Created by WAIDMANN, ALAN [AG/1000] on 2/25/15.
//  Copyright (c) 2015 Monsanto. All rights reserved.
//

import UIKit

class TMMergePathValueSetter: NSObject {
    
    private var valueToSet : Any?
    private var currentObjectPath : String = ""
    private var uidToObjectCache = [String : NSManagedObject]()
    private var refDataSearchCache = [String : NSSet]()
    
    private let context : MONContextProtocol
    private let inclusionRules : NSSet
    private let group : TMMergeGroup
    private let rootObject : NSManagedObject
    
    init(context: MONContextProtocol, inclusionRules: NSSet, mergeGroup: TMMergeGroup, rootObject: NSManagedObject) {
        self.context = context
        self.inclusionRules = inclusionRules
        self.group = mergeGroup
        self.rootObject = rootObject
        super.init()
    }
    
    func setAllResolvedValues() {
        group.mergeValues.forEach( { [unowned self] mergeValue -> () in
            self.valueToSet = mergeValue.resolvedValue
            self.currentObjectPath = self.removeAttributePathComponent(mergeValue.path)
            
            self.set(mergeValue.path.componentsSeparatedByString(PathSeparator), currentObject: self.rootObject)
        })

        let lengthSortedRefDataCacheKeys = prepareRefDataKeysForSave()
        
        for key in lengthSortedRefDataCacheKeys {
            valueToSet = refDataSearchCache[joinPathComponents(key)]!.anyObject() as NSManagedObject
            set(key, currentObject: rootObject)
        }
    }
    
    private func set(pathComponents: [String], currentObject: NSManagedObject) {
        
        if let headComponent = pathComponents.first {
            
            switch currentObject.entity.propertiesByName[headComponent] {
            
            case let attribute as NSAttributeDescription:
                if inclusionRules.member(currentObject.entity.managedObjectClassName) == nil {
                    self.reduceRefDataSetFor(headComponent, value: convertToAppropriateType(valueToSet)!, className: currentObject.entity.managedObjectClassName)
                } else {
                    currentObject.setValue(convertToAppropriateType(valueToSet), forKey: headComponent)
                }
                
            case let relationship as NSRelationshipDescription where !relationship.toMany:
                
                if valueToSet is NSManagedObject && pathComponents.count == 1 {
                    currentObject.setValue(convertToAppropriateType(valueToSet), forKey: headComponent)
                } else {
                    var destinationObject : NSManagedObject
                    
                    if let foundObject = currentObject.valueForKey(headComponent) as? NSManagedObject {
                        destinationObject = foundObject
                    } else {
                        MONLogger.logError("Creating object of type: \(relationship.destinationEntity!.managedObjectClassName) on \(currentObject.entity.managedObjectClassName)")
                        let createdObject = context.attachObject( NSClassFromString(relationship.destinationEntity!.managedObjectClassName) ) as NSManagedObject
                        currentObject.setValue(createdObject, forKey: headComponent)
                        destinationObject = createdObject
                    }
                    set(pathComponents.tail(), currentObject: destinationObject)
                }
            
            case let relationship as NSRelationshipDescription where relationship.toMany:
                if let explicitUID = pathComponents.tail().first {
                    var destinationObject : NSManagedObject
                    
                    if let cachedObject = uidToObjectCache[explicitUID] {
                        destinationObject = cachedObject
                    } else {
                        let uidComponents = relationship.destinationEntity?.userInfo?[UserInfoUIDKey] as String
                        
                        if let foundObject = TMMergeManagedObjectLocator.findManagedObjectWithPartialKeys(uidComponents, explicitUID: explicitUID, entity: relationship.destinationEntity!, relationObjects: currentObject.valueForKey(headComponent) as NSSet) {
                            destinationObject = foundObject
                        } else {
                            MONLogger.logError("Creating object of type: \(relationship.destinationEntity!.managedObjectClassName) with UID: \(explicitUID) on \(currentObject.entity.managedObjectClassName)")
                            let createdObject = context.attachObject( NSClassFromString(relationship.destinationEntity!.managedObjectClassName) ) as NSManagedObject
                            let existingSet = currentObject.valueForKey(headComponent) as NSSet
                            currentObject.setValue(existingSet.setByAddingObject(createdObject), forKey: headComponent)
                            destinationObject = createdObject
                        }
                        uidToObjectCache[explicitUID] = destinationObject
                    }
                    set(pathComponents.tail().tail(), currentObject: destinationObject)
                }
                
            default:
                MONLogger.logError("\(headComponent) is not a valid key for \(currentObject.entity.managedObjectClassName)")
            }
        }
    }
    
    private func prepareRefDataKeysForSave() -> [[String]] {
        return removeAllChildRefDataKeys( self.refDataSearchCache.keys.array.map( {$0.componentsSeparatedByString(PathSeparator)} ).sorted( {$0.count < $1.count} ) )
    }

    private func removeAllChildRefDataKeys(refDataKeys: [[String]]) -> [[String]] {
        if let parentRefDataKey = refDataKeys.first {
            return [parentRefDataKey] + removeAllChildRefDataKeys( refDataKeys.tail().filter( {[unowned self] in !self.joinPathComponents($0).hasPrefix(self.joinPathComponents(parentRefDataKey))} ) )
        } else {
            return []
        }
    }
    
    private func removeAttributePathComponent(objectPath: String) -> String {
        var separatedPath : [String] = objectPath.componentsSeparatedByString(PathSeparator)
        separatedPath.removeLast()
        return self.joinPathComponents(separatedPath)
    }
    
    private func joinPathComponents(pathComponents: [String]) -> String {
        return pathComponents.reduce("", combine: { (countElements($0) == 0 ? $0 : $0 + PathSeparator) + $1} )
    }
    
    private func reduceRefDataSetFor(attributeKey: String, value: AnyObject, className: String) {
        var refDataPred : NSPredicate
        if let valueAsInt = value as? NSNumber {
            refDataPred = NSPredicate(format: "\(attributeKey) = %ld", valueAsInt.integerValue )!
        } else {
            refDataPred = NSPredicate(format: "\(attributeKey) = '\(value)'")!
        }
        
        if let cachedSet = refDataSearchCache[self.currentObjectPath] {
            refDataSearchCache[self.currentObjectPath] = cachedSet.filteredSetUsingPredicate(refDataPred)
        } else {
            refDataSearchCache[self.currentObjectPath] = NSSet(array: context.findWithPredicate(className, wherePredicate: refDataPred, orderBy: attributeKey, ascending: true))
        }
    }
    
    private func convertToAppropriateType(value: Any?) -> AnyObject? {
        switch value {
        case let valueAsManagedObject as NSManagedObject:
            return valueAsManagedObject
        case let valueAsString as String:
            return valueAsString
        case let valueAsNumber as NSNumber:
            return valueAsNumber
        case let valueAsDecimal as NSDecimalNumber:
            return valueAsDecimal
        case let valueAsDate as NSDate:
            return valueAsDate
        default:
            return nil
        }
    }
}
