#import <UIKit/UIKit.h>

@interface TMCooperatorSearchResultsTableViewHeaderView : UIView

@end
