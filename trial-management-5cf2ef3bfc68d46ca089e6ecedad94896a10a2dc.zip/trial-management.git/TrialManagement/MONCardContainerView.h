#import <UIKit/UIKit.h>

@interface MONCardContainerView : UIView

@property (nonatomic, readonly) UIView *contentContainerView;

- (void)setBorderColor:(UIColor *)borderColor;

@end
