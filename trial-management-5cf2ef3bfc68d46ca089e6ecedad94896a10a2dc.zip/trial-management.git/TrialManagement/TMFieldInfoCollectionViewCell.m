#import "TMFieldInfoCollectionViewCell.h"
#import "MONCardContainerView.h"
#import "MONDimensions.h"
#import "TMFieldInfoObservationContainerView.h"
static const CGFloat HeaderDefaultHeight = 64.0;

@interface TMFieldInfoCollectionViewCell ()

@property (nonatomic) MONCardContainerView *backgroundCardContainerView;
@property (nonatomic) TMFieldInfoObservationContainerView *fieldInfoEditContainerView;

@end

@implementation TMFieldInfoCollectionViewCell

- (id)initWithFrame:(CGRect)frame {
	self = [super initWithFrame:frame];
	if (self) {
		self.backgroundCardContainerView = [[MONCardContainerView alloc] init];
		[self.contentView addSubview:self.backgroundCardContainerView];
	}
	return self;
}

- (void)layoutSubviews {
	[super layoutSubviews];
	self.backgroundCardContainerView.frame = self.contentView.bounds;
		
	self.fieldInfoEditContainerView.frame = CGRectMake(MONDimensionsSmallPadding,
													MONDimensionsLargePadding,
													 CGRectGetWidth(self.backgroundCardContainerView.bounds) - 2.0 * MONDimensionsSmallPadding,
													 CGRectGetHeight(self.backgroundCardContainerView.bounds) - MONDimensionsSmallPadding);
}

- (CGSize)sizeThatFits:(CGSize)size {
	CGSize sizeThatFits = CGSizeMake(size.width, 0.0);
	
	sizeThatFits.height += HeaderDefaultHeight;
	
	CGSize harvestEditContainerViewSize = [self.fieldInfoEditContainerView sizeThatFits:CGSizeMake(size.width, size.height - HeaderDefaultHeight)];
	sizeThatFits.height += harvestEditContainerViewSize.height;
	return sizeThatFits;
}

- (void)setFieldInfoEditContainerView:(TMFieldInfoObservationContainerView *)fieldInfoEditContainerView {
	[_fieldInfoEditContainerView removeFromSuperview];
	
	_fieldInfoEditContainerView = fieldInfoEditContainerView;

	[self.backgroundCardContainerView addSubview:fieldInfoEditContainerView];
	[self setNeedsLayout];
}

-(void)setModel:(TMFieldObservationModel*)model {
	[self setFieldInfoEditContainerView:[[TMFieldInfoObservationContainerView alloc] initWithFieldObservationModel:model]];
}
@end
