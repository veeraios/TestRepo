#import "TMCooperatorTableViewCell.h"
#import "MONDimensions.h"
#import "MONUIConvenienceFunctions.h"
#import "MONFonts.h"
#import "MONLabel.h"
#import "UIColor+MONThemeColorProvider.h"
#import "TMCooperatorTableViewCellFieldDimensions.h"
#import "TMCooperatorSearchResult.h"

@interface TMCooperatorTableViewCell ()
@property(nonatomic) MONLabel *cooperatorLabel;
@property(nonatomic) MONLabel *stateLabel;
@property(nonatomic) MONLabel *cityLabel;
@property(nonatomic) MONLabel *postalCodeLabel;
@property(nonatomic) UIColor *unselectedBackgroundColor;
@end

@implementation TMCooperatorTableViewCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
  self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
  if (self) {
    self.backgroundColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeBackground];

    self.cooperatorLabel = [self defaultLabel];
    [self addSubview:self.cooperatorLabel];

    self.stateLabel = [self defaultLabel];
    [self addSubview:self.stateLabel];

    self.cityLabel = [self defaultLabel];
    [self addSubview:self.cityLabel];

    self.postalCodeLabel = [self defaultLabel];
    [self addSubview:self.postalCodeLabel];

    self.layer.borderColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeBorder].CGColor;
    self.layer.borderWidth = MONDimensionsThinBorderWidth / 2;
    self.layer.cornerRadius = MONDimensionsCornerRadius;
  }
  return self;
}

- (MONLabel *)defaultLabel {
  MONLabel *label = [[MONLabel alloc] init];
  label.lineBreakMode = NSLineBreakByTruncatingTail;
  label.fontName = OpenSans;
  return label;
}

- (void)layoutSubviews {
  [super layoutSubviews];

  [self layoutLabelWithLabel:self.cooperatorLabel offsetLabel:nil labelWidthPercent:CooperatorLabelWidthPercent];
  [self layoutLabelWithLabel:self.stateLabel offsetLabel:self.cooperatorLabel labelWidthPercent:StateLabelWidthPercent];
  [self layoutLabelWithLabel:self.cityLabel offsetLabel:self.stateLabel labelWidthPercent:CityLabelWidthPercent];
  [self layoutLabelWithLabel:self.postalCodeLabel offsetLabel:self.cityLabel labelWidthPercent:PostalCodeLabelWidthPercent];
}

- (void)layoutLabelWithLabel:(MONLabel *)label offsetLabel:(MONLabel *)offsetLabel labelWidthPercent:(CGFloat)labelWidthPercent {
  [label sizeToFit];
  CGRect rectInset = CGRectInset(self.bounds, MONDimensionsSmallPadding, MONDimensionsSmallPadding);
  label.frame = CGRectMake(
      CGRectGetMinX(rectInset) + (offsetLabel ? CGRectGetMaxX(offsetLabel.frame) : 0),
      MONUIScreenRoundToScreenScale((CGFloat) ((CGRectGetMaxY(self.bounds) - CGRectGetHeight(label.frame)) / 2.0)),
      (CGRectGetWidth(rectInset) / 100 * labelWidthPercent) - (offsetLabel ? MONDimensionsSmallPadding : 0),
      CGRectGetHeight(label.frame)
  );
}

- (void)setCooperatorText:(NSString *)cooperatorText {
  self.cooperatorLabel.text = cooperatorText;
}

- (void)setPostalCodeText:(NSString *)postalCodeText {
  self.postalCodeLabel.text = postalCodeText;
}

- (void)setStateText:(NSString *)stateText {
  self.stateLabel.text = stateText;
}

- (void)setCityText:(NSString *)cityText {
  self.cityLabel.text = cityText;
}

- (void)setSearchResult:(id <MONSearchResult>)searchResult {
  TMCooperatorSearchResult *result = (TMCooperatorSearchResult *) searchResult;
  [self setCooperatorText:result.cooperator];
  [self setStateText:result.state];
  [self setCityText:result.city];
  [self setPostalCodeText:result.postalCode];
}

- (NSString *)cooperatorName {
  return self.cooperatorLabel.text;
}

- (void)useAlternateBackgroundColor:(BOOL)useAlternateBackgroundColor {
  if (useAlternateBackgroundColor) {
    self.unselectedBackgroundColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeBackgroundAlternate];
  } else {
    self.unselectedBackgroundColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeBackground];
  }

  self.backgroundColor = self.unselectedBackgroundColor;
}

- (void)setSelected:(BOOL)selected {
  [super setSelected:selected];

  UIColor *textColor = nil;

  if (selected) {
    self.selectedBackgroundView = [[UIView alloc] init];
    self.selectedBackgroundView.backgroundColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeSelectedBackground];
    textColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeSelectedText];
  } else {
    self.backgroundColor = self.unselectedBackgroundColor;
    textColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeText];
  }

  self.cooperatorLabel.textColor = textColor;
  self.stateLabel.textColor = textColor;
  self.cityLabel.textColor = textColor;
  self.postalCodeLabel.textColor = textColor;
}

@end