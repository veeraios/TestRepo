#import "NSArray+TMSortArray.h"

@implementation NSArray (TMSortArray)

-(NSArray*)sortByKeyPath:(NSString*)keyPath {
	return [self sortedArrayUsingDescriptors:
			@[[NSSortDescriptor sortDescriptorWithKey:keyPath
											ascending:YES]]];
}

-(NSArray*)sortIntegerStrings {
	return [self sortedArrayUsingDescriptors:
	 @[[NSSortDescriptor sortDescriptorWithKey:@"integerValue"
									 ascending:YES]]];
}

-(NSArray*)sortStringArray {
	return [self sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
}
@end
