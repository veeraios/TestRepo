#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
#import "TMCoordinatesLocationEnum.h"

@protocol TMEditTrialGPSViewDelegate <NSObject>

- (void)evt_updatedLocation:(TMCoordinatesLocation)location latitude:(NSDecimalNumber *)latitude longitude:(NSDecimalNumber *)longitude;
- (void)evt_doneUpdatingValue:(NSString *)value;
- (void)evt_updateToCurrentLocation:(TMCoordinatesLocation)location;
- (void)evt_deleteAllGPSPoints;

@end

@interface TMEditTrialGPSView : UIView

@property (nonatomic, weak) NSObject<TMEditTrialGPSViewDelegate> *delegate;

- (instancetype)initWithHeaderButtons:(NSArray *)headerButtons;
- (void)removeAnnotation:(id<MKAnnotation>)annotation;
- (void)addAnnotation:(id<MKAnnotation>)annotation;
- (void)removeOverlay:(id<MKOverlay>)overlay;
- (void)addOverlay:(id<MKOverlay>)overlay;
- (void)setCoordinates:(NSString *)latitude1 longitude1:(NSString*)longitude1
			latitude2:(NSString *)latitude2 longitude2:(NSString*)longitude2
			latitude3:(NSString *)latitude3 longitude3:(NSString*)longitude3
			latitude4:(NSString *)latitude4 longitude4:(NSString*)longitude4;
- (void)setCurrentLatitude:(double)latitude longitude:(double)longitude isAccuracyAcceptable:(BOOL)isAccuracyAcceptable;
- (void)setLatitude:(NSString *)latitude longitude:(NSString *)longitude forLocation:(TMCoordinatesLocation)location;
- (void)updateZoomRect:(MKMapRect)zoomRect;
- (void)startTrackingUserLocation;
- (void)stopTrackingUserLocation;

@end
