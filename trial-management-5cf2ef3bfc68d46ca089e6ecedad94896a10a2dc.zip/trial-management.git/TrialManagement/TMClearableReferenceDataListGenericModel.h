//
//  TMClearableReferenceDataListGenericModel.h
//  TrialManagement
//
//  Created by SINGH, SUPREET [AG/1000] on 12/2/14.
//  Copyright (c) 2014 Monsanto. All rights reserved.
//

#import "TMReferenceListDataModel.h"

@interface TMClearableReferenceDataListGenericModel : NSObject<TMReferenceListDataModel>

@property (nonatomic, readonly) NSString *placeholderText;

- (instancetype)initWithDataArray:(NSArray*)dataArray nameBlock:(NSString*(^)(NSInteger))nameBlock placeholderText:(NSString *)clearText;

@end
