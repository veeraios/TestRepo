#import "TMEntryRepository.h"

@implementation TMEntryRepository

- (TMEntry *)createEntryWithEntryId:(NSNumber *)entryId
							 number:(NSNumber *)number
							product:(TMProduct *)product
						  treatment:(TMTreatment *)treatment {
	TMEntry *entry = nil;
	//this won't work and probably the cause of the entry number out of order bug.
	//we don't have an entryId until we post, so it will never find the one created originally by core-data and they'll
	//be orphaned.  We could rely on productId and entryNumber, but that's dangerous.
	//we can probably get by on user entryNumber ONLY for the syncFromResponse condition, because the response happens
	//right after the request, we can be safe they haven't re-ordered the entires (or something else re-ordered them on the web).
	//it would be better if we could find a more robust way, but given the data model, that might be all we have.
	if (entryId) {
		entry = [[self find:[NSString stringWithFormat:@"entryId == %@", entryId]] firstObject];
	}
	if (entry == nil) {
		entry = [self create];
		entry.entryId = entryId;
		entry.number = number;
		entry.product = product;
		entry.treatment = treatment;
	}

	return entry;
}
@end
