
#import "TMImagePickerController.h"

@interface TMImagePickerController ()

@end

@implementation TMImagePickerController

- (BOOL)shouldAutorotate {
	return NO;
}

@end
