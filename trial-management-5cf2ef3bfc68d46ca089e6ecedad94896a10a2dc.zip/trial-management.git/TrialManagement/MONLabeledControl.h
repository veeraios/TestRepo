#import "MONLabel.h"
#import <UIKit/UIKit.h>

typedef NS_ENUM(NSInteger, MONLabeledControlLabelLocation) {
	MONLabeledControlLabelLocationTop,
	MONLabeledControlLabelLocationLeft,
	MONLabeledControlLabelLocationNone
};

@interface MONLabeledControl : UIView

@property (nonatomic, readonly) MONLabel *label;
@property (nonatomic) UIView *controlView;
@property (nonatomic) MONLabeledControlLabelLocation labelLocation;

- (void)setLabelText:(NSString *)labelText;
- (void)setLabelWidth:(CGFloat)labelWidth;
//- (void)setControlViewWidth:(CGFloat)controlViewWidth;

@end
