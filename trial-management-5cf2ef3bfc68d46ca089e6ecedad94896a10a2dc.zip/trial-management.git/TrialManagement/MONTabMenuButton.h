#import "MONTabButton.h"

@interface MONTabMenuButton : MONTabButton

@end
