import UIKit

protocol MONFacetViewActionDelegate: class {
    func removeFacetButtonTapped(facetView: MONFacetView)
}

class MONFacetView: UIView {
    weak var delegate: MONFacetViewActionDelegate?
    private let facetText = UITextView()
    private let removeFacetIcon = UIImageView()
    
    private var scaledOffset: CGFloat = 0.0
    private var scaledRemoveButtonHeight: CGFloat = 0.0
    
    init(text: String?) {
        facetText.text = text
        facetText.userInteractionEnabled = false
        
        removeFacetIcon.image = UIImage(named: "ui-icon-remove-small")
        removeFacetIcon.contentMode = .ScaleAspectFit
        
        super.init(frame: CGRect.zeroRect)
        
        addGestureRecognizer(UITapGestureRecognizer(target: self, action: "removeFacetButtonTapped"))
        
        backgroundColor = UIColor(forThemeComponentType: MONThemeComponentTypeButtonBackground)
        facetText.backgroundColor = UIColor.clearColor()
        facetText.textColor = UIColor.whiteColor()
        
        addSubview(facetText)
        addSubview(removeFacetIcon)
    }
    
    required init(coder aDecoder: NSCoder) {fatalError("init(coder:) has not been implemented")}
    
    override func layoutSubviews() {
        super.layoutSubviews()
        layer.cornerRadius = scaledOffset
        
        facetText.sizeToFit()
        
        facetText.frame = CGRectMake(scaledOffset,
            (CGRectGetHeight(frame) - CGRectGetHeight(facetText.bounds))/2.0,
            CGRectGetWidth(facetText.bounds),
            CGRectGetHeight(facetText.bounds))

        removeFacetIcon.frame = CGRectMake(CGRectGetMaxX(facetText.frame),
            (CGRectGetHeight(frame) - scaledRemoveButtonHeight)/2.0,
            scaledRemoveButtonHeight,
            scaledRemoveButtonHeight)
    }
    
    func removeFacetButtonTapped() {
        delegate?.removeFacetButtonTapped(self)
    }
    
    override func sizeThatFits(size: CGSize) -> CGSize {
        scaledOffset = ceil(0.1 * size.height)
        scaledRemoveButtonHeight = size.height - 4.0*scaledOffset
        
        var sizeThatFits = size
        facetText.sizeToFit()
        
        sizeThatFits.width = CGRectGetWidth(facetText.bounds) + scaledRemoveButtonHeight + 2.0*scaledOffset
        sizeThatFits.height = scaledRemoveButtonHeight + 2.0*scaledOffset
        return sizeThatFits
    }
    
    func setTextSize(size: CGFloat) {
        facetText.font = facetText.font.fontWithSize(size)
    }
}
