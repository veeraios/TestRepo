//
//  TMCrop.m
//  TrialManagement
//
//  Created by WAIDMANN, ALAN [AG/1000] on 7/15/15.
//  Copyright (c) 2015 Monsanto. All rights reserved.
//

#import "TMCrop.h"
#import "TMObservationCalculation.h"
#import "TMObservationReferenceData.h"
#import "TMProtocol.h"
#import "TMReportReferenceData.h"
#import "TMRowSpacingUnitOfMeasure.h"
#import "TMTrait.h"
#import "TMTreatment.h"
#import "TMTrial.h"
#import "TMUnitOfMeasure.h"
#import "TMUser.h"


@implementation TMCrop

@dynamic cropId;
@dynamic name;
@dynamic relativeMaturityIncrement;
@dynamic relativeMaturityMax;
@dynamic relativeMaturityMin;
@dynamic observationCalculations;
@dynamic observationReferenceData;
@dynamic protocols;
@dynamic reportReferenceData;
@dynamic rowSpacingUnitOfMeasures;
@dynamic traits;
@dynamic treatments;
@dynamic trials;
@dynamic unitOfMeasures;
@dynamic users;

@end
