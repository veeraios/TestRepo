#import "TMHarvestModel.h"
#import "NSDate+MONDateHelper.h"
#import "NSArray+TMBlocks.h"
#import "TMEntryModel.h"

@interface TMHarvestModel()

@property (nonatomic, readwrite) NSDate *harvestDate;
@property (nonatomic, readwrite) NSDate *plantingDate;

@end

@implementation TMHarvestModel
- (instancetype)initWithEntryModels:(NSArray *)entryModels
                        harvestDate:(NSDate *)harvestDate
                       plantingDate:(NSDate *)plantingDate {
	self = [super init];
	if(self) {
		self.entryModels = entryModels;
		self.harvestDate = harvestDate;
		self.plantingDate = plantingDate;
	}
	return self;
}

- (BOOL)isValidHarvestDate:(NSDate*)harvestDate {
	BOOL harvestDateIsValid = harvestDate != nil && self.plantingDate != nil && [harvestDate compare:[NSDate currentDateWithAddedDays:1]] == NSOrderedAscending && [harvestDate compare:self.plantingDate] == NSOrderedDescending;
	return harvestDateIsValid;
}

- (NSArray*)harvestYieldObservations {
	NSMutableArray *harvestYieldArray = [[NSMutableArray alloc] init];
	[self.entryModels arrayForEach:^id(TMEntryModel *whereObj) {
		[harvestYieldArray addObjectsFromArray:[whereObj harvestYieldObservations]];
		return harvestYieldArray;
	} where:^BOOL(TMEntryModel *whereObj) {
		return [[whereObj harvestYieldObservations] count] > 0;
	}];
	return harvestYieldArray;
}

- (NSArray*)moistureObservations {
	NSMutableArray *harvestYieldArray = [[NSMutableArray alloc] init];
	[self.entryModels arrayForEach:^id(TMEntryModel *whereObj) {
		[harvestYieldArray addObjectsFromArray:[whereObj harvestMoistureObservations]];
		return harvestYieldArray;
	} where:^BOOL(TMEntryModel *whereObj) {
		return [[whereObj harvestMoistureObservations] count] > 0;
	}];
	return harvestYieldArray;
}

@end
