#import "MONModalTableViewModel.h"
#import "TMTrialModel.h"

@interface TMEmailTableViewModel : NSObject<MONModalTableViewModel>
-(instancetype) initWithCounties:(NSArray*)counties;
@end
