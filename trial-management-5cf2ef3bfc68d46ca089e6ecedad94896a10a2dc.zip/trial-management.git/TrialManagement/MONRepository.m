#import "MONRepository.h"
#import "NSDictionary+MONDictionaryHelper.h"
#import "NSArray+TMNSArrayNSNull.h"
#import "TMUserManager.h"
#import "MONReflection.h"

@interface MONRepository()

@property (nonatomic) id<MONContextProtocol> context;
@property (nonatomic, assign) Class modelClass;
@property (nonatomic) NSPredicate *userPredicate;
@property (nonatomic) NSPredicate *userIdPredicate;
@property (nonatomic) NSPredicate *selectInPredicate;
@end


//TODO: Cache and reuse these predicates so they are not re-created everytime
@implementation MONRepository

static const int BatchSaveSize = 800;

- (id) initWithContext:(id<MONContextProtocol>) context withModel:(__unsafe_unretained Class)class{
    self = [super init];
    if (self) {
        self.context= context;
        self.modelClass = class;
		self.userPredicate = [NSPredicate predicateWithFormat:@"ANY users == $user"];
		self.userIdPredicate = [NSPredicate predicateWithFormat:@"userId = $theUserId"];
		self.selectInPredicate = [NSPredicate predicateWithFormat:@"($key IN $value)"];
    }
    return self;
}
-(Class)entity {
	return self.modelClass;
}

-(void)saveContext {
	[self.context saveChanges];
}

-(void)removeEntities:(Class)theClass where:(NSPredicate*)predicate {
	[self.context removeEntities:theClass where:predicate forUser:self.currentUser];
}

-(void)removeAll:(Class)classToUse {
	[self.context removeAllEntities:[classToUse description] forUser:self.currentUser];
}

-(void)removeAll {
	if([MONReflection class:self.modelClass hasProperty:@"users"]) {
		[self.context removeAllEntities:[self.modelClass description] forUser:self.currentUser];
	} else {
		[self.context removeAllEntities:[self.modelClass description]];
	}
}

-(NSManagedObject*)objectForId:(NSManagedObjectID*)objectId {
	return [self.context objectForId:objectId];
}

-(NSArray*)sortedEntitiesForUserBy:(NSString*)propertyToSortBy {
	return [self findWithPredicate:[self.userPredicate predicateWithSubstitutionVariables:@{@"user": self.currentUser}] orderBy:propertyToSortBy ascending:YES];
}

-(NSArray*)sortedEntitiesByName {
	return [self.context find:[self.modelClass description] orderBy:@"name" ascending:YES];
}

-(NSArray*)sortedEntitiesForUserByName {
	return [self findWithPredicate:[self.userPredicate predicateWithSubstitutionVariables:@{@"user": self.currentUser}] orderBy:@"name" ascending:YES];
}

-(NSArray*)sortedEntitiesForUserByKey:(NSString*)key {
	return [self findWithPredicate:[self.userPredicate predicateWithSubstitutionVariables:@{@"user": self.currentUser}] orderBy:key ascending:YES];
}


-(BOOL)exists:(NSString*) where {
	return [self countEntities:where] > 0;
}

-(NSInteger) countEntities:(NSString*) where
{
	return [self.context count:[self.modelClass description] where:where];
}

- (NSArray *)getAll:(Class)theClass prefechedProperties:(NSArray*)prefechedProperties prefetchedRelationships:(NSArray*)prefetchedRelationships {
    return [self.context getAll:theClass prefechedProperties:prefechedProperties prefetchedRelationships:prefetchedRelationships];
}

- (NSArray *)getAll:(Class)theClass {
    return [self.context getObjects:theClass];
}

- (NSArray *)getAll{
    return [self.context getObjects:self.modelClass];
}

- (id)create{
	return [self.context attachObject:self.modelClass];
}

- (id)createChild:(Class) theClass {
    return [self.context attachObject:theClass];
}

- (void)removeObjects:(NSArray*)objects {
	for (NSManagedObject *object in objects) {
		[self.context removeManagedObject:object];
	}
}

- (void)remove:(id)object{
    [self.context removeManagedObject:object];
}

- (NSArray *)findWithPredicate:(NSPredicate *)wherePredicate classToFind:(Class)classToFind {
    return [self.context findWithPredicate:[classToFind description] wherePredicate:wherePredicate propertyToFetch:nil];
}

- (NSArray *)findWithPredicate:(NSPredicate *)wherePredicate orderBy:(NSString *)orderByAttribute ascending:(BOOL)ascending {
	return [self.context findWithPredicate:[self.modelClass description] wherePredicate:wherePredicate orderBy:orderByAttribute ascending:ascending];
}

- (NSArray *)findWithPredicate:(NSPredicate *)wherePredicate {
    return [self.context findWithPredicate:[self.modelClass description] wherePredicate:wherePredicate propertyToFetch:nil];
}

- (NSArray *)findWithPredicate:(NSPredicate *)wherePredicate propertyToFetch:(NSArray*)propertyToFetch {
    return [self.context findWithPredicate:[self.modelClass description] wherePredicate:wherePredicate propertyToFetch:propertyToFetch];
}

- (NSArray *)findWithPredicate:(NSPredicate *)wherePredicate prefechedProperties:(NSArray*)prefechedProperties prefetchedRelationships:(NSArray*)prefetchedRelationships {
    return [self.context findWithPredicate:[self.modelClass description] wherePredicate:wherePredicate prefechedProperties:prefechedProperties prefetchedRelationships:prefetchedRelationships];
}

- (NSArray *)find:(NSString *)where propertyToFetch:(NSArray*)propertyToFetch {
    return [self.context find:[self.modelClass description] where:where];
}

- (NSArray *)find:(NSString *)where{
    return [self.context find:[self.modelClass description] where:where];
}

- (NSArray *)find:(NSString *)where take:(int) countItem{
    return [self.context find:[self.modelClass description] where:where take:countItem];
}

- (NSArray *)find:(NSString *)where orderBy:(NSString *)orderByAttribute ascending:(BOOL)ascending{
	return [self.context find:[self.modelClass description] where:where orderBy:orderByAttribute ascending:ascending];
}

- (NSArray *)find:(NSString *)where orderBy:(NSString *)orderByAttribute ascending:(BOOL)ascending take:(int)countItem{
    return [self.context find:[self.modelClass description] where:where orderBy:orderByAttribute ascending:ascending take:countItem];
}

-(TMUser*)currentUser {
	NSPredicate * findUser = [self.userIdPredicate predicateWithSubstitutionVariables:@{@"theUserId": [TMUserManager sharedInstance].currentUsername}];
	TMUser *user = [[self findWithPredicate:findUser classToFind:[TMUser class]] firstObject];
	if(user == nil) {
		NSException *exception = [[NSException alloc] initWithName:@"unexpected condition" reason:@"expected user to exist, but it doesn't" userInfo:nil];
		[exception raise];
	}
	return user;
}

-(void)import:(NSArray *)dataFromService dataServicePrimaryKey:(NSString*)dataServicePrimaryKey databasePrimaryKey:(NSString*)databasePrimaryKey dataStringImportBlock:(MONDataStringImportBlock) dataStringImportBlock currentUser:(TMUser *)currentUser completionBlock:(MONDataImportCompletionBlock)completionBlock {
	//todo: migrate this to use the nsdictionary map method
	if([dataFromService count] == 0) {
		return;
	}
	NSArray* existingObjects =  [self getAll];
	NSArray *filterByUser = [existingObjects filteredArrayUsingPredicate:[self.userPredicate predicateWithSubstitutionVariables:@{@"user": currentUser}]];
	NSArray * existingObjectIds = [filterByUser valueForKey:databasePrimaryKey];
	
	//right now, if it's not a dictionary, assume an array of nsstrings (tiles reference data)
	NSArray * safeArray = [dataFromService replaceNullsWith:@""];
	for (NSString * obj in safeArray) {
		NSManagedObject *cdmodel = nil;
		if([existingObjectIds containsObject:obj]) {
			cdmodel =  [[filterByUser filteredArrayUsingPredicate: [NSPredicate predicateWithFormat:@"%K == %@",databasePrimaryKey, obj] ] firstObject];
		} else {
			cdmodel = [self create];
		}
		if(cdmodel == nil) {
			DDLogError(@"some problem with %@ fetching %@", databasePrimaryKey, obj);
		}
		dataStringImportBlock(obj, cdmodel);
	}
	if(completionBlock) {
		completionBlock();
	}
}

- (NSDictionary *)mappedDictionaryFromContext:(NSArray *)array key:(id)key {
	NSMutableDictionary *mutableDictionary = [[NSMutableDictionary alloc] init];
	for (NSManagedObject *objectInstance in array){
		[mutableDictionary setObject:objectInstance forKey: [objectInstance valueForKey:key ]];
	}
	return mutableDictionary;
}

-(void)import:(NSArray *)dataFromService dataServicePrimaryKey:(NSString*)dataServicePrimaryKey databasePrimaryKey:(NSString*)databasePrimaryKey dataImportBlock:(MONDataImportBlock) dataImportBlock completionBlock:(MONDataImportCompletionBlock)completionBlock {
	
	NSArray	*allIdsInService = [dataFromService valueForKey:dataServicePrimaryKey];
	NSArray* existingObjects =  [self findWithPredicate:
								 [NSPredicate predicateWithFormat:@"(%K IN %@)", databasePrimaryKey,allIdsInService]];
	
	
	NSDictionary *mappedDictionary = [self mappedDictionaryFromContext:existingObjects key:databasePrimaryKey];
	
	DDLogInfo(@"Starting import for %@", self.modelClass);
	
	NSDate *importStart = [NSDate date];
	
	for (NSDictionary *dict in dataFromService) {
		NSDictionary *safeDict = [dict replaceNullObjectsWithObject:@""];
		NSNumber *dataServiceId = [safeDict valueForKey:dataServicePrimaryKey];
		NSManagedObject *cdmodel = nil;
		if( [mappedDictionary objectForKey:dataServiceId] != nil ){
			cdmodel = mappedDictionary[dataServiceId];
		} else {
			cdmodel = [self create];
		}
		if(cdmodel == nil) {
			DDLogError(@"some problem with %@ fetching %@", databasePrimaryKey, dataServiceId);
		}
		dataImportBlock(safeDict, cdmodel);
	}
	
	NSDate *importFinish = [NSDate date];
	NSTimeInterval executionTime = [importFinish timeIntervalSinceDate:importStart];
	DDLogInfo(@"%@ import time = %f\n", self.modelClass, executionTime);
	[self.context saveChanges];
	if(completionBlock) {
		completionBlock();
	}
}

-(void)import:(NSArray *)dataFromService dataFindBlock:(MONDataFindBlock)dataFindBlock dataImportBlock:(MONDataImportBlock) dataImportBlock currentUser:(TMUser*)currentUser completionBlock:(MONDataImportCompletionBlock)completionBlock afterImportBlock:(MONDataImportCompletionBlock)afterImportBlock {
	DDLogInfo(@"\n\n===================\n\nStarting import for %@\n\n", self.modelClass);
	
	NSDate *importStart = [NSDate date];
	NSInteger dataImportCount = 0;
	
	for (NSDictionary *dict in dataFromService) {
		NSDictionary *safeDict = [dict replaceNullObjectsWithObject:@""];
		NSManagedObject *cdmodel = dataFindBlock(dict);
		if( cdmodel == nil ){
			cdmodel = [self create];
		}
		dataImportBlock(safeDict, cdmodel);
		dataImportCount +=1;
		if(dataImportCount == BatchSaveSize) {
			[self.context saveChanges];
			dataImportCount = 0;
		}
	}
	
	NSDate *importFinish = [NSDate date];
	NSTimeInterval executionTime = [importFinish timeIntervalSinceDate:importStart];
	DDLogInfo(@"%@ import time = %f", self.modelClass, executionTime);
	if(afterImportBlock) {
		[self.context saveChanges];
		afterImportBlock();
		[self.context saveChanges];
	}
	if(completionBlock) {
		completionBlock();
	}
}

- (NSDictionary *)existingObjectsDictionaryFor:(NSArray *)allIdsInService withDatabasePrimaryKey:(NSString *)databasePrimaryKey forCurrentUser:(TMUser *)currentUser {
    NSArray *existingObjects =  [self findWithPredicate:[NSPredicate predicateWithFormat:@"(%K IN %@)", databasePrimaryKey, allIdsInService]];
    allIdsInService = nil; //immediately clear memory
    
    NSArray *filterByUser = [existingObjects filteredArrayUsingPredicate:[self.userPredicate predicateWithSubstitutionVariables:@{@"user": currentUser}]];
    existingObjects = nil; //immediately clear memory
    
    NSDictionary *mappedDictionary = [self mappedDictionaryFromContext:filterByUser key:databasePrimaryKey];
    filterByUser = nil;
    return mappedDictionary;
}

- (void)executeBlockForData:(NSDictionary *)dict withDataServicePrimaryKey:(NSString *)dataServicePrimaryKey existingObjectsDictionary:(NSDictionary *)mappedDictionary dataImportBlock:(MONDataImportBlock)dataImportBlock {
    NSInteger dataImportCount = 0;
    NSDictionary *safeDict = [dict replaceNullObjectsWithObject:@""];
    NSNumber *dataServiceId = [safeDict valueForKeyPath:dataServicePrimaryKey];
    NSManagedObject *cdmodel = nil;
    if( [mappedDictionary objectForKey:dataServiceId] != nil ){
        cdmodel = mappedDictionary[dataServiceId];
    } else {
        cdmodel = [self create];
    }
    dataImportBlock(safeDict, cdmodel);
    dataImportCount +=1;
    if (dataImportCount == BatchSaveSize) {
        [self.context saveChanges];
        dataImportCount = 0;
    }
}

-(void)import:(NSArray *)dataFromService dataServicePrimaryKey:(NSString*)dataServicePrimaryKey databasePrimaryKey:(NSString*)databasePrimaryKey dataImportBlock:(MONDataImportBlock) dataImportBlock currentUser:(TMUser *)currentUser completionBlock:(MONDataImportCompletionBlock)completionBlock {
    [self import:dataFromService dataServicePrimaryKey:dataServicePrimaryKey databasePrimaryKey:databasePrimaryKey dataImportBlock:dataImportBlock currentUser:currentUser idsOfObjectsToSkip:nil completionBlock:completionBlock];
}

- (void)import:(NSArray *)dataFromService dataServicePrimaryKey:(NSString *)dataServicePrimaryKey databasePrimaryKey:(NSString *)databasePrimaryKey dataImportBlock:(MONDataImportBlock)dataImportBlock currentUser:(TMUser *)currentUser idsOfObjectsToSkip:(NSSet *)idsOfObjectsToSkip completionBlock:(MONDataImportCompletionBlock)completionBlock {
    NSArray	*allIdsInService = [dataFromService valueForKeyPath:dataServicePrimaryKey];
    
    NSDictionary *mappedDictionary = [self existingObjectsDictionaryFor:allIdsInService withDatabasePrimaryKey:databasePrimaryKey forCurrentUser:currentUser];
    
    DDLogInfo(@"\n\n===================\n\nStarting import for %@\n\n", self.modelClass);
    
    NSDate *importStart = [NSDate date];
    
    for (NSDictionary *dict in dataFromService) {
        if (!idsOfObjectsToSkip || ![idsOfObjectsToSkip containsObject:[dict valueForKeyPath:dataServicePrimaryKey]]) {
            [self executeBlockForData:dict withDataServicePrimaryKey:dataServicePrimaryKey existingObjectsDictionary:mappedDictionary dataImportBlock:dataImportBlock];
        } else {
            DDLogInfo(@"**** Data with ID:%@ was skipped during import ****", [dict valueForKeyPath:dataServicePrimaryKey]);
        }
    }
    
    NSDate *importFinish = [NSDate date];
    NSTimeInterval executionTime = [importFinish timeIntervalSinceDate:importStart];
    DDLogInfo(@"%@ import time = %f", self.modelClass, executionTime);
    [self.context saveChanges];
    
    dataFromService = nil;
    mappedDictionary = nil;
    dataImportBlock = nil;
    
    if(completionBlock) {
        completionBlock();
    }
}

-(void)importFromDictionary:(NSDictionary *)dataFromService dataServicePrimaryKey:(NSString*)dataServicePrimaryKey databasePrimaryKey:(NSString*)databasePrimaryKey dataImportBlock:(MONDataImportBlock) dataImportBlock currentUser:(TMUser *)currentUser completionBlock:(MONDataImportCompletionBlock)completionBlock {
    
    NSNumber *allIdsInService = [dataFromService valueForKeyPath:dataServicePrimaryKey];
    
    NSDictionary *mappedDictionary = [self existingObjectsDictionaryFor:@[allIdsInService] withDatabasePrimaryKey:databasePrimaryKey forCurrentUser:currentUser];
    
    DDLogInfo(@"\n\n===================\n\nStarting import for %@\n\n", self.modelClass);
    
    NSDate *importStart = [NSDate date];
    
    [self executeBlockForData:dataFromService withDataServicePrimaryKey:dataServicePrimaryKey existingObjectsDictionary:mappedDictionary dataImportBlock:dataImportBlock];
    
    NSDate *importFinish = [NSDate date];
    NSTimeInterval executionTime = [importFinish timeIntervalSinceDate:importStart];
    DDLogInfo(@"%@ import time = %f", self.modelClass, executionTime);
    [self.context saveChanges];
    
    dataFromService = nil;
    mappedDictionary = nil;
    dataImportBlock = nil;
    
    if(completionBlock) {
        completionBlock();
    }
    
}

-(void)importAndRemovePrevious:(NSArray *)dataFromService dataImportBlock:(MONDataImportBlock) dataImportBlock completionBlock:(MONDataImportCompletionBlock)completionBlock {
	
	DDLogInfo(@"starting removing previous entities for %@", self.modelClass);
	[self.context saveChanges];
	[self removeAll];
	[self.context saveChanges];
	DDLogInfo(@"finished removing previous entities for %@", self.modelClass);
	DDLogInfo(@"\n\n===================\n\nStarting import for %@\n\n", self.modelClass);

	NSDate *importStart = [NSDate date];
	NSInteger dataImportCount = 0;
	
	for (NSDictionary *dict in dataFromService) {
		NSDictionary *safeDict = [dict replaceNullObjectsWithObject:@""];
		NSManagedObject *cdmodel = [self create];
		dataImportBlock(safeDict, cdmodel);
		dataImportCount +=1;
		if(dataImportCount == BatchSaveSize) {
			[self.context saveChanges];
			dataImportCount = 0;
		}
	}
	
	NSDate *importFinish = [NSDate date];
	NSTimeInterval executionTime = [importFinish timeIntervalSinceDate:importStart];
	DDLogInfo(@"%@ import time = %f", self.modelClass, executionTime);
	[self.context saveChanges];
	if(completionBlock) {
		completionBlock();
	}
}

-(id)findWithoutUser:(Class)theClass key:(NSString*)key value:(id)value {
	NSArray * results =  [self findWithPredicate:[NSPredicate predicateWithFormat:@"%K == %@",key, value] classToFind:theClass];
	return [self handleResultsForFind:theClass results:results searchData:@{key: value}];
}

-(id)findOrNilWithoutUser:(Class)theClass key:(NSString*)key value:(id)value {
    NSArray * results =  [self findWithPredicate:[NSPredicate predicateWithFormat:@"%K == %@",key, value] classToFind:theClass];
    if ([results count] == 0 || results == nil) {
        return nil;
    }
    return [results firstObject];
}

-(id)findOrNil:(Class)theClass key:(NSString*)key value:(id)value {
	NSArray * results =  [self findWithPredicate:[NSPredicate predicateWithFormat:@"%K == %@",key, value] classToFind:theClass];
	NSArray * filteredByUser = [results filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"ANY users == %@", self.currentUser]];
	if(filteredByUser == nil || [filteredByUser count] == 0) {
		return nil;
	}
	return  [results firstObject];
}

-(id)find:(Class)theClass key:(NSString*)key value:(id)value {
	
	NSArray * filteredByUser = [[self findWithPredicate:[NSPredicate predicateWithFormat:@"%K == %@",key, value] classToFind:theClass]
								filteredArrayUsingPredicate:
								[self.userPredicate predicateWithSubstitutionVariables:@{@"user": self.currentUser}]
								];
	
	return [self handleResultsForFind:theClass results:filteredByUser searchData:@{key: value}];
}

- (NSManagedObject*)findWithoutUser:(Class)classToFind dictionaryOfKeyValues:(NSDictionary*)keyValueDictionary {
	
	NSMutableArray *predicateArray = [NSMutableArray array];
	[keyValueDictionary enumerateKeysAndObjectsUsingBlock:^(id key, id object, BOOL *stop) {
		[predicateArray addObject:[NSPredicate predicateWithFormat:@"%K == %@",key, object]];
	}];
	
    NSArray * results = [self.context findWithPredicate:[classToFind description] wherePredicate:
						 [NSCompoundPredicate andPredicateWithSubpredicates: predicateArray] propertyToFetch:nil];
	return [self handleResultsForFind:classToFind results:results searchData:keyValueDictionary];
}



- (NSManagedObject*)find:(Class)classToFind dictionaryOfKeyValues:(NSDictionary*)keyValueDictionary {
	
	NSMutableArray *predicateArray = [NSMutableArray array];
	[keyValueDictionary enumerateKeysAndObjectsUsingBlock:^(id key, id object, BOOL *stop) {
		[predicateArray addObject:[NSPredicate predicateWithFormat:@"%K == %@",key, object]];
	}];
	[predicateArray addObject:[self.userPredicate predicateWithSubstitutionVariables:@{@"user": self.currentUser}]];
	
    NSArray * results = [self.context findWithPredicate:[classToFind description] wherePredicate:
						 [NSCompoundPredicate andPredicateWithSubpredicates: predicateArray] propertyToFetch:nil];
	return [self handleResultsForFind:classToFind results:results searchData:keyValueDictionary];
}

- (NSManagedObject*)findOrNil:(Class)classToFind dictionaryOfKeyValues:(NSDictionary*)keyValueDictionary {
	
	NSMutableArray *predicateArray = [NSMutableArray array];
	[keyValueDictionary enumerateKeysAndObjectsUsingBlock:^(id key, id object, BOOL *stop) {
		[predicateArray addObject:[NSPredicate predicateWithFormat:@"%K == %@",key, object]];
	}];
	[predicateArray addObject:[self.userPredicate predicateWithSubstitutionVariables:@{@"user": self.currentUser}]];
	
    NSArray * results = [self.context findWithPredicate:[classToFind description] wherePredicate:
						 [NSCompoundPredicate andPredicateWithSubpredicates: predicateArray] propertyToFetch:nil];
	if([results count] > 1) {
		DDLogError(@"expected result set for %@ to only contain one item, it contains: %lu search data: %@", classToFind, (unsigned long)[results count], [keyValueDictionary allKeys]);
	}
	return [results firstObject];
}


- (NSManagedObject*)findOrCreate:(Class)classToFind dictionaryOfKeyValues:(NSDictionary*)keyValueDictionary isChild:(BOOL)isChild {
	NSMutableArray *predicateArray = [NSMutableArray array];
	[keyValueDictionary enumerateKeysAndObjectsUsingBlock:^(id key, id object, BOOL *stop) {
		[predicateArray addObject:[NSPredicate predicateWithFormat:@"%K == %@",key, object]];
	}];
	[predicateArray addObject:[self.userPredicate predicateWithSubstitutionVariables:@{@"user": self.currentUser}]];
	NSPredicate *fullPredicate = [NSCompoundPredicate andPredicateWithSubpredicates: predicateArray];
	return [self handleResultsForFindOrCreate:classToFind
									  results: [self findWithPredicate:fullPredicate classToFind:classToFind]
									  isChild:isChild];
}

-(id)findOrCreate:(Class)theClass key:(NSString*)key value:(id)value isChild:(BOOL)isChild {
	return [self handleResultsForFindOrCreate:theClass
									  results: [self findWithPredicate:[NSPredicate predicateWithFormat:@"%K == %@",key, value] classToFind:theClass]
									  isChild:isChild];
}

-(NSManagedObject*)handleResultsForFind:(Class)theClass results:(NSArray*)results searchData:(NSDictionary*)searchData {
	NSManagedObject *returnObject = nil;
	if(results == nil || [results count] == 0) {
		DDLogError(@"expected object %@ to exist, but didn't. search data : %@", theClass, [searchData allKeys]);
	} else if([results count] == 1) {
		returnObject = [results firstObject];
	} else {
		DDLogError(@"expected result set for %@ to only contain one item, it contains: %lu search data: %@", theClass, (unsigned long)[results count],  [searchData allKeys]);
	}
	return returnObject;
}

-(NSManagedObject*)handleResultsForFindOrCreate:(Class)classToFind results:(NSArray*)results isChild:(BOOL)isChild {
	NSManagedObject *returnObject = nil;
	if(results == nil || [results count] == 0) {
		if(isChild) {
			returnObject = [self createChild:classToFind];
		} else {
			returnObject = [self create];
		}
	} else if([results count] == 1) {
		returnObject = [results firstObject];
	} else {
		DDLogError(@"expected result set to only contain one item, it contains: %lu",(unsigned long)[results count]);
	}
	return returnObject;
}

- (id)objectForUniqueIdentifier:(id)object {
	return [self.context managedObjectForManagedObjectIdURIRepresentation:object];
}

@end
