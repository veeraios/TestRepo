#import "MONFilterView.h"
#import "MONButton.h"
#import "MONDimensions.h"
#import "MONUIConvenienceFunctions.h"
#import "UIColor+MONThemeColorProvider.h"

static const CGFloat SearchBarMargin = 8.0;

@interface MONFilterView ()<ESCObservableInternal, UISearchBarDelegate>

@property (nonatomic) UISearchBar *searchBar;
@property (nonatomic) MONButton *closeButton;

@end

@implementation MONFilterView

- (id)initWithFrame:(CGRect)frame {
	self = [super initWithFrame:frame];
	if (self) {
		[self escRegisterObserverProtocol:@protocol(MONFilterViewObserver)];
		
		self.backgroundColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeBackground];

		self.searchBar = [self styledSearchBar];
		self.searchBar.placeholder = @"Search";
		self.searchBar.delegate = self;
		[self addSubview:self.searchBar];

		self.closeButton = [[MONButton alloc] init];
		self.closeButton.backgroundColor = [UIColor clearColor];
		[self.closeButton setTitle:@"CLOSE" forState:UIControlStateNormal];
		[self.closeButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
		[self.closeButton addTarget:self action:@selector(closeButtonTapped) forControlEvents:UIControlEventTouchUpInside];
		[self addSubview:self.closeButton];
	}
	return self;
}

- (UISearchBar *)styledSearchBar {
	UISearchBar *searchBar = [[UISearchBar alloc] init];
	searchBar.searchBarStyle = UISearchBarStyleProminent;
	[searchBar setBarTintColor:[UIColor colorForThemeComponentType:MONThemeComponentTypeBackground]];
	[searchBar setSearchFieldBackgroundImage:[UIImage imageNamed:@"trial-management-login-bg"] forState:UIControlStateNormal];
	[self setSearchBarBackgroundColor];
	return searchBar;
}

-(void)setSearchBarBackgroundColor {
	//this is the only way to set searchBar's textField without using private apis
	for (UIView* subview in [[self.searchBar.subviews lastObject] subviews]) {
		if ([subview isKindOfClass:[UITextField class]]) {
			UITextField *textField = (UITextField*)subview;
			[textField setBackgroundColor:[UIColor colorForThemeComponentType:MONThemeComponentTypeBackground]];
			[textField.layer setBorderWidth:MONDimensionsThinBorderWidth];
			[textField.layer setBorderColor:[UIColor colorForThemeComponentType:MONThemeComponentTypeBorder].CGColor];
			textField.layer.cornerRadius = 4.0f;
		}
	}
}

- (void)layoutSubviews {
	[super layoutSubviews];
	
	[self.closeButton sizeToFit];
	self.closeButton.frame = CGRectMake(CGRectGetMaxX(self.bounds) - CGRectGetWidth(self.closeButton.frame),
										 MONUIScreenRoundToScreenScale((CGRectGetMaxY(self.bounds) - CGRectGetHeight(self.closeButton.frame)) / 2.0),
										 CGRectGetWidth(self.closeButton.frame),
										 CGRectGetHeight(self.closeButton.frame));
	
	self.searchBar.frame = UIEdgeInsetsInsetRect(self.bounds, UIEdgeInsetsMake(0.0, 0.0, 0.0, CGRectGetWidth(self.closeButton.frame) - SearchBarMargin));
}

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText {
	[self.escNotifier filterTextDidChange:searchText];
}

- (void)setFilterText:(NSString *)filterText {
	if (![self.searchBar.text isEqualToString:filterText]) {
		self.searchBar.text = filterText;
	}
}

- (void)setPlaceholderText:(NSString *)placeholderText {
	self.searchBar.placeholder = placeholderText;
}

- (void)closeButtonTapped {
	self.searchBar.text = nil;
	[self.escNotifier filterCloseButtonTapped];
}

- (BOOL)becomeFirstResponder {
	return [self.searchBar becomeFirstResponder];
}

- (BOOL)resignFirstResponder {
	return [self.searchBar resignFirstResponder];
}

@end
