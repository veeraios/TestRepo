//
//  TMMarketingActionOptionsListModel.h
//  TrialManagement
//
//  Created by SINGH, SUPREET [AG/1000] on 10/7/14.
//  Copyright (c) 2014 Monsanto. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "TMUserManager.h"
#import "TMTrialModel.h"

static NSString *const TMRelinqushAndSubmitToMarketingMessage = @"Relinquish Trial and Submit To Marketing";
static NSString *const TMRelinquishTrialMessage = @"Relinquish Trial and Do Not Submit to Marketing";
static NSString *const TMSubmitToMarketingMessage = @"Submit to Marketing";
static NSString *const TMCancelTrialMessage = @"Cancel Trial";

@protocol TMMarketingActionOptionsListModelProtocol <NSObject>
-(void)submitToMarketingComplete;
-(void)relinquishComplete;
-(void)cancelTrialComplete;
@end

@interface TMMarketingActionOptionsListModel : TMReferenceDataListGenericModel
@property (nonatomic, weak) id<TMMarketingActionOptionsListModelProtocol> delegate;
- (instancetype)initWithUserRole:(TMUserRole)userRole trialModel:(TMTrialModel*)trialModel;
- (void)performActionForItemAtIndex:(NSInteger)index;
- (BOOL)marketingActionsAvailable;
@end
