#import "TMErrorHelper.h"

@implementation TMErrorHelper

+ (BOOL)isServiceError:(NSError *)error {
    return [error code] == NSURLErrorBadServerResponse;
}

+ (NSString *)extractErrorMessage:(NSError *)error {
    if(error.userInfo && [error.userInfo objectForKey:@"responseObject"]) {
		id responseObject = [error.userInfo objectForKey:@"responseObject"];
        return [NSString stringWithFormat:@"%@", [responseObject componentsJoinedByString:@","]];
	} else {
        return [error localizedDescription];
    }
}

@end
