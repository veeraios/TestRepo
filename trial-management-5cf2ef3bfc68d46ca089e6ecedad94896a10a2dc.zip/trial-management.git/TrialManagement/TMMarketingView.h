#import "TMTrialModel.h"
#import "TMMarketingModel.h"
#import "MONReadOnlyProtocol.h"
#import "TMCounty.h"
#import "TMMarketingSubmissionType.h"

@protocol TMMarketingViewProtocol
- (void)editCountiesWasTappedForSubmissionType:(TMMarketingSubmissionType)type;
- (void)removeCounty:(TMCounty *)county forSubmissionType:(TMMarketingSubmissionType)type;
- (void)postToWebSwitchWasChanged:(BOOL)postToWebValue;
- (void)submissionSwitchWasChanged:(BOOL)submissionValue forSubmissionType:(TMMarketingSubmissionType)type;
@end

@interface TMMarketingView : UIView<MONReadOnlyProtocol>

@property (nonatomic, weak) id<TMMarketingViewProtocol> delegate;
- (instancetype)initWithMarketingModel:(TMMarketingModel*)marketingModel headerButtons:(NSArray *)headerButtons;
- (void)refreshTables;
- (void)resetPostcardAndEmailSwitches;
- (void)setHeaderButtons:(NSArray *)headerButtons;
- (void)setSubmittedDate:(NSDate*)date animate:(BOOL)animate;
- (void)setCountiesSelectionEnabled:(BOOL)enabled forSubmissionType:(TMMarketingSubmissionType)type;
@end
