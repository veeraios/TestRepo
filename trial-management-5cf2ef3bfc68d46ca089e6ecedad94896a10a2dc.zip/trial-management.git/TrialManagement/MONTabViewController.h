#import "MONTabModel.h"
#import <UIKit/UIKit.h>

@interface MONTabViewController : UIViewController

- (instancetype)initWithTabModels:(NSArray *)tabModels;
- (void)setSelectedIndex:(NSUInteger)index;

@end
