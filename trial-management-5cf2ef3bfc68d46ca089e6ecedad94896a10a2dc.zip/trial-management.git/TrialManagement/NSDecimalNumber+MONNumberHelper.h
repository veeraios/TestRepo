#import <Foundation/Foundation.h>

@interface NSDecimalNumber (MONNumberHelper)

+ (NSDecimalNumber *)safeDecimalNumberWithString:(NSString *)decimalString;

@end
