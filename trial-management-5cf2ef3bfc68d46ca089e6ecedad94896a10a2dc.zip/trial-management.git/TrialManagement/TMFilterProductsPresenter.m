#import "TMFilterProductsPresenter.h"

@interface TMFilterProductsPresenter ()<TMFilterProductsViewDelegate, TMFilterProductsModelDelegate>

@property (nonatomic) NSObject<TMFilterProductsView> *filterProductsView;
@property (nonatomic) TMFilterProductsModel *filterProductsModel;

@end

@implementation TMFilterProductsPresenter

- (instancetype)initWithFilterProductsView:(NSObject<TMFilterProductsView> *)filterProductsView addEntriesModel:(TMFilterProductsModel *)filterProductsModel {
	self = [super init];
	if (self) {
		self.filterProductsView = filterProductsView;
        [self.filterProductsView setFilterProductsViewDelegate:self];
		self.filterProductsModel = filterProductsModel;
        self.filterProductsModel.delegate = self;
	}
	return self;
}

#pragma mark - TMFilterProductsViewDelegate Methods

- (void)brandSearchTextChanged:(NSString *)brandSearchText {
	[self.filterProductsModel setBrandSearchText:brandSearchText];
}

- (void)productSearchTextChanged:(NSString *)productSearchText {
	[self.filterProductsModel setProductSearchText:productSearchText];
}

- (void)traitsSearchTextChanged:(NSString *)traitsSearchText {
	[self.filterProductsModel setTraitsSearchText:traitsSearchText];
}

- (void)rmSearchTextChanged:(NSString *)rmSearchText {
	[self.filterProductsModel setRmSearchText:rmSearchText];
}

- (void)rmVarianceSearchTextChanged:(NSString *)rmVarianceSearchText {
	[self.filterProductsModel setRmVarianceSearchText:rmVarianceSearchText];
}

#pragma mark - TMFilterProductsModelDelegate Methods

-(void)searchPerformed {
    [self.filterProductsView refreshTableWithNumberOfResults:[self.filterProductsModel.searchResults count]];
}

@end
