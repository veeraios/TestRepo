//
//  TMDeletableValueCollectionViewCell.m
//  TrialManagement
//
//  Created by WAIDMANN, ALAN [AG/1000] on 10/30/14.
//  Copyright (c) 2014 Monsanto. All rights reserved.
//

#import "TMDeletableValueCollectionViewCell.h"

@implementation TMDeletableValueCollectionViewCell

@end
