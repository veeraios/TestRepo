//
//  TMUnitOfWorkBackup.m
//  TrialManagement
//
//  Created by GADIRAJU, PRANEETH [AG/1000] on 12/8/14.
//  Copyright (c) 2014 Monsanto. All rights reserved.
//

#import "TMBackupCoreDataContext.h"
#import "TMBackupUnitOfWork.h"

@interface TMBackupUnitOfWork()
@property (nonatomic) id<TMBackupCoreDataContextProtocol> context;
@end

@implementation TMBackupUnitOfWork

static id _sharedObject;

-(id) init {
    if (_sharedObject) {
        return _sharedObject;
    }
    else{
        self = [super init];
        if (self) {
            self.context = [[TMBackupCoreDataContext alloc] init];
        }
        return self;
    }
}

+ (id<TMBackupUnitOfWorkProtocol>)sharedInstance{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _sharedObject = [[TMBackupUnitOfWork alloc] init];
    });
    return _sharedObject;
}

- (id<TMBackupCoreDataContextProtocol>) backupContext {
    return self.context;
}

- (void) createBackupCopyOfTrial: (TMTrial *)trial {
    [self.context cloneTrial:trial];
}

- (void) deleteBackupCopyOfTrial:(TMTrial *)trial {
    [self.context deleteTrial:trial];
}

@end
