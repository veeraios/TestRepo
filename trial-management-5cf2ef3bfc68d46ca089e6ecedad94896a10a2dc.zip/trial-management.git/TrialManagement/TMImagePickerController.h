#import <UIKit/UIKit.h>

@interface TMImagePickerController : UIImagePickerController

@end
