#import "MONSingleSelectionCardCollectionViewCell.h"
#import "TMReferenceListDataModel.h"
#import <Foundation/Foundation.h>

@interface TMEditTrialSingleSelectionCell : MONSingleSelectionCardCollectionViewCell

@property (nonatomic) id<TMReferenceListDataModel> cellModel;

@end
