extension Array {
    func findFirst(includeElement: (T) -> Bool) -> (T)? {
        var filteredList:[T]? = filter(includeElement)
        return filteredList?.first
    }
    
    func forEach(closure: (T) -> ()){
        for i in self {
            closure(i)
        }
    }
    
    func tail() -> Array {
        var mutSelf = self
        if self.count >= 1 {
            mutSelf.removeAtIndex(0)
        }
        return mutSelf
    }
    
    func indexOver<H>(indexOver: (T)->H) -> [H : T] {
        var dict = [H : T]()
        self.forEach( {dict[indexOver($0)] = $0} )
        return dict
    }
    
    func partitionArray(splitSize: Int) -> [[T]] {
        if countElements(self) <= splitSize {
            return [self]
        } else {
            return [Array(self[0..<splitSize])] + Array(self[splitSize..<self.count]).partitionArray(splitSize)
        }
    }
}

extension String {
    func contains(elements: String) -> Bool {
        return self.rangeOfString(elements) != nil
    }
    
    func caseInsensitiveContains(elements: String) -> Bool {
        return self.rangeOfString(elements, options: .CaseInsensitiveSearch) != nil
    }
    
    func findReplace(pattern: String, values: [String]) -> String {
        return values.reduce(self, combine: { (output, arrayValue) -> String in
            output.stringByReplacingOccurrencesOfString(pattern, withString: arrayValue, options: nil, range: output.rangeOfString(pattern))
        })
    }
    
    func toDouble() -> Double? {
        return NSNumberFormatter().numberFromString(self)?.doubleValue
    }
    
    func toDoubleWithPrecision(#decimalPlaces:Int) -> String {
        return String(format: "%0.\(decimalPlaces)f", (self as NSString).doubleValue)
    }
}

extension NSDateFormatter {
    class var monDefaultDateFormatter: NSDateFormatter {
        struct DateFormatterWrapper {
            static let dateFormatter: NSDateFormatter = {
                var dateFormatter = NSDateFormatter()
                dateFormatter.dateFormat = "yyyy-MM-dd"
                return dateFormatter
            }()
        }
        return DateFormatterWrapper.dateFormatter
    }
}

extension NSManagedObject: MONFacetSearchObjectProtocol {
    var searchID: String { return objectID.description }
}

extension NSString {
    func toDate() -> NSDate? {
        return toDate(NSDateFormatter.monDefaultDateFormatter)
    }

    func toDate(dateFormatter: NSDateFormatter) -> NSDate? {
        return dateFormatter.dateFromString(self)
    }
}

extension NSDate {
    func toString() -> String {
        return toString(NSDateFormatter.monDefaultDateFormatter)
    }

    func toString(dateFormatter: NSDateFormatter) -> String {
        return dateFormatter.stringFromDate(self)
    }
}

extension NSCalendar {
    class func dateForYear(year:Int) -> NSDate? {
        let yearDateComponents = NSDateComponents()
        yearDateComponents.year = year
        
        return currentCalendar().dateFromComponents(yearDateComponents)
    }
}