#import "MONReferenceSearchableModel.h"
#import "MONHeaderViewProtocol.h"
#import "MONSearchViewProtocol.h"

@protocol MONSearchStrategy <NSObject>
-(NSObject<MONReferenceSearchableModel>*)searchModel;
-(UIView *)tableViewHeader;
-(UIView<MONSearchViewProtocol>*)searchView;
@end
