#import "NSArray+TMNSArrayNSNull.h"

@implementation NSArray (TMNSArrayNSNull)
- (NSArray *)replaceNullsWith:(NSString*)replaceString   {
    NSMutableArray *replaced = [self mutableCopy];
    const id nsNull = [NSNull null];
    for (int idx = 0; idx < [replaced count]; idx++) {
        id object = [replaced objectAtIndex:idx];
        if (object == nsNull) {
			[replaced replaceObjectAtIndex:idx withObject:replaceString];
		}
        else if ([object isKindOfClass:[NSArray class]]) {
			[replaced replaceObjectAtIndex:idx withObject:[object replaceNullsWith:replaceString]];
		}
    }
    return [replaced copy];
}

@end
