#import "TMBrandRepository.h"
#import "TMBrand.h"
#import "NSManagedObject+TMCoreDataTestHelper.h"
#import "TMWorkingCoreDataContext.h"
#import "TMUserManager.h"

@interface TMBrandRepositoryTest : XCTestCase
@end

@implementation TMBrandRepositoryTest

-(void)setUpUserForImportTest:(NSObject<MONRepositoryProtocol>*)repo {
	//todo: move to import Test helpers
	TMUserManager *manager = [TMUserManager sharedInstance];
	manager.currentUsername = @"test";
	TMUser *user = [TMUser create];
	user.userId = manager.currentUsername;
	[user.managedObjectContext save:nil];
	id mock = [OCMockObject partialMockForObject:repo];
	[[[mock stub] andReturn:user] currentUser];
}

- (void)testSyncFromService {
	TMWorkingCoreDataContext *context = [[TMWorkingCoreDataContext alloc] init];
	id mockContext = [OCMockObject partialMockForObject:context];
	[[mockContext stub] saveContext];
	
	TMBrandRepository *repo = [[TMBrandRepository alloc] initWithContext:context withModel:[TMBrand class]];
	[self setUpUserForImportTest:repo];
	
	[repo syncFromService:@[
	@{
		@"id": @2463107383296,
		@"name": @"A+ SEEDS"
	}] completionBlock:nil];
	
	TMBrand *actual = [[context find:NSStringFromClass([TMBrand class]) where:@"name = 'A+ SEEDS'"] firstObject];
	XCTAssertEqualObjects(actual.brandId, @2463107383296);
	XCTAssert(actual != nil);
}

@end
