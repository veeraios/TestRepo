#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger, TMCoordinatesLocation) {
    TMCoordinatesLocationFirstRowFront,
    TMCoordinatesLocationLastRowFront,
	TMCoordinatesLocationLastRowBack,
	TMCoordinatesLocationFirstRowBack
};
