#import "TMFieldObservationModel.h"

@interface TMFieldInfoObservationContainerView : UIView
- (instancetype)initWithFieldObservationModel:(TMFieldObservationModel*)fieldObservationModel;
@end
