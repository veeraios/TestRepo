#import "TMAddEntriesViewController.h"
#import "TMEntrySelectionView.h"
#import "TMFilterProductsModel.h"
#import "TMFilterProductsPresenter.h"
#import "TMFilterProductsTable.h"
#import "TMRequestNewProductViewController.h"
#import "TMEntryTableViewCell.h"
#import "TMWorkingUnitOfWork.h"
#import "MONMessages.h"
#import "TrialManagement-Swift.h"

@interface TMAddEntriesViewController()<TMAddNewEntriesSelectionViewDelegate>

@property (nonatomic) UIBarButtonItem *cancelButton;
@property (nonatomic) TMEntrySelectionView *addEntriesView;
@property (nonatomic) UITableView *searchResultsTableView;
@property (nonatomic) TMFilterProductsTable *productsSearchTable;
@property (nonatomic) TMFilterProductsModel *addEntriesModel;
@property (nonatomic) TMFilterProductsPresenter *addEntriesPresenter;
@property (nonatomic) TMSelectedEntriesModel *selectedEntriesModel;
@property (nonatomic) TMTrialModel *trialModel;

@end

@implementation TMAddEntriesViewController

- (instancetype)initWithSelectedEntriesModel:(TMSelectedEntriesModel *)selectedEntriesModel trialModel:(TMTrialModel *)trialModel {
	self = [super init];
	if (self) {
		self.title = @"Search Products";
		self.selectedEntriesModel = selectedEntriesModel;
		self.trialModel = trialModel;
	}
	return self;
}

- (void)viewDidLoad {
	[super viewDidLoad];

	self.edgesForExtendedLayout = UIRectEdgeNone;
    
    self.addEntriesModel = [[TMFilterProductsModel alloc] init];

    self.productsSearchTable = [[TMFilterProductsTable alloc]initWithFilterProductsModel:self.addEntriesModel];
    
	self.searchResultsTableView = [[UITableView alloc] init];
	self.searchResultsTableView.dataSource = self.productsSearchTable;
	self.searchResultsTableView.delegate = self.productsSearchTable;
	self.searchResultsTableView.allowsMultipleSelection = YES;
	[self.searchResultsTableView registerClass:[TMEntryTableViewCell class] forCellReuseIdentifier:NSStringFromClass([TMEntryTableViewCell class])];
	
	self.addEntriesView = [[TMEntrySelectionView alloc] initWithSearchResultsTableView:self.searchResultsTableView selectedBrand:self.trialModel.brandName willReplaceEntry:NO];
	self.addEntriesView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    self.addEntriesView.addNewEntriesSelectionViewDelegate = self;
	[self.view addSubview:self.addEntriesView];
	
	self.addEntriesPresenter = [[TMFilterProductsPresenter alloc] initWithFilterProductsView:self.addEntriesView addEntriesModel:self.addEntriesModel];

	if (self.trialModel.brandName) {
		id<TMCropRepositoryProtocol> cropRepository = [[TMWorkingUnitOfWork sharedInstance] cropRepository];
		NSNumber *cropId = [cropRepository cropIdForCropName:self.trialModel.cropName];
		[self.addEntriesModel setCropId:cropId];
		[self.addEntriesModel setBrandSearchText:self.trialModel.brandName];
	}
}

- (void)viewWillAppear:(BOOL)animated {
	[super viewWillAppear:animated];
	self.addEntriesView.frame = self.view.bounds;
}

- (void)viewDidAppear:(BOOL)animated {
	[super viewDidAppear:animated];

	[MONGoogleAnalytics trackView:@"Trial - Add Entries - Search Products"];
}

- (void)addProductForIndexPath:(NSIndexPath *)indexPath {
	TMProduct *product = [[self.addEntriesModel searchResults] objectAtIndex:indexPath.row];
	[self.selectedEntriesModel addObjectWithProduct:product entryId:nil];
}

- (void)addSelectedProductsIfNotAdded {
    for (NSIndexPath *indexPath in [self.searchResultsTableView indexPathsForSelectedRows]) {
        [self addProductForIndexPath:indexPath];
    }
}

#pragma mark - TMAddNewEntriesSelectionViewDelegate Methods

- (void)requestNewButtonTapped {
	TMRequestNewProductViewController *requestNewProductViewController = [[TMRequestNewProductViewController alloc] initWithSelectedEntriesModel:self.selectedEntriesModel trialModel:self.trialModel];
	[self.navigationController pushViewController:requestNewProductViewController animated:YES];
}

- (void)addProductsButtonTapped {
	NSArray *indexPathsForSelectedRows = [self.searchResultsTableView indexPathsForSelectedRows];
    
	for (NSIndexPath *indexPath in indexPathsForSelectedRows) {
		[self addProductForIndexPath:indexPath];
		[self.searchResultsTableView deselectRowAtIndexPath:indexPath animated:YES];
		UITableViewCell *cell = [self.searchResultsTableView cellForRowAtIndexPath:indexPath];
		[cell setSelected:NO];
	}
    
    if (indexPathsForSelectedRows.count == 0) {
        [MONMessages showWarningMessageTitle:@"No Products Selected" subtitle:@"" presentOverModal:YES];
    } else {
        [self.addEntriesView incrementSelectedProducts:indexPathsForSelectedRows.count];
        [MONMessages showSuccessMessageTitle:[NSString stringWithFormat:@"%lu Products Added", (unsigned long)indexPathsForSelectedRows.count] subtitle:@"" presentOverModal:YES];
    }
    
}

@end
