#import "TMGPSPointsView.h"
#import "TMCoordinatesView.h"
#import "MONDimensions.h"

static const CGFloat CoordinateViewSpacing = 20.0;

@interface TMGPSPointsView()<TMCoordinatesViewDelegate>

@property (nonatomic) TMCoordinatesView *firstPoint;
@property (nonatomic) TMCoordinatesView *secondPoint;
@property (nonatomic) TMCoordinatesView *thirdPoint;
@property (nonatomic) TMCoordinatesView *fourthPoint;

@end

@implementation TMGPSPointsView

- (instancetype)init {
    self = [super init];
    if (self) {
        self.firstPoint = [[TMCoordinatesView alloc] initWithTitle:@"First Row Front" location:TMCoordinatesLocationFirstRowFront];
		self.firstPoint.delegate = self;
        [self addSubview:self.firstPoint];
        self.secondPoint = [[TMCoordinatesView alloc] initWithTitle:@"Last Row Front" location:TMCoordinatesLocationLastRowFront];
		self.secondPoint.delegate = self;
        [self addSubview:self.secondPoint];
		self.thirdPoint = [[TMCoordinatesView alloc] initWithTitle:@"Last Row Back" location:TMCoordinatesLocationLastRowBack];
		self.thirdPoint.delegate = self;
        [self addSubview:self.thirdPoint];
        self.fourthPoint = [[TMCoordinatesView alloc] initWithTitle:@"First Row Back" location:TMCoordinatesLocationFirstRowBack];
		self.fourthPoint.delegate = self;
        [self addSubview:self.fourthPoint];
    }
    return self;
}

-(void)setCoordinates:(NSString *)latitude1 longitude1:(NSString*)longitude1
			latitude2:(NSString *)latitude2 longitude2:(NSString*)longitude2
			latitude3:(NSString *)latitude3 longitude3:(NSString*)longitude3
			latitude4:(NSString *)latitude4 longitude4:(NSString*)longitude4  {
	[self.firstPoint setCoordinates:latitude1 longitude:longitude1];
	[self.secondPoint setCoordinates:latitude2 longitude:longitude2];
	[self.thirdPoint setCoordinates:latitude3 longitude:longitude3];
	[self.fourthPoint setCoordinates:latitude4 longitude:longitude4];
}

- (void) layoutSubviews {
    [super layoutSubviews];
    
    CGFloat availableWidth = (CGRectGetWidth(self.bounds) - 1.0 * CoordinateViewSpacing) / 2.0 ;
    CGSize coordinatesViewSize = [self.firstPoint sizeThatFits:CGSizeMake(availableWidth, CGRectGetHeight(self.bounds) / 2.0)];
    
	self.firstPoint.frame = CGRectMake(0.0, 0.0, coordinatesViewSize.width, coordinatesViewSize.height);
    self.secondPoint.frame = CGRectMake(CGRectGetMaxX(self.firstPoint.frame) + CoordinateViewSpacing, 0.0, coordinatesViewSize.width, coordinatesViewSize.height);
	self.thirdPoint.frame = CGRectMake(0.0, CGRectGetMaxY(self.firstPoint.frame) + MONDimensionsSmallPadding, coordinatesViewSize.width, coordinatesViewSize.height);
	self.fourthPoint.frame = CGRectMake(CGRectGetMaxX(self.firstPoint.frame) + CoordinateViewSpacing, CGRectGetMaxY(self.firstPoint.frame) + MONDimensionsSmallPadding, coordinatesViewSize.width, coordinatesViewSize.height);
}

- (void)setLatitude:(NSString *)latitude longitude:(NSString *)longitude forLocation:(TMCoordinatesLocation)location {
    if(location == TMCoordinatesLocationFirstRowFront) {
        [self.firstPoint setCoordinates:latitude longitude:longitude];
    } else if(location == TMCoordinatesLocationLastRowFront) {
        [self.secondPoint setCoordinates:latitude longitude:longitude];
    } else if(location == TMCoordinatesLocationLastRowBack) {
        [self.thirdPoint setCoordinates:latitude longitude:longitude];
    } else if(location == TMCoordinatesLocationFirstRowBack) {
        [self.fourthPoint setCoordinates:latitude longitude:longitude];
    }
}

- (CGSize)sizeThatFits:(CGSize)size {
	CGSize sizeThatFits = size;
	CGFloat availableWidth = (size.width - 1.0 * CoordinateViewSpacing) / 2.0 ;
    CGSize coordinatesViewSize = [self.firstPoint sizeThatFits:CGSizeMake(availableWidth, size.height)];

	sizeThatFits.height = coordinatesViewSize.height * 2.0 + MONDimensionsSmallPadding;
	
	return sizeThatFits;
}

- (void) clearAllGPSPoints {
	[self.firstPoint clearCoordinates];
	[self.secondPoint clearCoordinates];
	[self.thirdPoint clearCoordinates];
	[self.fourthPoint clearCoordinates];
}

#pragma mark - TMCoordinatesViewDelegate Methods

- (void) evt_updatedLocation:(TMCoordinatesLocation)location latitude:(NSDecimalNumber *)latitude longitude:(NSDecimalNumber *)longitude {
	[self.delegate evt_updatedLocation:location latitude:latitude longitude:longitude];
}

- (void) evt_doneUpdatingValue:(NSString *)value; {
    [self.delegate evt_doneUpdatingValue:value];
}

- (void) evt_updateToCurrentLocation:(TMCoordinatesLocation)location {
    [self.delegate evt_updateToCurrentLocation:location];
}

@end
