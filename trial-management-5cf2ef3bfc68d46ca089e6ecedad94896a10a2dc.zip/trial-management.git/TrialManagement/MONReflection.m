#import "MONReflection.h"
@import ObjectiveC.runtime;

@implementation MONReflection
+ (BOOL)class:(Class)theClass hasProperty:(NSString*)propertyString {
	objc_property_t theProperty = class_getProperty(theClass, [propertyString cStringUsingEncoding:NSASCIIStringEncoding]);
	return theProperty != nil;
}
@end
