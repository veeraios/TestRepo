

#import "MONBlocker.h"
#import "MBProgressHUD.h"

@interface MONBlocker()
@property (nonatomic) UIView *currentView;
@end

@implementation MONBlocker

+(id)sharedInstance {
    static MONBlocker *_sharedManager = nil;
    static dispatch_once_t dispatchOnce;
    
    dispatch_once(&dispatchOnce, ^{
        _sharedManager = [[self alloc] init];
    });
    
    return _sharedManager;
}

-(void)showBlockerWithText:(NSString *)text forView:(UIView *)view {
    
    if(self.currentView == nil) {
        self.currentView = view;
        MBProgressHUD *progressHUD = [MBProgressHUD showHUDAddedTo:self.currentView animated:YES];
        progressHUD.labelText = text;
        progressHUD.dimBackground = YES;
    } else {
        DDLogError(@"Could not set the blocker for the view. Expected current view to be nil");
    }
    
}

-(void)hideBlocker {
    [MBProgressHUD hideHUDForView:self.currentView animated:YES];
    self.currentView = nil;
}

-(BOOL)isBlockerPresent {
    return nil != [MBProgressHUD HUDForView:self.currentView];
}

-(void)updateText:(NSString *)text{
    MBProgressHUD *progressHUD = [MBProgressHUD HUDForView:self.currentView];
    progressHUD.labelText = text;
}


@end
