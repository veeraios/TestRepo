#import "MONSegmentedControl.h"
#import "UIColor+MONThemeColorProvider.h"
#import "MONDimensions.h"

@implementation MONSegmentedControl

- (instancetype)initWithItems:(NSArray *)items {
    self = [super initWithItems:items];
    if (self) {
		self.backgroundColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeBackground];
		self.layer.cornerRadius = MONDimensionsSegmentedCornerRadius;
		self.layer.masksToBounds = YES;
		[self setTintColor:[UIColor colorForThemeComponentType:MONThemeComponentTypeButtonBackground]];
		[self setSelectedSegmentIndex:0];
		[self.layer setBorderColor:[UIColor colorForThemeComponentType:MONThemeComponentTypeSelectedBackground].CGColor];
		[self.layer setBorderWidth:MONDimensionsThinBorderWidth];
    }
    return self;
}

@end
