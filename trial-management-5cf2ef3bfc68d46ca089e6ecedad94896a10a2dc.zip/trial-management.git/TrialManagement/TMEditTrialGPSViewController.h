#import "MONTabController.h"
#import "TMTrialModel.h"
#import "TMPersistenceViewController.h"

@interface TMEditTrialGPSViewController : TMPersistenceViewController<MONTabController>
- (instancetype)initWithTrialModel:(TMTrialModel *)trialModel;
@end
