#import <UIKit/UIKit.h>

@interface MONItemCountView : UIView

- (void)setNumberOfItems:(NSUInteger)numberOfItems;
- (void)setAlertColor;

@end
