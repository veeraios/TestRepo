#import "TMMarketingView.h"
#import "MONHeaderView.h"
#import "MONDimensions.h"
#import "UIColor+MONThemeColorProvider.h"
#import "MONLabeledYesNoSwitch.h"
#import "MONModalTableView.h"
#import "MONButton.h"
#import "MONFonts.h"

@interface TMMarketingView()<MONModalTableViewDelegate>
@property (nonatomic) MONHeaderView *headerView;
@property (nonatomic) MONHeaderView *submittedForMarkingDateLabel;
@property (nonatomic) TMMarketingModel *marketingModel;
@property (nonatomic) MONLabel *subTitleLabel;
@property (nonatomic) MONLabeledYesNoSwitch* postToWebSwitch;
@property (nonatomic) MONLabeledYesNoSwitch* postCardYesNoSwitch;
@property (nonatomic) MONLabeledYesNoSwitch* emailYesNoSwitch;
@property (nonatomic) MONModalTableView *postcardModalTableView;
@property (nonatomic) MONModalTableView *emailModalTableView;
@property (nonatomic, assign) BOOL isReadOnly;

@end

@implementation TMMarketingView

- (instancetype)initWithMarketingModel:(TMMarketingModel*)marketingModel headerButtons:(NSArray *)headerButtons {
    self = [super init];
    if (self) {
		self.marketingModel = marketingModel;

		self.backgroundColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeBackground];

		self.headerView = [[MONHeaderView alloc] init];
		[self.headerView setTitle:@"MARKETING"];
		[self.headerView setRightButtons:headerButtons];
		[self addSubview:self.headerView];
		
		self.submittedForMarkingDateLabel = [[MONHeaderView alloc] init];
		[self.submittedForMarkingDateLabel setFont:[UIFont fontWithName:OpenSansSemibold size:24]];
		[self addSubview:self.submittedForMarkingDateLabel];
		
		self.subTitleLabel = [[MONLabel alloc] init];
		[self.subTitleLabel setText:@"How would you like to communicate plot results?"];
		[self addSubview:self.subTitleLabel];
		
		self.postToWebSwitch = [[MONLabeledYesNoSwitch alloc] initWithTitle:@"Post to Web" defaultValue:[self.marketingModel shouldPostToWeb]];
		[self.postToWebSwitch.yesNoSwitch addTarget:self action:@selector(postToWebSwitchWasTapped:) forControlEvents:UIControlEventValueChanged];
		[self addSubview:self.postToWebSwitch];

		self.postCardYesNoSwitch = [[MONLabeledYesNoSwitch alloc] initWithTitle:@"Postcard" borderColor:[UIColor clearColor] defaultValue:[self.marketingModel shouldPostCard]];
		[self.postCardYesNoSwitch.yesNoSwitch addTarget:self action:@selector(postCardSwitchWasTapped:) forControlEvents:UIControlEventValueChanged];
		
		self.postcardModalTableView = [[MONModalTableView alloc] initWithHeaderView:self.postCardYesNoSwitch  tableTitle:@"Send To These Counties:" modalButton: [[MONButton alloc] initWithTitle:@"Edit Counties"] footerView:[MONLabel defaultLabelWithText:@"Select up to 5 counties for Postcards."] model:[self.marketingModel postcardTableViewModel]];
		
		self.postcardModalTableView.delegate = self;
		[self addSubview:self.postcardModalTableView];
		
		self.emailYesNoSwitch = [[MONLabeledYesNoSwitch alloc] initWithTitle:@"Email" borderColor:[UIColor clearColor] defaultValue:[self.marketingModel shouldEmail]];
		[self.emailYesNoSwitch.yesNoSwitch addTarget:self action:@selector(emailSwitchWasTapped:) forControlEvents:UIControlEventValueChanged];
		
		self.emailModalTableView = [[MONModalTableView alloc] initWithHeaderView:self.emailYesNoSwitch tableTitle:@"Send To These Counties:" modalButton: [[MONButton alloc] initWithTitle:@"Edit Counties"] footerView:nil model:[self.marketingModel emailTableViewModel]];
		
		self.emailModalTableView.delegate = self;
		[self addSubview:self.emailModalTableView];
    }
    return self;
}

- (void)setAsReadOnly {
	self.isReadOnly = YES;
}

- (void)layoutSubviews {
	[super layoutSubviews];
	
	[self.headerView sizeToFit];
	self.headerView.frame = CGRectMake(0.0, 0.0, CGRectGetWidth(self.bounds), CGRectGetHeight(self.headerView.frame));
	
	[self.subTitleLabel sizeToFit];
	self.subTitleLabel.frame = CGRectMake(MONDimensionsSmallPadding, CGRectGetMaxY(self.headerView.frame) + MONDimensionsTinyPadding, CGRectGetWidth(self.bounds)-MONDimensionsSmallPadding, CGRectGetHeight(self.subTitleLabel.frame));
	
	if([self.submittedForMarkingDateLabel.title length] > 0) {
		self.submittedForMarkingDateLabel.frame = CGRectMake(140, 0.0, CGRectGetWidth(self.submittedForMarkingDateLabel.frame), CGRectGetHeight(self.headerView.frame));
	}
	
	[self.postToWebSwitch sizeToFit];
	self.postToWebSwitch.frame = CGRectMake(CGRectGetMinX(self.subTitleLabel.frame),
			CGRectGetMaxY(self.subTitleLabel.frame) + MONDimensionsSmallPadding,
											CGRectGetWidth(self.bounds)-(MONDimensionsSmallPadding*2),
											CGRectGetHeight(self.postToWebSwitch.frame));
	
	CGFloat cardHeight = CGRectGetMaxY(self.bounds) - (CGRectGetMaxY(self.postToWebSwitch.frame) + MONDimensionsSmallPadding + MONDimensionsLargePadding);
	
	[self.postcardModalTableView sizeToFit];
	CGFloat postCardWidth = ((CGRectGetWidth(self.bounds)-(MONDimensionsSmallPadding*2)) / 2.0 ) - (MONDimensionsSmallPadding/2.0);
	
	self.postcardModalTableView.frame = CGRectMake(CGRectGetMinX(self.postToWebSwitch.frame),
												   CGRectGetMaxY(self.postToWebSwitch.frame) + MONDimensionsSmallPadding,
										postCardWidth,cardHeight);

	[self.emailModalTableView sizeToFit];
	CGFloat emailCardWidth = ((CGRectGetWidth(self.bounds)-(MONDimensionsSmallPadding*2)) / 2.0) - (MONDimensionsSmallPadding/2.0);
	
	self.emailModalTableView.frame = CGRectMake(CGRectGetMaxX(self.postcardModalTableView.frame) + MONDimensionsSmallPadding, CGRectGetMaxY(self.postToWebSwitch.frame) + MONDimensionsSmallPadding,
												emailCardWidth, cardHeight);

}

- (void)setHeaderButtons:(NSArray *)headerButtons
{
    [self.headerView setRightButtons:headerButtons];
    [self setNeedsLayout];
}

- (void)setSubmittedDate:(NSDate*)date animate:(BOOL)animate {
	if(date != nil ) {
		NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
		[dateFormat setDateFormat:@"MM/dd/yyyy"];
		
		if(animate && [self.submittedForMarkingDateLabel.title length] == 0) {
			[self.submittedForMarkingDateLabel setAlpha:0.0];
			[self.submittedForMarkingDateLabel setTitle:[NSString stringWithFormat:@"(SUBMITTED %@)",[dateFormat stringFromDate:date]]];
			[UIView animateWithDuration:0.5
								  delay:0.0
								options:UIViewAnimationOptionCurveEaseIn
							 animations:^{
								 [self.submittedForMarkingDateLabel setAlpha:1.0];
							 }
							 completion:^(BOOL finished) {
							 }];
		} else {
			[self.submittedForMarkingDateLabel setTitle:[NSString stringWithFormat:@"(SUBMITTED %@)",[dateFormat stringFromDate:date]]];
		}
		[self setNeedsLayout];
	}
}



- (void)refreshTables {
	[self.postcardModalTableView refreshTable:[self.marketingModel postcardTableViewModel]];
	[self.emailModalTableView refreshTable:[self.marketingModel emailTableViewModel]];
}

- (void)resetPostcardAndEmailSwitches {
    [self.postCardYesNoSwitch.yesNoSwitch setSwitchValue:NO];
    [self.emailYesNoSwitch.yesNoSwitch setSwitchValue:NO];
    [self.delegate submissionSwitchWasChanged:NO forSubmissionType:PostCard];
    [self.delegate submissionSwitchWasChanged:NO forSubmissionType:Email];
}

- (void)modalButtonWasTapped:(MONModalTableView*)caller {
    [self.delegate editCountiesWasTappedForSubmissionType: caller == self.emailModalTableView ? Email : PostCard];
}

- (void)removeButtonTapped:(MONModalTableView*)caller index:(NSInteger)index objectToRemove:(id)objectToRemove {
	if(self.isReadOnly) {
		return;
	}
    [self.delegate removeCounty:objectToRemove forSubmissionType: caller == self.emailModalTableView ? Email : PostCard];
}

- (void)emailSwitchWasTapped:(id)caller {
    [self.delegate submissionSwitchWasChanged:((MONYesNoSwitch*)caller).switchValue forSubmissionType:Email];
}

- (void)postCardSwitchWasTapped:(id)caller {
    [self.delegate submissionSwitchWasChanged:((MONYesNoSwitch*)caller).switchValue forSubmissionType:PostCard];
}

- (void)postToWebSwitchWasTapped:(id)caller {
	[self.delegate postToWebSwitchWasChanged:((MONYesNoSwitch*)caller).switchValue];
}

- (void)setCountiesSelectionEnabled:(BOOL)enabled forSubmissionType:(TMMarketingSubmissionType)type {
    if (type == Email) {
        [self.emailYesNoSwitch.yesNoSwitch setSwitchValue:enabled];
        [self.emailModalTableView setModalButtonEnabled:enabled];
    } else {
        [self.postCardYesNoSwitch.yesNoSwitch setSwitchValue:enabled];
        [self.postcardModalTableView setModalButtonEnabled:enabled];
    }
}

@end
