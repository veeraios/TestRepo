//
//  TMMergePathValueLocator.swift
//  TrialManagement
//
//  Created by WAIDMANN, ALAN [AG/1000] on 2/13/15.
//  Copyright (c) 2015 Monsanto. All rights reserved.
//

import UIKit

let UserInfoUIDKey = "uniqueId"
let UserInfoUIDSeparator = ","
let PathSeparator = "."

class TMMergePathValueLocator: NSObject {

    
    func findObjectWith(fullPath: String, rootObject: NSManagedObject) -> AnyObject? {
        return findObjectWith(fullPath.componentsSeparatedByString(PathSeparator), rootObject: rootObject)
    }
    
    private func findObjectWith(pathComponents: [String], rootObject: NSManagedObject) -> AnyObject? {
        
        if let headComponent = pathComponents.first {
            
            switch rootObject.entity.propertiesByName[headComponent] {
                
            case let attribute as NSAttributeDescription:
                return rootObject.valueForKey(headComponent)

            case let relationship as NSRelationshipDescription where !relationship.toMany:
                if let destinationObject = rootObject.valueForKey(headComponent) as? NSManagedObject {
                    return findObjectWith(pathComponents.tail(), rootObject: destinationObject)
                } else {
                    MONLogger.logError("Object of type: \(relationship.destinationEntity!.managedObjectClassName) could not be found on \(rootObject.entity.managedObjectClassName)")
                }
                
            case let relationship as NSRelationshipDescription where relationship.toMany:
                if let explicitUID = pathComponents.tail().first {
                    let uidComponents = relationship.destinationEntity?.userInfo?[UserInfoUIDKey] as String

                    if let foundObject = TMMergeManagedObjectLocator.findManagedObjectWithPartialKeys(uidComponents, explicitUID: explicitUID, entity: relationship.destinationEntity!, relationObjects: rootObject.valueForKey(headComponent) as NSSet) {
                        return findObjectWith(pathComponents.tail().tail(), rootObject: foundObject)
                    } else {
                        MONLogger.logError("Object of type: \(relationship.destinationEntity!.managedObjectClassName) could not be found with UID: \(explicitUID)")
                    }
                }

            default:
                MONLogger.logError("\(headComponent) not valid partial key for \(rootObject.entity.managedObjectClassName)")
            }
        }
        
        return nil
    }
    
}
