#import "MONTitleValueVerticalButtonLabelView.h"
#import "MONFonts.h"
#import "MONLabel.h"
#import "UIColor+MONThemeColorProvider.h"

static const CGFloat ButtonOriginYOffset = 6.0;
static const CGFloat ButtonVerticalInset = 20.0;
static const CGFloat ButtonTextSize = 14.0;
static const CGFloat IconButtonWidth = 40.0;

@interface MONTitleValueVerticalButtonLabelView ()

@property (nonatomic) MONLabel *titleLabel;
@property (nonatomic) MONLabel *valueLabel;
@property (nonatomic) UIButton *valueButton;
@property (nonatomic) UIButton *iconButton;

@end

@implementation MONTitleValueVerticalButtonLabelView

- (id)initWithFrame:(CGRect)frame {
	self = [super initWithFrame:frame];
	if (self) {
		
		self.titleLabel.userInteractionEnabled = NO;
		self.valueLabel.alpha = 0.0;
		
		self.valueButton = [[UIButton alloc] init];
		self.valueButton.titleLabel.font = [UIFont fontWithName:OpenSans size:ButtonTextSize];
		self.valueButton.titleLabel.lineBreakMode = NSLineBreakByTruncatingTail;
		[self.valueButton setContentHorizontalAlignment:UIControlContentHorizontalAlignmentLeft];
		[self.valueButton setTitleColor:[UIColor colorForThemeComponentType:MONThemeComponentTypeLinkButtonText] forState:UIControlStateNormal];
		[self.valueButton addTarget:self action:@selector(valueButtonTapped) forControlEvents:UIControlEventTouchUpInside];
		[self addSubview:self.valueButton];
		
		self.iconButton = [[UIButton alloc] init];
		[self.iconButton addTarget:self action:@selector(iconButtonTapped) forControlEvents:UIControlEventTouchUpInside];
		[self addSubview:self.iconButton];
	}
	return self;
}

- (void)setIsReadOnly:(BOOL)isReadOnly {
	self.iconButton.enabled = !isReadOnly;
	self.valueButton.enabled = !isReadOnly;
}

- (void)layoutSubviews {
	[super layoutSubviews];
		
	CGRect titleLabelFrame = self.titleLabel.frame;
	titleLabelFrame.origin.x = IconButtonWidth;
	self.titleLabel.frame = titleLabelFrame;
	
	self.iconButton.frame = CGRectMake(0.0,
									   CGRectGetMinY(self.valueLabel.frame) - ButtonOriginYOffset,
									   IconButtonWidth,
									   IconButtonWidth);
	
	[self.valueButton sizeToFit];
	CGRect buttonFrame = CGRectMake(IconButtonWidth,
										CGRectGetMinY(self.valueLabel.frame) - ButtonOriginYOffset,
										CGRectGetWidth(self.bounds) - CGRectGetMaxX(self.iconButton.frame),
										CGRectGetHeight(self.valueButton.frame));
	
	self.valueButton.frame = CGRectInset(buttonFrame, 0.0, -ButtonVerticalInset);
	
	self.iconButton.center = CGPointMake(self.iconButton.center.x, self.valueButton.center.y);
}

- (void)setButtonText:(NSString *)buttonText {
	[self.valueButton setTitle:buttonText forState:UIControlStateNormal];
	[self setNeedsLayout];
}

- (void)valueButtonTapped {
	[self.delegate titleValueVerticalButtonLabelViewButtonTapped:self];
}

- (void)setIconButtonImage:(UIImage *)iconButtonImage {
	[self.iconButton setImage:iconButtonImage forState:UIControlStateNormal];
}

- (void)iconButtonTapped {
	[self.delegate iconButtonTapped];
}

@end
