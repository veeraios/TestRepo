#import "TMDealerTableViewHeaderView.h"

static const CGFloat CountyLabelOriginY = 228.0;
static const CGFloat StateLabelOriginY = 400.0;
static const CGFloat CityLabelOriginY = 578.0;

@interface TMDealerTableViewHeaderView ()

@property (nonatomic) MONLabel *dealerLabel;
@property (nonatomic) MONLabel *countryLabel;
@property (nonatomic) MONLabel *stateLabel;
@property (nonatomic) MONLabel *cityLabel;
@property (nonatomic) UIView *bottomBorderView;

@end

@implementation TMDealerTableViewHeaderView

- (instancetype)init {
	self = [super init];
	if (self) {
		self.backgroundColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeFreshAsphalt];
		
		self.dealerLabel = [self defaultLabelWithText:@"Dealer"];
		[self addSubview:self.dealerLabel];
		
		self.countryLabel = [self defaultLabelWithText:@"Country"];
		[self addSubview:self.countryLabel];
		
		self.stateLabel = [self defaultLabelWithText:@"State"];
		[self addSubview:self.stateLabel];
		
		self.cityLabel = [self defaultLabelWithText:@"City"];
		[self addSubview:self.cityLabel];
		
		self.bottomBorderView = [[UIView alloc] init];
		self.bottomBorderView.backgroundColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeEarlGray];
		[self addSubview:self.bottomBorderView];
	}
	return self;
}

- (MONLabel *)defaultLabelWithText:(NSString *)text {
	MONLabel *label = [[MONLabel alloc] init];
	label.text = text;
	return label;
}

- (void)layoutSubviews {
	[super layoutSubviews];
	
	CGRect contentRect = CGRectInset(self.bounds, MONDimensionsSmallPadding, MONDimensionsSmallPadding);
	
	[self.dealerLabel sizeToFit];
	self.dealerLabel.frame = CGRectMake(CGRectGetMinX(contentRect),
											MONUIScreenRoundToScreenScale((CGRectGetMaxY(self.bounds) - CGRectGetHeight(self.dealerLabel.frame)) / 2.0),
											CGRectGetWidth(self.dealerLabel.frame),
											CGRectGetHeight(self.dealerLabel.frame));
	
	[self.countryLabel sizeToFit];
	self.countryLabel.frame = CGRectMake(CGRectGetMinX(contentRect) + CountyLabelOriginY,
										 CGRectGetMinY(self.dealerLabel.frame),
										 CGRectGetWidth(self.countryLabel.frame),
										 CGRectGetHeight(self.countryLabel.frame));
	
	[self.stateLabel sizeToFit];
	self.stateLabel.frame = CGRectMake(CGRectGetMinX(contentRect) + StateLabelOriginY,
									   CGRectGetMinY(self.dealerLabel.frame),
									   CGRectGetWidth(self.stateLabel.frame),
									   CGRectGetHeight(self.stateLabel.frame));
	
	[self.cityLabel sizeToFit];
	self.cityLabel.frame = CGRectMake(CGRectGetMinX(contentRect) + CityLabelOriginY,
									  CGRectGetMinY(self.dealerLabel.frame),
									  CGRectGetWidth(self.cityLabel.frame),
									  CGRectGetHeight(self.cityLabel.frame));
	
	self.bottomBorderView.frame = CGRectMake(0.0, CGRectGetMaxY(self.bounds), CGRectGetWidth(self.bounds), MONDimensionsThinBorderWidth);
}

@end
