//
//  TMGlobalMenuModel.h
//  TrialManagement
//
//  Created by SINGH, SUPREET [AG/1000] on 8/11/14.
//  Copyright (c) 2014 Monsanto. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "TMTrialModel.h"

@interface TMGlobalMenuModel : NSObject

@property (nonatomic, readonly) NSString *status;
@property (nonatomic, readonly) NSString *trialName;
@property (nonatomic, readonly) NSString *growerName;
@property (nonatomic, readonly) NSString *salesManagerName;
@property (nonatomic, readonly) NSString *cropName;
@property (nonatomic, readonly) NSString *plotTypeDescription;

- (instancetype)init UNAVAILABLE_ATTRIBUTE;
- (instancetype)initWithTrialModel:(TMTrialModel *)trialModel;
- (BOOL)isEligibleForMarketing;
- (BOOL) isBasicTrialInfoFilled;


@end
