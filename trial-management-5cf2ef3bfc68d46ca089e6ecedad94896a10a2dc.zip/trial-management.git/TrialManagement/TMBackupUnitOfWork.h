//
//  TMUnitOfWorkBackup.h
//  TrialManagement
//
//  Created by GADIRAJU, PRANEETH [AG/1000] on 12/8/14.
//  Copyright (c) 2014 Monsanto. All rights reserved.
//
#import "TMBackupCoreDataContextProtocol.h"

@protocol TMBackupUnitOfWorkProtocol <NSObject>
@required
@property(nonatomic,strong,readonly) id<TMBackupCoreDataContextProtocol> backupContext;
- (void) createBackupCopyOfTrial: (TMTrial *)trial;
- (void) deleteBackupCopyOfTrial: (TMTrial *)trial;
+ (id<TMBackupUnitOfWorkProtocol>) sharedInstance;
@end

@interface TMBackupUnitOfWork : NSObject<TMBackupUnitOfWorkProtocol>
@end
