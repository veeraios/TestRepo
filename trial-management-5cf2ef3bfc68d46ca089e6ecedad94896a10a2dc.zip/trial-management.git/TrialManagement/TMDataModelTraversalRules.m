//
//  TMDataModelTraversalMergeRulesHolder.m
//  TrialManagement
//
//  Created by GADIRAJU, PRANEETH [AG/1000] on 1/6/15.
//  Copyright (c) 2015 Monsanto. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "TMDataModelTraversalRules.h"

@interface TMDataModelTraversalRules()
@property (nonatomic,readwrite) NSDictionary *dataModelTraversalRulesDictionary;
@property (nonatomic,readwrite) NSSet *dataModelTransactionalTableRules;
- (id)init;
@end

@implementation TMDataModelTraversalRules

+(id)sharedInstance {
    static TMDataModelTraversalRules *_sharedManager = nil;
    static dispatch_once_t dispatchOnce;
    
    dispatch_once(&dispatchOnce, ^{
        _sharedManager = [[self alloc] init];
    });
    
    return _sharedManager;
}

- (id)init {
    self = [super init];
    if (self) {
        self.dataModelTraversalRulesDictionary = @{@"TMTrial"                    : @[@"brand",@"county",@"crop",@"dealer",@"emailCounties",@"entries",@"grower",@"observations",@"plotType",@"postCardCounties",@"previousCrop",@"rowSpacingUnitOfMeasure",@"soilType",@"state",@"techAgronomist",@"tile",@"tillageMethod",@"unitOfMeasure",@"users"],
                                                   @"TMCrop"                     : @[@"rowSpacingUnitOfMeasures",@"unitOfMeasures"],
                                                   @"TMObservation"              : @[@"observationReferenceData",@"unitOfMeasure"],
                                                   @"TMObservationReferenceData" : @[@"category",@"observationCalculation",@"crop",@"unitOfMeasure"],
                                                   @"TMEntry"                    : @[@"observations",@"product",@"treatment"],
                                                   @"TMTechAgronomist"           : @[@"brand",@"users"]};
        self.dataModelTransactionalTableRules = [[NSSet alloc] initWithArray: @[@"TMTrial",@"TMEntry",@"TMObservation"]];
    }
    return self;
}


@end
