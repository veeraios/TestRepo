import UIKit

@objc protocol MONFacetSearchFieldDisplayDelegate: class {
    func closeSearchButtonTapped()
}

@objc protocol MONFacetSearchFieldModelDelegate: class {
    func filterUpdated()
}

class MONFacetSearchFieldController: UIViewController {
    
    weak var displayDelegate: MONFacetSearchFieldDisplayDelegate?
    weak var modelDelegate: MONFacetSearchFieldModelDelegate?
    
    private var searchModel: MONFacetSearchModel
    private var searchField: MONFacetSearchField
    private var facetViewModels = [MONFacetView : MONFacetModel]()
    
    init(placeholderText: String?, basePredicate: MONFacetPredicateProtocol) {
        searchModel = MONFacetSearchModel(basePredicate: basePredicate)
        searchField = MONFacetSearchField(placeholderText: placeholderText)
        
        super.init(nibName: nil, bundle: nil)
        
        searchModel.delegate = self
        searchField.delegate = self
        searchField.autoresizingMask = UIViewAutoresizing.FlexibleWidth | UIViewAutoresizing.FlexibleHeight
        view.addSubview(searchField)
    }
    
    required init(coder aDecoder: NSCoder) {fatalError("init(coder:) has not been implemented")}
    
    override func viewDidLoad() {
        super.viewDidLoad()
        searchField.frame = view.frame
    }
    
    override func becomeFirstResponder() -> Bool {
        return searchField.becomeFirstResponder()
    }
    
    override func resignFirstResponder() -> Bool {
        return searchField.resignFirstResponder()
    }
    
    func clearSearchField() {
        searchField.clearSearchField()
        searchModel.cancelSearch()
        facetViewModels = [MONFacetView : MONFacetModel]()
    }
}

extension MONFacetSearchFieldController: MONFacetSearchModelDelegate {
    
    func facetFinalized(facet: MONFacetModel) {
        let newFacetView = MONFacetView(text: facet.prevText)
        searchField.appendFacetView(newFacetView)
        facetViewModels[newFacetView] = facet
    }
    
    func filterUpdated() {
        modelDelegate?.filterUpdated()
    }
}

extension MONFacetSearchFieldController: MONFacetSearchFieldDelegate {
    
    func currentSearchFinalized() {
        searchModel.finalizeCurrentSearch()
    }
    
    func filterWithText(text: String) {
        searchModel.filterItemsWithText(text)
    }
    
    func facetRemoved(facetView: MONFacetView) {
        if let removedModel = facetViewModels[facetView] {
            searchModel.facetRemoved(removedModel)
            facetViewModels.removeValueForKey(facetView)
        }
    }
    
    func clearSearchFieldButtonTapped() {
        clearSearchField()
    }
    
    func closeSearchButtonTapped() {
        clearSearchField()
        displayDelegate?.closeSearchButtonTapped()
    }
}

extension MONFacetSearchFieldController: MONSearchModelProtocol {
    func setAllSearchItems(items: [AnyObject]?) { searchModel.setAllSearchItems(items) }
    func filterItemsWithText(filterText: String) { searchModel.filterItemsWithText(filterText) }
    func filteredItemAtIndex(index: Int) -> AnyObject? { return searchModel.filteredItemAtIndex(index) }
    func filteredItems() -> [AnyObject]? { return searchModel.filteredItems() }
    func itemsWereFiltered() -> Bool { return searchModel.itemsWereFiltered() }
    func cancelSearch() { searchModel.cancelSearch() }
}