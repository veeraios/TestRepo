import UIKit

protocol MONFacetSearchFieldDelegate: class {
    func currentSearchFinalized()
    func filterWithText(text: String)
    func facetRemoved(facetView: MONFacetView)
    func clearSearchFieldButtonTapped()
    func closeSearchButtonTapped()
}

class MONFacetSearchField: UIView {
    
    weak var delegate: MONFacetSearchFieldDelegate?
    var facetViews = [MONFacetView]()
    
    private let searchScrollView = UIScrollView()
    private let searchField = UITextField()
    private let borderView = UIView()
    private let searchIcon = UIImageView()
    private let clearSearchFieldButton = UIButton()
    private let closeSearchButton = UIButton()
    
    private var totalFacetViewWidth: CGFloat = 0.0
    private var textWidth: CGFloat = 0.0
    
    init(placeholderText: String?) {
        searchField.placeholder = placeholderText ?? "Search"
        searchField.autocorrectionType = .No
        
        searchIcon = UIImageView(image: UIImage(named: "ui-icon-search-light"))
        searchIcon.contentMode = .ScaleAspectFill
        
        clearSearchFieldButton.setImage(UIImage(named: "ui-icon-remove-small-light"), forState: .Normal)
        clearSearchFieldButton.contentMode = .ScaleAspectFill
        
        closeSearchButton.setTitle("CLOSE", forState: .Normal)
        
        super.init(frame: CGRect.zeroRect)
        
        searchField.delegate = self
        
        addSubview(borderView)
        addSubview(searchScrollView)
        addSubview(searchIcon)
        searchScrollView.addSubview(searchField)
        addSubview(clearSearchFieldButton)
        addSubview(closeSearchButton)
        
        clearSearchFieldButton.addTarget(self, action: "clearSearchFieldButtonTapped", forControlEvents: .TouchUpInside)
        closeSearchButton.addTarget(self, action: "closeSearchButtonTapped", forControlEvents: .TouchUpInside)
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "searchTextDidChange:", name: UITextFieldTextDidChangeNotification, object: nil)
        
        backgroundColor = UIColor(forThemeComponentType: MONThemeComponentTypeBackground)
        closeSearchButton.backgroundColor = backgroundColor
        closeSearchButton.setTitleColor(UIColor.blackColor(), forState: .Normal)
    }

    required init(coder aDecoder: NSCoder) {fatalError("init(coder:) has not been implemented")}
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        let scaledOffset = ceil(0.1 * frame.size.height)
        let scaledFontSize = ceil(0.35 * frame.size.height)
        
        let contentRect = CGRectInset(frame, scaledOffset, scaledOffset)
        let scaledSearchIconHeight = contentRect.height - 3.0*scaledOffset
        let scaledFacetViewHeight = contentRect.height - 2.0*scaledOffset
        
        closeSearchButton.titleLabel?.font = closeSearchButton.titleLabel?.font.fontWithSize(scaledFontSize)
        closeSearchButton.sizeToFit()
        
        closeSearchButton.frame = CGRectMake(
            CGRectGetMaxX(contentRect) - (CGRectGetWidth(closeSearchButton.frame) + 2.0*scaledOffset),
            CGRectGetMinY(contentRect),
            CGRectGetWidth(closeSearchButton.frame) + 2.0*scaledOffset,
            contentRect.height
        )
        
        searchIcon.frame = CGRectMake(
            CGRectGetMinX(contentRect) + 2.0*scaledOffset,
            (CGRectGetHeight(frame) - scaledSearchIconHeight)/2.0,
            scaledSearchIconHeight,
            scaledSearchIconHeight)
        
        borderView.frame = contentRect
        borderView.frame.origin.x = CGRectGetMinX(contentRect)
        borderView.frame.size.width = CGRectGetWidth(borderView.frame) - CGRectGetWidth(closeSearchButton.frame)
        
        clearSearchFieldButton.frame = searchIcon.frame
        clearSearchFieldButton.frame.origin.x = CGRectGetMaxX(borderView.frame) - (CGRectGetWidth(clearSearchFieldButton.frame) + 2.0*scaledOffset)
        
        searchScrollView.frame = CGRectMake(
            CGRectGetMaxX(searchIcon.frame) + scaledOffset,
            CGRectGetMinY(contentRect),
            CGRectGetMinX(clearSearchFieldButton.frame) - (CGRectGetMaxX(searchIcon.frame) + scaledOffset),
            contentRect.height
        )
        
        var lastFacetMaxX: CGFloat = 0.0
        facetViews.forEach({ [unowned self] in
            $0.setTextSize(scaledFontSize)

            let facetSize = $0.sizeThatFits(self.searchScrollView.frame.size)

            $0.frame = CGRectMake(
                lastFacetMaxX,
                (CGRectGetHeight(self.searchScrollView.frame) - scaledFacetViewHeight)/2.0,
                facetSize.width,
                scaledFacetViewHeight)

            lastFacetMaxX = CGRectGetMaxX($0.frame) + scaledOffset
        })
        
        totalFacetViewWidth = lastFacetMaxX + scaledOffset
        
        searchField.font = searchField.font.fontWithSize(scaledFontSize)
        
        borderView.layer.borderColor = UIColor.grayColor().CGColor
        borderView.layer.borderWidth = 1.0
        borderView.layer.cornerRadius = contentRect.height/2.0

        var searchFieldWidth: CGFloat
        if (facetViews.isEmpty) { searchFieldWidth = CGRectGetWidth(searchScrollView.frame) }
        else if (lastFacetMaxX < (CGRectGetWidth(searchScrollView.frame) * 0.75)) { searchFieldWidth = CGRectGetWidth(searchScrollView.frame) - lastFacetMaxX }
        else { searchFieldWidth = CGRectGetWidth(searchScrollView.frame)/4.0 }
        
        searchField.frame = CGRectMake(
            totalFacetViewWidth,
            0,
            searchFieldWidth,
            CGRectGetHeight(searchScrollView.frame)
        )
        
        searchScrollView.contentSize = CGSizeMake(
            CGRectGetWidth(searchField.frame) + totalFacetViewWidth,
            CGRectGetHeight(searchScrollView.frame)
        )
        
        searchScrollView.scrollRectToVisible(searchField.frame, animated: true)

    }
    
    func appendFacetView(facetView: MONFacetView) {
        searchField.text = ""
        
        facetView.delegate = self
        
        searchScrollView.addSubview(facetView)
        facetViews.append(facetView)
        
        setNeedsLayout()
    }
    
    func clearSearchField() {
        searchField.text = ""
        facetViews.forEach({ $0.removeFromSuperview() })
        facetViews = [MONFacetView]()
        setNeedsLayout()
    }
    
    func searchTextDidChange(notification: NSNotification) {
        if let textField = notification.object as? UITextField {
            let changedTextRect = (textField.text as NSString).boundingRectWithSize(
                searchScrollView.frame.size,
                options: .UsesLineFragmentOrigin,
                attributes: [NSFontAttributeName: textField.font],
                context: nil)
            
            if changedTextRect.width > CGRectGetWidth(searchScrollView.frame)/4.0 {
                searchScrollView.contentSize = CGSizeMake(
                    totalFacetViewWidth + changedTextRect.width,
                    searchScrollView.contentSize.height
                )
                
                searchField.sizeToFit()
                searchField.frame.size.height = searchScrollView.frame.height
                searchScrollView.scrollRectToVisible(searchField.frame, animated: true)
            }
        }
    }
    
    override func becomeFirstResponder() -> Bool {
        return searchField.becomeFirstResponder()
    }
    
    override func resignFirstResponder() -> Bool {
        return searchField.resignFirstResponder()
    }
    
    func clearSearchFieldButtonTapped() {
        delegate?.clearSearchFieldButtonTapped()
    }
    
    func closeSearchButtonTapped() {
        delegate?.closeSearchButtonTapped()
    }
}

extension MONFacetSearchField: UITextFieldDelegate {
    
    func textField(textField: UITextField, shouldChangeCharactersInRange range: NSRange, replacementString string: String) -> Bool {
        if string.contains(" ") || string.contains("\n") {
            if !textField.text.isEmpty {
                delegate?.currentSearchFinalized()
            }
            return false
        } else {
            delegate?.filterWithText((textField.text as NSString).stringByReplacingCharactersInRange(range, withString: string))
            return true
        }
    }
}

extension MONFacetSearchField: MONFacetViewActionDelegate {
    
    func removeFacetButtonTapped(facetView: MONFacetView) {
        facetViews = facetViews.filter( {$0 != facetView} )
        facetView.removeFromSuperview()
        setNeedsLayout()
        
        delegate?.facetRemoved(facetView)
    }
}


