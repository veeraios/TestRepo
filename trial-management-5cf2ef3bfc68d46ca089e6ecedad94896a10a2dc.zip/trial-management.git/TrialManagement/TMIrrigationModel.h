#import "TMClearableReferenceDataListGenericModel.h"

static NSString* const IrrigationPlaceholderValue = @"Select Irrigation";

@interface TMIrrigationModel : TMClearableReferenceDataListGenericModel
@end
