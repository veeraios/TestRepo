#import <MapKit/MapKit.h>
#import "TMEditTrialGPSView.h"
#import "TMGPSPointsView.h"
#import "MONHeaderView.h"
#import "MONDimensions.h"
#import "MONColors.h"
#import "MONButton.h"
#import "MONFonts.h"
#import "UIColor+MONThemeColorProvider.h"
#import "UIImage+MONThemeImageProvider.h"
#import "NSArray+MONHelpers.h"
#import "TrialManagement-Swift.h"

static NSString * const AnnotationReuseIdentifier = @"EditTrialGPSAnnotation";
static const CGFloat GPSPinVerticalOffset = -37;
static const CGFloat GPSLatLongLabelHeight = 30;

@interface TMEditTrialGPSView ()<TMGPSPointsViewDelegate, MKMapViewDelegate, UIActionSheetDelegate, UIGestureRecognizerDelegate>

@property (nonatomic) MONHeaderView *headerView;
@property (nonatomic) TMGPSPointsView *gpsPointsView;
@property (nonatomic) MKMapView *mapView;
@property (nonatomic) UIButton *deleteButton;
@property (nonatomic) MONButton *continueButton;
@property (nonatomic) UIView *latLongLabelBackground;
@property (nonatomic) MONLabel *latLongLabel;
@property (nonatomic) MONLabel *accuracyLabel;
@property (nonatomic) UIButton *moveToCurrentLocationButton;
@property (nonatomic) UIButton *moveToCoordinatesButton;
@property (nonatomic) MKMapRect coordinatesRect;
@property (nonatomic) BOOL zoomToPins;
@property (nonatomic) BOOL initialLocationUpdateHappened;
@property (nonatomic) UIImageView *pinImageView;

@end

@implementation TMEditTrialGPSView

- (instancetype)initWithHeaderButtons:(NSArray *)headerButtons {
    if (self = [super init]) {
        self.autoresizesSubviews = YES;
		self.backgroundColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeBackground];
		
		self.deleteButton = [[UIButton alloc] init];
		[self.deleteButton setImage:[UIImage imageForUserColorPreference:@"ui-icon-trash-active"] forState:UIControlStateNormal];
		[self.deleteButton addTarget:self action:@selector(deleteButtonTapped) forControlEvents:UIControlEventTouchUpInside];
      
		self.headerView = [[MONHeaderView alloc] init];
		[self.headerView setTitle:@"ENTER PLOT COORDINATES"];
		[self.headerView setRightButtons:[@[self.deleteButton] arrayByAddingObjectsFromArray:headerButtons]];
		[self addSubview:self.headerView];
        
        self.gpsPointsView = [[TMGPSPointsView alloc] init];
        self.gpsPointsView.autoresizingMask = UIViewAutoresizingFlexibleWidth;
		self.gpsPointsView.delegate = self;
		[self addSubview:self.gpsPointsView];
        
        self.mapView = [[MKMapView alloc]init];
		self.mapView.delegate = self;
        self.mapView.mapType = MKMapTypeHybrid;
		self.mapView.layer.cornerRadius = MONDimensionsCornerRadius;
		[self addSubview:self.mapView];
        
        self.latLongLabelBackground = [[UIView alloc] init];
        self.latLongLabelBackground.backgroundColor = [MONColors freshAsphaltColor];
        self.latLongLabelBackground.alpha = 0.8;
        [self addSubview:self.latLongLabelBackground];
        
        self.latLongLabel = [MONLabel defaultLabelWithText:@""];
        [self.latLongLabel setFontName:OpenSansSemibold];
        self.latLongLabel.textColor = [MONColors boneColor];
        [self addSubview:self.latLongLabel];
        
        self.accuracyLabel = [MONLabel defaultLabelWithText:@""];
        [self.accuracyLabel setFontName:OpenSansSemibold];
        self.accuracyLabel.textColor = [MONColors boneColor];
        self.accuracyLabel.textAlignment = NSTextAlignmentRight;
        [self addSubview:self.accuracyLabel];
        
        self.moveToCurrentLocationButton = [[UIButton alloc]init];
        [self.moveToCurrentLocationButton setImage:[UIImage imageNamed:@"btn-my-location"] forState:UIControlStateNormal];
        [self.moveToCurrentLocationButton addTarget:self action:@selector(moveToCurrentLocationButtonTapped) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:self.moveToCurrentLocationButton];
        
        self.moveToCoordinatesButton = [[UIButton alloc]init];
        [self.moveToCoordinatesButton setImage:[UIImage imageNamed:@"btn-trial-location"] forState:UIControlStateNormal];
        [self.moveToCoordinatesButton addTarget:self action:@selector(moveToCoordinatesButtonTapped) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:self.moveToCoordinatesButton];
        
		UITapGestureRecognizer *tapRecogonizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(endEditingOnGPSPointsView)];
		[self.mapView addGestureRecognizer:tapRecogonizer];
        
        self.pinImageView = [[UIImageView alloc] initWithImage: [UIImage imageNamed:@"ui-icon-gps-pin-active"]];
        
        UIPanGestureRecognizer* panRecogonizer = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(didPanMap:)];
        panRecogonizer.delegate = self;
        [self.mapView addGestureRecognizer:panRecogonizer];
	}
    return self;
}

- (void)layoutSubviews {
	[super layoutSubviews];
	
	[self.headerView sizeToFit];
	self.headerView.frame = CGRectMake(0.0, 0.0, CGRectGetWidth(self.bounds), CGRectGetHeight(self.headerView.frame));
	
	CGSize plotCoordinatesSize = [self.gpsPointsView sizeThatFits:CGSizeMake(CGRectGetWidth(self.bounds) - 2.0 * MONDimensionsSmallPadding, CGRectGetHeight(self.bounds))];
	self.gpsPointsView.frame = CGRectMake(MONDimensionsSmallPadding,
                                            CGRectGetMaxY(self.headerView.frame) + MONDimensionsSmallPadding,
                                            CGRectGetWidth(self.bounds) - 2.0 * MONDimensionsSmallPadding,
                                            plotCoordinatesSize.height);
    
	self.mapView.frame = CGRectMake(MONDimensionsSmallPadding,
                                            CGRectGetMaxY(self.gpsPointsView.frame) + MONDimensionsSmallPadding,
                                            CGRectGetWidth(self.bounds) - 2.0 * MONDimensionsSmallPadding,
                                            CGRectGetHeight(self.bounds) - CGRectGetMaxY(self.gpsPointsView.frame) - 2.0 * MONDimensionsSmallPadding);
    
    self.latLongLabelBackground.frame = CGRectMake(CGRectGetMinX(self.mapView.frame), CGRectGetMaxY(self.mapView.frame) - GPSLatLongLabelHeight, CGRectGetWidth(self.mapView.frame), GPSLatLongLabelHeight);
    
    [self.latLongLabel sizeToFit];
    self.latLongLabel.frame = CGRectMake(CGRectGetMinX(self.latLongLabelBackground.frame) + MONDimensionsTinyPadding,
                                         CGRectGetMinY(self.latLongLabelBackground.frame) + MONDimensionsMicroPadding,
                                         CGRectGetWidth(self.latLongLabelBackground.frame)/2, CGRectGetHeight(self.latLongLabel.frame));
    
    [self.accuracyLabel sizeToFit];
    self.accuracyLabel.frame = CGRectMake(CGRectGetMaxX(self.latLongLabelBackground.frame)/2,
                                         CGRectGetMinY(self.latLongLabelBackground.frame) + MONDimensionsMicroPadding,
                                         CGRectGetWidth(self.latLongLabelBackground.frame)/2, CGRectGetHeight(self.accuracyLabel.frame));
    
    
    [self.moveToCurrentLocationButton sizeToFit];
    self.moveToCurrentLocationButton.frame = CGRectMake(CGRectGetMinX(self.latLongLabelBackground.frame) + MONDimensionsSmallPadding,
                                                        CGRectGetMinY(self.latLongLabelBackground.frame) - CGRectGetHeight(self.moveToCurrentLocationButton.frame) - MONDimensionsSmallPadding,
                                                        CGRectGetWidth(self.moveToCurrentLocationButton.frame), CGRectGetHeight(self.moveToCurrentLocationButton.frame));
    
    [self.moveToCoordinatesButton sizeToFit];
    self.moveToCoordinatesButton.frame = CGRectMake(CGRectGetMaxX(self.moveToCurrentLocationButton.frame) + MONDimensionsSmallPadding, CGRectGetMinY(self.moveToCurrentLocationButton.frame),
                                                    CGRectGetWidth(self.moveToCoordinatesButton.frame), CGRectGetHeight(self.moveToCoordinatesButton.frame));
}

-(void)setCoordinates:(NSString *)latitude1 longitude1:(NSString*)longitude1
			latitude2:(NSString *)latitude2 longitude2:(NSString*)longitude2
			latitude3:(NSString *)latitude3 longitude3:(NSString*)longitude3
			latitude4:(NSString *)latitude4 longitude4:(NSString*)longitude4 {
	[self.gpsPointsView setCoordinates:latitude1 longitude1:longitude1 latitude2:latitude2 longitude2:longitude2 latitude3:latitude3 longitude3:longitude3 latitude4:latitude4 longitude4:longitude4];
    [self moveToCoordinatesButtonTapped];
}

- (void)moveToCurrentLocationButtonTapped {
    self.zoomToPins = NO;
}

- (void)moveToCoordinatesButtonTapped {
    if (self.coordinatesRect.size.width) {
        [self.mapView setVisibleMapRect:self.coordinatesRect edgePadding:UIEdgeInsetsMake(self.pinImageView.frame.size.height + MONDimensionsMicroPadding, self.pinImageView.frame.size.width/2 + MONDimensionsMicroPadding, GPSLatLongLabelHeight + MONDimensionsMicroPadding, self.pinImageView.frame.size.width/2 + MONDimensionsMicroPadding) animated:YES];
        self.zoomToPins = YES;
    }
}

- (void)didPanMap:(UIGestureRecognizer*)gestureRecognizer {
    if (gestureRecognizer.state == UIGestureRecognizerStateBegan && !self.zoomToPins) {
        self.zoomToPins = YES;
    }
}

- (void)updateZoomRect:(MKMapRect)zoomRect {
    self.coordinatesRect = zoomRect;
}

- (void)startTrackingUserLocation {
    self.mapView.showsUserLocation = YES;
}

- (void)stopTrackingUserLocation {
    self.mapView.showsUserLocation = NO;
}

- (void)zoomToLatitude:(double)latitude longitude:(double)longitude {
    if(latitude != [TMConstants emptyLocation] && longitude != [TMConstants emptyLocation]) {
        if (!self.initialLocationUpdateHappened) {
            self.mapView.region = MKCoordinateRegionMake(CLLocationCoordinate2DMake(latitude, longitude), MKCoordinateSpanMake(0.0001, 0.0001));
            self.initialLocationUpdateHappened = YES;
        } else {
            [self.mapView setCenterCoordinate:CLLocationCoordinate2DMake(latitude, longitude) animated:YES];
        }
    }
}

- (void)setCurrentLatitude:(double)latitude longitude:(double)longitude isAccuracyAcceptable:(BOOL)isAccuracyAcceptable {
    if (!self.zoomToPins) {
        [self zoomToLatitude:latitude longitude:longitude];
    }
    
    self.latLongLabel.text = latitude != [TMConstants emptyLocation] && longitude != [TMConstants emptyLocation] ? [NSString stringWithFormat:@"Current Location: %.7f, %.7f", latitude, longitude] : @"";
    self.accuracyLabel.text = isAccuracyAcceptable ?  @"" : @"Obtaining better accuracy...";
    
    [self setNeedsLayout];
}

- (void)setLatitude:(NSString *)latitude longitude:(NSString *)longitude forLocation:(TMCoordinatesLocation)location {
    [self.gpsPointsView setLatitude:latitude longitude:longitude forLocation:location];
}

- (void) endEditingOnGPSPointsView {
	[self.gpsPointsView endEditing:YES];
}

- (void) removeAnnotation:(id <MKAnnotation>)annotation {
	[self.mapView removeAnnotation:annotation];
}

- (void) addAnnotation:(id <MKAnnotation>)annotation {
	[self.mapView addAnnotation:annotation];
}

- (void)removeOverlay:(id<MKOverlay>)overlay {
	[self.mapView removeOverlay:overlay];
}

- (void)addOverlay:(id<MKOverlay>)overlay {
	[self.mapView addOverlay:overlay];	
}

- (void)deleteButtonTapped {
	UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:nil
															 delegate:self
													cancelButtonTitle:@"Cancel"
											   destructiveButtonTitle:@"Delete All GPS Points"
													otherButtonTitles:nil];
	[actionSheet addButtonWithTitle:@"Cancel"];
	[actionSheet showFromRect:self.deleteButton.frame inView:self.headerView animated:YES];
}


#pragma mark - UIGestureRecognizerDelegate Methods

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer {
    return YES;
}

#pragma mark - UIActionSheetDelegate Methods

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex {
	if (buttonIndex == actionSheet.destructiveButtonIndex) {
		[self.delegate evt_deleteAllGPSPoints];
		[self.gpsPointsView clearAllGPSPoints];
	}
}

#pragma mark - MKMapViewDelegate Methods

- (MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(id <MKAnnotation>)annotation {
    if ([annotation isKindOfClass:[MKUserLocation class]]) {
        return nil;
    }
    
	MKAnnotationView* pinView = (MKAnnotationView*)[mapView dequeueReusableAnnotationViewWithIdentifier:AnnotationReuseIdentifier];
	if (!pinView) {
		pinView = [[MKAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:AnnotationReuseIdentifier];
		pinView.image = [UIImage imageNamed:@"ui-icon-gps-pin-active"];
		pinView.centerOffset = CGPointMake(0, GPSPinVerticalOffset);
		pinView.canShowCallout = YES;
	} else {
		pinView.annotation = annotation;
	}
	return pinView;
}

- (MKOverlayRenderer *)mapView:(MKMapView *)mapView viewForOverlay:(id <MKOverlay>)overlay {
    if ([overlay isKindOfClass:[MKPolygon class]]) {
        MKPolygonRenderer* renderer = [[MKPolygonRenderer alloc] initWithPolygon:(MKPolygon*)overlay];
		renderer.fillColor = [[MONColors belizeHoleColor] colorWithAlphaComponent:0.25];
		renderer.strokeColor = [[MONColors midnightBlueColor] colorWithAlphaComponent:0.8];
		renderer.lineWidth = 2;
	    return renderer;
    }
    return nil;
}

#pragma mark - TMGPSPointsViewDelegate Methods

- (void) evt_updatedLocation:(TMCoordinatesLocation)location latitude:(NSDecimalNumber *)latitude longitude:(NSDecimalNumber *)longitude {
	[self.delegate evt_updatedLocation:location latitude:latitude longitude:longitude];
}

- (void)evt_doneUpdatingValue:(NSString *)value {
    [self.delegate evt_doneUpdatingValue:value];
}

- (void) evt_updateToCurrentLocation:(TMCoordinatesLocation)location {
    [self.delegate evt_updateToCurrentLocation:location];
}

@end
