#import "MONSearchResult.h"
#import "TMDealer.h"
#import "TMCooperatorCategoryEnum.h"

@interface TMCooperatorSearchResult : NSObject <MONSearchResult>

- (instancetype)initWithCooperator:(NSManagedObject *)cooperator cooperatorCategory:(CooperatorCategory)cooperatorCategory;

@property(nonatomic, readonly) NSString *cooperator;
@property(nonatomic, readonly) NSString *country;
@property(nonatomic, readonly) NSString *state;
@property(nonatomic, readonly) NSString *city;
@property(nonatomic, readonly) NSString *postalCode;

@end
