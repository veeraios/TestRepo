//
//  TMDealerModel.swift
//  TrialManagement
//
//  Created by GADIRAJU, PRANEETH [AG/1000] on 5/1/15.
//  Copyright (c) 2015 Monsanto. All rights reserved.
//

class TMDealerModel : NSObject, TMCooperatorModel {
    private let dealer: TMDealer
    
    override init() {
        dealer = TMWorkingUnitOfWork.sharedInstance().workingContext.attachObject(TMDealer) as TMDealer
        dealer.dealerId = nil
        dealer.country = "USA"
        dealer.category = "Dealer"
    }
    
    init(dealer: TMDealer) {
        self.dealer = dealer
    }
    
    convenience init(_ dealer: TMDealer) {
        self.init(dealer: dealer)
    }
    
    func hasRequiredInformation() -> Bool {
        return !name.isEmpty
    }
    
    func isNew() -> Bool {
        return dealer.trials.count == 0
    }
    
    func cooperator() -> NSManagedObject {
        return dealer
    }
    
    func title() -> String {
        return "Dealer"
    }
    
    var name:String {
        get { return MONSafeString.safeStringForString(dealer.name) }
        set (dealerName) {
            dealer.name = dealerName
            TMWorkingUnitOfWork.sharedInstance().saveChanges()
        }
    }
    
    var accountId:String {
        get { return MONSafeString.safeStringForString(dealer.accountId) }
        set (dealerAccountId) {
            dealer.accountId = dealerAccountId
            TMWorkingUnitOfWork.sharedInstance().saveChanges()
        }
    }
    
    var email:String {
        get { return MONSafeString.safeStringForString(dealer.email) }
        set (dealerEmail) {
            dealer.email = dealerEmail
            TMWorkingUnitOfWork.sharedInstance().saveChanges()
        }
    }
    
    var phone:String {
        get { return MONSafeString.safeStringForString(dealer.phoneNumber) }
        set (dealerPhone) {
            dealer.phoneNumber = dealerPhone
            TMWorkingUnitOfWork.sharedInstance().saveChanges()
        }
    }
    
    var address1:String {
        get { return MONSafeString.safeStringForString(dealer.address1) }
        set (dealerAddress1) {
            dealer.address1 = dealerAddress1
            TMWorkingUnitOfWork.sharedInstance().saveChanges()
        }
    }
    
    var address2:String {
        get { return MONSafeString.safeStringForString(dealer.address2) }
        set (dealerAddress2) {
            dealer.address2 = dealerAddress2
            TMWorkingUnitOfWork.sharedInstance().saveChanges()
        }
    }
    
    var city:String {
        get { return MONSafeString.safeStringForString(dealer.city) }
        set (dealerCity) {
            dealer.city = dealerCity
            TMWorkingUnitOfWork.sharedInstance().saveChanges()
        }
    }
    
    var state:String {
        get { return MONSafeString.safeStringForString(dealer.state) }
        set (dealerState) {
            dealer.state = dealerState
            TMWorkingUnitOfWork.sharedInstance().saveChanges()
        }
    }
    
    var postalCode:String {
        get { return MONSafeString.safeStringForString(dealer.postalCode) }
        set (dealerPostalCode) {
            dealer.postalCode = dealerPostalCode
            TMWorkingUnitOfWork.sharedInstance().saveChanges()
        }
    }
}
