#import <ESCObservable/ESCObservable.h>
#import <UIKit/UIKit.h>

@protocol TMCameraControlsViewObserver <NSObject>

- (void)cameraControlsTakePhotoButtonTapped;
- (void)cameraControlsShowPhotoLibraryButtonTapped;
- (void)cameraControlsCancelButtonTapped;

@end

@interface TMCameraControlsView : UIView<ESCObservable>

@end
