#import "MONPlaceholderControl.h"
#import "MONLabel.h"
#import "MONUIConvenienceFunctions.h"
#import "MONDimensions.h"
#import "MONFonts.h"
#import "UIColor+MONThemeColorProvider.h"

@interface MONPlaceholderControl ()

@property (nonatomic) UIImage *image;
@property (nonatomic) NSString *text;
@property (nonatomic) UIImageView *imageView;
@property (nonatomic) MONLabel *textLabel;

@end

@implementation MONPlaceholderControl

- (id)initWithFrame:(CGRect)frame {
	self = [super initWithFrame:frame];
	if (self) {
		self.backgroundColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeBackground];

		self.imageView = [[UIImageView alloc] init];
		[self addSubview:self.imageView];
		
		self.textLabel = [[MONLabel alloc] init];
		self.textLabel.font = [UIFont fontWithName:OpenSansSemibold size:17.0];
		[self addSubview:self.textLabel];
	}
	return self;
}

- (void)layoutSubviews {
	[super layoutSubviews];
	
	[self.imageView sizeToFit];
	[self.textLabel sizeToFit];
	
	CGFloat totalHeight = CGRectGetHeight(self.imageView.frame) + CGRectGetHeight(self.textLabel.frame) + MONDimensionsLargePadding;

	self.imageView.frame = CGRectMake(MONUIScreenRoundToScreenScale((CGRectGetMaxX(self.bounds) - CGRectGetWidth(self.imageView.frame)) / 2.0),
									  MONUIScreenRoundToScreenScale((CGRectGetMaxY(self.bounds) - totalHeight) / 2.0),
									  CGRectGetWidth(self.imageView.frame),
									  CGRectGetHeight(self.imageView.frame));
	
	self.textLabel.frame = CGRectMake(MONUIScreenRoundToScreenScale((CGRectGetMaxX(self.bounds) - CGRectGetWidth(self.textLabel.frame)) / 2.0),
									  CGRectGetMaxY(self.imageView.frame) + MONDimensionsLargePadding,
									  CGRectGetWidth(self.textLabel.frame),
									  CGRectGetHeight(self.textLabel.frame));
}

- (void)setImage:(UIImage *)image {
	self.imageView.image = image;
}

- (void)setText:(NSString *)text {
	self.textLabel.text = text;
}

@end
