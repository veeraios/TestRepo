@interface NSObject (TMNullHelper)
-(id)safeObject;
@end
