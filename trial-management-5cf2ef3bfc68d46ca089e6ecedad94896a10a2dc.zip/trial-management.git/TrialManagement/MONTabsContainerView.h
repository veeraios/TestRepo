#import <UIKit/UIKit.h>

@protocol MONTabsContainerViewDelegate <NSObject>

- (void)tabTappedAtIndex:(NSUInteger)index;

@end

@interface MONTabsContainerView : UIView

@property (nonatomic, weak) id<MONTabsContainerViewDelegate> delegate;

- (instancetype)initWithTabModels:(NSArray *)tabModels;
- (void)setSelectedTabAtIndex:(NSUInteger)index;

@end
