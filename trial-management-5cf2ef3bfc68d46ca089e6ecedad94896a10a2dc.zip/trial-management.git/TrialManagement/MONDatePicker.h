#import <UIKit/UIKit.h>

@class MONDatePicker;
@protocol MONDatePickerDelegate

- (void)datePickerChanged:(MONDatePicker *)datePicker newDate:(NSDate *)newDate;

@end

@interface MONDatePicker : UIDatePicker

@property (nonatomic, weak) id <MONDatePickerDelegate> delegate;

@end
