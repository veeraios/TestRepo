#import "MONPopoverButton.h"
#import "MONPopoverTableViewController.h"

const CGFloat PopupItemHeight = 55.0f;
const CGFloat PopupItemWidth = 420.0f;

@interface MONPopoverButton()<UIPopoverControllerDelegate, MONPopoverTableViewControllerObserver>
@property (nonatomic) UIPopoverController *cellPopoverController;
@property (nonatomic) NSString *popoverListTitle;
@end
@implementation MONPopoverButton

- (instancetype)initWithPopoverTitle:(NSString*)title model:(id<TMReferenceListDataModel>)model buttonText:(NSString*)buttonText {
	self = [self initWithPopoverTitle:title model:model buttonImage:nil];
	[self setTitle:buttonText forState:UIControlStateNormal];
	return self;
}

- (instancetype)initWithPopoverTitle:(NSString*)title model:(id<TMReferenceListDataModel>)model buttonImage:(UIImage*)buttonImage  {
	self = [self initWithModel:model buttonImage:buttonImage];
	self.popoverListTitle = title;
	return self;
}

- (instancetype)initWithModel:(id<TMReferenceListDataModel>)model buttonImage:(UIImage*)buttonImage {
    self = [super init];
    if (self) {
		if(buttonImage) {
			[self setImage:buttonImage forState:UIControlStateNormal];
		}
//		self.backgroundColor = [UIColor clearColor];
//		self.layer.cornerRadius = 2.0;
		self.model = model;
		[self addTarget:self action:@selector(wasTapped) forControlEvents:UIControlEventTouchUpInside];
	}
    return self;
}

- (void)wasTapped {
	[self resignFirstResponder];
	MONPopoverTableViewController * tableViewController;
	BOOL hasTitle = NO;
	if([self.popoverListTitle length] != 0) {
		hasTitle = YES;
		tableViewController = [[MONPopoverTableViewController alloc] initWithTitle:self.popoverListTitle model:self.model];
	} else {
		tableViewController = [[MONPopoverTableViewController alloc] initWithModel:self.model];
	}
	[tableViewController escAddObserver:self];
	
	self.cellPopoverController = [[UIPopoverController alloc] initWithContentViewController:tableViewController];
	self.cellPopoverController.delegate = self;
	[self.cellPopoverController setPopoverContentSize:CGSizeMake(PopupItemWidth, PopupItemHeight * ([self.model numberOfItems] +(hasTitle ? 1:0))+ (hasTitle ? 70:0))];
	self.cellPopoverController.popoverLayoutMargins = UIEdgeInsetsMake(0, 0, 0, (PopupItemWidth/3.0) + 10.0);
	[self.cellPopoverController presentPopoverFromRect:self.bounds inView:self permittedArrowDirections:UIPopoverArrowDirectionUp animated:YES];
}

- (void)didSelectRowIndex:(NSInteger)rowIndex{
	[self.cellPopoverController dismissPopoverAnimated:YES];
	[self.popoverDelegate valueWasSelected:self selectedValue:[self.model nameForItemAtIndex:rowIndex] selectedIndex:rowIndex];
}
@end