#import "MONItemCountView.h"
#import "MONLabel.h"
#import "MONFonts.h"
#import "UIColor+MONThemeColorProvider.h"

static const CGFloat DefaultCornerRadius = 4.0;
static const CGFloat DefaultHeight = 20.0;
static const CGFloat DefaultHorizontalContentPadding = 10.0;

@interface MONItemCountView ()

@property (nonatomic) MONLabel *numberOfItemsLabel;

@end

@implementation MONItemCountView

- (id)initWithFrame:(CGRect)frame {
	self = [super initWithFrame:frame];
	if (self) {
		self.backgroundColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeButtonBackground];
		self.layer.cornerRadius = DefaultCornerRadius;
		
		self.numberOfItemsLabel = [[MONLabel alloc] init];
		self.numberOfItemsLabel.textColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeSelectedText];
		self.numberOfItemsLabel.font = [UIFont fontWithName:OpenSansBold size:self.numberOfItemsLabel.textSize];
		self.numberOfItemsLabel.textAlignment = NSTextAlignmentCenter;
		self.numberOfItemsLabel.text = @"0";
		[self addSubview:self.numberOfItemsLabel];
	}
	return self;
}

- (void)layoutSubviews {
	[super layoutSubviews];
	self.numberOfItemsLabel.frame = self.bounds;
}

- (void)setNumberOfItems:(NSUInteger)numberOfItems {
	self.numberOfItemsLabel.text = [NSString stringWithFormat:@"%ld", (long)numberOfItems];
	[self setNeedsLayout];
}

- (void)setAlertColor {
    self.backgroundColor = [UIColor colorForThemeComponentType:MONThemeComponentTypeHighlight];
    [self setNeedsLayout];
}

- (CGSize)sizeThatFits:(CGSize)size {
	CGSize sizeThatFits = CGSizeZero;
	[self.numberOfItemsLabel sizeToFit];
	
	sizeThatFits.width += CGRectGetWidth(self.numberOfItemsLabel.frame);
	sizeThatFits.width += 2.0 * DefaultHorizontalContentPadding;
	
	sizeThatFits.height += DefaultHeight;
	
	return sizeThatFits;
}

@end
