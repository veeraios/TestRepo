#import "TMEditTrialValueUOMViewController.h"
#import "TMEditTrialValueUOMView.h"

@interface TMEditTrialValueUOMViewController()<TMEditTrialValueUOMViewDelegate>

@property (nonatomic) TMEditTrialValueUOMView *modalView;
@property (nonatomic) NSNumber *value;
@property (nonatomic) NSArray *unitOfMeasures;
@property (nonatomic) NSString *selectedUnitOfMeasure;

@end

@implementation TMEditTrialValueUOMViewController

- (instancetype)initWithTitle:(NSString *)title 
			   unitOfMeasures:(NSArray *)unitOfMeasures 
						value:(NSNumber *)value 
		selectedUnitOfMeasure:(NSString *)selectedUnitOfMeasure {
	self = [super init];
	if (self) {
		self.title = title;
		self.unitOfMeasures = unitOfMeasures;
		self.value = value;
		self.selectedUnitOfMeasure = selectedUnitOfMeasure;
	}
	return self;
}

- (void)viewDidLoad {
	[super viewDidLoad];
	self.modalView = [[TMEditTrialValueUOMView alloc] initWithTitle:self.title 
														 unitOfMeasures:self.unitOfMeasures 
																  value:[self.value doubleValue]
												  selectedUnitOfMeasure:self.selectedUnitOfMeasure];
	self.modalView.delegate = self;
	self.modalView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
	[self.view addSubview:self.modalView];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    self.modalView.frame = self.view.bounds;
}

- (void)viewDidAppear:(BOOL)animated {
	[super viewDidAppear:animated];
	[self.modalView becomeFirstResponder];
}

#pragma mark - TMEditTrialPlantingRateViewDelegate Methods

- (void) evt_value:(NSString *)value selectedUnitOfMeasure:(NSString *)unitOfMeasure {
	self.value = [value length] == 0.0 ? nil : [NSNumber numberWithDouble:[value doubleValue]];
	self.selectedUnitOfMeasure = unitOfMeasure;
}

@end
