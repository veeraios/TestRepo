#import "TMTechAgronomist.h"
#import "MONRepository.h"
#import "TMDataSyncProtocol.h"

@protocol TMBrandRepositoryProtocol <NSObject, MONRepositoryProtocol>

- (TMBrand *)createBrandWithBrandId:(NSNumber *)brandId brandName:(NSString *)brandName;
- (TMBrand *)brandForBrandId:(NSNumber *)brandId;
- (TMBrand *)brandForBrandName:(NSString *)brandName;
- (NSArray *)validBrandsSortedByName;

@end

@interface TMBrandRepository :  MONRepository<TMBrandRepositoryProtocol, TMDataSyncProtocol>
@end
