//
//  TMAuthority.m
//  TrialManagement
//
//  Created by Jason Ludwig on 6/17/14.
//  Copyright (c) 2014 Monsanto. All rights reserved.
//

#import "TMAuthority.h"


@implementation TMAuthority

@dynamic authority;
@dynamic users;

@end
