#import <Foundation/Foundation.h>
#import "MONHeaderViewProtocol.h"

@protocol MONHeaderViewAlertProtocol <NSObject,MONHeaderViewProtocol>
- (void)setAlertColorForItemCount;
@end
