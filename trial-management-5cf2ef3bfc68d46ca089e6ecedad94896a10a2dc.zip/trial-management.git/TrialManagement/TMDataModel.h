@protocol TMDataModel <NSObject>

@end
