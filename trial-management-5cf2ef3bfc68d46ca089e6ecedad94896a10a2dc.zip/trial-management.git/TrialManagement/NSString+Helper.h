#import <Foundation/Foundation.h>

@interface NSString (Helper)
-(NSString*)safeString;
-(BOOL)contains:(NSString*)searchString;
@end
