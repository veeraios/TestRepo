@import CoreData;
#import "MONContextProtocol.h"

@protocol TMBackupCoreDataContextProtocol<MONContextProtocol>
- (void) cloneTrial:(TMTrial *)trial;
- (void) deleteTrial:(TMTrial *)trial;
@end