#import "TMReferenceDataListGenericModel.h"
#import "TMReferenceDataFilterListModel.h"

@interface TMBrandModel : TMReferenceDataListGenericModel<TMReferenceDataFilterListModel>
-(instancetype)initWithDataSource:(NSArray*)dataSource;
@end
