#import "MONHeaderViewProtocol.h"
@interface MONSearchHeaderView : UIView<MONHeaderViewProtocol>

@end
