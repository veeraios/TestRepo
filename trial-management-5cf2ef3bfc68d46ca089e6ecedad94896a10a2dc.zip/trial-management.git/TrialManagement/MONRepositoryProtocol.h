#import "MONPersistenceBlocks.h"
#import "TMUser.h"
#import "MONContextProtocol.h"

@protocol MONRepositoryProtocol
@required
- (id<MONContextProtocol>)context;
- (id)create;
- (NSArray *)getAll;
- (void)remove:(id)object;
- (void)removeObjects:(NSArray*)objects;
- (NSArray *)find:(NSString *)where;
- (NSArray *)find:(NSString *)where take:(int)countItem;
- (NSArray *)find:(NSString *)where orderBy:(NSString *)orderByAttribute ascending:(BOOL)ascending;
- (NSArray *)find:(NSString *)where orderBy:(NSString *)orderByAttribute ascending:(BOOL)ascending take:(int)countItem;
- (NSArray *)findWithPredicate:(NSPredicate *)wherePredicate orderBy:(NSString *)orderByAttribute ascending:(BOOL)ascending;
- (BOOL)exists:(NSString *)where;
- (NSArray *)find:(NSString *)where propertyToFetch:(NSArray *)propertyToFetch;
- (NSArray *)findWithPredicate:(NSPredicate *)wherePredicate propertyToFetch:(NSArray *)propertyToFetch;
- (NSArray *)findWithPredicate:(NSPredicate *)wherePredicate prefechedProperties:(NSArray*)prefechedProperties prefetchedRelationships:(NSArray*)prefetchedRelationships;
- (NSArray *)findWithPredicate:(NSPredicate *)wherePredicate;
- (void)import:(NSArray *)dataFromService dataServicePrimaryKey:(NSString *)dataServicePrimaryKey databasePrimaryKey:(NSString *)databasePrimaryKey dataImportBlock:(MONDataImportBlock)dataImportBlock currentUser:(TMUser *)currentUser completionBlock:(MONDataImportCompletionBlock)completionBlock;
- (void)import:(NSArray *)dataFromService dataServicePrimaryKey:(NSString *)dataServicePrimaryKey databasePrimaryKey:(NSString *)databasePrimaryKey dataImportBlock:(MONDataImportBlock)dataImportBlock currentUser:(TMUser *)currentUser idsOfObjectsToSkip:(NSSet *)idsOfObjectsToSkip completionBlock:(MONDataImportCompletionBlock)completionBlock;
- (void)importFromDictionary:(NSDictionary *)dataFromService dataServicePrimaryKey:(NSString*)dataServicePrimaryKey databasePrimaryKey:(NSString*)databasePrimaryKey dataImportBlock:(MONDataImportBlock) dataImportBlock currentUser:(TMUser *)currentUser completionBlock:(MONDataImportCompletionBlock)completionBlock;
- (void)import:(NSArray *)dataFromService dataServicePrimaryKey:(NSString *)dataServicePrimaryKey databasePrimaryKey:(NSString *)databasePrimaryKey dataStringImportBlock:(MONDataStringImportBlock)dataStringImportBlock currentUser:(TMUser *)currentUser completionBlock:(MONDataImportCompletionBlock)completionBlock;
- (void)import:(NSArray *)dataFromService dataServicePrimaryKey:(NSString *)dataServicePrimaryKey databasePrimaryKey:(NSString *)databasePrimaryKey dataImportBlock:(MONDataImportBlock) dataImportBlock completionBlock:(MONDataImportCompletionBlock)completionBlock;
- (id)createChild:(Class)theClass;
- (NSArray *)findWithPredicate:(NSPredicate *)wherePredicate classToFind:(Class)classToFind;
- (id)findOrCreate:(Class)theClass key:(NSString*)key value:(id)value isChild:(BOOL)isChild;
- (TMUser *)currentUser;
- (NSArray *)sortedEntitiesForUserBy:(NSString *)propertyToSortBy;
- (NSArray *)sortedEntitiesForUserByName;
- (NSArray *)getAll:(Class)theClass;
- (NSArray*)sortedEntitiesByName;
//TODO: move to category
- (NSDictionary *)mappedDictionaryFromContext:(NSArray *)array key:(id)key;
- (id)find:(Class)theClass key:(NSString *)key value:(id)value;
- (id)findWithoutUser:(Class)theClass key:(NSString *)key value:(id)value;
- (id)findOrNilWithoutUser:(Class)theClass key:(NSString*)key value:(id)value;
- (NSArray *)sortedEntitiesForUserByKey:(NSString *)key;
- (void)saveContext;
- (NSManagedObject *)objectForId:(NSManagedObjectID *)objectId;
-(void)import:(NSArray *)dataFromService dataFindBlock:(MONDataFindBlock)dataFindBlock dataImportBlock:(MONDataImportBlock) dataImportBlock currentUser:(TMUser*)currentUser completionBlock:(MONDataImportCompletionBlock)completionBlock afterImportBlock:(MONDataImportCompletionBlock)afterImportBlock;
- (void)removeAll;
- (void)importAndRemovePrevious:(NSArray *)dataFromService dataImportBlock:(MONDataImportBlock) dataImportBlock completionBlock:(MONDataImportCompletionBlock)completionBlock;
- (void)removeAll:(Class)classToUse;
- (id)findOrNil:(Class)theClass key:(NSString*)key value:(id)value;
- (id)objectForUniqueIdentifier:(id)object;
- (NSManagedObject*)findOrCreate:(Class)classToFind dictionaryOfKeyValues:(NSDictionary*)keyValueDictionary isChild:(BOOL)isChild;
- (NSManagedObject*)find:(Class)classToFind dictionaryOfKeyValues:(NSDictionary*)keyValueDictionary;
- (void)removeEntities:(Class)theClass where:(NSPredicate*)predicate;
- (NSManagedObject*)findOrNil:(Class)classToFind dictionaryOfKeyValues:(NSDictionary*)keyValueDictionary;
- (NSArray *)getAll:(Class)theClass prefechedProperties:(NSArray*)prefechedProperties prefetchedRelationships:(NSArray*)prefetchedRelationships;
- (NSManagedObject*)findWithoutUser:(Class)classToFind dictionaryOfKeyValues:(NSDictionary*)keyValueDictionary;
@end

